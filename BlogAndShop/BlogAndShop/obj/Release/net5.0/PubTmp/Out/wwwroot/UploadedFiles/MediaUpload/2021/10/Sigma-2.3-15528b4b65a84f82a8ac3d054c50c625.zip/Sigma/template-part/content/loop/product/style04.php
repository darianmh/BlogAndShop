<li class="filedemo_gird_products_warp sigma-wc-product product filedemo_gird_products_archive">
    <div class="sigma-wc-product-inner fss_card_products darkeble">
        <div class="fss_card_products_photo">

            <?php global $sigma;
            if ($sigma['show_qviews_product_loop_v4'] == 'enable') {
                ?>
                <div class="sigma-wc-product-popop">
                    <a class="sigma-wc-product-popop--link"
                       href="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                </div>
            <?php } ?>
        
            <?php if ($sigma['show_img_product_loop_v4'] == 'enable') { ?>
                <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail('blog'); ?></a>
            <?php } ?>

            <?php if ($sigma['show_discount_product_loop_v4'] == 'enable') { ?>
                <div class="sigma-wc-products-badge">
                    <?php woocommerce_show_product_loop_sale_flash(); ?>
                </div>
            <?php } ?>

        </div>
        <div class="row">


            <div class="col-9">
                <div class="fss_card_products_price">
                    <ul>

                        <?php if ($sigma['show_price_product_loop_v4'] == 'enable') { ?>
                            <li>
                                <?php echo woocommerce_template_single_price(); ?>
                            </li>
                        <?php } ?>

                        <?php if ($sigma['show_cat_product_loop_v4'] == 'enable') { ?>
                            <?php
                            $terms = get_the_terms(get_the_ID(), 'product_cat');
                            $terms_count = count($terms);

                            if ($terms_count > 0) {
                                foreach ($terms as $key => $term) {
                                    $sperator = $key !== ($terms_count - 1) ? ' , ' : '';
                                    echo "<li><a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a></li>";
                                }
                            }
                            ?>
                        <?php } ?>

                    </ul>
                </div>
            </div>

            <?php if ($sigma['show_sale_product_loop_v4'] == 'enable') { ?>
                <div class="npr npl col-3">
                    <div class="fss_card_products_sale">
                        <i class="fal fa-shopping-basket"></i>
                        <?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?>
                    </div>
                </div>
            <?php } ?>

        </div>
        <div class="fss_card_products_seo">

            <a href="<?php the_permalink(); ?>">

                <?php if ($sigma['show_title_product_loop_v4'] == 'enable') { ?>
                    <h2><?php the_title(); ?></h2>
                <?php } ?>

                <?php if ($sigma['show_en_title_product_loop_v4'] == 'enable') { ?>
                    <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>
                <?php } ?>

            </a>

            <?php if ($sigma['show_desc_product_loop_v4'] == 'enable') { ?>
                <p><?php echo wp_trim_words(get_the_content(), 40, '...'); ?> </p>
            <?php } ?>

        </div>

        <?php if ($sigma['show_vendor_product_loop_v4'] == 'enable') { ?>
            <div class="fss_card_products_seller">
                <i class="fal fa-store"></i>
                <h3><?php $user_author = get_the_author_meta('display_name');
                    echo $user_author ?></h3>
                <span><?php echo author_description(get_the_author_meta('description'), 7); ?></span>
            </div>
        <?php } ?>

        <?php if ($sigma['show_cart_product_loop_v4'] == 'enable') { ?>
            <div class="fss_card_products_buy">
                <?php
                global $product;
                if ('' === $product->get_price() || 0 == $product->get_price()) {
                    $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-file"></i>' . __('Free Download', 'sigma-theme') . '</a>';
                } else {
                    $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-shopping-bag"></i>' . __('Buy Product', 'sigma-theme') . '</a>';
                }
                echo $price;
                ?>
            </div>
        <?php } ?>

    </div>
</li>