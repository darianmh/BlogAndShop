<?php
namespace Elementor;

class Main_Price_Table extends Widget_Base {
	
	public function get_name() {
		return 'price-table-sigma';
	}
	
	public function get_title() {
		return __( 'Price Table', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-table';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
    
	protected function _register_controls() {
        
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Price Table', 'sigma-theme' ),
			]
		);

		$this->add_responsive_control(
			'price_table_cols',
			[
				'label'          => esc_html__( 'Price Table Columns', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
                'default' => '4',
			]
		);		
		
		$this->add_control(
			'list_table_price',
			[
				'label' => __( 'Lists Table Price', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
				    [
				        'name' => 'popular_switcher',
        				'label'   => esc_html__( 'Popular Plan?', 'sigma-theme' ),
        				'type'    => Controls_Manager::SWITCHER,
        				'default' => 'no',
	                ],
					[
						'name' => 'popular_badge_text',
						'label' => __( 'Popular Badge Bext', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Popular Badge Bext Enter', 'sigma-theme' ),
						'default' => __( 'Popular', 'sigma-theme' ),
						'condition' => [ 'popular_switcher' => 'yes', ],
					],	                
					[
						'name' => 'title',
						'label' => __( 'Plan Title', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Title Plan Enter', 'sigma-theme' ),
						'default' => __( 'Golden Packege', 'sigma-theme' ),
					],
					[
						'name' => 'subtitle',
						'label' => __( 'Plan Subtitle', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Subtitle Plan Enter', 'sigma-theme' ),
						'default' => __( 'For Small Business', 'sigma-theme' ),
					],
					[
						'name' => 'price',
						'label' => __( 'Plan Price', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Price Plan Enter', 'sigma-theme' ),
						'default' => __( '99', 'sigma-theme' ),
					],	
					[
						'name' => 'currency',
						'label' => __( 'Plan Currency', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Plan Currency Enter', 'sigma-theme' ),
						'default' => __( 'Toman', 'sigma-theme' ),
					],		
					[
						'name' => 'time',
						'label' => __( 'Plan Time', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Plan Time Enter', 'sigma-theme' ),
						'default' => __( 'Yearly', 'sigma-theme' ),
					],						
					[
						'name' => 'description',
						'label' => __( 'Plan Description', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::WYSIWYG,
						'placeholder' => __( 'Description Plan Enter', 'sigma-theme' ),
						'default' => __('<div class="table__features-list"> <ul> <li><i class="fa fa-check-circle"></i>Free Domain</li> <li><i class="fa fa-check-circle"></i>6 months free support</li> <li><i class="fa fa-check-circle"></i>Free phone support</li> <li><i class="fa fa-check-circle"></i>24-hour support</li> <li><i class="fa fa-check-circle"></i>Use 1 site</li> </ul> </div>', 'sigma-theme' ),
					],
					[
						'name' => 'btn_link',
						'label' => __( 'Button Link', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => get_site_url() . '/shop',
        				'default' => [
        					'url' => get_site_url() . '/shop',
        				]						
					],					
					[
						'name' => 'btn_text',
						'label' => __( 'Button Text', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Button Text Enter', 'sigma-theme' ),
						'default' => __( 'Buy This Plan', 'sigma-theme' ),
					],		
					[
						'name' => 'note_plan',
						'label' => __( 'Plan Note', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Plan Note Enter', 'sigma-theme' ),
						'default' => __( 'This Plan Includes Free Updates.', 'sigma-theme' ),
					],						
				],
				'default' => [
					[
						'title' => __( 'Golden Packege', 'sigma-theme' ),
						'subtitle' => __( 'For Small Business', 'sigma-theme' ),
						'price' => '99',
						'currency' => __( 'Toman', 'sigma-theme' ),
						'time' => __( 'Yearly', 'sigma-theme' ),
						'description' => __('<div class="table__features-list"> <ul> <li><i class="fa fa-check-circle"></i>Free Domain</li> <li><i class="fa fa-check-circle"></i>6 months free support</li> <li><i class="fa fa-check-circle"></i>Free phone support</li> <li><i class="fa fa-check-circle"></i>24-hour support</li> <li><i class="fa fa-check-circle"></i>Use 1 site</li> </ul> </div>', 'sigma-theme' ),
						'btn_link' => get_site_url() . '/shop',
						'btn_text' => __( 'Buy This Plan', 'sigma-theme' ),
						'note_plan' => __( 'This Plan Includes Free Updates.', 'sigma-theme' ),
					],
					[
						'title' => __( 'Golden Packege', 'sigma-theme' ),
						'subtitle' => __( 'For Small Business', 'sigma-theme' ),
						'price' => '99',
						'currency' => __( 'Toman', 'sigma-theme' ),
						'time' => __( 'Yearly', 'sigma-theme' ),
						'description' => __('<div class="table__features-list"> <ul> <li><i class="fa fa-check-circle"></i>Free Domain</li> <li><i class="fa fa-check-circle"></i>6 months free support</li> <li><i class="fa fa-check-circle"></i>Free phone support</li> <li><i class="fa fa-check-circle"></i>24-hour support</li> <li><i class="fa fa-check-circle"></i>Use 1 site</li> </ul> </div>', 'sigma-theme' ),
						'btn_link' => get_site_url() . '/shop',
						'btn_text' => __( 'Buy This Plan', 'sigma-theme' ),
						'note_plan' => __( 'This Plan Includes Free Updates.', 'sigma-theme' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);


		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Price Table', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_table__head',
        		'label' => _x( 'Table Header Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .table__head',
        	]
        );
    
        $this->add_control(
        	'dgs_color_table__head_p',
        	[
        		'label' => __( 'Table Header Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .table__head p' => 'color: {{VALUE}}',
        		],		
        	]
        );
        
        $this->add_control(
        	'dgs_color_table_head_span',
        	[
        		'label' => __( 'Table Header SubTitle Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .table__head span' => 'color: {{VALUE}}',
        		],		
        	]
        );
        
        $this->add_control(
            'dgs_price_color',
        	[
        		'label' => __( 'Price Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .table__price p' => 'color: {{VALUE}}',
        		],		
        	]
        );

        $this->add_control(
            'dgs_time_color',
        	[
        		'label' => __( 'Time Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} span.time__table' => 'color: {{VALUE}}',
        		],		
        	]
        );     

        $this->add_control(
            'dgs_currency_color',
        	[
        		'label' => __( 'Currency Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} span.currency_table' => 'color: {{VALUE}}',
        		],		
        	]
        );    
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_table_body',
        		'label' => _x( 'Table Body Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .table__price',
        	]
        );

        $this->add_control(
        	'dgs_table_price_popular_bg',
        	[
        		'label' => __( 'Popular Table Badge Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .price-table__ribbon-inner' => 'color: {{VALUE}}',
        		],		
        	]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'dgs_table_price_popular_bg',
        		'label' => __( 'Popular Table Badge Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .price-table__ribbon-inner',
			]
		);
		
        $this->add_control(
        	'dgs_color_table_price_features_list',
        	[
        		'label' => __( 'Features List Table Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .table__features-list ul li' => 'color: {{VALUE}}',
        		],		
        	]
        );

        $this->add_control(
        	'dgs_icon_color_table_price_features_list',
        	[
        		'label' => __( 'Features List Table Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#8781bd',
        		'selectors' => [
        			'{{WRAPPER}} .table__features-list ul li i' => 'color: {{VALUE}}',
        		],		
        	]
        );    
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_table_button',
        		'label' => _x( 'Table Button Background Color ', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .table__price a',
        	]
        );
        
        $this->add_control(
        	'dgs_color_table_price_a',
        	[
        		'label' => __( 'Table Button Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .table__price a' => 'color: {{VALUE}}',
        		],		
        	]
        );

        $this->add_control(
        	'dgs_note_plan_color',
        	[
        		'label' => __( 'Table Price Note Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} p.plan_text' => 'color: {{VALUE}}',
        		],		
        	]
        );            
		$this->end_controls_section();
	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="price__table__hv3__body columns-<?php echo $settings['price_table_cols']; ?>">
		<?php foreach ( $settings['list_table_price'] as $index => $item ) : 
            echo'<div class="table-price popular-'.$item['popular_switcher'].'">';
            if($item['popular_switcher'] == 'yes' ){  
            echo'<div class="price-table__ribbon-inner">'.$item['popular_badge_text'].'</div>';
            }    
            echo'<div class="table__head darkeble">
                <p>'.$item['title'].'</p>
                <span>'.$item['subtitle'].'</span>
            </div>
            <div class="table__price darkeble">
                <p>'.$item['price'].'</p>
                <span class="currency_table">'.$item['currency'].'</span>
                <span class="time__table">'.$item['time'].'</span>
                '.$item['description'].'
                <a href="'.$item['btn_link']['url'].'">'.$item['btn_text'].'</a>
                <p class="plan_text">'.$item['note_plan'].'</p>
            </div>
        </div>'; ?>
		<?php endforeach; ?>
		</div>
		<?php
	}
}
