<?php get_header(); ?>


			
<div class="container">
<div class="content">
<div class="single-page">
	
	<div class="single-head">
		<h2><?php printf( esc_html__( 'نتیجه جستجو برای : %s', stackstar ), '<span>' . get_search_query() . '</span>' ); ?></h2>
		
	</div>
	

	

<div class="content-post">

    

    

<div class="row">
<div class="card-group col-lg-12 col-sx-12">
		<?php $query = new WP_Query(); ?>

							<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

							<?php

							$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'posts' );

							$url = $thumb['0'];

							?>


    <div class="card">
    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('product'); ?></a> 
    <div class="card-body-search">
     <a href="<?php  the_permalink(); ?>">   
<h2 class="card-title-search">
<?php the_title(); ?></h2></a>  
    <span class="date">
	<i class="fa fa-calendar" aria-hidden="true"></i>تاریخ انتشار <?php the_date('y/m/d'); ?>  <?php the_time('ساعت:g:i '); ?>
    </span>
    </div>
    </div>

						<?php endwhile; ?>


							<?php wp_reset_postdata(); ?>

							<?php else : ?>

							<p class="no-req col-xs-12"><?php _e( 'متأسفانه موردي يافت نشد.' ); ?></p>

							<?php endif; ?>



</div>
</div>
</div>


		
		
		</div>


</div>


</div>

<?php get_footer();?>
</body>
<style>
.card-body-search {
    padding: 10px 10px;
}
.card {
    width: 22.2%;
    margin: 20px 25px 20px 0;
    box-shadow: none !important;
    border: 1px solid #f3f3f3;
}
</style>
</html>
