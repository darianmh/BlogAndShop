<?php
namespace Elementor;

class Post_Title extends Widget_Base {
	
	public function get_name() {
		return 'post-title';
	}
	
	public function get_title() {
		return __( 'Single Title', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-post-title';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_title_style',
        	[
				'label' => __( 'Single Title Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
		$this->add_control(
			'sgm_title_alignment',
			[
				'label' => __( 'Alignment', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} h1.entry-title' => 'text-align: {{VALUE}};'
                ],				
			]
		);

		$this->add_control(
			'sgm_title_title_color',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} h1.entry-title' => 'color: {{VALUE}}',
				],			
				'default' => '#333333'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sgm_title_title_typography',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} h1.entry-title ',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'sgm_title_border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} h1.entry-title ',
			]
		);
		
        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            $content = $template->GetRelatedPostField("post_title");
            echo "<h1 class='entry-title'>".$content."</h1>";
        }
        else
        {
            echo "<h1 class='entry-title'>محل قرار گیری عنوان نوشته یا برگه شما</h1>";
        }
    }
}