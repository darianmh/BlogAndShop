<?php
namespace Elementor;

class Main_Menu extends Widget_Base {

	public function get_name() {
		return 'main-menu';
	}

	public function get_title() {
		return __( 'Menu Horizontal', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'Sigma-Header' ];
	}

    public function get_menus(){
        $list = [];
        $menus = wp_get_nav_menus();
        foreach($menus as $menu){
            $list[$menu->slug] = $menu->name;
        }

        return $list;	
    }
    
   protected function _register_controls() {

		$this->start_controls_section(
			'section_main_menu',
			[
				'label' => __( 'Menu Horizontal', 'sigma-theme' ),
			]
		); 
		
        $this->add_control(
            'sigma_nav_menu',
            [
                'label'     =>esc_html__( 'Select Menu', 'sigma-theme' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->get_menus(),
            ]
		);

		$this->add_control(
			'sigma_active_megamenu',
			[
				'label'     => esc_html__( 'Active Mega Menu', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);
		
		$this->add_control(
			'horizantal_menu_alignment',
			[
				'label' => __( 'Menu Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .sigma-main-menu ' => 'text-align: {{VALUE}};'
                ],				
			]
		);	
		
		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section_manin_menu',
        	[
				'label' => __( 'Main Menu Item', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Main Menu Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-main-menu ul li a , .has-mega-menu-sigma .navbar-dark .navbar-nav .nav-link ',
			]
		);		

		$this->add_control(
			'item_menu_color',
			[
				'label' => __( 'Main Menu Item Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-main-menu ul li a , .has-mega-menu-sigma .navbar-dark .navbar-nav .nav-link ' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);

		$this->add_control(
			'item_menu_arrow_color',
			[
				'label' => __( 'Menu Arrow Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .menu-item-has-children:after , .has-mega-menu-sigma .nav-item i.fal.fa-chevron-down ' => 'color: {{VALUE}} !important',
				],			
				'default' => '#888888'
			]
		);
		
		$this->add_control(
			'item_menu_arrow_size',
			[
				'label' => __( 'Menu Arrow Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 9,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .menu-item-has-children:after , .has-mega-menu-sigma .nav-item i.fal.fa-chevron-down ' => 'font-size:{{SIZE}}px',
				],
			]
		);			
		$this->end_controls_section();	
		
        $this->start_controls_section(
        	'style_section_manin_submenu',
        	[
				'label' => __( 'Main Menu Submenu', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'main_menu_item_type',
				'label' => __( 'Main Menu Submenu Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-main-menu ul li ul li a , .has-mega-menu-sigma .navbar .dropdown .dropdown-menu li a',
			]
		);		

		$this->add_control(
			'item_submenu_color',
			[
				'label' => __( 'Main Menu Submenu Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-main-menu ul li ul li a , .has-mega-menu-sigma .navbar .dropdown .dropdown-menu li a' => 'color: {{VALUE}} !important',
				],	
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'item_submenu_background',
				'label' => __( 'Main Menu Submenu Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .sigma-main-menu ul li ul , .has-mega-menu-sigma .navbar .dropdown-menu ,  .has-mega-menu-sigma .navbar .dropdown-menu li a , .has-mega-menu-sigma .navbar .dropdown-menu li',
			]
		);	
		
		$this->add_control(
			'item_submenu_border_color',
			[
				'label' => __( 'Submenu Bottom Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sigma-main-menu ul li ul , .has-mega-menu-sigma .navbar .dropdown-menu' => 'border-top: 3px solid {{VALUE}} !important',
				],			
				'default' => '#399bff'
			]
		);

		$this->add_control(
			'item_submenu_arrow_color',
			[
				'label' => __( 'Submenu Arrow Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sigma-main-menu ul li ul .menu-item-has-children:after ' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);

		$this->add_control(
			'item_submenu_arrow_size',
			[
				'label' => __( 'SubMenu Arrow Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-main-menu ul li ul .menu-item-has-children:after ' => 'font-size:{{SIZE}}px',
				],
			]
		);			
		$this->end_controls_section();	

        $this->start_controls_section(
        	'style_section_manin_megamenu',
        	[
				'label' => __( 'Mega Menu Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'mega_background',
				'label' => __( 'Mega Menu Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .has-mega-menu-sigma .mega_sigma ',
			]
		);	

		$this->add_control(
			'mega_background_head_color',
			[
				'label' => __( 'Mega Menu Heading Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .has-mega-menu-sigma .mega_sigma h6.category_menu ' => 'color: {{VALUE}} !important',
				],	
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mega_background_head_type',
				'label' => __( 'Mega Menu Heading Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .has-mega-menu-sigma .mega_sigma h6.category_menu ',
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mega_menu_item_type',
				'label' => __( 'Mega Menu Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .has-mega-menu-sigma .mega_sigma ul li a',
			]
		);		

		$this->add_control(
			'megamenu_item_color',
			[
				'label' => __( 'Mega Menu Item Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .has-mega-menu-sigma .mega_sigma ul li a' => 'color: {{VALUE}} !important',
				],	
				'default' => '#888888'
			]
		);		
		
		$this->end_controls_section();	
        
        
    }


	protected function render() {

        $settings = $this->get_settings();
        extract( $settings );
        if($settings['sigma_active_megamenu'] == 'yes'){    
        $menuLocations = get_nav_menu_locations();
        $menuID = $menuLocations['header-menu'];
        $primary_menus = json_decode(json_encode(wp_get_nav_menu_items($menuID)), true);        
            ?>
            <div class="has-mega-menu-sigma">
            <nav class="navbar navbar-expand-lg navbar-dark">
            <?php if ( has_nav_menu( 'header-menu' ) ): ?>
                    <div class="collapse navbar-collapse" id="rt">
                        <ul class="navbar-nav mr-auto">
                            <?php foreach ($primary_menus
            
                                           as $menu) { ?>
                                <?php if ($menu["menu_item_parent"] == 0) { ?>
                                    <?php if (!has_child($menu["ID"], $primary_menus)) { ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?= $menu["url"]; ?>"
                                               ><?= $menu["title"]; ?></a>
                                        </li>
                                    <?php } else { ?>
                                        <?php if (get_number_grandchild($menu["ID"], $primary_menus) < 2) { ?>
                                            <li class="nav-item dropdown" style="position: relative;"><i class="fal fa-chevron-down"></i>
                                                <a class="nav-link dropdown-toggle" href="<?= $menu["url"]; ?>" role="button"
                                                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <?= $menu["title"]; ?>
                                                </a>
                                                <ul class="dropdown-menu animate slideIn" style="position: absolute;">
                                                    <?php $childs = get_childs($menu["ID"], $primary_menus); ?>
                                                    <?php foreach ($childs as $child) { ?>
                                                        <?php if (has_child($child["ID"], $primary_menus)) { ?>
                                                            <li class="dropdown-submenu">
                                                                <a class="dropdown-item" href="<?= $child["url"]; ?>"
                                                                   ><?= $child["title"]; ?> <span
                                                                            class="fa fa-chevron-left"
                                                                            style="margin-left: 0.2rem;"></span></a>
                                                                <?php $sub_menu_items = get_childs($child["ID"], $primary_menus); ?>
                                                                <ul class="dropdown-menu animate slideIn">
                                                                    <?php foreach ($sub_menu_items as $sub_menu_item) { ?>
                                                                        <li><a class="dropdown-item"
                                                                               href="<?= $sub_menu_item["url"]; ?>"
                                                                            ><?= $sub_menu_item["title"]; ?></a>
                                                                        </li>
                                                                    <?php } ?>
                                                                </ul>
                                                            </li>
                                                        <?php } else { ?>
                                                            <li><a class="dropdown-item" href="<?= $child["url"]; ?>"
                                                                ><?= $child["title"]; ?></a></li>
                                                        <?php } ?>
            
                                                    <?php } ?>
                                                </ul>
                                            </li>
                                        <?php } else { ?>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="<?= $menu["url"]; ?>" role="button"
                                                   data-toggle="dropdown"
                                                   aria-haspopup="true" aria-expanded="false">
                                                    <?= $menu["title"]; ?>
                                                </a>
                                                <div class="dropdown-menu mega_sigma animate slideIn" style="position: fixed; width: 1140px !important;">
                                                    <div class="container">
                                                        <div class="row" style="padding-top: 0.8em;">
                                                            <?php $mega_menu_categories = get_childs($menu["ID"], $primary_menus); ?>
                                                            <?php foreach ($mega_menu_categories
                                                                           as $mega_menu_category) { ?>
                                                                <div class="col-md-3">
                                                                    <h6 class="category_menu"
                                                                        ><?= $mega_menu_category["title"]; ?>
                                                                    </h6>
                                                                    <!--
                                                                    <div class="dropdown-divider"
                                                                         style="color: #ccc;width: 70%;"></div>
                                                                    -->
                                                                    <?php if (has_child($mega_menu_category["ID"], $primary_menus)) { ?>
                                                                        <!--
                                                                        <div class="dropdown-divider"
                                                                             style="color: #ccc;width: 70%;"></div>
                                                                        -->
                                                                        <?php $mega_menu_items = get_childs($mega_menu_category["ID"], $primary_menus) ?>
                                                                        <ul class="nav flex-column">
                                                                            <?php foreach ($mega_menu_items as $mega_menu_item) { ?>
                                                                                <li class="nav-item">
                                                                                    <a class="nav-link "
                                                                                       href="<?= $mega_menu_item["url"]; ?>"><?= $mega_menu_item["title"]; ?></a>
                                                                                </li>
                                                                            <?php } ?>
                                                                        </ul>
                                                                    <?php } ?>
                                                                </div>
            
                                                            <?php } ?>
                                                        </div>
                                                    </div>
            
                                                </div>
                                            </li>
                                        <?php } ?>
                                    <?php } ?>
                                <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
            <?php else: ?>
            
            <div class="no-menu">
                <a class="nav-link" href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>" target="_blank">هیچ منویی برای منوی اصلی انتخاب نشده است ، برای ایجاد کلیک کنید!</a>
            </div>
            
            <?php endif; ?>     
            </nav>
            </div>
            <?php
        }
        else { ?>
            <div class="sigma-main-menu">
                <nav class="sigma-main-menu-nav" role="navigation">
                <?php
                    $args = array(
                        'container_class' => 'collapse navbar-collapse no-padding',
                        'fallback_cb' => '',
                        'menu_id' => 'header-menu',
        				'menu'         	  => $settings['sigma_nav_menu'],
                    );
                    wp_nav_menu($args);
                ?>
                
                </nav>
            </div>
        <?php }
    }

    
    protected function _content_template() { }
}