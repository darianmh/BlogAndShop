<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.5.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header( 'shop' ); ?>

<div class="container">
<div class="row">
<div class="single_prd col-12 col-lg-9">

	<?php
		/**
		 * woocommerce_before_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
		do_action( 'woocommerce_before_main_content' );
	?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php wc_get_template_part( 'content', 'single-product' ); ?>

		<?php endwhile; // end of the loop. ?>

	<?php
		/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		do_action( 'woocommerce_after_main_content' );
	?>
				
<div class="before-title" style="display:<?php echo ot_get_option("role_comment"); ?>">
		<span class="before-note"><?php echo ot_get_option("role_post_content"); ?></span>
</div>

<div class="ads-bottom" style="display:<?php echo ot_get_option("show_ads_product"); ?>">
<a href="<?php echo ot_get_option("ads_post_link"); ?>" target="<?php echo ot_get_option("single_ads_target"); ?>"><img class="ads2"style="display:<?php echo ot_get_option("single_ads"); ?>" src="<?php echo ot_get_option("single_ads_image"); ?>" ></a>   


</div>

	</div>
	

<div class="sidebar col-lg-3 col-sx-12 right">


<div class="sidebar-product licenseV2" style="display:<?php echo ot_get_option("license_productv2"); ?>">
	<img class="info" src="<?php echo ot_get_option("img_license"); ?>" style="max-width: 100px !important; margin-bottom: 20px; height: 100px !important;">
	<span class="title-info"><?php echo ot_get_option("title_license"); ?></span>
		<?php the_excerpt(); ?>
		
		</div>			
	<div class="sidebar-product">
		
		<div class="bgimg">
	<img class="info" src="<?php echo ot_get_option("img_detial"); ?>" style="max-width: 100px !important; margin-bottom: 20px; height: 100px !important;">
	<span class="title-info"><?php echo ot_get_option("title_detial"); ?></span>

	</div>

	<div class="box">
		
	<div class="license" style="display:<?php echo ot_get_option("license_product"); ?>">

<?php echo ot_get_option("license_content"); ?>


</div>

		
	<span class="price" style="display:<?php echo ot_get_option("show_price"); ?>" >

</span>


	<div class="help" >

<?php $mid_var = get_post_meta($post->ID, 'help',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<div class="help" ><a href="<?php echo get_post_meta($post->ID, 'help',true); ?>" target="_blank" class="help">
راهنمای کار با محصول</a></div>
<?php endif; ?>


		</div>	
		
		
	<div class="demo-fa" style="display:<?php echo ot_get_option("show_demo_fa"); ?>" >

<?php $mid_var = get_post_meta($post->ID, 'demo-fa',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<div class="demo-fa" ><a href="<?php echo get_post_meta($post->ID, 'demo-fa',true); ?>" target="_blank" class="demo">
پیشنمایش فارسی</a></div>
<?php endif; ?>
</div>
								
	<div class="demo-en" style="display:<?php echo ot_get_option("show_demo_en"); ?>" >

<?php $mid_var = get_post_meta($post->ID, 'demo',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<div class="demo-en" ><a href="<?php echo get_post_meta($post->ID, 'demo',true); ?>" target="_blank" class="demo">
پیشنمایش لاتین</a></div>
<?php endif; ?>



</div>
	
	<div class="info-box-dt" style="display:<?php echo ot_get_option("info_product"); ?>">

		<span class="date"><i class="fa fa-calendar"></i><p>تاریخ ارسال:</p><strong> <?php the_time('Y/m/d'); ?></strong></span>
		
		<span class="date"><i class="fa fa-file"></i><p>فایل های موجود: </p><strong><?php echo get_post_meta($post->ID, 'include',true); ?>

<?php $mid_var = get_post_meta($post->ID, 'include',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<?php endif; ?></strong></span>	

		<span class="date"><i class="fa fa-eye-slash"></i><p>تعداد بازدید:</p><strong><?php echo getPostViews(get_the_ID()); ?></strong></span>	

		<span class="date"><i class="fa fa-desktop"></i><p>نسخه محصول:</p><strong><?php echo get_post_meta($post->ID, 'verion',true); ?>


<?php $mid_var = get_post_meta($post->ID, 'verion',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<?php endif; ?></strong></span>	


		<span class="date"><i class="fa fa-info-circle"></i><p>فایل راهنما:</p><strong><?php echo get_post_meta($post->ID, 'rahmnama',true); ?>

<?php $mid_var = get_post_meta($post->ID, 'rahmnama',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<?php endif; ?></strong></span>	


		<span class="date" style="display:<?php echo ot_get_option("update_show"); ?>" ><i class="fa fa-upload"></i><p>تاریخ بروزرسانی:</p><strong><?php the_modified_time('Y/m/d');?></strong></span>	


		<span class="date"><i class="fa fa-file-o"></i><p>حجم فایل:</p><strong><?php echo get_post_meta($post->ID, 'size',true); ?>

<?php $mid_var = get_post_meta($post->ID, 'size',true);
if(isset($mid_var) && !empty($mid_var)) : ?>
<?php endif; ?></strong></span>	


		<span class="date" style="display:<?php echo ot_get_option("sales"); ?>" ><i class="fa fa-shopping-cart"></i><p>تعداد فروش:</p><strong>
<?php global $product;
$units_sold = get_post_meta( $product->id, 'total_sales', true );
echo ''. sprintf( __( '%s', 'woocommerce' ), $units_sold ).''; ?>

</strong></span>	


		<span class="date"><i class="fa fa-comment"></i><p>تعداد دیدگاه ها:</p><strong>

<?php comments_number( '0', ' 1 ', ' % ' ); ?>


</strong></span>	

<?php
setPostViews(get_the_ID());
?>



	</div>																							

	<div class="shoppin-card">
		<span>پرداخت امن با کلیه کارت های عضو شتاب</span>
		<img src="<?php echo ot_get_option("payment_img"); ?>">
	</div>
		</div>

	</div>
		
		<div class="sidebar-product" style="display:<?php echo ot_get_option("vendor_show"); ?>">
		<div class="box-vendor">
		<div class="media author-box">

    <div class="media-figure">
        <?php echo get_avatar( get_the_author_meta('email'), '100' ); ?>
    </div>

    <div class="media-body">
        <h2><?php the_author_posts_link(); ?></h2>
		<p><?php the_author_meta('description'); ?></p>
        <div class="author-icons">
            <a href="<?php bloginfo('url'); ?>" class="author-website">
                <img src="<?php bloginfo('template_url'); ?>/img/website.svg" alt="سایت" />
            </a>
            <a href="<?php echo ot_get_option("twitter"); ?>" class="author-twitter">
                <img src="<?php bloginfo('template_url'); ?>/img/twitter.svg" alt="توییتر" />
            </a>
            <a href="<?php echo ot_get_option("facebook"); ?>" class="author-facebook">
                <img src="<?php bloginfo('template_url'); ?>/img/facebook.svg" alt="فیسبوک" />
            </a>
			<a href="<?php echo ot_get_option("telegram"); ?>" class="author-telegram">
                <img src="<?php bloginfo('template_url'); ?>/img/telegram.svg" alt="تلکرام" />
            </a>
			<a href="<?php echo ot_get_option("instagram"); ?>" class="author-instagram">
                <img src="<?php bloginfo('template_url'); ?>/img/instagram.svg" alt="اینستاگرام" />
            </a>
        </div>
    </div>

</div>
						<span><i class="fa fa-archive"></i><a href="<?php bloginfo('url')?>/dokan">مشاهده محصولات دیگر این طراح</a></span>
				</div>
				</div>
				
		<div class="sidebar-product">
		<div class="box-fav-sup">
			
	<div style="display:<?php echo ot_get_option("favorit_show"); ?>" class="yith-wcwl-add-to-wishlist add-to-wishlist-289">
				<div class="yith-wcwl-add-button show" style="display:block">

<?php echo do_shortcode("[yith_wcwl_add_to_wishlist]"); ?><i class="fa fa-heart"></i>

			</div>
		
	</div>
					
	<div class="demo-en" style="display:<?php echo ot_get_option("support_show"); ?>"><a href="<?php echo ot_get_option("support_link"); ?>" target="_blank" class="support"><i class="fa fa-life-ring"></i><?php echo ot_get_option("support_title"); ?></a></div>
				

	<div class="report" style="display:<?php echo ot_get_option("report_show"); ?>" ><a id="reportbtn" class="report-btn"><i class="fa fa-bug"></i><?php echo ot_get_option("report_title"); ?></a></div>
	

	<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p>
	<?php echo do_shortcode( '[contact-form-7 id="424" title="report"]' ); ?>
	</p>
  </div>

</div>

<div style="display:<?php echo ot_get_option("urlshort_show"); ?>">
		<span style="color: #333; font-size: 12px; padding: 11px 0; float: right;"><i class="fa fa-link"></i>لینک کوتاه : </span>

					<input type="text" class="ulink" value="<?php bloginfo('url'); ?>/?p=<?php the_ID(); ?>" id="myInput">	
					<i class="fa fa-files-o copy" onclick="myFunction()" aria-hidden="true"></i>
					</div>

					</div>
				</div>
				

				
			
						</div>

	</div>
	</div>
<?php get_footer( 'shop' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
