<?php
add_action( 'init', 'sigma_theme_register_template_maker_post_type' );
function sigma_theme_register_template_maker_post_type() {
    $labels = array(
        'name'               => __( 'sigma template', 'sigma-theme' ),
        'singular_name'      => __( 'sigma template', 'sigma-theme' ),
        'menu_name'          => __( 'sigma templates','sigma-theme' ),
        'name_admin_bar'     => __( 'sigma template', 'sigma-theme' ),
        'add_new'            => __( 'Add New', 'sigma-theme' ),
        'add_new_item'       => __( 'Add New template', 'sigma-theme' ),
        'new_item'           => __( 'New template', 'sigma-theme' ),
        'edit_item'          => __( 'Edit template', 'sigma-theme' ),
        'view_item'          => __( 'View template', 'sigma-theme' ),
        'all_items'          => __( 'All templates', 'sigma-theme' ),
        'search_items'       => __( 'Search templates', 'sigma-theme' ),
        'parent_item_colon'  => __( 'Parent templates:', 'sigma-theme' ),
        'not_found'          => __( 'No templates found.', 'sigma-theme' ),
        'not_found_in_trash' => __( 'No templates found in Trash.', 'sigma-theme' )
    );
    $args = array(
        'labels'             => $labels,
        'description'        => __( 'sigma template builder', 'sigma-theme' ),
        'supports'           => array( 'title', 'editor'),
        'public'            => true,
        'has_archive'       => false,
        'show_in_nav_menus' => false,
        'menu_icon'         => 'dashicons-admin-post'
    );
    register_post_type( 'sigma-template', $args );
}