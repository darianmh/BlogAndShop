<h3 class="relate_sigma"><?php _e('Related products', 'sigma-theme'); ?></h3>
<div id="related" class="owl-carousel">

    <?php
    $trmids = wp_get_post_terms($post->ID, 'product_cat');
    $trmarray = array();
    foreach ($trmids as $v) {
        $trmarray[] = $v->term_id;
    }

    $arms = array(
        'post_type' => 'product',
        'posts_per_page' => '9',
        'order' => 'DESC',
        'post_status' => 'publish',
        'post__not_in' => array($post->ID),
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'terms' => $trmarray,
            ),
        )
    );
    $the_query = new WP_Query($arms);
    if ($the_query->have_posts()):
    while ($the_query->have_posts()) : $the_query->the_post(); ?>

<div class="product-index product-related">
    <?php global $sigma;
    if ($sigma['show_img_product_loop_v1'] == 'enable') {
        ?>
        <a href="<?php the_permalink(); ?>"><?php woocommerce_template_loop_product_thumbnail(); ?></a>
    <?php } ?>
    <div class="product-meta">
        <?php if ($sigma['show_title_product_loop_v1'] == 'enable') { ?>
            <div class="titleholder">
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                    <h2><?php the_title(); ?></h2>
                </a>
            </div>
        <?php } ?>
        <hr>
        <?php if ($sigma['show_desc_product_loop_v1'] == 'enable') { ?>
            <p><?php echo wp_trim_words(get_the_content(), 25, '...'); ?></p>
        <?php }
        if ($sigma['show_price_product_loop_v1'] == 'enable') { ?>
            <div class="priceholder">
                <i class="fa fa-id-card-o"></i>
                <?php echo woocommerce_template_single_price(); ?>
            </div>
        <?php }
        if ($sigma['show_cat_product_loop_v1'] == 'enable') { ?>
            <div class="metaholder">
                <div class="row">
                    <div class="cat-meta col-lg-12 col-12">
                        <i class="fa fa-folder"></i>
                        <?php
                        $terms = get_the_terms(get_the_ID(), 'product_cat');
                        $terms_count = count($terms);

                        if ($terms_count > 0) {
                            foreach ($terms as $key => $term) {
                                $sperator = $key !== ($terms_count - 1) ? ' ، ' : ' ، ';
                                echo "<li><a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a></li>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php }
        if ($sigma['show_btn_product_loop_v1'] == 'enable') { ?>
            <div class="readmore">
                <?php
                global $product;
                if ('' === $product->get_price() || 0 == $product->get_price()) {
                    $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-file"></i>' . __('Free Download', 'sigma-theme') . '</a>';
                } else {
                    $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-shopping-bag"></i>' . __('Buy Product', 'sigma-theme') . '</a>';
                }
                echo $price;
                ?>
            </div>
        <?php } ?>
    </div>
</div>   

    <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php else : ?>
        <p class="nopost"><?php _e('There are no products to display.', 'sigma-theme'); ?> </p>
    <?php endif; ?>
</div>   