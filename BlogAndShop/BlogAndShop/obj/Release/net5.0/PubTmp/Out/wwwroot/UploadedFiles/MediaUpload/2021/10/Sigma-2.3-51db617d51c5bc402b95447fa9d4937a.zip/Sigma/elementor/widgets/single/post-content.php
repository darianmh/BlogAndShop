<?php
namespace Elementor;

class Post_Content extends Widget_Base {
	
	public function get_name() {
		return 'post-content';
	}
	
	public function get_title() {
		return __( 'Single Content', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-image-box';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Single Content', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'active_content',
			[
				'label'   => esc_html__( 'Active Content', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'single_post_h1_type',
				'label' => __( 'Content h1 Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .postholder h1 ',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'single_post_h2_type',
				'label' => __( 'Content h2 Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .postholder h2 ',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'single_post_h3_type',
				'label' => __( 'Content h3 Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .postholder h3 ',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'single_post_h4_type',
				'label' => __( 'Content h4 Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .postholder h4 ',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'single_post_h5_type',
				'label' => __( 'Content h5 Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .postholder h5 ',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'single_post_h6_type',
				'label' => __( 'Content h6 Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .postholder h6 ',
			]
		);
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            if($settings['active_content'] == 'yes'){    
            $content = $template->GetRelatedPostField("post_content");
            echo "<div class='postholder postholder_elementor entry-content'>".$content."</div>";
            }
        }
        else
        {
            if($settings['active_content'] == 'yes'){    
            echo "<div class='elementor-post-sample'><p class='entry-content-sample'>محل توضیحات برگه یا نوشته شما</p>";
            echo "<div class='load-item-content postholder'>";
            echo "<h1>من یک تک h1 هستم.</h1>";
            echo "<h2>من یک تک h2 هستم.</h2>";
            echo "<h3>من یک تک h3 هستم.</h3>";
            echo "<h4>من یک تک h4 هستم.</h4>";
            echo "<h5>من یک تک h5 هستم.</h5>";
            echo "<h6>من یک تک h6 هستم.</h6>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";         
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";                     
            echo "</div></div>";
            }
        }
    }
}