<li class="modern_gird_products_warp sigma-wc-product product modern_gird_products_warp_archive">
    <div class="sigma-wc-product-inner">
        <div class="image__holder__v3">
            <a href="<?php the_permalink(); ?>">
                <?php global $sigma;
                if ($sigma['show_img_product_loop_v3'] == 'enable') {
                ?>                
                <?php the_post_thumbnail( 'blog' ); ?>
                <?php } ?>
    			<!-- popup content -->
    			    <?php if ($sigma['show_qviews_product_loop_v3'] == 'enable') { ?>
    				<div class="sigma-wc-product-popop">
    					<a class="sigma-wc-product-popop--link" href="<?php echo get_the_post_thumbnail_url( get_the_ID(), 'full' ); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
    				</div>
    			    <?php } ?>
    			    
    			<?php if ($sigma['show_discount_product_loop_v3'] == 'enable') { ?>	
				<div class="sigma-wc-products-badge">
					<?php woocommerce_show_product_loop_sale_flash(); ?>
				</div>
				<?php } ?>
				
            </a>
        </div>
        <div class="post__expect__v3__elementor darkeble">
            
            <?php if ($sigma['show_title_product_loop_v3'] == 'enable') { ?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><h2><?php the_title(); ?></h2></a>    
            <?php } ?>
            
					<!-- categories -->
					
					<?php if ($sigma['show_cat_product_loop_v3'] == 'enable') { ?>
					<?php 
							$terms = get_the_terms( get_the_ID(), 'product_cat' );
							$terms_count = count($terms);

							if($terms_count > 0){
								echo "<div class='sigma-wc-product-categories'><ul>";
								foreach($terms as $key => $term){
									$sperator = $key !== ($terms_count -1) ? '' : '';
									echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
								}
								echo "</ul></div>";
							}
					?>
					<!-- end categories -->	
					<?php } ?>
		
		<?php if ($sigma['show_discount_product_loop_v2'] == 'enable') { ?>			
        <p><?php echo wp_trim_words( get_the_content(), 40, '...' ); ?></p>
        <?php } ?>
        
        <div class="row">
        
        <?php if ($sigma['show_vendor_product_loop_v3'] == 'enable') { ?>    
        <div class="nopadding-left col-lg-7 col-7 cat__holder">
                    <h5><i class="fal fa-store"></i>
                <a href="<?php bloginfo('url'); ?>/store/<?php echo nl2br(get_the_author_meta('user_login')); ?>" target="_blank" ><?php $user_author = get_the_author_meta( 'display_name' ); echo $user_author ?></a>
                    </h5>
        </div>
        <?php } ?>
                
        <?php if ($sigma['show_date_product_loop_v3'] == 'enable') { ?>        
        <div class="nopadding-right col-lg-5 col-5 cat__holder">
            <h5><i class="fal fa-calendar"></i> <?php echo get_the_date(''); ?> </h5>
        </div>
        <?php } ?>
        
        </div>
            <hr>
        <div class="row">
            
        <?php if ($sigma['show_price_product_loop_v3'] == 'enable') { ?>    
        <div class="col-lg-9 col-9 price__holder nopadding-left">
            <i class="fal fa-sack-dollar"></i>
        <?php echo woocommerce_template_single_price(); ?>
        </div>
        <?php } ?>
        
        <?php if ($sigma['show_sale_product_loop_v3'] == 'enable') { ?>
        <div class="col-lg-3 col-3 sale__holder nopadding-right">
            <h4><i class="fal fa-shopping-bag"></i><span><?php echo ( get_post_meta( get_the_ID(), 'total_sales', true ) ); ?></span></h4>
        </div>
        <?php } ?>
        
        </div>
        
            <?php if ($sigma['show_cart_product_loop_v3'] == 'enable') { ?>
            <div class="get_products_page_color">
                <?php
                global $product;
                if ('' === $product->get_price() || 0 == $product->get_price()) {
                    $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-file"></i>' . __('Free Download', 'sigma-theme') . '</a>';
                } else {
                    $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-shopping-bag"></i>' . __('Buy Product', 'sigma-theme') . '</a>';
                }
                echo $price;
                ?>
            </div>
            <?php } ?>
            
        </div>
    </div>
</li>