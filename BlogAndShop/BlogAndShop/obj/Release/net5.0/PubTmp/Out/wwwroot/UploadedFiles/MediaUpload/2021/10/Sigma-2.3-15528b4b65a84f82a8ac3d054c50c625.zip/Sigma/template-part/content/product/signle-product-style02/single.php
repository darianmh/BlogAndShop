<?php global $sigma;
if ($sigma['single_product_full_width'] == 'enable') { ?>
<div class="container"> <?php } else{ ?>
    <div class="container-fluid"> <?php } ?>
        <div class="dgs_single_products_alert">
        <?php do_action('woocommerce_before_single_product'); ?>
        </div>    
        <div class="dgs_sigma_product_single">
            <div class="full-width-breadcame breadcame_dgs">
                <?php
                $id = get_the_ID();
                $info = sigma_get_physical_product_info($id);
                setPostViews(get_the_ID());
                $args = array(
                    'delimiter' => ' <i></i> ',
                    'home' => __('home', 'sigma-theme'));
                woocommerce_breadcrumb($args);
                if ($sigma['signle_product_v2_report'] == 'enable') {
                    ?>
                    <div class="dgs_single_products_report">
                        <a href="#" data-toggle="modal" data-target="#reportmodal" data-toggle="modal" data-target="#reportbox">
                            <i class="fal fa-flag"></i><?php echo __('Send Feedback For This Product', 'sigma-theme') ?>
                        </a>
                    </div>
                    <div id="reportmodal" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title"><?php _e('Send report for', 'sigma-theme'); ?> <?php the_title(); ?></h4>
                                </div>
                                <div class="modal-body">
                                    <p><?php _e('You are sending a report for the product', 'sigma-theme'); ?><strong><?php the_title(); ?></strong></p>
                
                                    <div class="notice_sigma">
                                        <p><strong><?php _e('Please note the following', 'sigma-theme'); ?>:</strong></p>
                                        <p></p>
                                        <ul>
                                            <li><?php _e('Be sure to check the accuracy of your report before submitting a report.', 'sigma-theme'); ?></li>
                                            <li><?php _e('Strictly avoid sending successive reports.', 'sigma-theme'); ?></li>
                                            <li><?php _e('Your information will be stored in the system.', 'sigma-theme'); ?></li>
                                            <li><?php _e('Important Note: Please include the product title in your report.', 'sigma-theme'); ?></li>
                                        </ul>
                                        <p></p>
                                    </div>
                                    <div class="report-form">
                                        <?php
                                        if (wpcf7_install_plugin()) {
                                            echo do_shortcode("[contact-form-7 title='500']");
                                        } else {
                                            echo __('Please Install and active Contact Form 7 Plugin and creat one form name:500', 'sigma-theme');
                                        }
                                        ?>
                                    </div>
                
                                </div>
                            </div>
                
                        </div>
                    </div>
                <?php } ?>

            </div>
                <?php while (have_posts()): the_post(); ?>
                <div class="dgs_single_products_warp <?php global $product;  if ( $product->is_on_sale() ) { echo 'is-sale'; } ?>">
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-sm-12">
                            <?php echo get_product_countdown_single($id) ; ?>
                            <div class="dgs_gallery_products_area">
                                <?php
                                if ($sigma['thumbnail_image_counter'] == 'all') { ?>
                                    <style>.dgs_gallery_products_area ol.flex-control-nav.flex-control-thumbs {
                                            height: auto;
                                        }</style><?php } ?>
                                <?php woocommerce_show_product_images(); ?>
                            <div class="dgs_single_product_button">
                                <ul>
                                    <!--<li><a href="#"><i class="fal fa-random"></i></a></li>-->
                                    <li><a href="#"><i class="fal fa-share"></i></a>
                                        <div class="dgs_share_btn_more">
                                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-facebook"></i></a>
                                            <a href="https://telegram.me/share/url?url=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-telegram"></i></a>
                                            <a href="https://twitter.com/intent/tweet?text=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-twitter"></i></a>
                                            <a href="https://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-pinterest"></i></a>
                                        </div>
                                    </li>
                                    <!--<li><a href="#"><i class="fal fa-chart-bar"></i></a></li> -->
                                    <?php
                                    if (!sigma_is_in_wishlist($post->ID)) {
                                        ?>
                                        <li><a class="sigma-add-to-wishlist" data-product-id="<?php the_ID(); ?>"><i
                                                        class="fal fa-heart"></i></a></li>
                                        <?php
                                    } else {
                                        ?>
                                        <li><a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank"
                                               class="sigma-add-to-wishlist-added" data-product-id="<?php the_ID(); ?>"><span class="badge-tooltip-all"><?php _e('Get wishlist', 'sigma-theme'); ?></span><i
                                                        class="fal fa-heart"></i></a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
                            </div>
                            <?php
                            global $post, $product;
                            if ($product->is_on_sale() && $product->is_type('simple')) { ?>
                                <div class="dgs_products_offer_number">
                                    <small><?php woocommerce_show_product_loop_sale_flash(); ?></small></div>
                            <?php } ?>
                        </div>

                        <div class="col-xl-5 col-lg-5 col-sm-12">
                            <div class="dgs_products_content">
                                <h1><?php the_title(); ?></h1>
                                <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>
                            </div>

                            <div class="dgs_single_products_description">
                                <p><?php echo __('Features of this product:', 'sigma-theme') ?></p>
                                <?php the_excerpt(); ?>
                            </div>

                            <div class="dgs_single_products_meta">
                                <ul>

                                    <?php
                                    $terms = get_the_terms(get_the_ID(), 'Brand');

                                    if ($terms && !is_wp_error($terms)) :

                                        $draught_links = array();

                                        echo '<li> '. __('Brand:', 'sigma-theme') .' ';
                                        foreach ($terms as $term) {
                                            $draught_links[] = $term->name;
                                            $draught_url[] = get_term_link($term->term_id);
                                        }

                                        $on_draught = join(" , ", $draught_links);
                                        echo $on_draught;
                                        echo '</li>';
                                    endif; ?>


                                    <li><?php _e('Category:', 'sigma-theme'); ?>
                                        <?php
                                        $terms = get_the_terms(get_the_ID(), 'product_cat');
                                        $terms_count = count($terms);
                                        foreach ($terms as $key => $term) {
                                            $sperator = $key !== ($terms_count - 1) ? '' : '';
                                            echo "<div class=''><a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a></div>";
                                        }
                                        ?>
                                    </li>
                                </ul>
                                <div class="dgs_single_products_total_sell">
                                    <?php
                                    
                                    if ($sigma['total_sale_sgm_active'] == 'block') {
                                        ?>
                                        <p><i class="fal fa-shield-check"></i>
                                            <?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?><?php echo __('People have bought this product!', 'sigma-theme') ?>
                                        </p>
                                    <?php } ?>
                                    <?php
                                    
                                    if ($sigma['gaurantee_time_active'] == 'block') {
                                        ?>
                                        <p class="redcolor">
                                            <?php
                                            if (isset($info['product_warranty'])) {    
                                                echo '<i class="fal fa-truck-container"></i>' . $info['product_warranty'];
                                            } else {
                                                echo '<i class="fal fa-truck-container"></i>' . $sigma['gaurantee_time_title'];
                                            }
                                            ?></p>
                                    <?php }
                                    if ($sigma['orginlity_product'] == 'block') { 
                                        $id = get_the_ID();
                                        $orginal = sigma_get_physical_product_info($id); 
                                        if ( $orginal ) {
                                        ?>
                                        <p class="product_orginality">
                                            <i class="fal fa-box-check"></i><?php _e('This product is orignal', 'sigma-theme'); ?>
                                        </p>
                                        <?php }
                                        else {
                                        ?>    
                                        <p class="product_orginality green">
                                            <i class="fal fa-engine-warning"></i><?php _e('This product is not manufactured by the original manufacturer (brand).', 'sigma-theme'); ?>
                                        </p>                                        
                                    <?php }
                                    }
                                    if ($sigma['show_product_ratting_counter'] == 'enable') {
                                    $rating_count = $product->get_rating_count();
                                    $review_count = $product->get_review_count();
                                    $average = $product->get_average_rating();
                                    echo '<p class="star-status-product"><i class="fal fa-star-half-alt"></i> '. __('This product', 'sigma-theme') .' ' . $average . ' '. __('Star from', 'sigma-theme') .' ' . $rating_count . ' '. __('Rating count', 'sigma-theme') .' ';
                                    }
                                    
                                    $sku_num = $product->get_sku();
                                    if ($sku_num) {
                                        ?>
                                        <p class="dgs_sku_number"><i class="far fa-align-right"></i><?php _e('Product sku', 'sigma-theme'); ?>
                                            : <?php global $product;
                                            echo $product->get_sku(); ?></p>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-3 col-sm-12">
                            <div class="dgs_products_buybox" id="buybox_area">

                                <ul>
                                    <?php
                                    if ($sigma['vendor_show_sgm'] == 'block') {
                                        ?>
                                        <li><i class="fal fa-store"></i><?php echo __('Seller:', 'sigma-theme') ?>
                                            <span><?php $user_author = get_the_author_meta('display_name');
                                                echo $user_author ?></span>
                                            <small><?php 
                                            if ($sigma['vendor_show_sgm'] == 'block') {
                                            if ( isset($info['product_send_time']) ) {
                                                echo $info['product_send_time'];
                                            }
                                            else {
                                                echo $sigma['vendor_sgm_subtitle'];
                                            }
                                            }?>
                                            </small>
                                        </li>
                                    <?php } ?>
                                    <?php
                                    
                                    if ($sigma['stock_show_sgm'] == 'block') {
                                        ?>
                                        <li>
                                            <i class="fal fa-check-square"></i><?php echo __('Inventory:', 'sigma-theme') ?>
                                            <?php
                                            global $product;
                                            if ($product->is_in_stock()) {
                                                echo '<span>' . __('In Stock', 'sigma-theme') . '</span><small>' ?><?php 
                                                echo $sigma['stock_sgm_subtitle']; ?><?php echo '</small>';
                                            } else {
                                                if ($product->backorders_allowed()) {
                                                    echo '<span class="dgs_red">' . __('Out of Stock', 'sigma-theme') . '</span><small>' ?><?php 
                                                    echo $sigma['out_stock_sgm_subtitle']; ?><?php echo '</small>';
                                                } else {
                                                    echo '<span class="dgs_red">' . __('Out of Stock', 'sigma-theme') . '</span><small>' ?><?php 
                                                    echo $sigma['out_stock_sgm_subtitle']; ?><?php echo '</small>';
                                                }
                                            }
                                            ?>
                                        </li>
                                    <?php } ?>
                                    <?php
                                    
                                    if ($sigma['guarantee_active'] == 'block') {
                                        echo '<li><i class="fal fa-shield-check"></i>'; ?>
                                        <?php 
                                        echo $sigma['guarantee_bold_title']; ?>
                                        <?php echo '<span>' ?><?php 
                                        echo $sigma['guarantee_title']; ?><?php echo '</span><small>' ?><?php 
                                        echo $sigma['guarantee_subtitle']; ?><?php echo '</small></li>' ?>
                                    <?php } ?>
                                    <?php
                                    
                                    if ($sigma['delivery_active'] == 'block') {
                                        echo '<li><i class="fal fa-shield-check"></i>'; ?>
                                        <?php 
                                        echo $sigma['delivery_bold_title']; ?>
                                        <?php echo '<span>' ?><?php 
                                        echo $sigma['delivery_title']; ?><?php echo '</span><small>' ?><?php 
                                        echo $sigma['delivery_subtitle']; ?><?php echo '</small></li>' ?>
                                    <?php } ?>
                                </ul>
                                <div class="edc_special_price edc_single_price dgs_single_price dgs_signle_addcart">
                                    <?php
                                    if ('' === $product->get_price() || 0 == $product->get_price() && $sigma['free_products_checkout'] == 'disable') {
                                        $downloads = $product->get_downloads();
                                        echo '<div class="sgm_free_product_label">' . $sigma['free_product_text'] . '</div>';
                                        foreach ($downloads as $key => $each_download) {
                                            echo '<button class="single_add_to_cart_button button alt freedl_sgm"><i class="fal fa-link"></i><a href="' . $each_download["file"] . '">' . $each_download["name"] . '</a></button>';
                                        }
                                    } else {
                                        echo woocommerce_template_single_price();
                                        do_action('woocommerce_single_product_summary');
                                    }
                                    ?>
                                </div>
                                <?php
                                
                                if ($sigma['country_send_active'] == 'block') {
                                    ?>
                                    <div class="dgs_ready_to_send">
                                        <p><i class="fal fa-truck-couch"></i><?php 
                                            echo $sigma['country_send_title']; ?>
                                        </p>
                                    </div>
                                    <?php
                                    
                                    if ($sigma['badges_dgs_active'] == 'block') {
                                        ?>
                                        <div class="dgs_single_product_badge">
                                            <ul>
                                                <?php
                                                $id = get_the_ID();
                                                $medals = sigma_get_product_medals($id);
                                                if (false != $medals) {
                                                    foreach ($medals as $medal) {
                                                        ?>
                                                        <li id="hexagon" class="badge_singel pink_badge"><img
                                                                    src="<?php echo $medal['medal_pic'] ?>"
                                                                    alt="<?php echo $medal['medal_name'] ?>"><span
                                                                    class="badge-tooltip"><?php echo $medal['medal_name'] ?></span>
                                                        </li>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="row">
                    <div class="col-12">
                        <?php
                        if ($sigma['signle_product_v2_atcive_default_tab'] == 'enable') {
                            do_action('woocommerce_after_single_product_summary');
                        } else {
                            ?>
                            <div class="dgs_single_products_tabs">
                                <nav>
                                    <div class="dgs_single_products_tabs_inline nav nav-tabs" id="nav-tab"
                                         role="tablist">

                                        <a class="nav-item nav-link active" id="nav-content-tab" data-toggle="tab"
                                           href="#nav-content" role="tab" aria-controls="nav-content"
                                           aria-selected="true"><i
                                                    class="fal fa-align-right"></i><?php echo __('Product details', 'sigma-theme') ?>
                                        </a>
                                        <?php
                                        
                                        if ($sigma['comment_tab_active'] == 'block') {
                                            ?>
                                            <a class="nav-item nav-link" id="nav-comment-tab" data-toggle="tab"
                                               href="#nav-comment"
                                               role="tab" aria-controls="nav-comment" aria-selected="false"><i
                                                        class="fal fa-comment-alt-smile"></i><?php echo __('Users Comment', 'sigma-theme') ?>
                                            </a>
                                        <?php } ?>
                                        <?php
                                        
                                        if ($sigma['more_dec_tab_active'] == 'block') {
                                            ?>
                                            <a class="nav-item nav-link" id="nav-morecontent-tab" data-toggle="tab"
                                               href="#nav-morecontent" role="tab" aria-controls="nav-morecontent"
                                               aria-selected="false"><i
                                                        class="fal fa-table"></i><?php echo __('More details', 'sigma-theme') ?>
                                            </a>

                                        <?php } ?>
                                        <?php
                                        
                                        if ($sigma['seller_tab_active'] == 'block' && class_exists('WeDevs_Dokan')) {
                                            ?>
                                            <a class="nav-item nav-link" id="nav-seller-tab" data-toggle="tab"
                                               href="#nav-seller"
                                               role="tab" aria-controls="nav-seller" aria-selected="false"><i
                                                        class="fal fa-store"></i><?php echo __('Seller Information', 'sigma-theme') ?>
                                            </a>
                                        <?php } ?>
                                    </div>
                                </nav>
                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="nav-content" role="tabpanel"
                                         aria-labelledby="nav-content-tab">
                                        <div class="tab_title_bar">
                                            <h2><?php echo __('Product details', 'sigma-theme') ?></h2>
                                            <small>Product Details</small>
                                        </div>
                                        <div class="content">
                                            <?php the_content(); ?>
                                            <?php
                                            if ($sigma['tags_active'] == 'block') { ?>
                                                <div class="fss_single_products_tags dgs_single_products_tags">
                                                    <p><?php echo __('Product tags:', 'sigma-theme') ?></p>
                                                    <ul>
                                                        <li>
                                                            <?php
                                                            $terms = get_the_terms(get_the_ID(), 'product_tag');
                                                            $terms_count = count($terms);
                                                            foreach ($terms as $key => $term) {
                                                                $sperator = $key !== ($terms_count - 1) ? ' ' : ' ';
                                                                echo "<a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a>";
                                                            }
                                                            ?>
                                                        </li>
                                                    </ul>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <?php
                                    
                                    if ($sigma['comment_tab_active'] == 'block') {
                                        ?>
                                        <div class="tab-pane fade" id="nav-comment" role="tabpanel"
                                             aria-labelledby="nav-comment-tab">
                                            <div class="row">
                                                <div class="col-xl-6 col-lg-6 col-sm-12">
                                                    <div class="edc_single_comments_lists border_line_left">
                                                        <h3><?php echo __('Submit A Comment', 'sigma-theme') ?></h3>
                                                        <small>Submit a Comment</small>
                                                        <div class="edc_commentes_roles">
                                                            <p>
                                                                <?php 
                                                                echo $sigma['role_post_content']; ?>
                                                            </p>
                                                        </div>
                                                        <div id="reviews" class="woocommerce-Reviews">
                                                            <?php if (get_option('woocommerce_review_rating_verification_required') === 'no' || wc_customer_bought_product('', get_current_user_id(), $product->get_id())) : ?>
                                                                <div id="review_form_wrapper">
                                                                    <div id="review_form">
                                                                        <?php
                                                                        $commenter = wp_get_current_commenter();
                                                                        $comment_form = array(
                                                                            'title_reply_to' => esc_html__('Leave a Reply to %s', 'woocommerce'),
                                                                            'title_reply_before' => '<span id="reply-title" class="comment-reply-title">',
                                                                            'title_reply_after' => '</span>',
                                                                            'comment_notes_after' => '',
                                                                            'label_submit' => esc_html__('Submit', 'woocommerce'),
                                                                            'logged_in_as' => '',
                                                                            'comment_field' => '',
                                                                        );

                                                                        $name_email_required = (bool)get_option('require_name_email', 1);
                                                                        $fields = array(
                                                                            'author' => array(
                                                                                'label' => __('Name', 'woocommerce'),
                                                                                'type' => 'text',
                                                                                'value' => $commenter['comment_author'],
                                                                                'required' => $name_email_required,
                                                                            ),
                                                                            'email' => array(
                                                                                'label' => __('Email', 'woocommerce'),
                                                                                'type' => 'email',
                                                                                'value' => $commenter['comment_author_email'],
                                                                                'required' => $name_email_required,
                                                                            ),
                                                                        );

                                                                        $comment_form['fields'] = array();

                                                                        foreach ($fields as $key => $field) {
                                                                            $field_html = '<p class="comment-form-' . esc_attr($key) . '">';
                                                                            $field_html .= '<label for="' . esc_attr($key) . '">' . esc_html($field['label']);

                                                                            if ($field['required']) {
                                                                                $field_html .= '&nbsp;<span class="required">*</span>';
                                                                            }

                                                                            $field_html .= '</label><input id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" type="' . esc_attr($field['type']) . '" value="' . esc_attr($field['value']) . '" size="30" ' . ($field['required'] ? 'required' : '') . ' /></p>';

                                                                            $comment_form['fields'][$key] = $field_html;
                                                                        }

                                                                        $account_page_url = wc_get_page_permalink('myaccount');
                                                                        if ($account_page_url) {
                                                                            /* translators: %s opening and closing link tags respectively */
                                                                            $comment_form['must_log_in'] = '<p class="must-log-in">' . sprintf(esc_html__('You must be %1$slogged in%2$s to post a review.', 'woocommerce'), '<a href="' . esc_url($account_page_url) . '">', '</a>') . '</p>';
                                                                        }

                                                                        if (wc_review_ratings_enabled()) {
                                                                            $comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating">' . esc_html__('Your rating', 'woocommerce') . '</label><select name="rating" id="rating" required>
                                    						<option value="">' . esc_html__('Rate&hellip;', 'woocommerce') . '</option>
                                    						<option value="5">' . esc_html__('Perfect', 'woocommerce') . '</option>
                                    						<option value="4">' . esc_html__('Good', 'woocommerce') . '</option>
                                    						<option value="3">' . esc_html__('Average', 'woocommerce') . '</option>
                                    						<option value="2">' . esc_html__('Not that bad', 'woocommerce') . '</option>
                                    						<option value="1">' . esc_html__('Very poor', 'woocommerce') . '</option>
                                    					</select></div>';
                                                                        }

                                                                        $comment_form['comment_field'] .= '<p class="comment-form-comment"><label for="comment">' . esc_html__('Your review', 'woocommerce') . '&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>';

                                                                        comment_form(apply_filters('woocommerce_product_review_comment_form_args', $comment_form));
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            <?php else : ?>
                                                                <p class="woocommerce-verification-required"><?php esc_html_e('Only logged in customers who have purchased this product may leave a review.', 'woocommerce'); ?></p>
                                                            <?php endif; ?>

                                                            <div class="clear"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-6 col-lg-6 col-sm-12">
                                                    <div class="edc_single_comments_lists border_line_left">
                                                        <h3><?php echo __('User Comments', 'sigma-theme') ?></h3>
                                                        <span class="edc_comments_number_total"><?php comments_popup_link( __('No Comment', 'sigma-theme'), __('1 Comment', 'sigma-theme'), __('% Comments', 'sigma-theme') , __('Comments are Closed', 'sigma-theme') ); ?></span>
                                                        <small>User Comments</small>
                                                        <ol class="commentlist">
                                                            <?php comments_template(); ?> 
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <?php
                                    
                                    if ($sigma['more_dec_tab_active'] == 'block') {
                                        ?>
                                        <div class="tab-pane fade" id="nav-morecontent" role="tabpanel"
                                             aria-labelledby="nav-morecontent-tab">
                                            <div class="more_content_area">
                                                <div class="tab_title_bar">
                                                    <h2><?php echo __('product Other specifications', 'sigma-theme') ?></h2>
                                                    <small>Product other specifications</small>
                                                    <?php do_action('woocommerce_product_additional_information', $product); ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <?php
                                    
                                    if ($sigma['seller_tab_active'] == 'block' && class_exists('WeDevs_Dokan')) {
                                        ?>
                                        <div class="tab-pane fade" id="nav-seller" role="tabpanel"
                                             aria-labelledby="nav-seller-tab">
                                            <?php
                                            $vendor_id = get_post_field('post_author', get_the_id());
                                            $store_url = dokan_get_store_url($vendor_id);
                                            ?>
                                            <div class="dgs_seller_tab_content">
                                                <div class="dgs_seller_meta">
                                                    <a href="<?php echo $store_url; ?>"><i
                                                                class="fal fa-store"></i></a>
                                                </div>
                                                <div class="dgs_seller_name">
                                                    <a href="<?php echo $store_url; ?>">
                                                        <h2><?php echo(get_the_author_meta('display_name')); ?></h2>
                                                        <span> 
                                        <?php
                                        global $wp_query;
                                        $registered = date_i18n("M Y", strtotime(get_the_author_meta('user_registered', $wp_query->queried_object_id)));
                                        echo ' '. __('Register from', 'sigma-theme') .' ' . $registered;
                                        ?>
                                                    </a>
                                                    </span>
                                                    <a href="<?php echo $store_url; ?>">
                                                        <small><?php echo(get_the_author_meta('description')); ?></small>
                                                    </a>
                                                    <div class="dgs_seller_social">
                                                        <ul>
                                                            <li>
                                                                <a href="<?php echo(get_the_author_meta('user_url')); ?>"><i
                                                                            class="fal fa-globe"></i></a></li>
                                                            <li>
                                                                <a href="mailto:<?php echo(get_the_author_meta('user_email')); ?>"><i
                                                                            class="fal fa-envelope"></i></a></li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>

            <?php endwhile; ?>

            <?php
            
            if ($sigma['related_active'] == 'block') {
                ?>
                <div class="dgs_related_products">
                    <div class="tab_title_bar">
                        <h2><?php echo __('Related Products', 'sigma-theme') ?></h2>
                        <small>Related Products</small>
                    </div>
                    <div id="related_dgs" class="owl-carousel">
                        <?php
                        $trmids = wp_get_post_terms($post->ID, 'product_cat');
                        $trmarray = array();
                        foreach ($trmids as $v) {
                            $trmarray[] = $v->term_id;
                        }

                        $arms = array(
                            'post_type' => 'product',
                            'posts_per_page' => '9',
                            'order' => 'DESC',
                            'post_status' => 'publish',
                            'post__not_in' => array($post->ID),
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'product_cat',
                                    'terms' => $trmarray,
                                ),
                            )
                        );
                        $the_query = new WP_Query($arms);
                        if ($the_query->have_posts()) : ?>
                            <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                                <div class="sigma-wc-product-inner dgs_gird_products_warp dgs_gird_products_warp_archive">
                                    <div class="dgs_gird_product_inner">
                                        <div class="sigma-wc-product-image sigma-background-cover">
                                            <!-- popup content -->
                                            <div class="sigma-wc-product-popop">
                                                <div class="sigma-fast-preview"
                                                     data-product-id="<?php echo get_the_ID() ?>"><a
                                                            class="sigma-wc-product-popop--link"><i class="fa fa-eye"
                                                                                                    aria-hidden="true"></i></a>
                                                </div>
                                            </div>

                                            <!-- badge content -->
                                            <div class="sigma-wc-products-badge dgs_gird_products_gift">
                                                <?php woocommerce_show_product_loop_sale_flash(); ?>
                                            </div>

                                            <!-- Thumb content -->
                                            <a class="sigma_woo_product_img_link" href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('blog'); ?>
                                            </a>

                                            <!-- Add to cart button -->
                                            <div class="sigma-wc-add-to-cart">
                                                <?php woocommerce_template_loop_add_to_cart([
                                                    'class button product_type_simple add_to_cart_button ajax_add_to_cart'
                                                ]); ?>
                                            </div>
                                        </div>
                                        <div class="dgs_gird_products_text">
                                            <div class="dgs_gird_products_title">
                                                <a href="<?php the_permalink(); ?>" class="sigma-link-reset">
                                                    <h2 class="sigma-wc-product-title">
                                                        <?php the_title(); ?>
                                                    </h2>
                                                    <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>
                                                </a>
                                            </div>
                                            <div class="sigma-wc-product-price">
                                                <?php woocommerce_template_single_price(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                            <?php wp_reset_postdata(); ?>


                        <?php else : ?>
                            <p class="nopostdata"><?php _e('There are no products to display.', 'sigma-theme'); ?> </p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>