<?php
global $sigma;
if ($sigma['blog_sidebar'] == 'left-sidebar') { ?>

    <div class="content-post">
        <div class="container<?php echo $sigma['blog_page_layout']; ?>">
            <div class="row">
                
                <div class="col-lg-9 archive-post-content">
                    <?php get_template_part('template-part/content/archive/all'); ?>
                

                <div class="col-lg-3 sidebar-post nopadding-left">
                    <?php get_template_part('template-part/content/archive/sidebar'); ?>
                </div>
                
            </div>
        </div>
    </div>
    </div>

<?php } ?>


<?php
global $sigma;
if ($sigma['blog_sidebar'] == 'right-sidebar') { ?>

    <div class="content-post">
        <div class="container<?php echo $sigma['blog_page_layout']; ?>">
            <div class="row">
                <div class="col-lg-3 sidebar-post nopadding-left">
                    <?php get_template_part('template-part/content/archive/sidebar'); ?>
                </div>
                <div class="col-lg-9 archive-post-content">
                    <?php get_template_part('template-part/content/archive/all'); ?>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php } ?>


<?php
global $sigma;
if ($sigma['blog_sidebar'] == 'none-sidebar') { ?>

    <div class="content-post">
        <div class="container<?php echo $sigma['blog_page_layout']; ?>">
            <div class="row">
                <div class="col-lg-12 archive-post-content">
                    <?php get_template_part('template-part/content/archive/all'); ?>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php } ?>