<div class="content-post">
    <?php global $sigma;
    if ($sigma['single_product_full_width'] == 'enable') { ?>
    <div class="container"> <?php } else{ ?>
        <div class="container-fluid"> <?php } ?>
            <div class="row">

                <div class="col-lg-9 main-content-product main-content-product-v2">

                    <?php get_template_part('template-part/content/product/signle-product-style01/main'); ?>
                    <?php get_template_part('template-part/content/single/auther'); ?>
                    <?php get_template_part('template-part/content/single/ads-post'); ?>
                    <?php get_template_part('template-part/content/product/signle-product-style01/related-product'); ?>
                </div>


                <div class="col-lg-3 sidebar-post nopadding-right" id="sidebarWrap">
                    <?php get_template_part('template-part/content/product/signle-product-style01/sidebar'); ?>
                </div>
            </div>
        </div>
    </div>