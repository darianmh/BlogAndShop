<?php
/**
 * Template for displaying search forms in Twenty Seventeen
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>

<?php $unique_id = esc_attr( uniqid( 'search-form-' ) ); ?>

<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" autocomplate="off" >
<input id="searchInput" onkeyup="fetchResults()" style="background:<?php echo ot_get_option("input_serch_back"); ?> !important" type="text" name="s" placeholder="<?php echo ot_get_option("serch_text"); ?>" class="search">  
<button class="btn-search"style="background:<?php echo ot_get_option("btn_serch_back"); ?>" ><i class="fa fa-search" aria-hidden="true"></i>
</button>
<div id="datafetch"></div>
</form>	
