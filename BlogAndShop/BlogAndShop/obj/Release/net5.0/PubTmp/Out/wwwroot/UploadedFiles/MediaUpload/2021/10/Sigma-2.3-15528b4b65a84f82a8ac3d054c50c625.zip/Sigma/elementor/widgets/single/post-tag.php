<?php
namespace Elementor;

class Post_Tag extends Widget_Base {
	
	public function get_name() {
		return 'post-tag';
	}
	
	public function get_title() {
		return __( 'Single tag Style', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-animated-headline';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_tag_style',
        	[
				'label' => __( 'Single tag Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
		$this->add_control(
			'sgm_tag_alignment',
			[
				'label' => __( 'Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'tag' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'tag' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'tag' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .single-post-tags' => 'text-align: {{VALUE}};'
                ],				
			]
		);

		$this->add_control(
			'sgm_tag_tag_title_color',
			[
				'label' => __( 'tag title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .single-post-tags small' => 'color: {{VALUE}}',
				],			
				'default' => '#555555'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sgm_tag_title_typography',
				'label' => __( 'Tag Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single-post-tags small ',
			]
		);
		
		$this->add_control(
			'sgm_tag_tag_color',
			[
				'label' => __( 'tag Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .single-post-tags a' => 'color: {{VALUE}}',
				],			
				'default' => '#555555'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sgm_tag_tag_typography',
				'label' => __( 'tag Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single-post-tags a ',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sgm_tag_background',
				'label' => __( 'Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .single-post-tags a ',
			]
		); 
		
        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
        $post_tags = get_the_tags();
        $separator = ' ';
        echo '<div class="single-post-tags"><small>'. __( 'Post Tags: ', 'sigma-theme' ) .'</small>';
            if ( $post_tags ) {
                foreach( $post_tags as $tag ) {
                echo '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>' . $separator ;
                }
            }
        echo '</div>';    
        }
        else
        {
        echo '<div class="single-post-tags"><small>'. __( 'Post Tags: ', 'sigma-theme' ) .'</small><a href="#">'. __( 'sigmple tag', 'sigma-theme' ) .'</a><a href="#">'. __( 'sigmple tag', 'sigma-theme' ) .'</a><a href="#">'. __( 'sigmple tag', 'sigma-theme' ) .'</a><a href="#">'. __( 'sigmple tag', 'sigma-theme' ) .'</a><a href="#">'. __( 'sigmple tag', 'sigma-theme' ) .'</a></div>';
        }
    }
}