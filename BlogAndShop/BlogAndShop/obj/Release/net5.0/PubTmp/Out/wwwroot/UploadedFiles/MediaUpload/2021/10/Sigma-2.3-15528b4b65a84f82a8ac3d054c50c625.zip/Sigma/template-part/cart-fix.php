<?php
global $sigma;
if ($sigma['cart_active'] == 'inherit') {
    ?>
    <div class="cartfix">
        <a style="background:<?php
        echo '' . $sigma['cart_fix_bg_style01']['background-color']; ?>; color:<?php
        echo $sigma['cart_fix_color_style01']; ?> ;<?php
        echo $sigma['cart_poss_fix']; ?>:15px !important;" href="<?php echo esc_url(wc_get_cart_url()); ?>"
           class="cart-sigma">
            <i class="fal fa-shopping-bag"></i><span style="color:<?php
            echo $sigma['cart_fix_color_style01']; ?> ;background:<?php
            echo '' . $sigma['cart_fix_count_style01']['background-color']; ?>" class="cart-counter"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
        </a>
    </div>
<?php } ?>