<div class="sigma-wc-product-inner dgs_gird_products_warp dgs_gird_products_warp_archive">
    <div class="dgs_gird_product_inner">
        <div class="sigma-wc-product-image sigma-background-cover">
            <!-- popup content -->
            <?php global $sigma;
            if ($sigma['show_qviews_product_loop_v2'] == 'enable') {
                ?>
                <div class="sigma-wc-product-popop">
                    <div class="sigma-fast-preview" data-product-id="<?php echo get_the_ID() ?>"><a
                                class="sigma-wc-product-popop--link"><i class="fa fa-eye" aria-hidden="true"></i></a>
                    </div>
                </div>
            <?php } ?>
            <!-- badge content -->

            <?php if ($sigma['show_discount_product_loop_v2'] == 'enable') { ?>
                <div class="sigma-wc-products-badge dgs_gird_products_gift">
                    <?php woocommerce_show_product_loop_sale_flash(); ?>
                </div>
            <?php } ?>

            <?php if ($sigma['show_img_product_loop_v2'] == 'enable') { ?>
                <!-- Thumb content -->
                <a class="sigma_woo_product_img_link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('blog'); ?>
                </a>
            <?php } ?>

            <?php if ($sigma['show_cart_product_loop_v2'] == 'enable') { ?>
                <!-- Add to cart button -->
                <div class="sigma-wc-add-to-cart">
                    <?php woocommerce_template_loop_add_to_cart([
                        'class button product_type_simple add_to_cart_button ajax_add_to_cart'
                    ]); ?>
                </div>
            <?php } ?>

        </div>
        <div class="dgs_gird_products_text">
            <div class="dgs_gird_products_title">
                <a href="<?php the_permalink(); ?>" class="sigma-link-reset">
                    <?php if ($sigma['show_title_product_loop_v2'] == 'enable') { ?>
                        <h2 class="sigma-wc-product-title"> <?php the_title(); ?> </h2>
                    <?php } ?>

                    <?php if ($sigma['show_en_title_product_loop_v2'] == 'enable') { ?>
                        <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>
                    <?php } ?>

                </a>
            </div>

            <?php if ($sigma['show_price_product_loop_v2'] == 'enable') { ?>
                <div class="sigma-wc-product-price">
                    <?php echo woocommerce_template_single_price(); ?>
                </div>
            <?php } ?>

        </div>
    </div>
</div>