<?php
function sigma_add_to_wishlist()
{
    $product_id = $_POST['product_id'];
    $result = array();
    if(is_numeric($product_id) && get_post_status($product_id) && get_post($product_id)->post_type == 'product')
    {
        if(is_user_logged_in())
        {
            $user_id = get_current_user_id();
            $wishlist = get_user_meta($user_id,'sigma_wish_list',true);
            if(is_array($wishlist))
            {
                if(!in_array($product_id,$wishlist))
                {
                    array_push($wishlist,$product_id);
                    update_user_meta($user_id,'sigma_wish_list',$wishlist);
                    $result['message'] = __('product successfully added to your wishlist','sigma-theme');
                    wp_send_json_success(json_encode($result));
                    wp_die();
                }
                else
                {
                    $result['message'] = __('this product is already in your wishlist','sigma-theme');
                    wp_send_json_error(json_encode($result));
                    wp_die();
                }
            }
            else
            {
                $wishlist = array();
                array_push($wishlist,$product_id);
                update_user_meta($user_id,'sigma_wish_list',$wishlist);
                $result['message'] = __('product successfully added to your wishlist','sigma-theme');
                wp_send_json_success(json_encode($result));
                wp_die();
            }
        }
        else
        {
            $result['message'] = __('you must first sign in','sigma-theme');
            wp_send_json_error(json_encode($result));
            wp_die();
        }
    }
    else
    {
        $result['message'] = __('we got an error at this time.please try later','sigma-theme');
        wp_send_json_error(json_encode($result));
        wp_die();
    }
}
add_action('wp_ajax_sigma_add_to_wishlist','sigma_add_to_wishlist');
add_action('wp_ajax_nopriv_sigma_add_to_wishlist','sigma_add_to_wishlist');
function sigma_remove_from_wishlist()
{
    $product_id = $_POST['product_id'];
    $result = array();
    if(is_numeric($product_id) && get_post_status($product_id) && get_post($product_id)->post_type == 'product')
    {
        if(is_user_logged_in())
        {
            $user_id = get_current_user_id();
            $wishlist = get_user_meta($user_id,'sigma_wish_list',true);
            if(is_array($wishlist))
            {
                if (($key = array_search($product_id, $wishlist)) !== false) {
                    unset($wishlist[$key]);
                    update_user_meta($user_id,'sigma_wish_list',$wishlist);
                    $result['message'] = __('product successfully removed from your wishlist','sigma-theme');
                    wp_send_json_success(json_encode($result));
                    wp_die();
                }
                else
                {
                    $result['message'] = __('this product is not exist in your wishlist','sigma-theme');
                    wp_send_json_error(json_encode($result));
                    wp_die();;
                }
            }
            else
            {
                $result['message'] = __('this product is not exist in your wishlist','sigma-theme');
                wp_send_json_error(json_encode($result));
                wp_die();
            }
        }
        else
        {
            $result['message'] = __('you must first sign in','sigma-theme');
            wp_send_json_error(json_encode($result));
            wp_die();
        }
    }
    else
    {
        $result['message'] = __('we got an error at this time.please try later','sigma-theme');
        wp_send_json_error(json_encode($result));
        wp_die();
    }
}
add_action('wp_ajax_sigma_remove_from_wishlist','sigma_remove_from_wishlist');
add_action('wp_ajax_nopriv_sigma_remove_from_wishlist','sigma_remove_from_wishlist');
function sigma_show_fast_preview()
{
    $product_id = $_POST['product_id'];
    ob_start();
    global $post;
    $post = get_post($product_id);
    setup_postdata( $post );
    get_template_part('template-part/extra/fast-preview');
    $content = ob_get_contents();
    ob_get_clean();
    $result = array();
    $result['html'] = $content;
    wp_send_json_success(json_encode($result));
    wp_die();
}
add_action('wp_ajax_sigma_show_fast_preview','sigma_show_fast_preview');
add_action('wp_ajax_nopriv_sigma_show_fast_preview','sigma_show_fast_preview');