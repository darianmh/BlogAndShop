<!doctype html>
<html dir="rtl" lang="fa-IR">
<head>
<meta charset="utf-8">
<title><?php echo ot_get_option("title"); ?> | <?php the_title(); ?></title>
<meta name="description" content="<?php echo ot_get_option("description"); ?>">
<meta name="keywords" content="<?php echo ot_get_option("keywords"); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
<link href="<?php bloginfo('template_url')?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link rel="icon" href="<?php echo ot_get_option("favicon"); ?>" type="image/x-icon" />
<link href="<?php bloginfo('template_url')?>/css/sigma.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/style.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/responsive.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url'); ?>/css/menu.css" rel="stylesheet" type="text/css">



<style>html { padding-top: 0 !important; }.crunchify-social { display: <?php echo ot_get_option("share_posts"); ?> !important; }
.cartfix , .header-cart-count{<?php echo ot_get_option("cart_poss_fix"); ?>:15px}
.login { padding: 8px 21px 8px 32px; }
p.topmail a { color: #666; letter-spacing: -0.5px; }
span.wpcf7-not-valid-tip { direction: rtl; } .use-floating-validation-tip span.wpcf7-not-valid-tip { left: auto; right: 20%; } span.wpcf7-list-item { margin: 0 1em 0 0; }
.dokan-import-export-header { margin-top: 30px; }
#loading{ position: absolute; top: 10%; left: 45%; opacity: 1; display: none; } .dokan-ajax-search-category{ border:none; background-color: #eeeeee; width: 90px; height: auto; padding-left: 3px; } .ajaxsearchform .input-group-addon{ padding: 0px; } .site-header .widget_dokna_product_search { max-width: 70%; float: right; }

</style>
<!--  jQuery 1.7+  -->
<script src="<?php bloginfo('template_url')?>/js/jquery-1.9.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="<?php bloginfo('template_url')?>/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

<?php wp_head(); ?>

<div class="cart-shop" style="display:<?php echo ot_get_option("cart_fix"); ?>">
	<a href="<?php bloginfo('url')?>/cart" class="cartfix"><i class="fa fa-shopping-cart"></i></a>
	<a href="<?php echo WC()->cart->get_cart_url(); ?>"></a>
   <i class="your-icon-class"> </i>
   <div class="header-cart-count">
      <?php echo WC()->cart->get_cart_contents_count(); ?>
   </div>
</div>
</head>

<?php get_header(); ?>

		
<div class="container">
<div class="content right col-lg-9 col-sx-12">
<div class="single-content">
	
	<div class="single-head">
		<h2 style="display:<?php echo ot_get_option("title_post"); ?>;font-family:<?php echo ot_get_option("title_font"); ?>; font-size:<?php echo ot_get_option("title_size"); ?>" ><?php the_title(); ?></h2>
		
	</div>
	
	<div class="single-info">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="single-info">
<p style="display:<?php echo ot_get_option("cat"); ?>"><i class="fa fa-list-ul"></i><?php the_category(', ') ?>
<p style="display:<?php echo ot_get_option("date"); ?>"><i class="fa fa-calendar"></i><?php the_time('Y/m/d'); ?>
<p style="display:<?php echo ot_get_option("author"); ?>"><i class="fa fa-users"></i>توسط : <?php the_author(', ') ?></p>
<p style="display:<?php echo ot_get_option("view"); ?>"><i class="fa fa-bar-chart"></i><?php echo getPostViews(get_the_ID()); ?></p>

</div>

<?php
setPostViews(get_the_ID());
?>
<?php endwhile; else: ?><?php endif; ?>
	

		</div>

	

<div class="content-post" style="font-family:<?php echo ot_get_option("content_font"); ?>; font-size:<?php echo ot_get_option("font_size_content"); ?>" >

<span><?php the_post_thumbnail('postindex'); ?></span>
	
<?php the_content(__('')); ?>

		</div>

<div class="tags" style="display:<?php echo ot_get_option("tags"); ?>;    font-size: 14px;">
	
<p><i class="fa fa-tag"></i><?php the_tags(); ?></p>

</div>	

	
</div>	


<div class="media author-box">

    <div class="media-figure">
        <?php echo get_avatar( get_the_author_meta('email'), '100' ); ?>
    </div>

    <div class="media-body">
        <h2><?php the_author_posts_link(); ?> 		<p class="date-reg">		<?php
    global $wp_query;
    $registered = date_i18n( "m M Y", strtotime( get_the_author_meta( 'user_registered', $wp_query->queried_object_id ) ) );
    echo 'تاریخ عضویت : ' . $registered;
?><p/></h2>





        <p><?php the_author_meta('description'); ?></p>
        <div class="author-icons">
            	<a href="<?php echo ot_get_option("facebook"); ?>"><i class="fa-facebook sigma-facebook"></i></a>
				<a href="<?php echo ot_get_option("instagram"); ?>"><i class="fa-instagram sigma-insta"></i></a>
				<a href="<?php echo ot_get_option("telegram"); ?>"><i class="fa-paper-plane sigma-telegram"></i></a>
				<a href="<?php echo ot_get_option("googleplus"); ?>"><i class="fa-google-plus sigma-googleplus"></i></a>
				<a href="<?php echo ot_get_option("twitter"); ?>"><i class="fa-twitter sigma-tw"></i></a>
        </div>
    </div>

</div>

<a class="telegram_chanel" href="<?php echo ot_get_option("link_btn_channel"); ?>" target="_blank">
        <i class="icon-telegram"></i>
        <span><?php echo ot_get_option("text_box_telegram"); ?></span>
        <span class="pull-left"><?php echo ot_get_option("text_btn_box_telegram"); ?></span>
    </a>

<div class="relatedposts">
<h3><?php echo ot_get_option("relate_post_title"); ?></h3>
<?php
    $orig_post = $post;
    global $post;
    $tags = wp_get_post_tags($post->ID);
     
    if ($tags) {
    $tag_ids = array();
    foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
    $args=array(
    'tag__in' => $tag_ids,
    'post__not_in' => array($post->ID),
    'posts_per_page'=>3, // Number of related posts to display.
    'caller_get_posts'=>1
    );
     
    $my_query = new wp_query( $args );
 
    while( $my_query->have_posts() ) {
    $my_query->the_post();
    ?>
     
   <div class="relatedthumb col-lg-3 col-sx-12">
        <a rel="external" href="<? the_permalink()?>"><?php the_post_thumbnail(array(250,250)); ?><br />
        <?php the_title(); ?>
        </a>

<i class="fa-eye"></i> <?php echo getPostViews(get_the_ID()); ?>
<i class="fa-users"></i>توسط : <?php the_author(', ') ?>
			</div>		
		
     
    <? }
    }
    $post = $orig_post;
    wp_reset_query();
    ?>
</div>


<div class="ads-bottom">
<a href="<?php echo ot_get_option("ads_post_link"); ?>" target="<?php echo ot_get_option("single_ads_target"); ?>"><img class="ads1"style="display:<?php echo ot_get_option("single_ads"); ?>" src="<?php echo ot_get_option("single_ads_image"); ?>" ></a>   


</div>
<div class="before-title" style="display:<?php echo ot_get_option("role_comment"); ?>">
		<span class="before-note"><?php echo ot_get_option("role_post_content"); ?></span>
</div>


<div class="comment" style="display:<?php echo ot_get_option("comment_form"); ?>">
<i class="fa-comment comment-title">نظرات کاربران</i>


<?php comments_template(); ?>


</div>



</div>

<?php get_sidebar();?>


</div>

<?php get_footer();?>


</body>
</html>
