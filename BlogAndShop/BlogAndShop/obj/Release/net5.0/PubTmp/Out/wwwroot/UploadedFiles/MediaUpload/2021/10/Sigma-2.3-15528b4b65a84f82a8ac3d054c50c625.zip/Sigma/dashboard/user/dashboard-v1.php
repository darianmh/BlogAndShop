<?php get_template_part('dashboard/panel-menu'); ?>
<div class="topbar-dashboard-v1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 panel-title col-10">
                <h1><a href="<?php bloginfo('url') ?>"><i class="fal fa-list-ul"></i><?php bloginfo('name'); ?></a></h1>
            </div>

            <div class="col-lg-2 panel-logo col-2">
                <a href="<?php bloginfo('url') ?>" target="_blank">
                    <?php global $sigma;
                    if ($sigma['panel_logo']['url'] != '') { ?>
                        <img src="<?php echo $sigma['panel_logo']['url']; ?>">
                    <?php } else { ?>
                        <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/favicon.png">
                    <?php } ?>
                </a>
            </div>

            <div class="col-lg-5 panel-menu">
                <div class="support-menu">
                    <?php if ($sigma['show_support_phone'] == 'inherit') { ?>
                    <p><i class="fal fa-phone"></i><?php _e('support:', 'sigma-theme'); ?><?php 
                        echo $sigma['supp_phone']; ?> </p>
                    <?php
                    }
                    if (class_exists('WooWallet')) {
                        if ($sigma['show_deposit'] == 'inherit') {
                        echo '<p><i class="fal fa-money"></i>';
                        _e('Wallet balance:', 'sigma-theme');
                        echo woo_wallet()->wallet->get_wallet_balance(get_current_user_id()) . ' </p> ';
                        }
                    }
                    ?>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="container-fluid panel-v1-content">
    <div class="row">
        <div class="col-sm-6 col-lg-3 panel-v1-right nopadding">
            <div class="user_menu_v1">
                <?php
                $user = wp_get_current_user();
                if ($user) { ?>
                    <img src="<?php echo esc_url(get_avatar_url($user->ID)); ?>"/>
                <?php } ?>

                <div class="user-n">
                    <?php $current_user = wp_get_current_user();
                    echo $current_user->display_name . '<br/>'; ?>
                </div>

                <div class="wellcome">
                    <?php
                    $current_user = wp_get_current_user();
                    $reg_date = date_i18n('j F Y', strtotime($current_user->user_registered));
                    ?>
                    <p><?php _e('Your membership date:', 'sigma-theme'); ?><?php echo $reg_date; ?></p>
                </div>
            </div>
            <div class="menu-panel-v1">

                <?php
                if ($sigma['active_woo_my_account_nav'] == 'enable') {
                    do_action('woocommerce_before_account_navigation'); ?>
                    <ul>
                        <?php foreach (wc_get_account_menu_items() as $endpoint => $label) : ?>
                            <li class="<?php echo wc_get_account_menu_item_classes($endpoint); ?>">
                                <a href="<?php echo esc_url(wc_get_account_endpoint_url($endpoint)); ?>"><?php echo esc_html($label); ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php do_action('woocommerce_after_account_navigation');
                } ?>

                <?php if (has_nav_menu('users-menu')) {
                    wp_nav_menu(array('theme_location' => 'users-menu'));
                }
                ?>
            </div>
        </div>
        <div class="col-sm-6 col-lg-9">
            <div class="panel-content">
                <div class="breadcrumb_post">
                    <?php
                    $args = array(
                        'delimiter' => ' <i></i> ',
                        'home' => __('home', 'sigma-theme'));
                    woocommerce_breadcrumb($args); ?>
                </div>
                <?php while (have_posts()) : the_post(); ?>

                    <div class="postholder pageholder" style="border: none; box-shadow: 0 0 12px 0 rgba(0,0,0,0.06);">
                        <?php if ($sigma['welcome_panel_active'] == 'inherit') { ?>
                        <small><?php _e('Hello', 'sigma-theme'); ?> 
                            <?php global $current_user;
                            wp_get_current_user();
                            echo $current_user->display_name . "\n"; ?><?php _e('Dear, welcome!', 'sigma-theme'); ?><?php global $wp_query;
                            $registered = date_i18n("Y/m/d", strtotime(get_the_author_meta('user_registered', $wp_query->queried_object_id)));
                            _e(' today:', 'sigma-theme') ?> <?php echo $registered; ?> 
                        </small>
                        <?php } ?>
                        
                        <div class="row">
                            
                            <?php if ($sigma['usermeta_box_panel'] == 'block') { ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="comment__count__c4">
                                    <div class="title_conut_d5">
                                        <h4><?php echo do_shortcode("[sigma_comments_counter]"); ?></h4>
                                        <span><?php echo $sigma['usermeta_title_01']; ?></span>
                                    </div>
                                    <div class="icon_conut_d5">
                                        <i class="fal fa-comment"></i>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            
                            <?php if ($sigma['usermeta_box_panel'] == 'block') { ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="sales__count__c4">
                                    <div class="title_conut_d5">
                                        <a href="<?php echo $sigma['usermeta_link_02']; ?>" target="_blank">
                                            <h4><?php echo do_shortcode("[sigma_order_counter]"); ?></h4>
                                            <span><?php echo $sigma['usermeta_title_02']; ?></span>
                                        </a>
                                    </div>
                                    <div class="icon_conut_d5">
                                        <i class="fal fa-shopping-cart"></i>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            
                            <?php if ($sigma['usermeta_box_panel'] == 'block') { ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="ticket__count__c4">
                                    <div class="title_conut_d5">
                                        <a href="<?php echo $sigma['usermeta_link_03']; ?>" target="_blank">
                                            <h4><?php echo do_shortcode("[sigma_ticket_counter]"); ?></h4>
                                            <span><?php echo $sigma['usermeta_title_03']; ?></span>
                                        </a>
                                    </div>
                                    <div class="icon_conut_d5">
                                        <i class="fal fa-ticket"></i>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            
                            <?php if ($sigma['usermeta_box_panel'] == 'block') { ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="order__count__c4">
                                    <div class="title_conut_d5">
                                        <a href="<?php echo $sigma['usermeta_link_04']; ?>" target="_blank">
                                            <h4 style="letter-spacing: -4px; font-size: 32px !important;"><?php echo do_shortcode("[sigma_order_price]"); ?></h4>
                                            <span><?php echo $sigma['usermeta_title_04']; ?></span>
                                        </a>
                                    </div>
                                    <div class="icon_conut_d5">
                                        <i class="fal fa-sack-dollar"></i>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            
                        </div>
                    </div>
                    <div class="row">
                        
                        <?php if ($sigma['codeoff_active'] == 'inherit') { ?>
                        <div class="col-lg-6 col-md-12">
                            <div class="codeoffe__count__c4">
                                <div class="title_conut_d5">
                                    <h5><?php echo $sigma['codeoff_panel']; ?></h5>
                                    <span><?php echo $sigma['codeoff_title_panel']; ?></span>
                                </div>
                                <div class="icon_conut_d5">
                                    <i class="<?php echo $sigma['codeoff_panel_icon']; ?>"></i>
                                </div>
                            </div>
                        </div>
                        <?php } ?>

                        <?php if ($sigma['notif_active'] == 'block') { ?>
                        <div class="col-lg-6 col-md-12">
                            <div class="alarm_sgm">
                                <h4><?php echo $sigma['notif_title_panel']; ?></h4>
                                <ul class="last-alarm_v1">
                                    <?php
                                    $cat_posts = new WP_Query(array(
                                        'post_type' => 'post',
                                        'post_status' => 'publish',
                                        'order' => 'DESC',
                                        'meta_key' => 'post_views_count',
                                        'orderby' => 'meta_value_num',
                                        'cat' => $sigma['notif_cat_panel'],
                                        'posts_per_page' => $sigma['notif_counter_panel'],
                                    ));

                                    if ($cat_posts->have_posts()):
                                        while ($cat_posts->have_posts()): $cat_posts->the_post(); ?>
                                            <li>
                                                <a href="<?php the_permalink() ?>" target="_blank"></a>
                                                <a href="<?php the_permalink() ?>" target="_blank">
                                                    <?php the_title(); ?>
                                                </a>
                                            </li>
                                        <?php endwhile; endif;
                                    wp_reset_query(); ?>

                                </ul>
                            </div>
                        </div>
                        <?php } ?>
                        
                    </div>

                <?php endwhile; ?>

            </div>
        </div>
    </div>
</div>    