<?php
namespace Elementor;

class Post_Meta extends Widget_Base {
	
	public function get_name() {
		return 'post-meta';
	}
	
	public function get_title() {
		return __( 'Single Meta', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-table-of-contents';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
        
// date meta
		
        $this->start_controls_section(
        	'meta_date',
        	[
				'label' => __( 'Single Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'active_meta_date',
			[
				'label'   => esc_html__( 'Active Date', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'date_icon',
			[
				'label' => __( 'Date Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-calendar',
					'library' => 'light',
				],
				'condition' => [ 'active_meta_date' => 'yes', ],
			]
		);

		$this->add_control(
			'active_meta_author',
			[
				'label'   => esc_html__( 'Active Author', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'author_icon',
			[
				'label' => __( 'Author Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-users',
					'library' => 'light',
				],
				'condition' => [ 'active_meta_author' => 'yes', ],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Color user panel text', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sign_in_top' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => 'style03_login',
                ],   	
				'default' => '#888888'
			]
		);
	
		$this->add_control(
			'active_meta_comment',
			[
				'label'   => esc_html__( 'Active Comment Count', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'comment_icon',
			[
				'label' => __( 'Comment Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-comment',
					'library' => 'light',
				],
				'condition' => [ 'active_meta_comment' => 'yes', ],
			]
		);
    
		$this->add_control(
			'active_meta_views',
			[
				'label'   => esc_html__( 'Active Views Count', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'view_icon',
			[
				'label' => __( 'View Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-file-chart-line',
					'library' => 'light',
				],
				'condition' => [ 'active_meta_views' => 'yes', ],
			]
		);
		
        $this->end_controls_section();         
        
        $this->start_controls_section(
        	'single_meta_style',
        	[
				'label' => __( 'Single Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	

		$this->add_control(
			'meta_color',
			[
				'label' => __( 'Single Meta Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta-posts span' => 'color: {{VALUE}}',
				],			
				'default' => '#444444'
			]
		);        

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'label' => __( 'Single Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .meta-posts span',
			]
		);	
		
		$this->add_control(
			'meta_icon_color',
			[
				'label' => __( 'Meta Post Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta-posts i' => 'color: {{VALUE}}',
				],			
				'default' => '#444444'
			]
		);        

		$this->add_control(
			'meta_icon_size',
			[
				'label' => __( 'Meta Post Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 40,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .meta-posts i ' => 'font-size:{{SIZE}}px',
				],
			]
		);

		
        $this->end_controls_section();       
        
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            echo"<div class='meta-posts'>";
            $post_date = get_the_time('j F Y');
            $post_author = $template->GetRelatedPostField("post_author");
            $post_views = get_post_meta($template->GetRelatedPostId(),"post_views_count",true);
            $post_comment = $template->GetRelatedPostField("comment_count");
            if($settings['active_meta_date'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['date_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>".$post_date."</span>"; }
            if($settings['active_meta_author'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['author_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>".$post_author."</span>"; }
            if($settings['active_meta_views'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['view_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>".$post_views." بازدید </span>"; }
            if($settings['active_meta_comment'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['comment_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>".$post_comment." دیدگاه </span>"; }
            echo"</div>";
        }
        else
        {
            echo"<div class='meta-posts'>";
            if($settings['active_meta_date'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['date_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>تاریخ ارسال نوشته</span>"; }
            if($settings['active_meta_author'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['author_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>نویسنده نوشته</span>"; }
            if($settings['active_meta_views'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['view_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>تعداد بازدید</span>"; }
            if($settings['active_meta_comment'] == 'yes'){ ?><?php \Elementor\Icons_Manager::render_icon( $settings['comment_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo"<span class='category'>تعداد دیدگاه</span>";    }         
            echo"</div>";
        }
    }
}