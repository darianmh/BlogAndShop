<?php
if (have_posts()):
    setPostViews(get_the_ID());
    ?>
    <?php while (have_posts()): the_post(); ?><?php global $product;
    $id = get_the_ID();
    $info = sigma_get_digital_product_info($id);
?>

<div class="fss_single_cart_area">
<?php global $sigma;
if ($sigma['single_product_full_width'] == 'enable') { ?>
    <div class="container"> <?php } else{ ?>
        <div class="container-fluid"> <?php } ?>
            <?php do_action('woocommerce_before_single_product'); ?>
            <div class="row">
                <div class="col-xl-7 col-lg-7 col-sm-7">
                    <div class="fss_single_breadcrumb">
                        <?php
                        $args = array(
                            'delimiter' => ' <i></i> ',
                            'home' => __('home', 'sigma-theme'));
                        woocommerce_breadcrumb($args);
                        ?>
                    </div>
                    <div class="fss_single_title_area">
                        <h1>
                            <?php echo the_title(); ?>
                        </h1>
                        <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>
                    </div>
                    <div class="fss_single_product_main_meta">
                        <div class="row">
                            <?php
                            global $sigma;
                            if ($sigma['sales_count_v4'] == 'block') {
                                ?>
                                <div class="col-xl-6 col-lg-6 col-sm-6">
                                    <div class="fss_single_sales_counter">
                                        <i class="fal fa-shopping-bag"></i>
                                        <div class="fss_single_sales_div">
                                            <span><b><?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?></b><?php echo __('Customer', 'sigma-theme') ?></span>
                                            <p>
                                                <?php echo __('Select This Products.', 'sigma-theme') ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                            <?php
                            global $sigma;
                            if ($sigma['price_count_v4'] == 'block') {
                                ?>
                                <div class="col-xl-6 col-lg-6 col-sm-6 npr">
                                    <div class="fss_single_price_holder">
                                        <i class="fal fa-tags"></i>
                                        <div class="fss_single_sales_div">
                                            <span><b><?php echo woocommerce_template_single_price(); ?></b></span>
                                            <p>
                                                <?php
                                                if ('' === $product->get_price() || 0 == $product->get_price()) {
                                                    echo '<div class="free-product_text"><p>' . __('Our gift Shop for you', 'sigma-theme') . '</p></div>';
                                                } else {
                                                    echo __('Price For This Product', 'sigma-theme');
                                                }
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="fss_single_products_small_meta">
                        <div class="row">
                            <?php
                            global $sigma;
                            if ($sigma['date_active_v4'] == 'block') {
                                ?>
                                <div class="col-xl-5 col-lg-5 col-sm-12">
                                    <div class="fss_single_products_small_meta_alone"><i
                                                class="fal fa-calendar-edit"></i><span> <?php echo __('Release date :', 'sigma-theme') ?> <b><?php the_time('j F Y '); ?></b></span>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php
                            global $sigma;
                            if ($sigma['update_active_v4'] == 'block') {
                                ?>
                                <div class="col-xl-5 col-lg-5 col-sm-12">
                                    <div class="fss_single_products_small_meta_alone"><i
                                                class="fal fa-calendar-exclamation"></i><span> <?php echo __('Update date', 'sigma-theme') ?> : 
                            <b><?php global $product;
                                echo $product->get_date_modified()->date_i18n('j F Y'); ?></b></span></div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="fss_single_products_btn_meta">
                        <?php
                        global $sigma;
                        if ($sigma['demo_btn_active_v4'] == 'block') {
                            ?>
                            <div class="fss_single_products_btn_demo">
                                <?php
                                $id = get_the_ID();
                                $info = sigma_get_digital_product_info($id);
                                if (!empty($info['product_preview'])) {
                                    ?>
                                    <a href="<?php echo $info['product_preview'] ?>" target="_blank"><i
                                                class="fal fa-eye"></i><?php echo __('View preview', 'sigma-theme') ?>
                                    </a>
                                <?php }

                                if (!empty($info['en_product_preview'])) { ?>
                                    <a class="dgs-en-demo" href="<?php echo $info['en_product_preview'] ?>"
                                       target="_blank"><i
                                                class="fal fa-eye"></i><?php echo __('View en preview', 'sigma-theme') ?>
                                    </a>
                                <?php } ?>
                            </div>
                        <?php } ?>
                        <?php
                        global $sigma;
                        if ($sigma['add_cart_active_v4'] == 'block') {

                            if ('' === $product->get_price() || 0 == $product->get_price() && $sigma['free_products_checkout'] == 'disable') {
                                $downloads = $product->get_downloads();

                                foreach ($downloads as $key => $each_download) {
                                    echo '<button class="single_add_to_cart_button button alt freedl_sgm"><i class="fal fa-link"></i><a href="' . $each_download["file"] . '">' . $each_download["name"] . '</a></button>';
                                }
                            } else {
                                do_action('woocommerce_single_product_summary');
                            }
                        } ?>
                    </div>

                    <?php
                    global $sigma;
                    if ($sigma['badge_right_active_v4'] == 'block') {
                        ?>
                        <div class="fss_single_products_badges">
                            <ul>
                                <?php
                                $id = get_the_ID();
                                $medals = sigma_get_product_medals($id);
                                if (false != $medals) {
                                    foreach ($medals as $medal) {
                                        ?>
                                        <li id="hexagon" class="badge_singel pink_badge"><img
                                                    src="<?php echo $medal['medal_pic'] ?>"
                                                    alt="<?php echo $medal['medal_name'] ?>"><span
                                                    class="badge-tooltip"><?php echo $medal['medal_name'] ?></span></li>
                                        <?php
                                    }
                                }
                                ?>
                            </ul>
                        </div>
                    <?php } ?>

                </div>
                <div class="col-xl-5 col-lg-5 col-sm-5">
                    <?php
                    global $post, $product;
                    if ($product->is_on_sale() && $product->is_type('semplae')) { ?>
                        <div class="fss_single_off_discount">
                            <?php woocommerce_show_product_loop_sale_flash(); ?>
                        </div>
                    <?php } ?>
                    <div class="fss_single_product_image_gallery">
                        <div id="product-<?php
                        the_ID();
                        ?>" <?php
                        wc_product_class('', $product);
                        ?>>

                            <?php
                            defined('ABSPATH') || exit;

                            // Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
                            if (!function_exists('wc_get_gallery_image_html')) {
                                return;
                            }

                            global $product;

                            $columns = apply_filters('woocommerce_product_thumbnails_columns', 4);
                            $post_thumbnail_id = $product->get_image_id();
                            $wrapper_classes = apply_filters('woocommerce_single_product_image_gallery_classes', array(
                                'woocommerce-product-gallery',
                                'woocommerce-product-gallery--' . ($product->get_image_id() ? 'with-images' : 'without-images'),
                                'woocommerce-product-gallery--columns-' . absint($columns),
                                'images'
                            ));
                            ?>
                            <div class="<?php
                            echo esc_attr(implode(' ', array_map('sanitize_html_class', $wrapper_classes)));
                            ?>" data-columns="<?php
                            echo esc_attr($columns);
                            ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
                                <figure class="woocommerce-product-gallery__wrapper">
                                    <?php
                                    if ($product->get_image_id()) {
                                        $html = wc_get_gallery_image_html($post_thumbnail_id, true);
                                    } else {
                                        $html = '<div class="woocommerce-product-gallery__image--placeholder">';
                                        $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src('woocommerce_single')), esc_html__('Awaiting product image', 'woocommerce'));
                                        $html .= '</div>';
                                    }

                                    echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped

                                    do_action('woocommerce_product_thumbnails');
                                    ?>
                                </figure>
                            </div>

                        </div>

                    </div>
                    <div class="fss_single_product_video_preview">
                        <?php
                        $mid_var = get_post_meta($post->ID, 'video', true);
                        if (isset($mid_var) && !empty($mid_var)):
                            ?>

                            <a href="javascript:void(0);" data-toggle="modal" data-target="#videomodal"
                               data-toggle="modal" data-target="#videomodal" class="fss-video-demo"><i
                                        class="fal fa-play"></i><?php echo __('Video Preview ', 'sigma-theme') ?></a>

                        <?php endif; ?>

                        <div id="videomodal" class="modal fade" role="dialog">
                            <div class="modal-dialog modal-lg modal-dialog-centered">

                                <!-- Modal content-->
                                <div class="modal-content modal-top">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title"><?php echo __('Video Preview', 'sigma-theme') ?><?php the_title(); ?></h4>
                                    </div>
                                    <div class="modal-body">

                                        <video width="100%" controls>
                                            <source src="<?php
                                            echo get_post_meta($post->ID, 'video', true);
                                            ?>" type="video/mp4">
                                        </video>


                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="fss_single_tab_area dgs_single_products_tabs <?php global $product;
    if ($product->is_on_sale()) {
        echo 'is-sale';
    } ?>">
    <nav>
        <?php
        if ($sigma['signle_product_v2_atcive_default_tab'] == 'enable') {
            do_action('woocommerce_after_single_product_summary');
        } else {
            ?>
            <div class="fss_single_products_tabs_inline nav nav-tabs" id="nav-tab" role="tablist">

                <a class="nav-item nav-link active" id="nav-content-tab" data-toggle="tab" href="#nav-content"
                   role="tab" aria-controls="nav-content" aria-selected="true"><i
                            class="fal fa-align-right"></i><?php echo __('Product details', 'sigma-theme') ?></a>
                <?php
                global $sigma;
                if ($sigma['comment_tab_active_v4'] == 'block') {
                    ?>
                    <a class="nav-item nav-link" id="nav-comment-tab" data-toggle="tab" href="#nav-comment" role="tab"
                       aria-controls="nav-comment" aria-selected="false"><i
                                class="fal fa-comment-alt-smile"></i><?php echo __('User Comments', 'sigma-theme') ?>
                    </a>
                <?php } ?>
                <?php
                global $sigma;
                if ($sigma['support_tab_active_v4'] == 'block') {
                    ?>
                    <a class="nav-item nav-link" id="nav-morecontent-tab" data-toggle="tab" href="#nav-morecontent"
                       role="tab" aria-controls="nav-morecontent" aria-selected="false"><i
                                class="fal fa-phone-square"></i><?php echo __('Product Support', 'sigma-theme') ?></a>

                <?php } ?>
                <?php
                global $sigma;
                if (class_exists('WeDevs_Dokan') && $sigma['seller_tab_active_v4'] == 'block') {
                    ?>
                    <a class="nav-item nav-link" id="nav-seller-tab" data-toggle="tab" href="#nav-seller" role="tab"
                       aria-controls="nav-seller" aria-selected="false"><i
                                class="fal fa-store"></i><?php echo __('Seller information', 'sigma-theme') ?></a>
                <?php } ?>
            </div>
        <?php } ?>
        <div class="fss_single_product_nav_icons">
            <?php
            global $sigma;
            if ($sigma['wishlist_nav_active_v4'] == 'block') {
                ?>
                <div class="fss_add_to_wishlist">
                    <?php
                    if (!sigma_is_in_wishlist($post->ID)) {
                        ?>
                        <div class="edc_bookmark_meta_single">
                            <a class="sigma-add-to-wishlist" data-product-id="<?php echo $post->ID ?>"><i class="far fa-heart"></i></a>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="edc_bookmark_meta_single">
                            <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank" class="sigma-add-to-wishlist-added" data-product-id="<?php echo $post->ID ?>"><i
                                        class="far fa-heart"></i></a></div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
            global $sigma;
            if ($sigma['share_nav_active_v4'] == 'block') {
                ?>
                <div class="edc_bookmark_meta_single edc_share_meta_single">
                    <a href="javascript:void(0);"><i class="far fa-share-alt-square"></i></a>
                    <div class="edd_share_btn_more">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink(); ?>"><i
                                    class="fab fa-facebook"></i></a>
                        <a href="https://telegram.me/share/url?url=<?php echo get_permalink(); ?>"><i
                                    class="fab fa-telegram"></i></a>
                        <a href="https://twitter.com/intent/tweet?text=<?php echo get_permalink(); ?>"><i
                                    class="fab fa-twitter"></i></a>
                        <a href="https://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>"><i
                                    class="fab fa-pinterest"></i></a>
                    </div>
                </div>
                <?php
            }
            global $sigma;
            if ($sigma['url_nav_active_v4'] == 'block') {
                ?>
                <div class="fss_short_url_single_products">
                    <a href="javascript:void(0);"><i class="far fa-link">
                            <div class="fss_single_products_short_url">
                                <input type="text" class="fss_ulink"
                                       value="<?php bloginfo('url'); ?>/?p=<?php the_ID(); ?>" id="myInput">
                                <i class="fal fa-file copy" onclick="myFunction()" aria-hidden="true"></i>
                            </div>
                        </i></a>
                </div>

                <?php
            }
            ?>

        </div>
    </nav>

<?php global $sigma;
if ($sigma['single_product_full_width'] == 'enable') { ?>
    <div class="container"> <?php } else{ ?>
        <div class="container-fluid"> <?php } ?>

            <?php if ($sigma['signle_product_v2_atcive_default_tab'] == 'disable') { ?>

                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-sm-12">
                        <div class="fss_signle_product_tabs">
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-content" role="tabpanel"
                                     aria-labelledby="nav-content-tab">
                                    <div class="content">
                                        <?php the_content(); ?>
                                    </div>
                                </div>
                                <?php
                                global $sigma;
                                if ($sigma['comment_tab_active_v4'] == 'block') {
                                    ?>
                                    <div class="tab-pane fade" id="nav-comment" role="tabpanel"
                                         aria-labelledby="nav-comment-tab">
                                        <div class="edc_single_comments_lists border_line_left">
                                            <div class="edc_commentes_roles">
                                                <p>
                                                    <?php global $sigma;
                                                    echo $sigma['role_post_content']; ?>
                                                </p>
                                            </div>
                                            <div id="reviews" class="woocommerce-Reviews">
                                                <?php if (get_option('woocommerce_review_rating_verification_required') === 'no' || wc_customer_bought_product('', get_current_user_id(), $product->get_id())) : ?>
                                                    <div id="review_form_wrapper">
                                                        <div id="review_form">
                                                            <?php
                                                            $commenter = wp_get_current_commenter();
                                                            $comment_form = array(
                                                                'title_reply_to' => esc_html__('Leave a Reply to %s', 'woocommerce'),
                                                                'title_reply_before' => '<span id="reply-title" class="comment-reply-title">',
                                                                'title_reply_after' => '</span>',
                                                                'comment_notes_after' => '',
                                                                'label_submit' => esc_html__('Submit', 'woocommerce'),
                                                                'logged_in_as' => '',
                                                                'comment_field' => '',
                                                            );

                                                            $name_email_required = (bool)get_option('require_name_email', 1);
                                                            $fields = array(
                                                                'author' => array(
                                                                    'label' => __('Name', 'woocommerce'),
                                                                    'type' => 'text',
                                                                    'value' => $commenter['comment_author'],
                                                                    'required' => $name_email_required,
                                                                ),
                                                                'email' => array(
                                                                    'label' => __('Email', 'woocommerce'),
                                                                    'type' => 'email',
                                                                    'value' => $commenter['comment_author_email'],
                                                                    'required' => $name_email_required,
                                                                ),
                                                            );

                                                            $comment_form['fields'] = array();

                                                            foreach ($fields as $key => $field) {
                                                                $field_html = '<p class="comment-form-' . esc_attr($key) . '">';
                                                                $field_html .= '<label for="' . esc_attr($key) . '">' . esc_html($field['label']);

                                                                if ($field['required']) {
                                                                    $field_html .= '&nbsp;<span class="required">*</span>';
                                                                }

                                                                $field_html .= '</label><input id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" type="' . esc_attr($field['type']) . '" value="' . esc_attr($field['value']) . '" size="30" ' . ($field['required'] ? 'required' : '') . ' /></p>';

                                                                $comment_form['fields'][$key] = $field_html;
                                                            }

                                                            $account_page_url = wc_get_page_permalink('myaccount');
                                                            if ($account_page_url) {
                                                                /* translators: %s opening and closing link tags respectively */
                                                                $comment_form['must_log_in'] = '<p class="must-log-in">' . sprintf(esc_html__('You must be %1$slogged in%2$s to post a review.', 'woocommerce'), '<a href="' . esc_url($account_page_url) . '">', '</a>') . '</p>';
                                                            }

                                                            if (wc_review_ratings_enabled()) {
                                                                $comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating">' . esc_html__('Your rating', 'woocommerce') . '</label><select name="rating" id="rating" required>
                                    						<option value="">' . esc_html__('Rate&hellip;', 'woocommerce') . '</option>
                                    						<option value="5">' . esc_html__('Perfect', 'woocommerce') . '</option>
                                    						<option value="4">' . esc_html__('Good', 'woocommerce') . '</option>
                                    						<option value="3">' . esc_html__('Average', 'woocommerce') . '</option>
                                    						<option value="2">' . esc_html__('Not that bad', 'woocommerce') . '</option>
                                    						<option value="1">' . esc_html__('Very poor', 'woocommerce') . '</option>
                                    					</select></div>';
                                                            }

                                                            $comment_form['comment_field'] .= '<p class="comment-form-comment"><label for="comment">' . esc_html__('Your review', 'woocommerce') . '&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>';

                                                            comment_form(apply_filters('woocommerce_product_review_comment_form_args', $comment_form));
                                                            ?>
                                                        </div>
                                                    </div>
                                                <?php else : ?>
                                                    <p class="woocommerce-verification-required"><?php esc_html_e('Only logged in customers who have purchased this product may leave a review.', 'woocommerce'); ?></p>
                                                <?php endif; ?>

                                                <div class="clear"></div>
                                            </div>
                                        </div>
                                        <div class="edc_single_comments_lists border_line_left">
                                            <h3><?php _e('User comments', 'sigma-theme'); ?></h3>
                                            <span class="edc_comments_number_total"><?php comments_popup_link( __('No Comment', 'sigma-theme'), __('1 Comment', 'sigma-theme'), __('% Comments', 'sigma-theme'), __('Comments are Closed', 'sigma-theme') ); ?></span>
                                            <small>User Comments</small>
                                            <ol class="commentlist">
                                                <?php
                                                global $postid;
                                                $postid = get_the_ID();
                                                //Gather comments for a specific page/post 
                                                $comments = get_comments(array(
                                                    'post_id' => $postid,
                                                    'status' => 'approve' //Change this to the type of comments to be displayed
                                                ));

                                                //Display the list of comments
                                                wp_list_comments(array(
                                                    'per_page' => 10, //Allow comment pagination
                                                    'reverse_top_level' => false //Show the latest comments at the top of the list
                                                ), $comments);

                                                ?>
                                            </ol>
                                        </div>
                                    </div>
                                <?php } ?>
                                <?php
                                global $sigma;
                                if ($sigma['support_tab_active_v4'] == 'block') {
                                    ?>
                                    <div class="tab-pane fade" id="nav-morecontent" role="tabpanel"
                                         aria-labelledby="nav-morecontent-tab">
                                        <div class="support_tab_content">
                                            <div class="tab_title_bar">
                                                <?php the_excerpt(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                <?php
                                global $sigma;
                                if (class_exists('WeDevs_Dokan') && $sigma['seller_tab_active_v4'] == 'block') {
                                    $vendor_id = get_post_field('post_author', get_the_id());
                                    $vendor = new WP_User($vendor_id);
                                    $store_url = dokan_get_store_url($vendor_id);
                                    ?>
                                    <div class="tab-pane fade" id="nav-seller" role="tabpanel"
                                         aria-labelledby="nav-seller-tab">
                                        <div class="dgs_seller_tab_content fss_seller_tab_content">
                                            <div class="dgs_seller_meta">
                                                <a href="<?php echo $store_url; ?>"><i
                                                            class="fal fa-store"></i></a>
                                            </div>
                                            <div class="dgs_seller_name">
                                                <a href="<?php echo $store_url; ?>">
                                                    <h2><?php echo(get_the_author_meta('display_name')); ?> </h2>
                                                </a>
                                                <span> 
                                        <?php
                                        global $wp_query;
                                        $registered = date_i18n("M Y", strtotime(get_the_author_meta('user_registered', $wp_query->queried_object_id)));
                                        echo ' '. __('Register from', 'sigma-theme') .' ' . $registered;
                                        ?>
                                   </span>
                                                <small><?php echo(get_the_author_meta('description')); ?></small>
                                                <div class="dgs_seller_social">
                                                    <ul>
                                                        <li><a href="<?php echo(get_the_author_meta('user_url')); ?>"><i
                                                                        class="fal fa-globe"></i></a></li>
                                                        <li>
                                                            <a href="mailto:<?php echo(get_the_author_meta('user_email')); ?>"><i
                                                                        class="fal fa-envelope"></i></a></li>
                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-sm-12 npl npr">
                        <div class="fss_single_product_sidebar" id="fss_side_fixed">
                            <div class="fss_single_products_buy">
                                <div class="row">
                                    <?php
                                    global $sigma;
                                    if ($sigma['salles_sidebar_active_v4'] == 'block') {
                                        ?>
                                        <div class="col-xl-6 col-lg-6 col-sm-6">
                                            <div class="fss_single_product_sidebar_meta">
                                                <div class="fss_single_product_sidebar_meta_alone">
                                                    <i class="fal fa-shopping-bag"></i>
                                                    <span><?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?></span>
                                                    <small><?php echo __('Successful sale', 'sigma-theme') ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                    global $sigma;
                                    if ($sigma['price_sidebar_active_v4'] == 'block') {
                                        ?>
                                        <div class="col-xl-6 col-lg-6 col-sm-6 npl">
                                            <div class="fss_single_product_sidebar_meta bnone">
                                                <div class="fss_single_product_sidebar_meta_alone">
                                                    <i class="fal fa-tags"></i>
                                                    <span><b><?php echo woocommerce_template_single_price(); ?></b></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>

                                </div>
                            </div>
                            <?php echo get_product_countdown_single($id) ; ?>    
                            <?php
                            global $sigma;
                            if ($sigma['medal_sidebar_active_v4'] == 'block') {
                                ?>
                                <div class="fss_single_products_badges">
                                    <ul>
                                        <?php
                                        $id = get_the_ID();
                                        $medals = sigma_get_product_medals($id);
                                        if (false != $medals) {
                                            foreach ($medals as $medal) {
                                                ?>
                                                <li id="hexagon" class="badge_singel pink_badge"><img
                                                            src="<?php echo $medal['medal_pic'] ?>"
                                                            alt="<?php echo $medal['medal_name'] ?>"><span
                                                            class="badge-tooltip"><?php echo $medal['medal_name'] ?></span>
                                                </li>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </ul>
                                </div>
                            <?php } ?>

                            <?php
                            global $sigma;
                            if ($sigma['license_sidebar_active_v4'] == 'block') {
                                ?>
                                <div class="fss_single_products_notes">
                                    <?php global $sigma;
                                    echo $sigma['license_text_sidebar_v4']; ?>
                                </div>
                            <?php } ?>

                            <div class="fss_single_products_btn_buy fss_single_products_btn_buy_sidebar fss_single_products_btn_meta">
                                <?php
                                global $sigma;
                                if ($sigma['addcart_sidebar_active_v4'] == 'block') {
                                    ?>

                                    <?php
                                    if ('' === $product->get_price() || 0 == $product->get_price() && $sigma['free_products_checkout'] == 'disable') {
                                        $downloads = $product->get_downloads();

                                        foreach ($downloads as $key => $each_download) {
                                            echo '<button class="single_add_to_cart_button button alt freedl_sgm"><a href="' . $each_download["file"] . '">' . $each_download["name"] . '</a></button>';
                                        }
                                    } else {
                                        do_action('woocommerce_single_product_summary');
                                    }
                                    ?>
                                <?php } ?>

                                <p><?php global $sigma;
                                    echo $sigma['after_addcart_text_v4']; ?></p>
                            </div>


                            <?php
                            global $sigma;
                            if ($sigma['meta_sidebar_active_v4'] == 'block') {
                                ?>

                                <div class="fss_single_products_attributes">
                                    <ul>

                                        <li>
                                            <i class="fal fa-eye"></i><span><?php echo __('veiws: ', 'sigma-theme') ?> </span><b><?php echo getPostViews(get_the_ID()); ?></b>
                                        </li>

                                        <?php if (!empty($info['product_size'])) { ?>
                                            <li>
                                                <i class="fal fa-download"></i><span><?php echo __('File Size: ', 'sigma-theme') ?> </span><b><?php echo $info['product_size'] ?></b>
                                            </li>
                                        <?php } ?>

                                        <?php if (!empty($info['product_type'])) { ?>
                                            <li>
                                                <i class="fal fa-text"></i><span><?php echo __('File Type: ', 'sigma-theme') ?> </span><b><?php echo $info['product_type'] ?></b>
                                            </li>
                                        <?php } ?>

                                        <li>
                                            <i class="fal fa-comments-alt"></i><span><?php echo __('Comment Count : ', 'sigma-theme') ?> </span><b><?php comments_number('0', ' 1 ', ' % '); ?>
                                                <?php _e('Comment', 'sigma-theme'); ?> </b></li>

                                        <li>
                                            <i class="fal fa-star"></i><span><?php echo __('Ratting Averag : ', 'sigma-theme') ?> </span><b><?php echo(get_post_meta(get_the_ID(), '_wc_average_rating', true)); ?>
                                              <?php _e('From 5 ratting', 'sigma-theme'); ?></b></li>

                                        <?php if (!empty($info['product_version'])) { ?>
                                            <li>
                                                <i class="fal fa-desktop"></i><span><?php echo __('Product Version: ', 'sigma-theme') ?> </span><b><?php echo $info['product_version'] ?></b>
                                            </li>
                                        <?php } ?>

                                        <?php if (!empty($info['product_include'])) { ?>
                                            <li>
                                                <i class="fal fa-text"></i><span><?php echo __('Include File: ', 'sigma-theme') ?> </span><b><?php echo $info['product_include'] ?></b>
                                            </li>
                                        <?php } ?>

                                        <?php if (!empty($info['product_doc'])) { ?>
                                            <li>
                                                <i class="fal fa-info-circle"></i><span><?php echo __('File Documentation: ', 'sigma-theme') ?> </span><b><?php echo $info['product_doc'] ?></b>
                                            </li>
                                        <?php } ?>

                                        <?php if (!empty($info['product_license'])) { ?>
                                            <li>
                                                <i class="fal fa-key"></i><span><?php echo __('Product License: ', 'sigma-theme') ?> </span><b><?php echo $info['product_license'] ?></b>
                                            </li>

                                        <?php } ?>
                                        <?php if (!empty($info['product_compatibility'])) { ?>
                                            <li>
                                                <i class="fal fa-exchange-alt"></i><span><?php echo __('Compatibility: ', 'sigma-theme') ?> </span><b><?php echo $info['product_compatibility'] ?></b>
                                            </li>
                                        <?php } ?>

                                    </ul>
                                </div>

                            <?php }

                            global $sigma;
                            if ($sigma['tags_sidebar_active_v4'] == 'block') {
                                ?>

                                <div class="fss_single_products_tags">
                                    <ul>
                                        <li>
                                            <?php
                                            $terms = get_the_terms(get_the_ID(), 'product_tag');
                                            $terms_count = count($terms);
                                            foreach ($terms as $key => $term) {
                                                $sperator = $key !== ($terms_count - 1) ? ' ' : ' ';
                                                echo "<a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a>";
                                            }
                                            ?>
                                        </li>
                                    </ul>
                                </div>

                            <?php } ?>
                        </div>
                    </div>
                </div>

            <?php } ?>

            <?php if ($sigma['related_active_v4'] == 'block') { ?>
                <div class="fss_related_products">
                    <div class="tab_title_bar">
                        <h2>محصولات مرتبط</h2>
                        <small>Related Products</small>
                    </div>
                    <div id="related_dgs" class="owl-carousel">
                        <?php
                        $trmids = wp_get_post_terms($post->ID, 'product_cat');
                        $trmarray = array();
                        foreach ($trmids as $v) {
                            $trmarray[] = $v->term_id;
                        }

                        $arms = array(
                            'post_type' => 'product',
                            'posts_per_page' => '9',
                            'order' => 'DESC',
                            'post_status' => 'publish',
                            'post__not_in' => array($post->ID),
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'product_cat',
                                    'terms' => $trmarray,
                                ),
                            )
                        );
                        $the_query = new WP_Query($arms);
                        if ($the_query->have_posts()) : ?>
                            <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                                <li class="filedemo_gird_products_warp sigma-wc-product product filedemo_gird_products_archive">
                                    <div class="sigma-wc-product-inner fss_card_products darkeble">
                                        <div class="fss_card_products_photo">
                                            <div class="sigma-wc-product-popop">
                                                <a class="sigma-wc-product-popop--link"
                                                   href="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>"><i
                                                            class="fa fa-eye" aria-hidden="true"></i></a>
                                            </div>
                                            <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail('blog'); ?></a>
                                            <div class="sigma-wc-products-badge">
                                                <?php woocommerce_show_product_loop_sale_flash(); ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-9">
                                                <div class="fss_card_products_price">
                                                    <ul>
                                                        <li>
                                                            <?php woocommerce_template_single_price(); ?>
                                                        </li>

                                                        <?php
                                                        $terms = get_the_terms(get_the_ID(), 'product_cat');
                                                        $terms_count = count($terms);

                                                        if ($terms_count > 0) {
                                                            foreach ($terms as $key => $term) {
                                                                $sperator = $key !== ($terms_count - 1) ? ' , ' : '';
                                                                echo "<li><a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a></li>";
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="npr npl col-3">
                                                <div class="fss_card_products_sale">
                                                    <i class="fal fa-shopping-basket"></i>
                                                    <?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="fss_card_products_seo">

                                            <a href="<?php the_permalink(); ?>"><h2><?php the_title(); ?></h2>
                                                <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small></a>

                                            <p>
                                                <?php echo wp_trim_words(get_the_content(), 40, '...'); ?>
                                            </p>

                                        </div>
                                        <div class="fss_card_products_seller">
                                            <i class="fal fa-store"></i>
                                            <h3><?php $user_author = get_the_author_meta('display_name');
                                                echo $user_author ?></h3>
                                            <span><?php echo author_description(get_the_author_meta('description'), 7); ?></span>
                                        </div>
                                        <div class="fss_card_products_buy">
                                            <?php
                                            $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fal fa-shopping-bag"></i>'. __('Buy product', 'sigma-theme') .'</a>';
                                            echo $price;
                                            ?>
                                        </div>
                                    </div>
                                </li>

                            <?php endwhile; ?>
                            <?php wp_reset_postdata(); ?>


                        <?php else : ?>
                            <p class="nopostdata"><?php _e('There are no products to display.', 'sigma-theme'); ?> </p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>

    <script>
        $(window).scroll(() => {
            topOfFooter = $('.footer-sgm-main').position().top;
            scrollDistanceFromTopOfDoc = $(document).scrollTop() + 1350;
            scrollDistanceFromTopOfFooter = scrollDistanceFromTopOfDoc - topOfFooter;

            if (scrollDistanceFromTopOfDoc > topOfFooter) {
                $('.fss_fix_show').css('opacity', 0);
            } else {
                $('.fss_fix_show').css('opacity', 1);
            }
        });
    </script>
<?php endwhile; ?>
<?php endif; ?>