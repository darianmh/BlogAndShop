<!doctype html>
<html dir="rtl" lang="fa-IR">
<head>
<meta charset="utf-8">
<title> <?php echo ot_get_option("title"); ?> | <?php echo ot_get_option("description"); ?></title>
<meta name="description" content="<?php echo ot_get_option("description"); ?>">
<meta name="keywords" content="<?php echo ot_get_option("keywords"); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
<link href="<?php bloginfo('template_url')?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="icon" href="<?php echo ot_get_option("favicon"); ?>" type="image/x-icon" />
<link href="<?php bloginfo('template_url')?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/sigma.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/app-sigma.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/style.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url'); ?>/css/menu.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/responsive.css" rel="stylesheet" type="text/css">


<style>.crunchify-social { display: <?php echo ot_get_option("socials_share_page"); ?>; }html { padding-top: 0 !important;}.demo:hover { background: <?php echo ot_get_option("demo_bg_product_hover"); ?> !important}
.newslleter{background:<?php echo ot_get_option("widget_newslater_back"); ?>}
a.single:hover { background: #333; }.auther:hover { background: <?php echo ot_get_option("bg_cpright_hover"); ?>; }
.um-form{padding:170px 40px 40px;background:url(<?php echo ot_get_option("login_image"); ?>)}
.cartfix , .header-cart-count{<?php echo ot_get_option("cart_poss_fix"); ?>:15px !important;background:<?php echo ot_get_option("bg_fix_cart_number"); ?>; color:<?php echo ot_get_option("fix_cart_number"); ?> !important;}
.login { padding: 8px 21px 8px 32px; }.topbutton:hover{background: <?php echo ot_get_option("bg_backtop_hover"); ?>}
p.topmail a { color: #666; letter-spacing: -0.5px; }
span.wpcf7-not-valid-tip { direction: rtl; } .use-floating-validation-tip span.wpcf7-not-valid-tip { left: auto; right: 20%; } span.wpcf7-list-item { margin: 0 1em 0 0; }
.dokan-import-export-header { margin-top: 30px; }
#loading{ position: absolute; top: 10%; left: 45%; opacity: 1; display: none; } .dokan-ajax-search-category{ border:none; background-color: #eeeeee; width: 90px; height: auto; padding-left: 3px; } .ajaxsearchform .input-group-addon{ padding: 0px; } .site-header .widget_dokna_product_search { max-width: 70%; float: right; }
body { background:<?php echo ot_get_option("body_back"); ?> !important;background: url(<?php echo ot_get_option("body_image"); ?>);}.social-top {display: <?php echo ot_get_option("socials"); ?> }
h1, h2, h3, h4, h5, h6, h7 { font-family:<?php echo ot_get_option("head_font"); ?> }p, em, div { font-family:<?php echo ot_get_option("body_font"); ?>} li { font-family:<?php echo ot_get_option("lists_font"); ?>}
</style>
<!--  jQuery 1.7+  -->
<script src="<?php bloginfo('template_url')?>/js/jquery-1.9.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="<?php bloginfo('template_url')?>/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

<?php wp_head(); ?>
<div style="display:<?php echo ot_get_option("socials_box"); ?>" class="socials_box">
<div style="display:<?php echo ot_get_option("googleplus_show"); ?>" class="google-box"><a href="<?php echo ot_get_option("googleplus"); ?>"><i class="fa fa-google-plus"></i></a></div>
<div style="display:<?php echo ot_get_option("telegram_show"); ?>" class="telegram-box"><a href="<?php echo ot_get_option("telegram"); ?>"><i class="fa fa-telegram"></i></a></div>
<div style="display:<?php echo ot_get_option("instagram_show"); ?>" class="instagram-box"><a href="<?php echo ot_get_option("instagram"); ?>"><i class="fa fa-instagram"></i></a></div>
<div style="display:<?php echo ot_get_option("facebook_show"); ?>" class="facebook-box"><a href="<?php echo ot_get_option("facebook"); ?>"><i class="fa fa-facebook"></i></a></div>
<div style="display:<?php echo ot_get_option("twitter_show"); ?>" class="twitter-box"><a href="<?php echo ot_get_option("twitter"); ?>"><i class="fa fa-twitter"></i></a></div>
</div>
<div class="cart-shop" style="display:<?php echo ot_get_option("cart_fix"); ?>">
	<a href="<?php bloginfo('url')?>/cart" class="cartfix" style="background:<?php echo ot_get_option("bg_fix_cart"); ?>" ><i class="fa fa-shopping-cart"></i></a>
	<a href="<?php echo WC()->cart->get_cart_url(); ?>"></a>
   <i class="your-icon-class"> </i>
   <div class="header-cart-count">
      <?php echo WC()->cart->get_cart_contents_count(); ?>
   </div>
</div>
</head>

<body>
<div id="main"> 
<a href="#"><div id="black"></div><!--black--></a>
<div class="header" style="background:<?php echo ot_get_option("topbar_back"); ?>">
<div class="container">
	<div class="top-bar">
		<div class="top-right col-lg-8 col-sx-12" style="font-family: <?php echo ot_get_option("topmenu_font"); ?>;font-size:<?php echo ot_get_option("size_topbar"); ?>">
<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>


			</div>


		<div class="top-left">
			<div class="phone-top">
				<p class="topmail" style="font-family: <?php echo ot_get_option("phone_font"); ?>;font-size:<?php echo ot_get_option("phone_size"); ?>" ><a href="tel://<?php echo ot_get_option("phone"); ?>"><?php echo ot_get_option("phone"); ?></a><i class="fa-phone"></i> <a href="mailto:<?php echo ot_get_option("email_head"); ?> "><?php echo ot_get_option("email_head"); ?></a> <i class="fa-envelope"></i></p>
			</div>
			
		</div>
		</div>

				</div>
				</div>


			<div class="clear"></div>

<div class="head" style="background:<?php echo ot_get_option("head_back"); ?>">


   <div class="container">


<nav class="navbar navbar-light navbar-xs ">
 <button  id="xsmenu" type="button" class="navbar-toggle menu-koochak"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
 <div class="sub" id="myNavbar1">
 <ul class="top-menu-xs">
<?php wp_nav_menu( array( 'theme_location' => 'mobile_menu' ) ); ?>
 </ul>
 <!--nav navbar-nav-->
 </div>
 </nav>
		<div class="logo col-lg-3 col-sx-12">
		<a href="<?php echo ot_get_option("logo_link"); ?>"><img src="<?php echo ot_get_option("logo"); ?>" alt="logo" ></a>


	</div>
		<div class="search col-lg-5 col-sx-12">

<?php get_template_part('searchform'); ?>

	</div>

	<div class="panel-mobile">
	
	<?php if ( is_user_logged_in() ) { ?>
		<div class="login-mobile" style="background:<?php echo ot_get_option("login_back"); ?>">
			<a style="color:<?php echo ot_get_option("color_login"); ?>;font-family: <?php echo ot_get_option("panel_font"); ?>;font-size:<?php echo ot_get_option("panel_size"); ?>;" href="<?php echo wp_logout_url( get_permalink() ); ?> " target="_blank"><i class="fa-user-o"></i></a>
						</div>
					<div class="register-mobile" style="background:<?php echo ot_get_option("reg_back"); ?>">
			<a style="color:<?php echo ot_get_option("color_reg"); ?>;font-family: <?php echo ot_get_option("panel_font"); ?>;font-size:<?php echo ot_get_option("panel_size"); ?>" href="<?php bloginfo('url')?>/account" target="_blank"><i class="fa-user-plus"></i></a>
		</div>
		
		<?php } else { ?>
		<div class="login-mobile" style="background:<?php echo ot_get_option("login_back"); ?>">
			<a style="color:<?php echo ot_get_option("color_login"); ?>;font-family: <?php echo ot_get_option("panel_font"); ?>;font-size:<?php echo ot_get_option("panel_size"); ?>;" href="<?php echo ot_get_option("login_link"); ?>" target="_blank"><i class="fa-user-o"></i></a>
						</div>
					<div class="register-mobile" style="background:<?php echo ot_get_option("reg_back"); ?>">
			<a style="color:<?php echo ot_get_option("color_reg"); ?>;font-family: <?php echo ot_get_option("panel_font"); ?>;font-size:<?php echo ot_get_option("panel_size"); ?>" href="<?php echo ot_get_option("register_link"); ?>" target="_blank"><i class="fa-user-plus"></i></a>
		</div><?php } ?>



	</div>
	
	
	<div class="panel-top">
	
	<?php if ( is_user_logged_in() ) { ?>

	<div class="top-user-menu">
	 
	 <div class="dropdown top-user-menu-right">
  <button class="dropbtn1">		<a href="<?php bloginfo('url')?>/account" target="_blank"><i class="fa fa-user-o"></i> <?php global $current_user;
      get_currentuserinfo();
      echo '' . $current_user->display_name . "\n";
?> | موجودی : <?php echo woo_wallet()->wallet->get_wallet_balance(get_current_user_id()); ?> </a>

</button>
  <div class="dropdown-content1">
 <?php wp_nav_menu( array( 'theme_location' => 'users-top-menu' ) ); ?>

  </div>
</div>

			<div class="top-user-menu-left">
	
	<a href="<?php bloginfo('url')?>/logout"> <i class="fa fa-power-off"></i> خروج </a>
		</div>
		</div>
			</div>

				<div class="user-top">
		<?php } else { ?>
			<a class="login" style="position: relative; top: 12px;background:<?php echo ot_get_option("login_back"); ?>; color:<?php echo ot_get_option("color_login"); ?>;font-family: <?php echo ot_get_option("panel_font"); ?>;font-size:<?php echo ot_get_option("panel_size"); ?>;" href="<?php echo ot_get_option("login_link"); ?>" target="_blank"><i class="fa-group"></i>وارد شوید</a>
			<a class="register" style="position: relative; top: 12px;background:<?php echo ot_get_option("reg_back"); ?>;color:<?php echo ot_get_option("color_reg"); ?>;font-family: <?php echo ot_get_option("panel_font"); ?>;font-size:<?php echo ot_get_option("panel_size"); ?>" href="<?php echo ot_get_option("register_link"); ?>" target="_blank"><i class="fa-user-plus"></i>ثبت نام کنید </a>

		
		<?php } ?>



	</div>
	</div>

	</div>

	

<div class="menus" style="background:<?php echo ot_get_option("menu_back"); ?>">
<div class="container">

		<div class="main-menu" style="background:<?php echo ot_get_option("menu_back"); ?> ; font-size:<?php echo ot_get_option("menu_size"); ?>;font-family: <?php echo ot_get_option("font_menu"); ?>"> 

				<nav class="navbar navbar-inverse">
  <div class="container-fluid">


    <div class="collapse navbar-collapse" id="myNavbar">
<?php wp_nav_menu( array( 'theme_location' => 'extra-menu' ) ); ?>
    </div>

  </div>
</nav>	
					</div>

					<div class="social-top">
				
				<a href="<?php echo ot_get_option("facebook"); ?>" style="display:<?php echo ot_get_option("facebook_show"); ?>" ><i class="fa-facebook sigma-facebook"></i></a>
				<a href="<?php echo ot_get_option("instagram"); ?>" style="display:<?php echo ot_get_option("instagram_show"); ?>" ><i class="fa-instagram sigma-insta"></i></a>
				<a href="<?php echo ot_get_option("telegram"); ?>" style="display:<?php echo ot_get_option("telegram_show"); ?>" ><i class="fa-paper-plane sigma-telegram"></i></a>
				<a href="<?php echo ot_get_option("googleplus"); ?>" style="display:<?php echo ot_get_option("googleplus_show"); ?>" ><i class="fa-google-plus sigma-googleplus"></i></a>
				<a href="<?php echo ot_get_option("twitter"); ?>" style="display:<?php echo ot_get_option("twitter_show"); ?>" ><i class="fa-twitter sigma-tw"></i></a>
				 
			</div>
						</div>
						</div>


<style>a.added_to_cart.wc-forward { display: none; }a.button.product_type_simple.add_to_cart_button.ajax_add_to_cart { margin: 0 !important; padding: 20px !important; border-radius: 0 !important; }</style>
	<div class="container">
	<div class="content col-lg-9 col-sx-12 right">
	<div class="slider" style="display:<?php echo ot_get_option("slider_show"); ?>">
	<?php masterslider(1); ?>
	</div>	

	
<div class="sev-index" style="display:<?php echo ot_get_option("icon_box_show"); ?>;background:<?php echo ot_get_option("bg_iconbox"); ?>">



	<div class="services">
	
	<img src="<?php echo ot_get_option("bx_slider_img01"); ?>">
<h6 style="color:<?php echo ot_get_option("title_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_txt01"); ?></h6>
<p style="color:<?php echo ot_get_option("subtitle_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_sub01"); ?></p>
	</div>

	<div class="services">
	
	<img src="<?php echo ot_get_option("bx_slider_img02"); ?>">
<h6 style="color:<?php echo ot_get_option("title_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_txt02"); ?></h6>
<p style="color:<?php echo ot_get_option("subtitle_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_sub02"); ?></p>
	</div>


	<div class="services">
	
	<img src="<?php echo ot_get_option("bx_slider_img03"); ?>">
<h6 style="color:<?php echo ot_get_option("title_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_txt03"); ?></h6>
<p style="color:<?php echo ot_get_option("subtitle_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_sub03"); ?></p>
	</div>

	<div class="services-l">
	
	<img src="<?php echo ot_get_option("bx_slider_img04"); ?>">
<h6 style="color:<?php echo ot_get_option("title_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_txt04"); ?></h6>
<p style="color:<?php echo ot_get_option("subtitle_iconbox"); ?>" ><?php echo ot_get_option("bx_slider_sub04"); ?></p>
	</div>

	
	</div>


			<div class="product-box" >

					<div class="title-pro col-lg-12 col-sx-12" style="background:<?php echo ot_get_option("head_box"); ?> ; color:<?php echo ot_get_option("head_color"); ?>">

				<h3><?php echo ot_get_option("last_product_title"); ?></h3>
						<div class="archive"><a href="<?php echo ot_get_option("archive_product_link"); ?>" style="color:<?php echo ot_get_option("archive_head"); ?>"><?php echo ot_get_option("archive_product_title"); ?></a></div>

			</div>

			
		<div class="products">
<ul class="products">
    <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => 6 , 'orderby' => 'time' );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
                <li style="background:<?php echo ot_get_option("bg_product_meta"); ?>" class="product col-xl-4 col-lg-4 col-sx-12">    
                    <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
                        <h3 style="color:<?php echo ot_get_option("title_product"); ?>" class="p-title"><?php the_title(); ?></h3>
						                    </a>

                        <div style="color:<?php echo ot_get_option("short_des_product"); ?>" class="content-index"> <?php the_content_rss('', TRUE, '', 25); ?> </div>
                        <span style="background:<?php echo ot_get_option("bg_price_product"); ?>" class="price-index"><i class="fa fa-id-card-o"></i> <?php echo $product->get_price_html(); ?></span>                    

<div class="info">
<div class="cat"><i class="fa fa-folder" aria-hidden="true"></i>
<?php global $product; echo $product->get_categories( ', ', ' ' . _n( ' ', '  ', $cat_count, 'woocommerce' ) . ' ', ' ' ) ?>
 </div>
<div class="view"><i class="fa fa-eye" aria-hidden="true"></i>
<?php
echo getPostViews(get_the_ID());
?>
</div>

</div>

<div class="demo-index" style="background:<?php echo ot_get_option("bg_product_meta"); ?>"><?php woocommerce_template_loop_add_to_cart(); ?>
                </li>

    <?php endwhile; ?>
    <?php wp_reset_query(); ?>
</ul><!--/.products-->



			
		</div>	
			</div>	
			
			
		<div class="content-box" style="display:<?php echo ot_get_option("box_post_01_show"); ?>">

					<div class="title-box" style="background:<?php echo ot_get_option("head_box"); ?> ; color:<?php echo ot_get_option("head_color"); ?>">

				<h3><?php echo ot_get_option("last_posts_01_title"); ?></h3>
						<div class="archive"><a href="<?php echo ot_get_option("archive_posts_01_link"); ?>" style="color:<?php echo ot_get_option("archive_head"); ?>"><?php echo ot_get_option("btn_posts_01"); ?></a></div>

			</div>

			
		<div class="boxes">

	<?php $cat=1; ?>
	<?php query_posts("cat=$cat&showposts=3"); ?>
	<?php while (have_posts()) : the_post(); ?>
		
			<div class="boxe col-lg-3 col-sx-12">



			<a href="<?php the_permalink() ?>"><?php the_post_thumbnail('postindex'); ?></a>
					<div class="post-info" style="background:<?php echo ot_get_option("bg_meta_post"); ?>" >

			<a style="font-family: <?php echo ot_get_option("heading_box"); ?>;font-size:<?php echo ot_get_option("heading_size"); ?>"  href="<?php the_permalink() ?>"><h2 style="color:<?php echo ot_get_option("puzzle_title"); ?>;" > <?php the_title(); ?></h2></a>
	<p style="color: <?php echo ot_get_option("des_meta_post"); ?>; font-family: <?php echo ot_get_option("box_font"); ?>;font-size:<?php echo ot_get_option("box_size"); ?>" ><?php the_content_rss('', TRUE, '', 25); ?></p>

	<div class="post-meta" style="font-family: <?php echo ot_get_option("heading_box"); ?>;font-size:<?php echo ot_get_option("heading_size"); ?>">	
	<div class="post-views">	<i class="fa-eye"></i> <?php echo getPostViews(get_the_ID()); ?></div>
	<div class="post-author">	<i class="fa-users"></i><?php the_author(', ') ?></div>

				</div>
		
			</div>
					<a  style="background:<?php echo ot_get_option("bg_puzzle"); ?> ; color:<?php echo ot_get_option("color_puzzle"); ?>;font-family: <?php echo ot_get_option("botton_font"); ?>;font-size:<?php echo ot_get_option("botton_size"); ?>" href="<?php the_permalink() ?>" class="single"><i class="fa fa-list-ul"></i><?php echo ot_get_option("btn_posts_02"); ?></a>
		
		</div>	

	<?php endwhile;?>
	<?php wp_reset_query(); ?>




			
		</div>	
			</div>	
			
		<div class="content-box" style="display:<?php echo ot_get_option("box_post_02_show"); ?>">

					<div class="title-box" style="background:<?php echo ot_get_option("head_box"); ?> ; color:<?php echo ot_get_option("head_color"); ?>">

				<h3><?php echo ot_get_option("last_posts_02_title"); ?></h3>
						<div class="archive"><a href="<?php echo ot_get_option("archive_posts_02_link"); ?>" style="color:<?php echo ot_get_option("archive_head"); ?>"><?php echo ot_get_option("archive_posts_02_title"); ?></a></div>

			</div>

			
		<div class="boxes">

	<?php $cat=15; ?>
	<?php query_posts("cat=$cat&showposts=3"); ?>
	<?php while (have_posts()) : the_post(); ?>
		
			<div class="boxe col-lg-3 col-sx-12">



			<a href="<?php the_permalink() ?>"><?php the_post_thumbnail('postindex'); ?></a>
					<div class="post-info" style="background:<?php echo ot_get_option("bg_meta_post"); ?>">

			<a style="font-family: <?php echo ot_get_option("heading_box"); ?>;font-size:<?php echo ot_get_option("heading_size"); ?>"  href="<?php the_permalink() ?>"><h2 style="color:<?php echo ot_get_option("puzzle_title"); ?>;" > <?php the_title(); ?></h2></a>
	<p><?php the_content_rss('', TRUE, '', 30); ?></p>	
	<div class="post-meta" style="font-family: <?php echo ot_get_option("heading_box"); ?>;font-size:<?php echo ot_get_option("heading_size"); ?>">	
	<div class="post-views">	<i class="fa-eye"></i> <?php echo getPostViews(get_the_ID()); ?></div>
	<div class="post-author">	<i class="fa-users"></i><?php the_author(', ') ?></div>

				</div>
			</div>
					<a  style="background:<?php echo ot_get_option("bg_puzzle"); ?> ; color:<?php echo ot_get_option("color_puzzle"); ?>;font-family: <?php echo ot_get_option("botton_font"); ?>;font-size:<?php echo ot_get_option("botton_size"); ?>" href="<?php the_permalink() ?>" class="single"><i class="fa fa-list-ul"></i><?php echo ot_get_option("btn_posts_02"); ?></a>	
		</div>	

	<?php endwhile;?>
	<?php wp_reset_query(); ?>




			
		</div>	
			</div>	
			
			
			
	</div>

	<?php get_sidebar();?>



	</div>

	<?php get_footer();?>

	</body>
	</html>