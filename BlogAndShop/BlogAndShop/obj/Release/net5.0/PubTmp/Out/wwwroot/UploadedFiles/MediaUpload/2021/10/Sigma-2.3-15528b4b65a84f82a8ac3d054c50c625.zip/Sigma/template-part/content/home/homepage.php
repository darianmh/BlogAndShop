<div id="homev1" class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <?php get_template_part('template-part/content/home/homepage-sections/title-site'); ?>
                <?php get_template_part('template-part/content/home/homepage-sections/service'); ?>
                <?php get_template_part('template-part/content/home/homepage-sections/products'); ?>
                <?php get_template_part('template-part/content/home/homepage-sections/posts'); ?>
            </div>


            <div class="col-lg-3 sidebar-sg nopadding-right col-sm-12">
                <?php get_template_part('template-part/content/home/homepage-sections/sidebar'); ?>
            </div>
        </div>
    </div>