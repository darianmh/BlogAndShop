<div class="row titlearea">
    <div class="col-lg-9 col-sm-9 col-6 title-sigma nopadding">
        <h3><?php _e('Last posts on site', 'sigma-theme'); ?></h3>
    </div>
    <div class="col-lg-3 col-sm-3 col-6 title-archive nopadding">
        <a href="<?php echo get_site_url (''); ?>"><?php _e('Content Archive', 'sigma-theme'); ?></a>
    </div>
</div>

<div class="row index-posts">

    <?php
    $cat_posts = new WP_Query(array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'order' => 'ASC',
        'meta_key' => 'post_views_count',
        'orderby' => 'meta_value_num',
        'posts_per_page' => 3
    ));

    if ($cat_posts->have_posts()):
        while ($cat_posts->have_posts()): $cat_posts->the_post(); ?>

            <div class="col-lg-4 last-posts col-sm-6">
                <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('index'); ?></a>

                <div class="post-meta">
                    <div class="title-post"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
                    <p><?php echo wp_trim_words(get_the_content(), 30, '...'); ?></p>

                    <div class="row">
                        <div class="cat-post col-lg-8 col-8">
                            <i class="fal fa-folder"></i>
                            <?php the_category(', ') ?>
                        </div>
                        
                        <div class="cat-post col-lg-4 col-4">
                            <i class="fal fa-eye"></i> 
                            <?php echo getPostViews(get_the_ID()); ?>
                        </div>
                        
                    </div>
                    <a class="more-post" href="<?php the_permalink() ?>" target="_blank"><i
                                class="fa fa-list-ul"></i><?php _e('More details', 'sigma-theme'); ?></a>
                </div>
            </div>

        <?php
        endwhile;
        ?>
        <?php
        wp_reset_postdata();
        ?>
    <?php
    else: ?>
        <p class="nopost"><?php _e('There are no posts to display.', 'sigma-theme'); ?> </p>
    <?php
    endif;
    ?>


</div>


<div class="row titlearea">
    <div class="col-lg-9 col-sm-9 col-6 title-sigma nopadding">
        <h3><?php _e('Best posts on site', 'sigma-theme'); ?></h3>
    </div>
    <div class="col-lg-3 col-sm-3 col-6 title-archive nopadding">
        <a href="<?php echo get_site_url (''); ?>"><?php _e('Content Archive', 'sigma-theme'); ?></a>
    </div>
</div>

<div class="row index-posts">

    <?php


    $cat_posts = new WP_Query(array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'order' => 'DESC',
        'orderby' => 'ID',
        'posts_per_page' => 3,

    ));

    if ($cat_posts->have_posts()):
        while ($cat_posts->have_posts()): $cat_posts->the_post(); ?>
            <div class="col-lg-4 last-posts col-sm-6">
                <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('index'); ?></a>

                <div class="post-meta">
                    <div class="title-post"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
                    <p><?php echo wp_trim_words(get_the_content(), 30, '...'); ?></p>

                    <div class="row">
                        <div class="cat-post col-lg-8 col-8">
                            <i class="fal fa-folder"></i>
                            <?php the_category(', ') ?>
                        </div>
                        
                        <div class="cat-post col-lg-4 col-4">
                            <i class="fal fa-eye"></i> 
                            <?php echo getPostViews(get_the_ID()); ?>
                        </div>
                        
                    </div>
                    <a class="more-post" href="<?php the_permalink() ?>" target="_blank"><i
                                class="fa fa-list-ul"></i><?php _e('More details', 'sigma-theme'); ?></a>
                </div>
            </div>

        <?php
        endwhile;
        ?>
        <?php
        wp_reset_postdata();
        ?>
    <?php
    else: ?>
        <p class="nopost"><?php _e('There are no posts to display.', 'sigma-theme'); ?> </p>
    <?php
    endif;
    ?>

</div>        