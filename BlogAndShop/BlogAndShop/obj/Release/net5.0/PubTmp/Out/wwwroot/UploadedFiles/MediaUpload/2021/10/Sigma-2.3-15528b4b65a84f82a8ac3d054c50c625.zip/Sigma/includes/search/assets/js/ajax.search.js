jQuery(document).ready(function ($) {
    //
    $.thf = {};
    $.thf.ajax = {};
    $.thf.render = {};
    $.thf.cache = {
        search : [],
        getCats: [],
    };

    // Base64: Encode
    $.thf.bta = function (str) {
        return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
            return String.fromCharCode(parseInt(p1, 16))
        }));
    };

    // Select
    $('select:not([disabled])').click(function () {
        $(this).toggleClass('open');
    }).focusout(function () {
        $(this).removeClass('open')
    });

    // Enter Event
    $('select,input,textarea').keyup(function (e) {
        if (e.keyCode == 13) {
            $(this).trigger("enterKey");
        }
    });

    // Ajax Searhc
    if ($('#thf_ajax_search').length) {
        var $form   = $('#thf_ajax_search'),
            $btn    = $('#thf_btn'),
            $type   = $('#thf_type'),
            $cat    = $('#thf_cat'),
            $input  = $('#thf_input'),
            $result = $('#thf_result');

        /*
         * Events
         */
        $input.keyup(function (e) {
            // $input.val($.trim($(this).val()));

            if (e.keyCode !== 13) {
                $.thf.search();
            }
        });

        $type.change(function () {
            $.thf.getCats();
        });

        $cat.change(function () {
            $.thf.search();
        });

        $btn.click(function () {
            $form.addClass('submited');
            $('#thf_ajax_search').submit();
        });

        $form.submit(function (e) {
            if (!$(this).hasClass('submited')) {
                $.thf.search();
                e.preventDefault();
            }
        });

        $(document).on('click', '#thf_showAll', function () {
            $btn.click();
        })

        /*
         * Form: Toggle Inputs
         */
        $.thf.disableFormInputs = function () {
            $form.find('input,select').attr('disabled', 'disabled');
        };

        $.thf.enableFormInputs = function () {
            $form.find('input:not(".disable"),select:not(".disable")').removeAttr('disabled');
        };

        /*
         * Ajax: Default
         */
        $.ajaxSetup({
            url : THF.ajaxURL,
            type: "POST",

        });

        /*
         * Ajax: Searching
         */
        $.thf.ajax.search = null;
        $.thf.search = function () {
            var data     = {
                    action  : 'thf_search',
                    type    : $type.val(),
                    cat     : $cat.val(),
                    s       : $.trim($input.val()),
                    security: THF.security
                },
                cache_id = $.thf.bta(data.type + data.cat + data.s);

            $input.removeClass('loading');
            $result.hide().html('');

            if ($.thf.ajax.search) {
                $.thf.ajax.search.abort();
            }

            if (data.s.length < 3) {
                return false;
            }

            // Check Cach
            if (cache_id in $.thf.cache.search) {
                $.thf.render.searchItems($.thf.cache.search[cache_id]);
                return;
            }

            // Call
            $.thf.ajax.search = $.ajax({
                data      : data,
                beforeSend: function () {
                    $input.addClass('loading');
                    $result.hide().html('');
                },
                success   : function (res) {
                    if (res.success && typeof res.data.items !== 'undefined') {
                        $.thf.render.searchItems(res.data.items);
                        $.thf.cache.search[cache_id] = res.data.items;
                    } else if (typeof res.data.msg !== 'undefined') {
                        $result.html(res.data.msg);
                    }
                },
            }).done(function () {
                $input.removeClass('loading');
                $result.show();
            });
        }

        /*
         * Ajax: Get Cats
         */
        $.thf.ajax.getCats = null;
        $.thf.getCats = function () {
            var data         = {
                    action  : 'thf_getCats',
                    type    : $type.val(),
                    security: THF.security
                },
                default_item = $cat.find('option:first-child').get(0).outerHTML;

            if ($.thf.ajax.getCats) {
                $.thf.ajax.getCats.abort();
            }

            // Check cache
            if (data.type in $.thf.cache.getCats) {
                $.thf.render.catOptions($.thf.cache.getCats[data.type], default_item);
                return;
            }

            // Call
            $.thf.ajax.getCats = $.ajax({
                data      : data,
                beforeSend: function () {
                    $.thf.disableFormInputs();
                    $cat.addClass('loading').html(default_item);
                },
                success   : function (res) {
                    if (res.success && typeof res.data.items !== 'undefined') {
                        $.thf.render.catOptions(res.data.items, default_item);
                        $.thf.cache.getCats[data.type] = res.data.items;
                    }
                },
            }).done(function () {
                $.thf.enableFormInputs();
                $cat.removeClass('loading');
            });
        }

        /*
        * HTML: Render
        */
        $.thf.render.searchItems = function (data) {
            var items   = '',
                showAll = '<button id="thf_showAll"class="btn btn-primary btn-sm">نمایش تمامی نتایج جستجو</button>',
                item    = '<li class="item mb-1"><a title="{title}" href="{href}" class="d-flex text-right"><span class="thumb"><img src="{image}" title="{title}" alt="{title}"></span><h3 class="mr-2">{title}</h3></a></li>';

            $.each(data, function (index, data) {
                items += item;
                items = items.replace(/{title}/g, data.title);
                items = items.replace(/{href}/g, data.link);
                items = items.replace(/{image}/g, data.image);
            });

            $result.html('<ul class="p-0 m-0">' + items + '</ul>' + showAll).show();
        };

        $.thf.render.catOptions = function (options, default_item) {
            var items = '',
                group = '<optgroup label="{label}">{childs}</optgroup>',
                item  = '<option value="{id}">{title}</option>';

            if( options[0]['id'] !== 'all' ) {
                options.unshift({
                    type : 'item',
                    id   : 'all',
                    title: 'همه',
                });
            }

            $.each(options, function (index, data) {
                if (data.type == 'group') {
                    var childs = '';

                    $.each(data.items, function (i, d) {
                        childs += item;
                        childs = childs.replace(/{id}/g, d.id);
                        childs = childs.replace(/{title}/g, d.title);
                    });

                    items += group;
                    items = items.replace(/{label}/g, data.label);
                    items = items.replace(/{childs}/g, childs);
                } else {
                    items += item;
                    items = items.replace(/{id}/g, data.id);
                    items = items.replace(/{title}/g, data.title);
                }
            });

            $cat.html(default_item + items).trigger('change');
        };

    }
});