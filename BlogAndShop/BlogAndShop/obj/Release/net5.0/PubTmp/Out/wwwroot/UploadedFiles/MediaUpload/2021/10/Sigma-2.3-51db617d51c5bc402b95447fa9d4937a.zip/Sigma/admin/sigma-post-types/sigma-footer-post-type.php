<?php
add_action( 'init', 'sigma_theme_register_footer_post_type' );
function sigma_theme_register_footer_post_type() {
    $labels = array(
        'name'               => __( 'sigma footer', 'sigma-theme' ),
        'singular_name'      => __( 'sigma footer',  'sigma-theme' ),
        'menu_name'          => __( 'sigma footers',  'sigma-theme' ),
        'name_admin_bar'     => __( 'sigma footer',  'sigma-theme' ),
        'add_new'            => __( 'Add New', 'sigma-theme' ),
        'add_new_item'       => __( 'Add New footer', 'sigma-theme' ),
        'new_item'           => __( 'New footer', 'sigma-theme' ),
        'edit_item'          => __( 'Edit footer', 'sigma-theme' ),
        'view_item'          => __( 'View footer', 'sigma-theme' ),
        'all_items'          => __( 'All footers', 'sigma-theme' ),
        'search_items'       => __( 'Search footers', 'sigma-theme' ),
        'parent_item_colon'  => __( 'Parent footers:', 'sigma-theme' ),
        'not_found'          => __( 'No footers found.', 'sigma-theme' ),
        'not_found_in_trash' => __( 'No footers found in Trash.', 'sigma-theme' )
    );
    $args = array(
        'labels'             => $labels,
        'description'        => __( 'sigma footer builder', 'sigma-theme' ),
        'supports'           => array( 'title', 'editor'),
        'public'            => true,
        'has_archive'       => false,
        'show_in_nav_menus' => false,
        'menu_icon'         => 'dashicons-admin-post'
    );
    register_post_type( 'sigma-footer', $args );
}