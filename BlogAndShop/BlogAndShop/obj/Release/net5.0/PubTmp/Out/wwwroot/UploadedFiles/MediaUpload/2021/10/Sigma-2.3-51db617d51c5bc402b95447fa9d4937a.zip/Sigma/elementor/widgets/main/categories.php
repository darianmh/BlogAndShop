<?php
namespace Elementor;

class Main_Products_Categories extends Widget_Base {
	
	public function get_name() {
		return 'product-categories';
	}
	
	public function get_title() {
		return __( 'Categories', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-product-categories';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Sigma Categories', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'product_cat_limit',
			[
				'label'   => esc_html__( 'Category Limit', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);

		$this->add_control(
			'product_cat_type',
			[
				'label'   => esc_html__( 'Category Type', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'options'        => [
					'category' => 'Post Cat',
					'product_cat' => 'Product Cat',
                ],
                'default' => 'product_cat',				
			]
		);

		$this->add_control(
			'product_cat_empty',
			[
				'label'     => esc_html__( 'Hide empty Category', 'sigma-theme' ),
				'type'      => Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => __( 'Yes', 'sigma-theme' ),
						'icon' => 'fa fa-pause-circle',
					],
					'0' => [
						'title' => __( 'No', 'sigma-theme' ),
						'icon' => 'fa fa-play-circle',
					],
				],
				'default' => '1',
				'toggle' => true,
			]
		);
		
		$this->add_control(
			'cat_order',
			[
				'label'   => esc_html__( 'Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);	
				
		$this->end_controls_section();


        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Sigma Categories', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'categoris_background_color',
				'label' => __( 'Categoris Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .left_category_edc ul',
			]
		);

		$this->add_control(
			'categoris_border_top_color',
			[
				'label' => __( 'Categoris Border Top Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .left_category_edc ul' => 'border-top: 3px solid {{VALUE}}',
				],
				'default' => '#41d3e6'
			]
		);

		$this->add_control(
			'categoris_item_color',
			[
				'label' => __( 'Categoris Item Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .left_category_edc ul li a' => 'color: {{VALUE}}',
				],	
				'default' => '#333333'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'categoris_item_typography',
				'label' => __( 'Categoris Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .left_category_edc ul li a',
			]
		);			
		
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		  echo'<div class="left_category_edc darkeble"><ul>';
          $taxonomy     = ''.$settings['product_cat_type'].'';
          $orderby      = 'name';  
          $order        = ''.$settings['cat_order'].'';
          $show_count   = 0;      // 1 for yes, 0 for no
          $pad_counts   = 0;      // 1 for yes, 0 for no
          $hierarchical = 1;      // 1 for yes, 0 for no  
          $title        = '';  
          $empty        = ''.$settings['product_cat_empty'].'';
          $number       = ''.$settings['product_cat_limit'].'';     
        
          $args = array(
                 'taxonomy'     => $taxonomy,
                 'orderby'      => $orderby,
                 'order'        => $order,
                 'show_count'   => $show_count,
                 'pad_counts'   => $pad_counts,
                 'hierarchical' => $hierarchical,
                 'title_li'     => $title,
                 'hide_empty'   => $empty,
                 'number'       => $number,                 
          );
         $all_categories = get_categories( $args );
         foreach ($all_categories as $cat) {
            if($cat->category_parent == 0) {
                $category_id = $cat->term_id;       
                echo '<li><a href="'. get_term_link($cat->slug, ''.$settings['product_cat_type'].'') .'">'. $cat->name .'</a></li>';
        
                $args2 = array(
                        'taxonomy'     => $taxonomy,
                        'child_of'     => 0,
                        'parent'       => $category_id,
                        'orderby'      => $orderby,
                        'show_count'   => $show_count,
                        'pad_counts'   => $pad_counts,
                        'hierarchical' => $hierarchical,
                        'title_li'     => $title,
                        'hide_empty'   => $empty
                );
                $sub_cats = get_categories( $args2 );
                if($sub_cats) {
                    foreach($sub_cats as $sub_category) {
                        echo '<li class="cat-sigma-child"><a href="'. get_term_link($sub_category->slug, ''.$settings['product_cat_type'].'') .'">'. $sub_category->name .'</a></li>';
                    }   
                }
            }       
        }		
        echo'</div></ul>';
	}
	
}