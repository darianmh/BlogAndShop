<?php
namespace Elementor;

class Footer_App_Lists extends Widget_Base {

	public function get_name() {
		return 'footer-apps';
	}

	public function get_title() {
		return __( 'Footer Apps', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}     

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_apps',
			[
				'label' => __( 'Footer Apps Lists', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'select_apps_style',
			[
				'label'   => esc_html__( 'Select Site Apps Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'apps_style01',
				'options' => [
                    'apps_style01' => esc_html__('Style 01', 'sigma-theme'),
                    'apps_style02' => esc_html__('Style 02', 'sigma-theme'),
                ],
			]
        );

		$this->add_control(
			'select_apps_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/footers/select_apps_style01.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_apps_style' => 'apps_style01',
                ],      				
			]
		);        

        $this->add_control(
			'select_apps_style02',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/footers/select_apps_style02.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_apps_style' => 'apps_style02',
                ],      				
			]
		);        
		        
        
		$this->add_control(
			'section_content_apps_title',
			[
				'label' => __( 'Downloads Website Apps', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'website apps downloads', 'sigma-theme' ),
                'default' => __( 'website apps downloads', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'footer_apps_list',
			[
				'label' => __( 'Apps Lists', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'App Name', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'app Name', 'sigma-theme' ),
						'default' => __( 'Facebook', 'sigma-theme' ),
					],
					[
						'name' => 'link',
						'label' => __( 'Apps Link', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => __( 'http://hamkarwp.com', 'sigma-theme' ),
        				'default' => [
        					'url' => 'http://hamkarwp.com',
        				]						
					],
					[
						'name' => 'icon',
						'label' => __( 'Apps Icon', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
						'default' => [ 'value' => 'fab fa-apple', 'library' => 'brand', ],
					],	
					[
						'name' => 'title',
						'label' => __( 'Apps Title', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Social title', 'sigma-theme' ),
						'default' => __( 'download from app-store', 'sigma-theme' ),
					],					
				],
				'default' => [
					[
						'text' => 'ios',
						'link' => 'https://apple.com/',
						'icon' => [ 'value' => 'fab fa-apple', 'library' => 'brand', ],
						'title' => __( 'Download From App Store', 'sigma-theme' ),
					],
					[
						'text' => 'android',
						'link' => 'https://samsung.com/',
						'icon' => [ 'value' => 'fab fa-android', 'library' => 'brand', ],
						'title' => __( 'Download From Cafebazar', 'sigma-theme' ),
					],
					[
						'text' => 'playstore',
						'link' => 'https://play-store.com/',
						'icon' => [ 'value' => 'fab fa-google-play', 'library' => 'brand', ],
						'title' => __( 'Download From Google Play' , 'sigma-theme' ),
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);

		$this->end_controls_section();
		
        $this->start_controls_section(
        	'footer_apps_style_section',
        	[
				'label' => __( 'Footer Apps Lists', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_control(
			'footer_apps_color_title',
			[
				'label' => __( 'Apps List Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .footer_apps_lists h3 , .footer_apps_lists_s2 h3' => 'color: {{VALUE}}',
				],	
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'apps_title_typography',
				'label' => __( 'Apps List Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .footer_apps_lists h3 , .footer_apps_lists_s2 h3',
			]
		);

		$this->add_control(
			'apps_icon_size',
			[
				'label' => __( 'Apps Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .footer_apps_lists ul li a i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'select_apps_style' => 'apps_style01', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'apps_list_color_type_s1',
				'label' => __( 'Apps Lists Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .footer_apps_lists ul li a',
				'condition' => [
					'select_apps_style' => 'apps_style01',
                ],	
            ]
		);
		
		$this->add_control(
			'apps_icon_size_S2',
			[
				'label' => __( 'Apps Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 18,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .footer_apps_lists_s2 ul li a i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'select_apps_style' => 'apps_style02', ],
			]
		);		
		$this->add_control(
			'apps_icons_color',
			[
				'label' => __( 'Apps Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .footer_apps_lists_s2 ul li a i' => 'color: {{VALUE}}',
				],	
				'condition' => [
					'select_apps_style' => 'apps_style02',
                ],	
            	'default' => '#888888'    
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'apps_list_color_type',
				'label' => __( 'Apps Lists Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .footer_apps_lists_s2 ul li a',
				'condition' => [
					'select_apps_style' => 'apps_style02',
                ],	
            ]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'apps_background',
				'label' => __( 'Apps Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .footer_apps_lists_s2 ul li a',
				'condition' => [
					'select_apps_style' => 'apps_style02',
                ],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'app_border',
				'label' => __( 'Apps Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .footer_apps_lists ul li a ',
				'condition' => [ 'select_apps_style' => 'apps_style01', ],
			]
		);
		
		$this->add_control(
			'apps_icons_color_hover',
			[
				'label' => __( 'Apps Icon Color Hover', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .footer_apps_lists_s2 ul li a:hover i ' => 'color: {{VALUE}}',
				],		
				'condition' => [
					'select_apps_style' => 'apps_style02',
                ],	
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'apps_background_hover',
				'label' => __( 'Apps Background Color Hover', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'select_apps_style' => 'apps_style02',
                ],	
				'selector' => '{{WRAPPER}} .footer_apps_lists_s2 ul li a:hover',
			]
		);
		
		$this->end_controls_section();		
		
	}	

	protected function render() {
		$settings = $this->get_settings_for_display();
        if($settings['select_apps_style'] == 'apps_style01' && !empty($settings['select_apps_style'])){    
		?>
		<div class="footer_apps_lists"><ul>
		<h3><?php echo $settings['section_content_apps_title']; ?></h3>    
		<?php foreach ( $settings['footer_apps_list'] as $index => $item ) :
		?>
			<li>
				<?php
					echo '<div class="app-'.$item['text'].'"><a href="'.$item['link']['url'].'" class="'.$item['text'].'">'.$item['title'].' ' ?><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</a></div>';
				?>
			</li>
		<?php endforeach; ?>
		</ul></div>
		<?php
        }
        if($settings['select_apps_style'] == 'apps_style02'){    
        ?>
		<div class="footer_apps_lists_s2"><ul>
		<h3><?php echo $settings['section_content_apps_title']; ?></h3>    
		<?php foreach ( $settings['footer_apps_list'] as $index => $item ) :
		?>
			<li>
				<?php
					echo '<a href="'.$item['link']['url'].'" class="'.$item['text'].'">'.$item['title'].' ' ?><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</a>';
				?>
			</li>
		<?php endforeach; ?>
		</ul></div>
		<?php
        }		
	}
	
}