<?php
namespace Elementor;

class Telegram_Box extends Widget_Base {
	
	public function get_name() {
		return 'telegram-box';
	}
	
	public function get_title() {
		return  __( 'Social Box', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-social-icons';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {

		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Social Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 
        
		$this->add_control(
			'active_tl_box',
			[
				'label'   => esc_html__( 'Active Social Box', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

 		$this->add_control(
			'tl_box_text',
			[
				'label' => __( 'Social Box Text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Social Box Text', 'sigma-theme' ),
                'default' => __( 'We have found an easier way to connect with our users...', 'sigma-theme' ),
                'condition' => [ 'active_tl_box' => 'yes', ],
			]
		);

 		$this->add_control(
			'tl_box_btn_text',
			[
				'label' => __( 'Social Box Button Text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Social Box Button Text', 'sigma-theme' ),
                'default' => __( 'Subscribe to the channel', 'sigma-theme' ),
                'condition' => [ 'active_tl_box' => 'yes', ],
			]
		);

		$this->add_control(
			'tl_box_url',
			[
				'label' => __( 'Social Box Button Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://t.me/hamkarwp', 'sigma-theme' ),
				'default' => [
					'url' => 'https://t.me/hamkarwp',
				],
				'condition' => [ 'active_tl_box' => 'yes', ],
			]
		);		
				
        $this->end_controls_section();       
        
        
        $this->start_controls_section(
        	'tl_box_style',
        	[
				'label' => __( 'Social Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'active_tl_box' => 'yes', ],			
        	]
        );	 

		$this->add_control(
			'tbox_bg',
			[
				'label' => __( 'Social Box Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .telegram_chanel' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'active_tl_box' => 'yes', ],
				'default' => '#03A9F4'
			]
		);

		$this->add_control(
			'tbox_color',
			[
				'label' => __( 'Social Box Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .telegram_chanel' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'active_tl_box' => 'yes', ],
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tbox_color_typography',
				'label' => __( 'Social Box Text Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .telegram_chanel ',
				'condition' => [ 'active_tl_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .telegram_chanel ',
				'condition' => [ 'active_tl_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .telegram_chanel ',
                'condition' => [ 'active_tl_box' => 'yes', ],					
			]
		);

        $this->end_controls_section();       


        $this->start_controls_section(
        	'tl_box_btn_style',
        	[
				'label' => __( 'Social Box Button Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'active_tl_box' => 'yes', ],			
        	]
        );	 

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_bg',
				'label' => __( 'Button Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'active_tl_box' => 'yes', ],					
				'selector' => '{{WRAPPER}} .telegram_chanel .pull-left',
			]
		);
		
		$this->add_control(
			'btn_color',
			[
				'label' => __( 'Button Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .telegram_chanel .pull-left' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_tl_box' => 'yes', ],					
				'default' => '#ffffff'
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border_btn',
				'label' => __( 'Button Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .telegram_chanel .pull-left',
                'condition' => [ 'active_tl_box' => 'yes', ],					
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'border_btn_typography',
				'label' => __( 'Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .telegram_chanel .pull-left',
                'condition' => [ 'active_tl_box' => 'yes', ],					
			]
		);

        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            if($settings['active_tl_box'] == 'yes'){
            echo'<a class="darkeble telegram_chanel" href="'.$settings['tl_box_url']['url'].'" target="_blank"><i class="icon-Social"></i><span>'.$settings['tl_box_text'].'</span><span class="pull-left">'.$settings['tl_box_btn_text'].'</span></a>';
            }
        }
        else
        {
            if($settings['active_tl_box'] == 'yes'){
            echo'<a class="darkeble telegram_chanel" href="'.$settings['tl_box_url']['url'].'" target="_blank">
                    <i class="icon-Social"></i>
                    <span>'.$settings['tl_box_text'].'</span>
                    <span class="pull-left">'.$settings['tl_box_btn_text'].'</span>
                </a>';
            }    
        }
    }
}