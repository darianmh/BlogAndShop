<?php
namespace Elementor;

class Header_Wishlist extends Widget_Base {
	
	public function get_name() {
		return 'header-wishlist';
	}
	
	public function get_title() {
		return __( 'Header Wishlist', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-heart-o';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}
	
    protected function _register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Header Wishlist', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'simga_woo_mini_Wishlist_icon',
			[
				'label' => __( 'Icon', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-heart',
					'library' => 'solid',
				],				
			]
        );
        
        $this->add_responsive_control(
            'simga_woo_mini_cart_alignment',
            [
                'label' =>esc_html__( 'Alignment', 'sigma-theme' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left'    => [
                        'title' =>esc_html__( 'Left', 'sigma-theme' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' =>esc_html__( 'Center', 'sigma-theme' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' =>esc_html__( 'Right', 'sigma-theme' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .simga-mini-cart' => 'text-align: {{VALUE}};'
                ],
                'default' => 'left',
            ]
        );

        $this->end_controls_section();

		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Wishlist Icon Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'color_Wishlist_icon',
			[
				'label' => __( 'Wishlist Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_Wishlist_shop i' => 'color: {{VALUE}}',
				],
				'default' => '#555555',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_count_Wishlist',
				'label' => __( 'Wishlist Count Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .dgs_Wishlist_shop span',
			]
		);		
 
		$this->add_control(
			'colr_count_Wishlist',
			[
				'label' => __( 'Wishlist Count Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_Wishlist_shop span' => 'color: {{VALUE}}',
				],
				'default' => '#ffffff'
			]
		);  

		$this->add_control(
			'Wishlist_icon_size',
			[
				'label' => __( 'Wishlist Icon typography', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 25,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_Wishlist_shop i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'Wishlist_count_type',
				'label' => __( 'Wishlist Count typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_Wishlist_shop span',
			]
		);	
		
        $this->end_controls_section();       
		
        $this->start_controls_section(
        	'Wishlist_items_style',
        	[
				'label' => __( 'Wishlist Items Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
        $this->add_control(
			'color_item_name',
			[
				'label' => __( 'Item Color Name', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_wish_mini_sigma' => 'color: {{VALUE}}',
				],		
				'default' => '#465157',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'color_item_type',
				'label' => __( 'Item Color Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title_wish_mini_sigma',
			]
		);	


        $this->add_control(
			'item_remove_color',
			[
				'label' => __( 'Item Remove Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .widget_shopping_wishlist_content .sigma-remove-from-wishlist' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'item_remove_bg',
				'label' => __( 'Item Remove Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .widget_shopping_wishlist_content .sigma-remove-from-wishlist ',
			]
		);		
		
		
		$this->add_control(
			'remove_icon_size',
			[
				'label' => __( 'Remove Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .widget_shopping_wishlist_content .sigma-remove-from-wishlist ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();               
        
        $this->start_controls_section(
        	'footer_Wishlist_style',
        	[
				'label' => __( 'Wishlist Footer', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'go_to_checkout_bg',
				'label' => __( 'Go To Wishlist Background', 'sigma-theme' ),
				'types' => [ 'gradient'],
				'selector' => '{{WRAPPER}} .woo-go-wishlist',
			]
		);

        $this->add_control(
			'go_to_checkout_color',
			[
				'label' => __( 'Go To Wishlist Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .woo-go-wishlist ' => 'color: {{VALUE}} !important',
				],		
				'default' => '#ffffff',
			]
		);
		
        $this->end_controls_section();               
    }	
	
	protected function render() {

        $settings = $this->get_settings_for_display();
        if( is_user_logged_in()) {
        $user_id = get_current_user_id();
        $wishlist = get_user_meta($user_id,'sigma_wish_list',true);
        if(is_array($wishlist) && count($wishlist) > 0) {
        echo '<div class="simga-mini-cart"><a href="'.get_site_url().'/wishlist" class="dgs_Wishlist_shop">'?><?php \Elementor\Icons_Manager::render_icon( $settings['simga_woo_mini_Wishlist_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</i></a>';
        echo do_shortcode( ' [sigma_mini_wishlist] ' );
        }
        else {
        echo '<div class="simga-mini-cart"><a href="'.get_site_url().'/wishlist" class="dgs_Wishlist_shop">'?><?php \Elementor\Icons_Manager::render_icon( $settings['simga_woo_mini_Wishlist_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</i></a>';
        echo do_shortcode( ' [sigma_mini_wishlist] ' );            
        echo '</div>';
	    }
        }
	    else {
        echo '<div class="simga-mini-cart"><a href="'.get_site_url().'/wishlist" class="dgs_Wishlist_shop">'?><?php \Elementor\Icons_Manager::render_icon( $settings['simga_woo_mini_Wishlist_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</i></a>';
        echo do_shortcode( ' [sigma_mini_wishlist] ' );            
        echo '</div>';	    
	    }
	}
}