<?php
namespace Elementor;

class Grid_Poroducts_Widget  extends Widget_Base  {
	
	public function get_name() {
		return 'grid-products';
	}
	
	public function get_title() {
		return __( 'grid products', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-products';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

    function get_product_cat(){
        $terms = get_terms( array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }
 
    function get_product_tag(){
        $terms = get_terms( array(
            'taxonomy' => 'product_tag',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }    
	protected function _register_controls() {

		$this->start_controls_section(
			'grid_products_content_section_two',
			[
				'label' => __( 'grid products', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sigma_select_products_lists_style',
			[
				'label'   => esc_html__( 'Select products lists Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_products_lists',
				'options' => [
                    'style01_products_lists' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_products_lists' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_products_lists' => esc_html__('Style 03', 'sigma-theme'),
                    'style04_products_lists' => esc_html__('Style 04', 'sigma-theme'),
                ],
			]
        );


		$this->add_control(
			'sigma_select_products_lists_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style01_products_lists.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_products_lists_style' => 'style01_products_lists',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_select_products_lists_style02',
			[
				'raw' => '<img  
				    class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style02_products_lists.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_products_lists_style' => 'style02_products_lists',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_select_products_lists_style03',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style03_products_lists.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_products_lists_style' => 'style03_products_lists',
                ],      				
			]
		);       
				
		$this->add_control(
			'sigma_select_products_lists_style04',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style04_products_lists.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_products_lists_style' => 'style04_products_lists',
                ],      				
			]
		);       

		$this->add_control(
			'product_title_alignmentـs1',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title-sigma h3 ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	

		$this->add_control(
			'product_entitle_alignmentـs1',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title-archive small ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	

		$this->add_control(
			'product_title_alignmentـs2',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title_warp_dgs h3 ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
			]
		);	

		$this->add_control(
			'product_entitle_alignmentـs2',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title_warp_dgs small ' => 'text-align: {{VALUE}};'
                ],			
                'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
			]
		);	
		
		$this->add_control(
			'product_title_alignmentـs3',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title__area h3 ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	

		$this->add_control(
			'product_entitle_alignmentـs3',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title__area p ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	
		
		$this->add_control(
			'product_title_alignmentـs4',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .fss_title_area h2, .fss_title_area h2 b ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);	

		$this->add_control(
			'product_entitle_alignmentـs4',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .fss_title_area small' => 'text-align: {{VALUE}};'
                ],			
                'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);			
		$this->add_control(
			'grid_products_title',
			[
				'label' => __( 'title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'title products title', 'sigma-theme' ),
                'default' => __( 'Digital and Electric Goods', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'grid_products_en_title',
			[
				'label' => __( 'english title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'english title products title', 'sigma-theme' ),
                'default' => __( 'Digital and Electric Goods', 'sigma-theme' ),
			]
		);		

		$this->add_control(
			'grid_products_icon',
			[
				'label' => __( 'Icon Title', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
                'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],			
			]
		);

		$this->add_control(
			'grid_products_link',
			[
				'label' => __( 'Title Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'Title Link Enter', 'sigma-theme' ),
                'default' => [ 'url' => 'https://www.zhaket.com/web/sigma-wordpress-theme', ]
			]
		);
		
		$this->add_responsive_control(
			'sigma_columns',
			[
				'label'          => esc_html__( 'Columns', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
			]
		);		
		
		$this->add_control(
			'sigma_posts_per_page',
			[
				'label'   => esc_html__( 'Product Limit', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);
		
		$this->add_control(
			'sigma_orderby',
			[
				'label'   => esc_html__( 'Order by', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'     => esc_html__( 'Date', 'sigma-theme' ),
					'title'    => esc_html__( 'Title', 'sigma-theme' ),
					'category' => esc_html__( 'Category', 'sigma-theme' ),
					'rand'     => esc_html__( 'Random', 'sigma-theme' ),
					'total_sales'     => esc_html__( 'Sale', 'sigma-theme' ),
					'modified' => esc_html__( 'Updated', 'sigma-theme' ),
				],
			]
		);

		$this->add_control(
			'sigma_order',
			[
				'label'   => esc_html__( 'Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);		

		$this->add_control(
			'sigma_woo_product_select',
			[
				'label'   => esc_html__( 'Show product by ', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'category',
				'options' => [
                    'category' => esc_html__('Category', 'sigma-theme'),
                    'product' => esc_html__('Product', 'sigma-theme'),
                    'tag' => esc_html__('Tag', 'sigma-theme'),
                ],
			]
        );
        
		$this->add_control(
			'sigma_woo_cat',
			[
				'label'   => esc_html__( 'Category', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_cat(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'category',
                ],
			]
        );

		$this->add_control(
			'sigma_woo_tag',
			[
				'label'   => esc_html__( 'tag', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_tag(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'tag',
                ],
			]
        );        
		$this->add_control(
			'sigma_open_thumb_in_popup',
			[
				'label'     => esc_html__( 'Open Thumb in Popup', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_badge',
			[
				'label'     => esc_html__( 'Show Badge', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_title',
			[
				'label'   => esc_html__( 'Title', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_categories',
			[
				'label'     => esc_html__( 'Categories', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_veiws',
			[
				'label'     => esc_html__( 'Veiws', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],				
			]
		);

		$this->add_control(
			'sigma_show_seller',
			[
				'label'     => esc_html__( 'Saller', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [ 'sigma_select_products_lists_style' => [ 'style03_products_lists', 'style04_products_lists'] ],				
			]
		);

		$this->add_control(
			'sigma_show_date',
			[
				'label'     => esc_html__( 'Date', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],		
			]
		);
		
		$this->add_control(
			'sigma_show_sales',
			[
				'label'     => esc_html__( 'Sales number', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [ 'sigma_select_products_lists_style' => [ 'style03_products_lists', 'style04_products_lists'] ],				
			]
		);		
		$this->add_control(
			'sigma_show_price',
			[
				'label'   => esc_html__( 'Price', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_des',
			[
				'label'   => esc_html__( 'Description', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [ 'sigma_select_products_lists_style' => [ 'style01_products_lists','style03_products_lists', 'style04_products_lists'] ],				
			]
		);
		
		$this->add_control(
			'sigma_show_cart',
			[
				'label'   => esc_html__( 'Add to Cart', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'sigma_image',
				'label'     => esc_html__( 'Image Size', 'sigma-theme' ),
				'exclude'   => [ 'custom' ],
				'default'   => 'medium',
			]
		);
		
		$this->end_controls_section();	
		
		$this->start_controls_section(
			'grid_products_style_section',
			[
				'label' => __( 'Grid Product Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

// style 04

		$this->add_control(
			'dgs_last_products_title_color_s4',
			[
				'label' => __( 'Grid Products Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#f6ca16',
				'selectors' => [
					'{{WRAPPER}} .fss_title_area h2 b' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style04_products_lists',
                ],         
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_last_products_title_type_s4',
				'label' => __( 'Grid Products Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_title_area h2 b ',
                'condition' => [
                    'sigma_select_products_lists_style' => 'style04_products_lists',
                ],         
            ]
		);	
		
		
		$this->add_control(
			'dgs_last_products_en_title_color_s4',
			[
				'label' => __( 'Grid Products English Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#9999',
				'selectors' => [
					'{{WRAPPER}} .fss_title_area small ' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style04_products_lists',
                ],         
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_last_products_entitle_type_s4',
				'label' => __( 'Grid Products English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_title_area small ',
                'condition' => [
                    'sigma_select_products_lists_style' => 'style04_products_lists',
                ],         
            ]
		);	


// style 03

		$this->add_control(
			'dgs_last_products_title_color',
			[
				'label' => __( 'Grid Products Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#666666',
				'selectors' => [
					'{{WRAPPER}} .title__area h3' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style03_products_lists',
                ],         
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_last_products_title_type',
				'label' => __( 'Grid Products Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title__area h3 ',
                'condition' => [
                    'sigma_select_products_lists_style' => 'style03_products_lists',
                ],         
            ]
		);	
		
		
		$this->add_control(
			'dgs_last_products_en_title_color',
			[
				'label' => __( 'Grid Products English Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#b1b1b1',
				'selectors' => [
					'{{WRAPPER}} .title__area p' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style03_products_lists',
                ],         
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_last_products_entitle_type',
				'label' => __( 'Grid Products English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title__area p ',
                'condition' => [
                    'sigma_select_products_lists_style' => 'style03_products_lists',
                ],         
            ]
		);	
		
// style 02

		$this->add_control(
			'dgs_last_products_title_color_S2',
			[
				'label' => __( 'Grid Products Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#444444',
				'selectors' => [
					'{{WRAPPER}} .title_warp_dgs h3' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style02_products_lists',
                ],         
			]
		);

		$this->add_control(
			'dgs_last_products_en_title_color_S2',
			[
				'label' => __( 'Grid Products English Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#999999',
				'selectors' => [
					'{{WRAPPER}} .title_warp_dgs small' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style02_products_lists',
                ],         
			]
		);

		$this->add_control(
			'dgs_last_products_icon_color',
			[
				'label' => __( 'icon title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#f19077',
				'selectors' => [
					'{{WRAPPER}} .title_warp_dgs i' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_products_lists_style' => 'style02_products_lists',
                ],         
			]
		);
		

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'dgs_last_products_border',
		    	'label' => _x( 'title bottom border', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .title_warp_dgs small:before',
                'condition' => [
                    'sigma_select_products_lists_style' => 'style02_products_lists',
                ],      		
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'dgs_last_products_background',
		    	'label' => _x( 'last products background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient' , 'video'],
				'selector' => '{{WRAPPER}} .dgs_products_grid_warp',
                'condition' => [
                    'sigma_select_products_lists_style' => 'style02_products_lists',
                ],      		
			]
		);

//style 01

        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_top_products',
        		'label' => _x( 'Title Box Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .titlearea',
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],      		
        	]
        );

        $this->add_control(
        	'dgs_color_top_text',
        	[
        		'label' => __( 'Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .title-sigma h3' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],         
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'grid_products_s1_title_type',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title-sigma h3',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	
		
        $this->add_control(
        	'dgs_color_More_text',
        	[
        		'label' => __( 'English Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .titlearea small' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],         
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'grid_products_s1_entitle_type',
				'label' => __( 'English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title-sigma small',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'grid_products_s1_border',
				'label' => __( 'Title Area Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .titlearea',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);
		
		
		$this->end_controls_section();		

// style image start 

        $this->start_controls_section(
        	'image_style',
        	[
				'label' => __( 'Zoom', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'zoom_icon_color',
			[
				'label' => __( 'Zoom Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-popop--link' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
			]
		);        

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'zoom_icon_bg',
				'label' => __( 'Zoom Iocn Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .sigma-wc-product-popop--link',
			]
		);

		$this->add_control(
			'zoom_icon_size',
			[
				'label' => __( 'Zoom Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-popop--link ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();

		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Sale Badge', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'sale_badge_color',
			[
				'label' => __( 'Sale Badge Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_gird_products_warp .sigma-wc-products-badge span.onsale , .filedemo_gird_products_warp span.onsale, .modern_gird_products_warp span.onsale, .products_index_plus span.onsale ' => 'color: {{VALUE}}',
				],	
				'default' => '#ffffff',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sale_badge_background',
				'label' => __( 'Sale Badge Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp .sigma-wc-products-badge span.onsale , .filedemo_gird_products_warp span.onsale, .modern_gird_products_warp span.onsale, .products_index_plus span.onsale',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sale_badge_typography',
				'label' => __( 'Badge Sale Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp .sigma-wc-products-badge span.onsale , .filedemo_gird_products_warp span.onsale, .modern_gird_products_warp span.onsale, .products_index_plus span.onsale ',
			]
		);	
		
        $this->end_controls_section();               


        $this->start_controls_section(
        	'title_style_setting',
        	[
				'label' => __( 'Title Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	

		
//title setting 04

		$this->add_control(
			'gp_title_s4_color',
			[
				'label' => __( 'Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seo h2' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
				'default' => '#444444'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_title_s4_type',
				'label' => __( 'Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seo h2',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);	

		$this->add_control(
			'gp_entitle_s4_color',
			[
				'label' => __( 'English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seo small' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
				'default' => '#999999'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_entitle_s4_type',
				'label' => __( 'English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seo small',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);	
        
//title setting 03
        
		$this->add_control(
			'title_color_s3',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .post__expect__v3__elementor h2 ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
				'default' => '#333333'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_color_typography',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .post__expect__v3__elementor h2 ',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	
		
		
//title setting 02

		$this->add_control(
			'gp_title_s2_color',
			[
				'label' => __( 'Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_gird_products_warp h2' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
				'default' => '#444444'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_title_s2_type',
				'label' => __( 'Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp h2',
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
			]
		);	

		$this->add_control(
			'gp_entitle_s2_color',
			[
				'label' => __( 'English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_gird_products_warp small' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
				'default' => '#999999'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_entitle_s2_type',
				'label' => __( 'English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp small',
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
			]
		);	
		
//title setting 01

		$this->add_control(
			'title_height_s1',
			[
				'label' => __( 'Title Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 51,
				],
				'range' => [
					'px' => [
						'min'  => 30,
						'max'  => 200,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .titleholder ' => 'height:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);
		
		
        $this->add_control(
        	'dgs_color_title_holder',
        	[
        		'label' => __( 'Product Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#333333',
        		'selectors' => [
        			'{{WRAPPER}} .titleholder h2' => 'color: {{VALUE}}',
        		],		
        		'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_title_type',
				'label' => __( 'Product Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .titleholder h2',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'titlearea_bg_s1',
				'label' => __( 'Products Area Title Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .titleholder ',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);		
		
        $this->end_controls_section();       


		
        $this->start_controls_section(
        	'description_product',
        	[
				'label' => __( 'Description Product', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'sigma_select_products_lists_style' => [ 'style01_products_lists',  'style03_products_lists' , 'style04_products_lists',  ] ],
        	]
        );	 

// desrcription style 04

		$this->add_control(
			'des_height_s4',
			[
				'label' => __( 'Description Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 110,
				],
				'range' => [
					'px' => [
						'min'  => 50,
						'max'  => 250,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seo p ' => 'height:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);
		
		$this->add_control(
			'des_color_s4',
			[
				'label' => __( 'Description Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seo p ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ], 
                'default' => '#777777'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'des_s4_typography',
				'label' => __( 'Description typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seo p',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);	
		
// desrcription style 03 

		$this->add_control(
			'des_height_s3',
			[
				'label' => __( 'Description Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 70,
				],
				'range' => [
					'px' => [
						'min'  => 50,
						'max'  => 150,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post__expect__v3__elementor p ' => 'height:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);
		
		$this->add_control(
			'des_color_s3',
			[
				'label' => __( 'Description Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .post__expect__v3__elementor p ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
                ], 
                'default' => '#999999'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'des_s3_typography',
				'label' => __( 'Description typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .post__expect__v3__elementor p',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	
		
// desrcription style 01        

		$this->add_control(
			'des_height_s1',
			[
				'label' => __( 'Description Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 100,
				],
				'range' => [
					'px' => [
						'min'  => 100,
						'max'  => 300,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .product-meta p ' => 'height:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);
		
        $this->add_control(
        	'dgs_color_product-meta',
        	[
        		'label' => __( 'Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .product-meta p' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],         
        	]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'des_bg_color_s1',
        		'label' => __( 'Description Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .product-meta p',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'des_type_s1',
				'label' => __( 'Description typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .product-meta p',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'price_box_s1',
        	[
				'label' => __( 'Price Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
// pricebox_s4

		$this->add_control(
			'price_color_s4',
			[
				'label' => __( 'Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_price ul li:first-child p' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_type',
				'label' => __( 'Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_price ul li:first-child p',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'price_bg_s4',
				'label' => __( 'Price Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
				'selector' => '{{WRAPPER}} .fss_card_products_price',
			]
		);

		
// pricebox_s3

		$this->add_control(
			'sale_icon_color_s3',
			[
				'label' => __( 'Sale Price Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .price__holder i' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
				'default' => '#888888'
			]
		);

		$this->add_control(
			'sale_icon_size_s3',
			[
				'label' => __( 'Sale Price Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .price__holder i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);

		$this->add_control(
			'price_regular_s3_color',
			[
				'label' => __( 'Regular Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .price__holder span ins span' => 'color: {{VALUE}} !important',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
				'default' => '#f45b66'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_regular_s3_type',
				'label' => __( 'Regular Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .price__holder span ins span',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	
		

		$this->add_control(
			'price_sale_s3_color',
			[
				'label' => __( 'Sale Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .price__holder span' => 'color: {{VALUE}}  !important',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
				'default' => '#555555'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_sale_s3_type',
				'label' => __( 'Sale Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .price__holder span',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);			
		
// pricebox_s2

		$this->add_control(
			'price_regular_s2_color',
			[
				'label' => __( 'Regular Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-price p ins' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
				'default' => '#f45b66'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_regular_s2_type',
				'label' => __( 'Regular Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-price p ins',
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
			]
		);	
		

		$this->add_control(
			'price_sale_s2_color',
			[
				'label' => __( 'Sale Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-price del span' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
				'default' => '#555555'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_sale_s2_type',
				'label' => __( 'Sale Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-price del span',
				'condition' => [ 'sigma_select_products_lists_style' => 'style02_products_lists', ],
			]
		);	
		
// pricebox_s1

		$this->add_control(
			'pricebox_height_s1',
			[
				'label' => __( 'Price Box Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 35,
				],
				'range' => [
					'px' => [
						'min'  => 35,
						'max'  => 200,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .priceholder ' => 'height:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);
		
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_priceholder',
        		'label' => _x( 'Color Background Price Holder', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .priceholder',
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],      		
        	]
        );        

		$this->add_control(
			'dgs_pricebox_icon_color',
			[
				'label' => __( 'Pricebox Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .priceholder i' => 'color: {{VALUE}}',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],     
        		'default' => '#888888'
			]
		);

		$this->add_control(
			'dgs_pricebox_icon_size',
			[
				'label' => __( 'Pricebox Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 30,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .priceholder i ' => 'font-size:{{SIZE}}px',
				],
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],
			]
		);

		$this->add_control(
			'price_regular_color_s1',
			[
				'label' => __( 'Regular Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .priceholder span' => 'color: {{VALUE}}',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],  
        		'default' => '#888888'
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_regular_type_s1',
				'label' => __( 'Regular Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .priceholder span',
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],				
			]
		);	
		
		$this->add_control(
			'price_sale_color_s1',
			[
				'label' => __( 'Sale Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .priceholder del , .priceholder del span' => 'color: {{VALUE}} !important',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],  	
        		'default' => '#888888'
			]
		);
		
        $this->end_controls_section();

		
        $this->start_controls_section(
        	'products_sale_count',
        	[
				'label' => __( 'Sales Counter', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
        		],        		
        	]
        );	
        
        
// sales box s4

		$this->add_control(
			'sales_icons_size_s4',
			[
				'label' => __( 'Sales Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_sale i ' => 'font-size:{{SIZE}}px',
				],
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
        		],				
			]
		);
		
		$this->add_control(
			'sales_icons_color_s4',
			[
				'label' => __( 'Sales Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_sale i ' => 'color: {{VALUE}}',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
        		],    	
				'default' => '#999999'
			]
		);

		$this->add_control(
			'sales_count_color_s4',
			[
				'label' => __( 'Sales Counter Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_sale ' => 'color: {{VALUE}}',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
        		],    	
				'default' => '#999999'
			]
		);		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sales_count_type_s4',
				'label' => __( 'Sales Counter Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_sale ',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);	
		
		
// sales box s3

		$this->add_control(
			'sales_icons_size_s3',
			[
				'label' => __( 'Sales Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 22,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .sale__holder i ' => 'font-size:{{SIZE}}px',
				],
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
        		],				
			]
		);
		
		$this->add_control(
			'sales_icons_color_s3',
			[
				'label' => __( 'Sales Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sale__holder i ' => 'color: {{VALUE}}',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
        		],    	
				'default' => '#cbe874'
			]
		);

		$this->add_control(
			'sales_count_color_s3',
			[
				'label' => __( 'Sales Counter Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sale__holder h4 ' => 'color: {{VALUE}}',
				],			
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
        		],    	
				'default' => '#999999'
			]
		);		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sales_count_type_s3',
				'label' => __( 'Sales Counter Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sale__holder h4',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	
		
        $this->end_controls_section();       
        
        
        $this->start_controls_section(
        	'product_meta_s1',
        	[
				'label' => __( 'Product Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );

//meta s4

		$this->add_control(
			'cat_s4_color',
			[
				'label' => __( 'Category Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_price ul li:last-child a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ],   	
				'default' => '#ffffff'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_s4_typography',
				'label' => __( 'Category Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_price ul li:last-child a ',
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ], 
            ]
		);	

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cat_s4_bg',
				'label' => __( 'Category Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ], 
				'selector' => '{{WRAPPER}} .fss_card_products_price ul li:last-child',
			]
		);
		
//meta s2


		$this->add_control(
			'cat_s2_color',
			[
				'label' => __( 'Product Category Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-categories ul li a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => ['style02_products_lists' , 'style03_products_lists' ],
                ],   	
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cat_s2_bg',
				'label' => __( 'Product Category Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'sigma_select_products_lists_style' => ['style02_products_lists' , 'style03_products_lists' ],
                ], 
				'selector' => '{{WRAPPER}} .sigma-wc-product-categories ul li a ',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_s2_typography',
				'label' => __( 'Product Category typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-categories ul li a ',
				'condition' => [
        			'sigma_select_products_lists_style' => ['style02_products_lists' , 'style03_products_lists' ],
                ], 			]
		);	

//meta s1

		$this->add_control(
			'metabox_cat_height_s1',
			[
				'label' => __( 'Meta Box Category Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 18,
				],
				'range' => [
					'px' => [
						'min'  => 10,
						'max'  => 200,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cat-meta ' => 'height:{{SIZE}}px',
				],
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],  				
			]
		);
		$this->add_control(
			'metabox_height_s1',
			[
				'label' => __( 'Meta Box Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 37,
				],
				'range' => [
					'px' => [
						'min'  => 35,
						'max'  => 200,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .metaholder ' => 'height:{{SIZE}}px',
				],
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],  				
			]
		);

		$this->add_control(
			'remove_icon_size',
			[
				'label' => __( 'Remove Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li a.remove ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'metabox_background',
				'label' => __( 'Meta Box Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
        		'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
        		],  
				'selector' => '{{WRAPPER}} .metaholder',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);

		$this->add_control(
			'metabox_color',
			[
				'label' => __( 'MetaBox Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-categories-plusdemo ul li a , .cat-meta ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],   	
				'default' => '#888888'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'metabox_type',
				'label' => __( 'MetaBox typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-categories-plusdemo ul li a , .cat-meta ',
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],   	
			]
		);	
		
		$this->add_control(
			'metabox_icon_color',
			[
				'label' => __( 'MetaBox Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .metaholder i' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],   	
				'default' => '#888888'
			]
		);

		$this->add_control(
			'metabox_icon_size',
			[
				'label' => __( 'MetaBox Icon Color', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 10,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .metaholder i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],   					
			]
		);
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'other_meta_s3',
        	[
				'label' => __( 'Other Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
                ],   
        	]
        );
        
		$this->add_control(
			'other_meta_icon_size_s3',
			[
				'label' => __( 'Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 16,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cat__holder i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);

		$this->add_control(
			'other_meta_icon_color_s3',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cat__holder i' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
				'default' => '#888888'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'other_meta_type_s3',
				'label' => __( 'Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .cat__holder h5',
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
			]
		);	

		$this->add_control(
			'color_logged_in',
			[
				'label' => __( 'Meta Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cat__holder h5 ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'sigma_select_products_lists_style' => 'style03_products_lists', ],
				'default' => '#999999d6'
			]
		);
		
        $this->end_controls_section();       
        
		
        $this->start_controls_section(
        	'add_cart_style',
        	[
				'label' => __( 'Add To Cart', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	
// cart s4

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'add_cart_s4_bg',
				'label' => __( 'Add To Cart Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fss_card_products_buy a',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);

		$this->add_control(
			'add_cart_s4_color',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_buy a' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'add_cart_s4_typography',
				'label' => __( 'Add To Cart Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_buy a',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);
		
// cart s3

		$this->add_control(
			'add_cart_color_s3',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .get_products_page_color a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
                ],   	
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'add_cart_s3_typography',
				'label' => __( 'Add To Cart Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .get_products_page_color a',
				'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
                ], 
            ]
		);			
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_loginv2_user',
				'label' => __( 'Add To Cart Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'sigma_select_products_lists_style' => 'style03_products_lists',
                ], 
				'selector' => '{{WRAPPER}} .get_products_page_color a',
			]
		);

		
//cart s2        

		$this->add_control(
			'add_cart_color_s2',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-add-to-cart a ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style02_products_lists',
                ],   	
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'add_cart_s2_typography',
				'label' => __( 'Add To Cart typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-add-to-cart a',
				'condition' => [
        			'sigma_select_products_lists_style' => 'style02_products_lists',
                ], 
            ]
		);			
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'add_cart_bg_s2',
				'label' => __( 'Add To Cart Background Color', 'sigma-theme' ),
				'types' => [ 'gradient' ],
				'condition' => [
        			'sigma_select_products_lists_style' => 'style02_products_lists',
                ], 
				'selector' => '{{WRAPPER}} .sigma-wc-add-to-cart a ',
			]
		);        
        
        
//cart s1

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'add_to_cart_bg',
				'label' => __( 'Add To Cart Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .readmore a',
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],   					
			]
		);

		$this->add_control(
			'add_to_cart_color',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .readmore a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],   	
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'add_to_cart_typography',
				'label' => __( 'Add To Cart Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .readmore a',
				'condition' => [
        			'sigma_select_products_lists_style' => 'style01_products_lists',
                ],				
			]
		);	
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'seller_section',
        	[
				'label' => __( 'Seller', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
        			'sigma_select_products_lists_style' => ['style04_products_lists']
                ],		        		
        	]
        );	 

//style 04 seller

		$this->add_control(
			'seller_icon_icon',
			[
				'label' => __( 'Seller Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seller i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
        		],    
			]
		);        

		$this->add_control(
			'seller_icon_color',
			[
				'label' => __( 'Seller Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seller i ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ],   	
				'default' => '#ffffff'
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'seller_icon_bg',
				'label' => __( 'Seller Icon Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ], 
				'selector' => '{{WRAPPER}} .fss_card_products_seller i',
			]
		);

		$this->add_control(
			'seller_name_color_s4',
			[
				'label' => __( 'Seller Name Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seller h3 ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ],   	
				'default' => '#666666'
			]
		);

		$this->add_control(
			'seller_des_color_s4',
			[
				'label' => __( 'Seller Decription Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seller span ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'sigma_select_products_lists_style' => 'style04_products_lists',
                ],   	
				'default' => '#999999'
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'seller_name_type_s4',
				'label' => __( 'Seller Name Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seller h3',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);			
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'seller_des_type_s4',
				'label' => __( 'Seller Decription Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seller span',
				'condition' => [ 'sigma_select_products_lists_style' => 'style04_products_lists', ],
			]
		);					
		
        $this->end_controls_section();       
        
	}
	
    protected function render(){
		$settings = $this->get_settings();
		$target = $settings['grid_products_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['grid_products_link']['nofollow'] ? ' rel="nofollow"' : '';			
        if($settings['sigma_select_products_lists_style'] == 'style03_products_lists' && !empty($settings['sigma_select_products_lists_style'])){    
        echo '<div class="last__products__v3_elementor"><a href="' . $settings['grid_products_link']['url'] . '"><div class="title__area"><h3>'.$settings['grid_products_title'].'</h3> <p>'.$settings['grid_products_en_title'].'</p> </div></a>';        
		echo '<div class="post__holder__v3_elementor" >';
		$this->render_loop_item();
        echo '</div></div>';
        }
        if($settings['sigma_select_products_lists_style'] == 'style02_products_lists') {
        echo '<a href="' . $settings['grid_products_link']['url'] . '"><div class="dgs_products_grid_warp darkeble"><div class="title_warp_dgs">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['grid_products_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'<h3>'.$settings['grid_products_title'].'</h3> <small>'.$settings['grid_products_en_title'].'</small> </div></a>';        
		echo '<div class="sigma-wid-con" >';
			$this->render_loop_item();
        echo '</div></div>';
        }
        if($settings['sigma_select_products_lists_style'] == 'style01_products_lists') {
        echo '<a href="' . $settings['grid_products_link']['url'] . '"><div class="row titlearea darkeble"><div class="col-sm-6 col-6 title-sigma nopadding"> <h3>'.$settings['grid_products_title'].'</h3> </div> <div class="col-lg-6 col-sm-6 col-6 title-archive nopadding"><small>'.$settings['grid_products_en_title'].'</small> </div> </div></a>';        
		echo '<div class="sigma-wid-con" >';
			$this->render_loop_item();
        echo '</div>';
        }         
        if($settings['sigma_select_products_lists_style'] == 'style04_products_lists') {
        echo '<a href="' . $settings['grid_products_link']['url'] . '"><div class="fss_title_area"> <h2><b>'.$settings['grid_products_title'].'</b></h2> <small>'.$settings['grid_products_en_title'].'</small> </div></a>';        
		echo '<div class="sigma-wid-con" >';
			$this->render_loop_item();
        echo '</div></div>';
        }
    }

    public function render_image() {
		$settings = $this->get_settings();
		?>
		<?php
        if($settings['sigma_select_products_lists_style'] == 'style02_products_lists' && !empty($settings['sigma_select_products_lists_style'])){    
		?>
		<div class="sigma-wc-product-image sigma-background-cover">
			<!-- popup content -->
			<?php if($settings['sigma_open_thumb_in_popup'] === 'yes') :
			?>
				<div class="sigma-wc-product-popop">
                    <div class="sigma-fast-preview" data-product-id="<?php echo get_the_ID() ?>"><a class="sigma-wc-product-popop--link"><i class="fa fa-eye" aria-hidden="true"></i></a></div>
				</div>
			<?php endif; ?>

			<!-- badge content -->
			<?php if ('yes' == $settings['sigma_show_badge']) : ?>
				<div class="sigma-wc-products-badge">
					<?php woocommerce_show_product_loop_sale_flash(); ?>
				</div>
			<?php endif; ?>

			<!-- Thumb content -->
			<a class="sigma_woo_product_img_link" href="<?php the_permalink(); ?>">
				<img alt="<?php the_title(); ?>" title="<?php the_title(); ?>"  src="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(), $settings['sigma_image_size']); ?>" width="300" height="300">
			</a>

			<!-- Add to cart button -->
			<?php if ('yes' == $settings['sigma_show_cart']): ?>
				<div class="sigma-wc-add-to-cart">
					<?php woocommerce_template_loop_add_to_cart([
						'class button product_type_simple add_to_cart_button ajax_add_to_cart'
					]);?>
				</div>
			<?php endif; ?>
			
			
		</div>
		
		<?php
        }
        if($settings['sigma_select_products_lists_style'] == 'style03_products_lists') {
        ?>
        <div class="image__holder__v3">
            <a href="<?php the_permalink(); ?>">
                <img alt="<?php the_title(); ?>" title="<?php the_title(); ?>"  src="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(), $settings['sigma_image_size']); ?>">
    			<!-- popup content -->
    			<?php if($settings['sigma_open_thumb_in_popup'] === 'yes') : ?>
    				<div class="sigma-wc-product-popop">
            <div class="sigma-fast-preview" data-product-id="<?php echo get_the_ID() ?>"><a class="sigma-wc-product-popop--link"><i class="fa fa-eye" aria-hidden="true"></i></a></div>
    				</div>
    			<?php endif; ?>   
			<?php if ('yes' == $settings['sigma_show_badge']) : ?>
				<div class="sigma-wc-products-badge">
					<?php woocommerce_show_product_loop_sale_flash(); ?>
				</div>
			<?php endif; ?>    			
            </a>
        </div>
        <?php
        }        
        if($settings['sigma_select_products_lists_style'] == 'style01_products_lists') {
        ?>
        <div class="products_index_plus">
            <a href="<?php the_permalink(); ?>">
                <img alt="<?php the_title(); ?>" title="<?php the_title(); ?>"  src="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(), $settings['sigma_image_size']); ?>">
			<?php if ('yes' == $settings['sigma_show_badge']) : ?>
				<div class="sigma-wc-products-badge">
					<?php woocommerce_show_product_loop_sale_flash(); ?>
				</div>
			<?php endif; ?>       
			<!-- popup content -->
			<?php if($settings['sigma_open_thumb_in_popup'] === 'yes') :
			?>
				<div class="sigma-wc-product-popop">
            <div class="sigma-fast-preview" data-product-id="<?php echo get_the_ID() ?>"><a class="sigma-wc-product-popop--link"><i class="fa fa-eye" aria-hidden="true"></i></a></div>
				</div>
			<?php endif; ?>			
            </a>
        </div>
        <?php
        } 
        if($settings['sigma_select_products_lists_style'] == 'style04_products_lists') {
        ?>
        <div class="fss_card_products_photo">
			<?php if($settings['sigma_open_thumb_in_popup'] === 'yes') :
			?>
				<div class="sigma-wc-product-popop">
            <div class="sigma-fast-preview" data-product-id="<?php echo get_the_ID() ?>"><a class="sigma-wc-product-popop--link"><i class="fa fa-eye" aria-hidden="true"></i></a></div>
				</div>
			<?php endif; ?>            
        <a href="<?php the_permalink(); ?>"><img alt="<?php the_title(); ?>" title="<?php the_title(); ?>"  src="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(), $settings['sigma_image_size']); ?>"></a>
			<?php if ('yes' == $settings['sigma_show_badge']) : ?>
				<div class="sigma-wc-products-badge">
					<?php woocommerce_show_product_loop_sale_flash(); ?>
				</div>
			<?php endif; ?>
        </div>
        <?php
        }         
	}

	public function render_description() {
		$settings = $this->get_settings();
		global $product;
		?>
		<?php
		//style 02
        if($settings['sigma_select_products_lists_style'] == 'style02_products_lists' && !empty($settings['sigma_select_products_lists_style'])){    
        ?>
			<div class="sigma-wc-product-desc">
				<div class="sigma-wc-product-desc-inner">
					<!-- categories -->
					<?php 
						if($settings['sigma_show_categories'] === 'yes'){
							$terms = get_the_terms( get_the_ID(), 'product_cat' );
							$terms_count = count($terms);

							if($terms_count > 0){
								echo "<div class='sigma-wc-product-categories'><ul>";
								foreach($terms as $key => $term){
									$sperator = $key !== ($terms_count -1) ? '' : '';
									echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
								}
								echo "</ul></div>";
							}
						}
					?>
					<!-- end categories -->
					<?php if ( 'yes' == $settings['sigma_show_title']) : ?>
					    <div class="dgs_gird_products_title">
						<a href="<?php the_permalink(); ?>" class="sigma-link-reset">
							<h2 class="sigma-wc-product-title">
								<?php the_title(); ?>
							</h2>
							<small><?php echo ( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ); ?></small>
						</a>
						</div>
					<?php endif; ?>

					<?php if (('yes' == $settings['sigma_show_price']) or ('yes' == $settings['sigma_show_rating'])) : ?>
						<?php if ( 'yes' == $settings['sigma_show_price']) : ?>
							<div class="sigma-wc-product-price">
								<?php woocommerce_template_single_price(); ?>
							</div>
						<?php endif; ?>
							

					<?php endif; ?>
				</div>
			</div>
		<?php
        }
        //style 03
        if($settings['sigma_select_products_lists_style'] == 'style03_products_lists') {
        ?>

        <div class="post__expect__v3__elementor darkeble">
            
			<?php if ( 'yes' == $settings['sigma_show_title']) : ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><h2><?php the_title(); ?></h2></a>    
			<?php endif; ?>        
					<!-- categories -->
					<?php 
						if($settings['sigma_show_categories'] === 'yes'){
							$terms = get_the_terms( get_the_ID(), 'product_cat' );
							$terms_count = count($terms);

							if($terms_count > 0){
								echo "<div class='sigma-wc-product-categories'><ul>";
								foreach($terms as $key => $term){
									$sperator = $key !== ($terms_count -1) ? '' : '';
									echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
								}
								echo "</ul></div>";
							}
						}
					?>
					<!-- end categories -->	
					
        <?php if($settings['sigma_show_des'] === 'yes'){ ?>
        <p><?php echo wp_trim_words( get_the_content(), 40, '...' ); ?></p>
        <?php } ?>    
        <div class="row">
        <?php if($settings['sigma_show_seller'] === 'yes'){ ?>
        <?php
        if ( class_exists('WeDevs_Dokan') ) {
        $vendor_id = get_post_field( 'post_author', get_the_id() );
        $store_url   = dokan_get_store_url( $vendor_id );
        ?>        
        <div class="nopadding-left col-lg-7 col-7 cat__holder">
            <h5><i class="fal fa-store"></i>
                <a href="<?php echo $store_url; ?>" target="_blank" ><?php $user_author = get_the_author_meta( 'display_name' ); echo $user_author ?></a>
            </h5>
        </div>
        <?php } ?>
        <?php } ?>
        <?php if($settings['sigma_show_date'] === 'yes'){ ?>
        <div class="col-lg-5 col-5 cat__holder">
            <h5><i class="fal fa-calendar"></i> <?php echo get_the_date('Y-m-d'); ?> </h5>
        </div>
        <?php } ?>        
        </div>
            <hr>
        <div class="row">
        <?php if($settings['sigma_show_price'] === 'yes'){ ?>
        <div class="col-lg-9 col-9 price__holder nopadding-left">
            <i class="fal fa-sack-dollar"></i><?php woocommerce_template_loop_price(); ?>
        </div>
        <?php } ?>
        <?php if($settings['sigma_show_sales'] === 'yes'){ ?>
        <div class="col-lg-3 col-3 sale__holder nopadding-right">
            <h4><i class="fal fa-shopping-bag"></i><span><?php echo ( get_post_meta( get_the_ID(), 'total_sales', true ) ); ?></span></h4>
        </div>
        <?php } ?>        
        </div>
			<?php if ('yes' == $settings['sigma_show_cart']): ?>
            <div class="get_products_page_color">
                <?php
                if ( '' === $product->get_price() || 0 == $product->get_price() ) {
                    $price = '<a href="'.get_permalink().'" target="_blank"><i class="fa fa-basket"></i>دانلود رایگان محصول</a>';
                } 
                else {
                    $price = '<a href="'.get_permalink().'" target="_blank"><i class="fa fa-basket"></i>خرید آنلاین محصول</a>';
                }
                	echo $price;
                ?>                
            </div>
			<?php endif; ?>
        </div>
            
        <?php
        }    
        //style 01
        if($settings['sigma_select_products_lists_style'] == 'style01_products_lists') {
        ?>

        <div class="product-meta darkeble">
		<?php if ( 'yes' == $settings['sigma_show_title']) : ?>
        <div class="titleholder"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><h2><?php the_title(); ?></h2></a></div>
		<?php endif; ?>  
		
        <?php if($settings['sigma_show_des'] === 'yes'){ ?>
        <hr>
        <p><?php echo wp_trim_words( get_the_content(), 40, '...' ); ?></p>
        <?php } ?>    
        
        <?php if($settings['sigma_show_price'] === 'yes'){ ?>
        <div class="priceholder"><i class="fal fa-sack-dollar"></i><?php woocommerce_template_single_price(); ?></span> </div>
        <?php } ?>
        
        <div class="metaholder">
            <div class="row">
            <?php
	            if($settings['sigma_show_categories'] === 'yes'){
					$terms = get_the_terms( get_the_ID(), 'product_cat' );
					$terms_count = count($terms);

				if($terms_count > 0){
					echo "<div class='cat-meta col-lg-8 col-8'><div class='sigma-wc-product-categories-plusdemo'><h5>  <i class='fa fa-folder'></i><ul>";
						foreach($terms as $key => $term){
						$sperator = $key !== ($terms_count -1) ? ' , ' : '';
						echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
						}
						echo "</ul></h5></div></div>";
					}
				}            
            ?>
          
          <?php						
          if($settings['sigma_show_veiws'] === 'yes'){ ?>
                <div class="cat-meta col-lg-4 col-4"><i class="fa fa-eye"></i><?php echo getPostViews(get_the_ID()); ?></div> <?php
          }
          ?>
        
        
        </div>
        </div>
        
			<?php if ('yes' == $settings['sigma_show_cart']): ?>
                <div class="readmore">
                <?php
                if ( '' === $product->get_price() || 0 == $product->get_price() ) {
                    $price = '<a href="'.get_permalink().'" target="_blank"><i class="fa fa-basket"></i>دانلود رایگان محصول</a>';
                } 
                else {
                    $price = '<a href="'.get_permalink().'" target="_blank"><i class="fa fa-basket"></i>خرید آنلاین محصول</a>';
                }
                	echo $price;
                ?>
                </div>
			<?php endif; ?>
			
        
        
            </div>
            
        <?php
        }    
        //style 04
        if($settings['sigma_select_products_lists_style'] == 'style04_products_lists') {
        ?>
        <div class="row">
            <div class="col-9">
                <div class="fss_card_products_price">
                    <ul>
						<?php if ( 'yes' == $settings['sigma_show_price']) : ?>
                            <li><?php woocommerce_template_single_price(); ?></li>
						<?php endif; ?>              
						
                        <?php
						if($settings['sigma_show_categories'] === 'yes'){
							$terms = get_the_terms( get_the_ID(), 'product_cat' );
							$terms_count = count($terms);

							if($terms_count > 0){
								foreach($terms as $key => $term){
									$sperator = $key !== ($terms_count -1) ? ' , ' : '';
									echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
								}
							}
						}                        
                        ?>
                    </ul>
                </div>
            </div>
        <?php if($settings['sigma_show_sales'] === 'yes'){ ?>
        <div class="npr npl col-3">
            <div class="fss_card_products_sale">
                <i class="fal fa-shopping-basket"></i><?php echo ( get_post_meta( get_the_ID(), 'total_sales', true ) ); ?>
            </div>
        </div>
        <?php } ?>      
        
        </div>
        <div class="fss_card_products_seo">
            
		<?php if ( 'yes' == $settings['sigma_show_title']) : ?>
            <a href="<?php the_permalink();?>"><h2><?php the_title(); ?></h2>
            <small><?php echo ( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ); ?></small></a>
		<?php endif; ?>            
		
        <?php if($settings['sigma_show_des'] === 'yes'){ ?>
        <p><?php echo wp_trim_words( get_the_content(), 40, '...' ); ?></p>
        <?php } ?>               

        </div>
        <?php if($settings['sigma_show_seller'] === 'yes'){ ?>
        <div class="fss_card_products_seller">
            <i class="fal fa-store"></i>
            <h3><?php $user_author = get_the_author_meta( 'display_name' ); echo $user_author ?></h3>
            <span><?php echo author_description ( get_the_author_meta('description') , 7 ); ?></span>
        </div>
        <?php } ?>
			<?php if ('yes' == $settings['sigma_show_cart']): ?>
            <div class="fss_card_products_buy">
                <?php
                if ( '' === $product->get_price() || 0 == $product->get_price() ) {
                    $price = '<a href="'.get_permalink().'" target="_blank"><i class="fal fa-shopping-bag"></i>دانلود رایگان محصول</a>';
                } 
                else {
                    $price = '<a href="'.get_permalink().'" target="_blank"><i class="fal fa-shopping-bag"></i>خرید آنلاین محصول</a>';
                }
                	echo $price;
                ?>                
            </div>
			<?php endif;
        }    
	}

	public function render_query() {
		$settings = $this->get_settings();

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } 
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } 
		else { $paged = 1; }

        if($settings['sigma_orderby'] == 'total_sales'){
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'order'               => $settings['sigma_order'],
            'meta_key'            => 'total_sales',
            'orderby'             => 'meta_value_num',			
			'paged'               => $paged,
        );
        }
        elseif($settings['sigma_orderby'] == 'modified'){
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'order'               => $settings['sigma_order'],
			'paged'               => $paged,
			'orderby'  => 'modified',
        );            
        }    
        else {
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'orderby'             => $settings['sigma_orderby'],
			'order'               => $settings['sigma_order'],
			'paged'               => $paged,
        );
        }
    
        
        if($settings['sigma_woo_product_select'] == 'category'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_cat',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_cat'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}

        if($settings['sigma_woo_product_select'] == 'tag'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_tag',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_tag'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}
		
        if($settings['sigma_woo_product_select'] == 'product' && !empty($settings['sigma_woo_product'])){
            $arg_product = [
				'post__in' => $settings['sigma_woo_product'],
			];
			$args = array_merge($args, $arg_product);
		}

		$wp_query = new \WP_Query($args);

		return $wp_query;
	}

	public function render_loop_item() {
		$settings = $this->get_settings();
		global $post;

        $wp_query = $this->render_query();

		if($wp_query->have_posts()) {

			$this->add_render_attribute('sigma-wc-products-wrapper', 'sigma-grid', '');

			$this->add_render_attribute(
				[
					'sigma-wc-products-wrapper' => [
						'class' => [
							'sigma-wc-products-wrapper',
							'sigma-grid',
							'sigma-grid-medium',
							'woocommerce',
							'columns-' . $settings['sigma_columns'],
							'sigma-tablet-columns-'. $settings['sigma_columns_tablet'],
							'sigma-mobile-columns-'. $settings['sigma_columns_mobile'],
						],
					],
				]
			);

			?>
			<div <?php echo $this->get_render_attribute_string( 'sigma-wc-products-wrapper' ); ?>>
			<?php			

			$this->add_render_attribute('sigma-wc-product', 'class', [
				'sigma-wc-product',
				]); 
				?>
				<ul class="products">
					<?php $count = 1; while ( $wp_query->have_posts() ) : $wp_query->the_post(); 
			        if($settings['sigma_select_products_lists_style'] == 'style02_products_lists') {
					?>
						<li class="dgs_gird_products_warp sigma-wc-product product">
							<div class="sigma-wc-product-inner">

							<?php 
								$this->render_image();
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php }

			        if($settings['sigma_select_products_lists_style'] == 'style01_products_lists') {
					?>
						<li class="plus_products_warp sigma-wc-product product">
							<div class="sigma-wc-product-inner">

							<?php 
								$this->render_image();
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php }
					
                    if($settings['sigma_select_products_lists_style'] == 'style03_products_lists' && !empty($settings['sigma_select_products_lists_style'])){    
					?>
						<li class="modern_gird_products_warp sigma-wc-product product">
							<div class="sigma-wc-product-inner">

							<?php 
								$this->render_image();
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php
                    }
                    
                    if($settings['sigma_select_products_lists_style'] == 'style04_products_lists'){    
					?>
						<li class="filedemo_gird_products_warp sigma-wc-product product">
							<div class="sigma-wc-product-inner fss_card_products darkeble">

							<?php 
								$this->render_image();
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php
                    }
					?>					
						<?php if($count % $settings['sigma_columns'] === 0) : ?>
							<div style="clear:both"></div>
						<?php endif; ?>
					<?php $count++; endwhile;	?>
				</ul>
			</div>
			<?php

			wp_reset_postdata();
			
		} else {
			echo '<div class="attr-alert-warning attr-alert no-products">' . esc_html__( 'Oops! No products were found.', 'sigma-theme' ) .'<div>';
		}
	}	
}	