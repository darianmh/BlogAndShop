<?php 
/**
 * Template Name: Dashboard Sigma
 *
 * Login Page Template.
 *
 * @author AminWEB
 * @since 1.0.0
 */
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php the_title(); ?> | <?php echo ot_get_option("title"); ?></title>
<meta name="description" content="<?php echo ot_get_option("description"); ?>">
<meta name="keywords" content="<?php echo ot_get_option("keywords"); ?>">
<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
<link rel="icon" href="<?php echo ot_get_option("favicon"); ?>" type="image/x-icon" />
<link href="<?php bloginfo('template_url')?>/style.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/front.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/sigma.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/responsive.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/app-sigma.css" rel="stylesheet" type="text/css">



<!--  jQuery 1.7+  -->
<script src="<?php bloginfo('template_url')?>/js/jquery-1.9.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/js/jquery.browser.min.js"></script>

<?php wp_head(); ?>
</head>


<body>

<div class="panel-header">
	
	<div class="panel-title">
		<i class="fa fa-list-ul"></i><a href="<?php bloginfo('url')?>/account"><p> پنل کاربران </p></a>
	</div>
	
	<div class="logo-panel">
		<a href="<?php echo ot_get_option("logo_link"); ?>"><img src="<?php echo ot_get_option("panel_logo"); ?>"</a>
	</div>
	
	<div class="panel-left" >
<div onclick="myFunction()" class="avat-panel dropbtn" style="background: url(<?php bloginfo('template_url'); ?>/img/user.svg) no-repeat;">
  <div id="myDropdown" class="dropdown-content">
<div class="heading"><?php echo get_avatar( um_user('ID'), 30); ?><span class="name">

<?php global $current_user;
      get_currentuserinfo();
      echo '' . $current_user->display_name . "\n";
?>


</span><span class="users-sigma">
<?php global $current_user;
      get_currentuserinfo();

      echo '' . $current_user->user_login . "\n";
?>

</span></div>
    <a href=<?php bloginfo('url')?>/my-account/edit-account/"><i class="panel-i fa fa-group"></i>ویرایش مشخصات کاربری</a>
    <a href="<?php bloginfo('url')?>/submit-ticket/"><i class="panel-i fa fa-life-bouy"></i>درخواست پشتیبانی</a>
	    <a href="<?php bloginfo('url')?>/echarge/"><i class="panel-i fa fa-vcard"></i>شارژ حساب</a>
<div class="divider"></div>
	    <a href="<?php bloginfo('url')?>/logout"><i class="panel-i fa fa-power-off"></i>خروج </a>


  </div>
</div>


		<div class="suppor-panel"><i class="fa fa-phone"></i> پشتیبانی : <?php echo ot_get_option("supp_phone"); ?> </div>
		<div class="ecahrg-panel" style="display:<?php echo ot_get_option("show_deposit"); ?>"><i class="fa fa-signal"></i><?php echo woo_wallet()->wallet->get_wallet_balance(get_current_user_id()); ?></div>


		
	</div>
	
</div>

</div>

	<div class="sidebar-panel left col-lg-3 col-sx-12">
	




	<div class="user-image">
		                    <a href="<?php echo um_user_profile_url(); ?>"><?php echo get_avatar( um_user('ID'), 120); ?></a>
		<br>
			<span class="un-panel">
<?php global $current_user;
      get_currentuserinfo();

      echo '' . $current_user->user_login . "\n";
?>

</span>	
					<br>
<span class="name-panel">

<?php global $current_user;
      get_currentuserinfo();
      echo '' . $current_user->display_name . "\n";
?>


</span><br>
	<span class="date-panel">

	<?php
    global $wp_query;
    $registered = date_i18n( "Y/m/d", strtotime( get_the_author_meta( 'user_registered', $wp_query->queried_object_id ) ) );
    echo 'امروز : ' . $registered;
?><p/>

</span>

		</div>
	
		<div class="user-menu">

<?php wp_nav_menu( array( 'theme_location' => 'users-menu' ) ); ?>

			
			
		</div>	
	</div>	

	
	<div class="single-info">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php
setPostViews(get_the_ID());
?>
<?php endwhile; else: ?><?php endif; ?>
	

		</div>

	

<div class="content-panel left col-lg-9 col-sx-12">

<div class="bread-panel" style="display:<?php echo ot_get_option("breac_panel"); ?>">
<?php custom_breadcrumbs(); ?>
</div>
	
<?php the_content(__('')); ?>

		</div>

	
</div>	
</body>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
<style>
.crunchify-social {
    display: none;
}
.um {
    max-width: 100%;
    width: 100%;
    max-width: 100%;
    -webkit-box-shadow: none !important;
}
.um-form {
    padding: 10px 0 0 0;
    background: none;
    background-size: 160px;
    background-position-x: 50%;
    border-radius: 100px;
}
.um-account-side {
    float: right;
    width: 39%;
    padding: 0 0;
    box-sizing: border-box;
}
.um-account-main {
    float: left;
    width: 61%;
    padding: 0 30px 0 0;
    box-sizing: border-box;
}
.footer {
    display: none !important;
}
.top-footer {
    display: none !important;
}
</style>
	<?php get_footer();?>

</html>
