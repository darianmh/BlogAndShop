<div class="row titlearea">
    <div class="col-lg-9 col-sm-9 col-7 title-sigma nopadding">
        <h3><?php _e('Last products on site', 'sigma-theme'); ?></h3>
    </div>
    <div class="col-lg-3 col-sm-3 col-5 title-archive nopadding">
        <a href="<?php echo wc_get_page_permalink( 'shop' ); ?>"
           target="_blank"><?php _e('Get to shop', 'sigma-theme'); ?></a>
    </div>
</div>

<div class="row">

    <?php
    $arms = array(
        'post_type' => 'product',
        'posts_per_page' => 6,
        'order' => 'DESC',
        'meta_query' => array(
            array(
                'key' => '_stock_status',
                'value' => 'instock'
            )
        ),
        'post_status' => 'publish',
    );
    $the_query = new WP_Query($arms);
    ?>

    <?php
        if ($the_query->have_posts()):
        while ($the_query->have_posts()):
        $the_query->the_post();
    ?>

            <div class="col-lg-4 col-sm-6 product-index">
                <a href="<?php the_permalink(); ?>"><?php woocommerce_template_loop_product_thumbnail(); ?></a>
                <div class="product-meta">
                    <div class="titleholder"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><h2><?php the_title(); ?></h2></a></div>
                    <hr>
                    <p><?php echo wp_trim_words(get_the_content(), 25, '...'); ?></p>
                    <div class="priceholder"><i class="fal fa-dollar"></i><?php woocommerce_template_loop_price(); ?></span>
                    </div>
                    <div class="metaholder">
                        <div class="row">
                            <div class="cat-meta col-lg-6 col-6">
                                <h5><i class="fal fa-folder"></i>
                                    <?php
                                        global $product;
            							$terms = get_the_terms( get_the_ID(), 'product_cat' );
            							$terms_count = count($terms);
        								foreach($terms as $key => $term){
        									$sperator = $key !== ($terms_count -1) ? '' : '';
        									echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
        								}
                                    ?>
                                </h5></div>
                            <div class="cat-meta col-lg-6 col-6">
                                <i class="fal fa-eye"></i><?php echo getPostViews(get_the_ID()); ?>
                            </div>
                        </div>
                    </div>
                    <div class="readmore">
                        <?php
                        if ('' === $product->get_price() || 0 == $product->get_price()) {
                            $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fa fa-basket"></i>'. __('Free Download', 'sigma-theme') .'</a>';
                        } else {
                            $price = '<a href="' . get_permalink() . '" target="_blank"><i class="fa fa-basket"></i>'. __('Buy Product', 'sigma-theme') .'</a>';
                        }
                        echo $price;
                        ?>
                    </div>
                </div>
            </div>

        <?php
        endwhile;
        wp_reset_postdata();
        
        else:
            ?>
            <p class="nopost"><?php _e('There are no products to display.', 'sigma-theme'); ?> </p>
        <?php
        endif;
        ?>
</div>