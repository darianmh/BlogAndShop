<?php 
/**
 * Template Name: Profile New Sigma
 *
 * Login Page Template.
 *
 * @author Hamkarwp
 * @since 1.0.0
 */


get_header();

if(is_user_logged_in()) {
    global $sigma;
    get_template_part($sigma['user_panel_style_index'] );
}
else {
    get_template_part('dashboard/my-account');
}

wp_footer();