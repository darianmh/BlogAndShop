<div class="sidebar left col-lg-3 col-sx-12">


<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('سایدبار چپ - صفحه اصلی')) : else : ?><?php endif; ?>

<a href="<?php echo ot_get_option("ads_side_link"); ?>" target="<?php echo ot_get_option("ads_side_target"); ?>"><img class="ads" style="display:<?php echo ot_get_option("side_ads"); ?>" src="<?php echo ot_get_option("ads_side_banner"); ?>" alt="ads-sidebar" ></a>   

<div class="enamad">

<?php echo ot_get_option("enamad_code"); ?>
<?php echo ot_get_option("samandehi_code"); ?>

</div>
</div>	