<?php get_header(); ?>



  <!-- left+right -->
<div class="container center">
<div class="row center">
    


  <!-- left -->
<div class="left col-12">
  <!-- grid-shop -->





    
<div class="breadcrumb_product">
<?php 
$args = array(
'delimiter' => ' » ',
'home' => _x( 'خانه', 'breadcrumb', 'woocommerce' ));
woocommerce_breadcrumb($args); ?>
</div>

<div class="card-group cat-product col-sx-12">

 

 
    <?php while ( have_posts() ) : the_post(); ?>
    <div class="card">
     <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('product'); ?></a> 
    <div class="card-body">
  <a href="<?php  the_permalink(); ?>">   
<h2 class="card-title">
<?php the_title(''); ?></h2></a>
    <span class="card-date">
	<i class="fa fa-calendar" aria-hidden="true"></i>تاریخ انتشار <?php the_date('y/m/d'); ?>  <?php the_time('ساعت:g:i '); ?>
    </span>
	<div class="card-des"> <?php the_content_rss('', TRUE, '', 25); ?> </div>
  
    
    </div>
    </div>


     <?php endwhile; // end of the loop. ?>

 



</div>
 
<?php woocommerce_product_loop_end(); ?>
  <!-- grid-shop -->

<?php sigma_numeric_posts_nav(); ?>


</div>
  <!-- left -->
</div>
</div>
</div>
  <!-- left+right -->


<?php get_footer(); ?>
