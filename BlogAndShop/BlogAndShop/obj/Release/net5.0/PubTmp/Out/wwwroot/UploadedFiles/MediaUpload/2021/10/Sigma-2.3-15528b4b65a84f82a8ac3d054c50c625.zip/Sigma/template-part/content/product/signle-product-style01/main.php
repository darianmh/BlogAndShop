<?php
if (have_posts()):
setPostViews(get_the_ID());
?>

<div class="content-single">
    <div class="breadcrumb_post">
        <?php
        $args = array(
            'delimiter' => ' <i></i> ',
            'home' => __('home', 'sigma-theme'));
        woocommerce_breadcrumb($args); ?>
    </div>

    <div class="product_holder">
        <div class="row product-title">
            <div class="col-lg-8">
                <h1 class="product-title-page"><?php the_title(); ?></h1>
            </div>

            <div class="col-lg-4">
                <?php
                $mid_var = get_post_meta($post->ID, 'video', true);
                if (isset($mid_var) && !empty($mid_var)): ?>
                
                    <a href="#" data-toggle="modal" data-target="#videomodal" data-toggle="modal"
                       data-target="#videomodal" class="video-demo">
                        <i class="fal fa-play"></i>
                       <?php _e('Product video preview', 'sigma-theme'); ?>
                    </a>

                <?php endif; ?>
            </div>

            <div id="videomodal" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <!-- Modal content-->
                    <div class="modal-content modal-top">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title"><?php _e('Video preview', 'sigma-theme'); ?><?php the_title(); ?>
                            </h4>
                        </div>
                        
                        <div class="modal-body">
                            <video width="100%" controls>
                                <source src="<?php
                                echo get_post_meta($post->ID, 'video', true);
                                ?>" type="video/mp4">
                            </video>
                        </div>
                        
                    </div>
                </div>
            </div>


        </div>
        <?php
        while (have_posts()):
        the_post();
            global $product;

            /**
             * Hook: woocommerce_before_single_product.
             *
             * @hooked wc_print_notices - 10
             */
            do_action('woocommerce_before_single_product');

            if (post_password_required()) {
                echo get_the_password_form(); // WPCS: XSS ok.
                return;
            }
            ?>
            <div id="product-<?php the_ID(); ?>" <?php wc_product_class('', $product); ?>>

                <?php
                defined('ABSPATH') || exit;

                // Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
                if (!function_exists('wc_get_gallery_image_html')) {
                    return;
                }

                global $product;

                $columns = apply_filters('woocommerce_product_thumbnails_columns', 4);
                $post_thumbnail_id = $product->get_image_id();
                $wrapper_classes = apply_filters('woocommerce_single_product_image_gallery_classes', array(
                    'woocommerce-product-gallery',
                    'woocommerce-product-gallery--' . ($product->get_image_id() ? 'with-images' : 'without-images'),
                    'woocommerce-product-gallery--columns-' . absint($columns),
                    'images'
                ));
                ?>
                <div class="<?php
                echo esc_attr(implode(' ', array_map('sanitize_html_class', $wrapper_classes)));
                ?>" data-columns="<?php
                echo esc_attr($columns);
                ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
                    <figure class="woocommerce-product-gallery__wrapper">
                        <?php
                        if ($product->get_image_id()) {
                            $html = wc_get_gallery_image_html($post_thumbnail_id, true);
                        } else {
                            $html = '<div class="woocommerce-product-gallery__image--placeholder">';
                            $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src('woocommerce_single')), esc_html__('Awaiting product image', 'woocommerce'));
                            $html .= '</div>';
                        }

                        echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped

                        do_action('woocommerce_product_thumbnails');
                        ?>
                    </figure>
                </div>

                <div class="sgm_products_single_warp">
                    <?php
                    /**
                     * Hook: woocommerce_after_single_product_summary.
                     *
                     * @hooked woocommerce_output_product_data_tabs - 10
                     * @hooked woocommerce_upsell_display - 15
                     * @hooked woocommerce_output_related_products - 20
                     */
                    do_action('woocommerce_after_single_product_summary');
                    ?>
                </div>
            </div>

            <?php
            do_action('woocommerce_after_single_product');
            ?>

        <?php
        endwhile;
        ?>
    </div>

    <?php
    wcr_share_buttons();
    endif;
    ?>

</div>