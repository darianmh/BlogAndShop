<?php
namespace Elementor;


class Header_Nav_Qiuck_Link extends Widget_Base {

	public function get_name() {
		return 'header-nav-qiuck-link';
	}
	
	public function get_title() {
		return __( 'Header Nav Qiuck Link', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-navigation-horizontal';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Header Nav Qiuck Link', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'list',
			[
				'label' => __( 'Lists Nav Quick Link', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'Text', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'List Item Name', 'sigma-theme' ),
						'default' => __( 'Order Tracking', 'sigma-theme' ),
					],
					[
						'name' => 'link',
						'label' => __( 'Link', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => get_site_url(),
        				'default' => [
        					'url' => get_site_url(),
        				]						
					],
					[
						'name' => 'icon',
						'label' => __( 'Icon', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
						'default' => [ 'value' => 'far fa-truck-moving', 'library' => 'regular', ],
					],					
				],
				'default' => [
					[
						'text' => __( 'Order Tracking', 'sigma-theme' ),
						'link' => get_site_url(),
						'icon' => [ 'value' => 'far fa-truck-moving', 'library' => 'regular', ],
					],
					[
						'text' => __( 'Site Faqs', 'sigma-theme' ),
						'link' => get_site_url(),
						'icon' => [ 'value' => 'far fa-location', 'library' => 'regular', ],
					],
					[
						'text' => __( 'Contact Us', 'sigma-theme' ),
						'link' => get_site_url(),
						'icon' => [ 'value' => 'far fa-align-center', 'library' => 'regular', ],
					],					
				],
				'title_field' => '{{{ text }}}',
			]
		);

		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Header Nav Qiuck Link', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_control(
			'icons_align',
			[
				'label' => __( 'Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .dgs_topbar_menuicons' => 'text-align: {{VALUE}};'
                ],				
			]
		);
		
		$this->add_control(
			'icon_color_nav',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [ '{{WRAPPER}} .dgs_topbar_menuicons ul li a i' => 'color: {{VALUE}}', ],
				'default' => '#fca803'
			]
		);

		$this->add_control(
			'icon_typography',
			[
				'label' => __( 'Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .dgs_topbar_menuicons ul li a i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		
		$this->add_control(
			'link_color_nav',
			[
				'label' => __( 'Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [ '{{WRAPPER}} .dgs_topbar_menuicons ul li a' => 'color: {{VALUE}}', ],
				'default' => '#666666'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Text Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_topbar_menuicons ul li a',
			]
		);
		
		$this->end_controls_section();		

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="dgs_topbar_menuicons"><ul>
		<?php foreach ( $settings['list'] as $index => $item ) : ?>
			<li>
				<?php
					?><a href="<?php echo esc_url( $item['link']['url'] ); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $item['text']; ?></a><?php
				?>
			</li>
		<?php endforeach; ?>
		</ul></div>
		<?php
	}

}