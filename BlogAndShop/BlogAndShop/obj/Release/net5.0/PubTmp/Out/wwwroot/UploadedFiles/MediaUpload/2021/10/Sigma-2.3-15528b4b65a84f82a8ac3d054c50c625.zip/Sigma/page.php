<?php get_header();?>
<?php while (have_posts()) : the_post();?>
<div class="cover-single">
    <div class="container">
        <div class="row">

<div class="breadcrumb_page">
<?php 
$args = array(
'delimiter' => ' » ',
'home' => _x( 'خانه', 'breadcrumb', 'woocommerce' ));
woocommerce_breadcrumb($args); ?>
</div>
        </div>
    </div>
</div>
    <div class="container">
        <div class= "row">
 <div class="block-white shadow">
     <?php the_content();?>
 </div>
        </div>
    </div>

<?php endwhile;?>
<style>
.fa-user:before {
    float: right;
    font-family: 'FontAwesome';
    line-height: 1;
    padding-left: 0px;
    color: #333;
    font-size: 16px;
}
button[type="submit" i] {
    border: inherit;
    background: inherit;
    color: inherit;
    height: inherit;
    line-height: inherit;
    width: inherit;
    padding: inherit;
    float: inherit;
    margin-right: inherit;
}	
.crunchify-social { display: <?php echo ot_get_option("socials_share_page"); ?>; }
</style>
<?php get_footer();?>