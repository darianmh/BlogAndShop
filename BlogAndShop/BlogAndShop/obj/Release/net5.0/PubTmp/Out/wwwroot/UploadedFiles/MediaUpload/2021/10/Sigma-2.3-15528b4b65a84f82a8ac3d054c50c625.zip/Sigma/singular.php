<?php
\SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance()->RenderSingular();
get_template_part($sigma['cart_style'] );
get_template_part($sigma['social_style'] );
