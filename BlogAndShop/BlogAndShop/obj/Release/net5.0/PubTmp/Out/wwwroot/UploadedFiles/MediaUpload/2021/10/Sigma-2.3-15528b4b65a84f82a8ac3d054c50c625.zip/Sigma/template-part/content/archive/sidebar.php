<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('left-sidebar')) : else : ?><?php endif; ?>

<?php global $sigma; if ($sigma['side_ads'] == 'inherit') { ?>
<div class="ads_sidebar">
    <a href="<?php echo $sigma['ads_side_link']; ?>" target="<?php echo $sigma['ads_side_target']; ?>">
        <?php 
        if ($sigma['ads_side_banner']['url'] != '') { ?>
            <img src="<?php echo $sigma['ads_side_banner']['url']; ?>">
        <?php } else { ?>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/ads300-1.png">
        <?php } ?>
    </a>
</div>
<?php } ?>

<div id="permissions" class="owl-carousel owl-theme enamad">
    <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('permissions-sidebar')) : else : ?><?php endif; ?>
</div>