var $ = jQuery; 
(function ($) {
    $(document).ready(function () {
        var Toast = Swal.mixin({
            toast: true,
            position: "center",
            showConfirmButton: false,
            timer: 5000,
            timerProgressBar: true,
            onOpen: (toast) => {
                toast.addEventListener("mouseenter", Swal.stopTimer), toast.addEventListener("mouseleave", Swal.resumeTimer);
            },
        });
    });
    function SigmaReturnSwal(num) {
        let Toast;
        switch (num) {
            case 1:
                Toast = Swal.mixin({
                    toast: true,
                    position: "center",
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    onOpen: (toast) => {
                        toast.addEventListener("mouseenter", Swal.stopTimer), toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                });
                break;
            case 2:
                Toast = Swal.mixin({
                    toast: true,
                    position: "center",
                    showConfirmButton: false,
                    onOpen: (toast) => {
                        toast.addEventListener("mouseenter", Swal.stopTimer), toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                });
                break;
            default:
                Toast = Swal.mixin({
                    toast: true,
                    position: "center",
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true,
                    onOpen: (toast) => {
                        toast.addEventListener("mouseenter", Swal.stopTimer), toast.addEventListener("mouseleave", Swal.resumeTimer);
                    },
                });
                break;
        }
        return Toast;
    }
    $(".sigma-add-to-wishlist").on("click", function () {
        let product_id = $(this).data("product-id");
        let message = SigmaReturnSwal(1);
        let loading = SigmaReturnSwal(2);
        loading.fire({ icon: "info", title: "در حال پردازش . . ." });
        $.post(ajax_object.ajax_url, { action: "sigma_add_to_wishlist", product_id: product_id }, function (results) {
            data = JSON.parse(results.data);
            if (results.success === false) {
                message.fire({ icon: "error", title: data.message });
            } else {
                message.fire({ icon: "success", title: data.message });
            }
        });
    });
    $(".sigma-remove-from-wishlist").on("click", function () {
        let product_id = $(this).data("product-id");
        let element = $(this);
        let message = SigmaReturnSwal(1);
        let loading = SigmaReturnSwal(2);
        loading.fire({ icon: "info", title: "در حال پردازش . . ." });
        $.post(ajax_object.ajax_url, { action: "sigma_remove_from_wishlist", product_id: product_id }, function (results) {
            data = JSON.parse(results.data);
            if (results.success === false) {
                message.fire({ icon: "error", title: data.message });
            } else {
                element.parent().parent().fadeOut();
                message.fire({ icon: "success", title: data.message });
            }
        });
    });
    $(".sigma-fast-preview").on("click", function () {
        $(".sigma-fast-load-content").addClass("loading");
        $("#sigma-fast-load").slideDown();
        let product_id = $(this).data("product-id");
        $.post(ajax_object.ajax_url, { action: "sigma_show_fast_preview", product_id: product_id }, function (results) {
            data = JSON.parse(results.data);
            console.log(data);
            if (results.success === true) {
                $(".sigma-fast-load-content").removeClass("loading");
                $(".sigma-fast-load-content").html(data.html);
            }
        });
    });
    $(".sigma-fast-load-close").on("click", function () {
        $("#sigma-fast-load").slideUp();
        $(".sigma-fast-load-content").removeClass("loading");
        $(".sigma-fast-load-content").html("");
    });
})(jQuery);
document.addEventListener("DOMContentLoaded", function (event) {
    var $load = document.getElementById("load");
    var removeLoading = setTimeout(function () {
        $load.className += " loader-removed";
    }, 500);
});
jQuery(document).ready(function ($) {
    $(".dark-mode").on("click", () => {
        $("body").toggleClass("dark-sigma");
    });
    $(".m-btn").on("click", function (e) {
        var val = parseInt($(this).prev("input").val());
        $(this)
            .prev("input")
            .val(val + 1);
    });
    $(".p-btn").on("click", function (e) {
        var val = parseInt($(this).next("input").val());
        if (val !== 0) {
            $(this)
                .next("input")
                .val(val - 1);
        }
    });
    $.thf = {};
    $.thf.ajax = {};
    $.thf.render = {};
    $.thf.cache = { search: [], getCats: [] };
    $.thf.bta = function (str) {
        return btoa(
            encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
                return String.fromCharCode(parseInt(p1, 16));
            })
        );
    };
    $("select:not([disabled])")
        .click(function () {
            $(this).toggleClass("open");
        })
        .focusout(function () {
            $(this).removeClass("open");
        });
    $("select,input,textarea").keyup(function (e) {
        if (e.keyCode == 13) {
            $(this).trigger("enterKey");
        }
    });
    if ($("#thf_ajax_search").length) {
        var $form = $("#thf_ajax_search"),
            $btn = $("#thf_btn"),
            $type = $("#thf_type"),
            $cat = $("#thf_cat"),
            $input = $("#thf_input"),
            $result = $("#thf_result");
        $input.keyup(function (e) {
            if (e.keyCode !== 13) {
                $.thf.search();
            }
        });
        $type.change(function () {
            $.thf.getCats();
        });
        $cat.change(function () {
            $.thf.search();
        });
        $btn.click(function () {
            $form.addClass("submited");
            $("#thf_ajax_search").submit();
        });
        $form.submit(function (e) {
            if (!$(this).hasClass("submited")) {
                $.thf.search();
                e.preventDefault();
            }
        });
        $(document).on("click", "#thf_showAll", function () {
            $btn.click();
        });
        $.thf.disableFormInputs = function () {
            $form.find("input,select").attr("disabled", "disabled");
        };
        $.thf.enableFormInputs = function () {
            $form.find('input:not(".disable"),select:not(".disable")').removeAttr("disabled");
        };
        $.ajaxSetup({ url: THF.ajaxURL, type: "POST" });
        $.thf.ajax.search = null;
        $.thf.search = function () {
            var data = { action: "thf_search", type: $type.val(), cat: $cat.val(), s: $.trim($input.val()), security: THF.security },
                cache_id = $.thf.bta(data.type + data.cat + data.s);
            $input.removeClass("loading");
            $result.hide().html("");
            if ($.thf.ajax.search) {
                $.thf.ajax.search.abort();
            }
            if (data.s.length < 3) {
                return false;
            }
            if (cache_id in $.thf.cache.search) {
                $.thf.render.searchItems($.thf.cache.search[cache_id]);
                return;
            }
            $.thf.ajax.search = $.ajax({
                data: data,
                beforeSend: function () {
                    $input.addClass("loading");
                    $result.hide().html("");
                },
                success: function (res) {
                    if (res.success && typeof res.data.items !== "undefined") {
                        $.thf.render.searchItems(res.data.items);
                        $.thf.cache.search[cache_id] = res.data.items;
                    } else if (typeof res.data.msg !== "undefined") {
                        $result.html(res.data.msg);
                    }
                },
            }).done(function () {
                $input.removeClass("loading");
                $result.show();
            });
        };
        $.thf.ajax.getCats = null;
        $.thf.getCats = function () {
            var data = { action: "thf_getCats", type: $type.val(), security: THF.security },
                default_item = $cat.find("option:first-child").get(0).outerHTML;
            if ($.thf.ajax.getCats) {
                $.thf.ajax.getCats.abort();
            }
            if (data.type in $.thf.cache.getCats) {
                $.thf.render.catOptions($.thf.cache.getCats[data.type], default_item);
                return;
            }
            $.thf.ajax.getCats = $.ajax({
                data: data,
                beforeSend: function () {
                    $.thf.disableFormInputs();
                    $cat.addClass("loading").html(default_item);
                },
                success: function (res) {
                    if (res.success && typeof res.data.items !== "undefined") {
                        $.thf.render.catOptions(res.data.items, default_item);
                        $.thf.cache.getCats[data.type] = res.data.items;
                    }
                },
            }).done(function () {
                $.thf.enableFormInputs();
                $cat.removeClass("loading");
            });
        };
        $.thf.render.searchItems = function (data) {
            var items = "",
                showAll = '<button id="thf_showAll"class="btn btn-primary btn-sm">مشاهده تماس نتایج</button>',
                item = '<li class="item mb-1"><a title="{title}" href="{href}" class="d-flex text-right"><span class="thumb"><img src="{image}" title="{title}" alt="{title}"></span><h3 class="mr-2">{title}</h3></a></li>';
            $.each(data, function (index, data) {
                items += item;
                items = items.replace(/{title}/g, data.title);
                items = items.replace(/{href}/g, data.link);
                items = items.replace(/{image}/g, data.image);
            });
            $result.html('<ul class="p-0 m-0">' + items + "</ul>" + showAll).show();
        };
        $.thf.render.catOptions = function (options, default_item) {
            var items = "",
                group = '<optgroup label="{label}">{childs}</optgroup>',
                item = '<option value="{id}">{title}</option>';
            if (options[0]["id"] !== "all") {
                options.unshift({ type: "item", id: "all", title: "همه دسته بندی ها" });
            }
            $.each(options, function (index, data) {
                if (data.type == "group") {
                    var childs = "";
                    $.each(data.items, function (i, d) {
                        childs += item;
                        childs = childs.replace(/{id}/g, d.id);
                        childs = childs.replace(/{title}/g, d.title);
                    });
                    items += group;
                    items = items.replace(/{label}/g, data.label);
                    items = items.replace(/{childs}/g, childs);
                } else {
                    items += item;
                    items = items.replace(/{id}/g, data.id);
                    items = items.replace(/{title}/g, data.title);
                }
            });
            $cat.html(default_item + items).trigger("change");
        };
    }
    $("#seller").owlCarousel({ nav: !0, rtl: !0, dots: !1, margin: 10, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 2 } } });
    $("#related_dgs").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 4 } } });
    $("#permissions").owlCarousel({ nav: !1, rtl: !0, dots: 0, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#permissions_footer").owlCarousel({ nav: !1, rtl: !0, dots: 0, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#course_slider_edc").owlCarousel({ nav: !1, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#slider__v4").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !0, autoplayTimeout: 5000, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#dgs_banners_slider").owlCarousel({ nav: !0, rtl: !0, dots: !0, loop: !0, autoplay: !0, autoplayTimeout: 5000, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#slider_v2").owlCarousel({ nav: !0, rtl: !0, dots: !0, loop: !0, autoplay: !0, autoplayTimeout: 5000, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#slider1").owlCarousel({ nav: !1, rtl: !0, loop: !0, autoplay: !0, autoplayTimeout: 5000, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 6 } } });
    $("#slider").owlCarousel({ nav: !1, rtl: !0, autoplay: !0, loop: !0, autoplayTimeout: 5000, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 1 } } });
    $("#last__products__homev3").owlCarousel({ nav: !0, rtl: !0, dots: !0, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 4 } } });
    $("#last__products__homev2").owlCarousel({ nav: !0, rtl: !0, dots: !0, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 4 } } });
    $("#top__posts").owlCarousel({ nav: !0, rtl: !0, dots: !0, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 3 } } });
    $("#top__products").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 3 } } });
    $("#last_products").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 3 } } });
    $("#related").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 3 } } });
    $("#related_v1").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 2 }, 1000: { items: 3 } } });
    $("#related_edc").owlCarousel({ nav: !0, rtl: !0, dots: !1, autoplay: !1, responsive: { 0: { items: 1 }, 600: { items: 1 }, 1000: { items: 2 } } });
    $(".have-mega").toggle(
        function () {
            $(this).next(".mega-menu").children(".mega-dropdown-menu").slideDown();
        },
        function () {
            $(this).next(".mega-menu").children(".mega-dropdown-menu").slideUp();
        }
    );
});
jQuery(document).ready(function () {
    jQuery(".email-popup-con").delay(2000).fadeIn();
    jQuery(".close").click(function () {
        jQuery(".email-popup-con").fadeOut();
    });
});
function myFunction() {
    var copyText = document.getElementById("myInput");
    copyText.select();
    document.execCommand("copy");
    alert("لینک کوتاه کپی شد!");
}
jQuery(document).ready(function ($) {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 1000) {
            $("#fss_side_fixed").addClass("fss_fix_show");
        }
        if ($(this).scrollTop() < 1400) {
            $("#fss_side_fixed").removeClass("fss_fix_show");
        }
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $("#menu-for-fix").addClass("fixed_menu_v3");
        } else {
            $("#menu-for-fix").removeClass("fixed_menu_v3");
        }
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            $("#for_fixed_v2").addClass("menu_fixed_v2");
        } else {
            $("#for_fixed_v2").removeClass("menu_fixed_v2");
        }
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            $("#for_fixed_v1").addClass("menu_fixed_v1");
        } else {
            $("#for_fixed_v1").removeClass("menu_fixed_v1");
        }
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() > 500) {
            $("#edc_course_meta_area_fixed").addClass("edc_course_show_fixed");
        } else {
            $("#edc_course_meta_area_fixed").removeClass("edc_course_show_fixed");
        }
    });
    $(".dropdown").hover(
        function () {
            $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeIn(500);
        },
        function () {
            $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeOut(500);
        }
    );
    $(".dropdown-submenu").hover(
        function () {
            $(this).find(".dropdown-menu").fadeIn(500);
        },
        function () {
            $(this).find(".dropdown-menu").fadeOut(500);
        }
    );
    $(".dropdown-sub-submenu").hover(
        function () {
            $(this).find(".dropdown-menu").fadeIn(500);
        },
        function () {
            $(this).find(".dropdown-menu").fadeOut(500);
        }
    );
    $(window).resize(function () {
        if ($(window).width() >= 980) {
            $(".navbar .dropdown-toggle").hover(function () {
                $(this).parent().toggleClass("show");
                $(this).parent().find(".dropdown-menu").toggleClass("show");
            });
            $(".navbar .dropdown-menu").mouseleave(function () {
                $(this).removeClass("show");
            });
        }
    });
});
jQuery(document).ready(function ($) {
    $(window).resize(function () {
        if ($(window).width() >= 980) {
            $(".navbar .dropdown-toggle").hover(function () {
                $(this).parent().toggleClass("show");
                $(this).parent().find(".dropdown-menu").toggleClass("show");
            });
            $(".navbar .dropdown-menu").mouseleave(function () {
                $(this).removeClass("show");
            });
        }
    });
});
jQuery(document).ready(function ($) {
    $(window).on("load", function () {
        preloaderFadeOutTime = 500;
        function hidePreloader() {
            var preloader = $(".spinner-wrapper");
            preloader.fadeOut(preloaderFadeOutTime);
        }
        hidePreloader();
    });
});
jQuery(document).ready(function ($) {
    $("select:not([disabled])")
        .click(function () {
            $(this).toggleClass("open");
        })
        .focusout(function () {
            $(this).removeClass("open");
        });
    $("select,input,textarea").keyup(function (e) {
        if (e.keyCode == 13) {
            $(this).trigger("enterKey");
        }
    });
    $("#thf_btn_close_top_alert").click(function () {
        Cookies.set("thfShowTopAlert", false, { expires: 1 });
    });
    $("#sgm_btn_close_popup_newsletter").click(function () {
        Cookies.set("sgmPopupNewsletter", false, { expires: 1 });
    });
});
!(function (e) {
    var n;
    if (("function" == typeof define && define.amd && (define(e), (n = !0)), "object" == typeof exports && ((module.exports = e()), (n = !0)), !n)) {
        var t = window.Cookies,
            o = (window.Cookies = e());
        o.noConflict = function () {
            return (window.Cookies = t), o;
        };
    }
})(function () {
    function f() {
        for (var e = 0, n = {}; e < arguments.length; e++) {
            var t = arguments[e];
            for (var o in t) n[o] = t[o];
        }
        return n;
    }
    function a(e) {
        return e.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent);
    }
    return (function e(u) {
        function c() {}
        function t(e, n, t) {
            if ("undefined" != typeof document) {
                "number" == typeof (t = f({ path: "/" }, c.defaults, t)).expires && (t.expires = new Date(1 * new Date() + 864e5 * t.expires)), (t.expires = t.expires ? t.expires.toUTCString() : "");
                try {
                    var o = JSON.stringify(n);
                    /^[\{\[]/.test(o) && (n = o);
                } catch (e) {}
                (n = u.write ? u.write(n, e) : encodeURIComponent(String(n)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent)),
                    (e = encodeURIComponent(String(e))
                        .replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent)
                        .replace(/[\(\)]/g, escape));
                var r = "";
                for (var i in t) t[i] && ((r += "; " + i), !0 !== t[i] && (r += "=" + t[i].split(";")[0]));
                return (document.cookie = e + "=" + n + r);
            }
        }
        function n(e, n) {
            if ("undefined" != typeof document) {
                for (var t = {}, o = document.cookie ? document.cookie.split("; ") : [], r = 0; r < o.length; r++) {
                    var i = o[r].split("="),
                        c = i.slice(1).join("=");
                    n || '"' !== c.charAt(0) || (c = c.slice(1, -1));
                    try {
                        var f = a(i[0]);
                        if (((c = (u.read || u)(c, f) || a(c)), n))
                            try {
                                c = JSON.parse(c);
                            } catch (e) {}
                        if (((t[f] = c), e === f)) break;
                    } catch (e) {}
                }
                return e ? t[e] : t;
            }
        }
        return (
            (c.set = t),
            (c.get = function (e) {
                return n(e, !1);
            }),
            (c.getJSON = function (e) {
                return n(e, !0);
            }),
            (c.remove = function (e, n) {
                t(e, "", f(n, { expires: -1 }));
            }),
            (c.defaults = {}),
            (c.withConverter = e),
            c
        );
    })(function () {});
});
jQuery(document).ready(function ($) {
    $("nav#menu01").mmenu();
});