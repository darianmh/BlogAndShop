<?php
global $sigma;
if ($sigma['cart_active'] == 'inherit') {
    ?>
    <div class="cartfix-light">
    <a style="border:2px solid <?php global $sigma;
    echo $sigma['cart_fix_count_style02']; ?> ;color:<?php 
    echo $sigma['cart_fix_count_style02']; ?> !important; display:<?php 
    echo $sigma['cart_active']; ?> ; <?php 
    echo $sigma['cart_poss_fix']; ?>:15px !important;" href="<?php echo get_permalink(wc_get_page_id('cart')); ?>"
       class="cart-sigma-light">
        <i class="fal fa-shopping-bag"></i><span style="background:<?php 
        echo '' . $sigma['cart_fix_count_style022']['background-color']; ?>;color:<?php 
        echo $sigma['cart_fix_color_style02']; ?>;display:<?php 
        echo $sigma['cart_active']; ?> ; <?php 
        echo $sigma['cart_poss_fix']; ?>:65px !important;" class="cart-counter-light"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
    </a>
</div>
<?php } ?>