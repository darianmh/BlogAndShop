<?php global $sigma; if ($sigma['user_auther_box'] == 'inherit') { ?>

<div class="autherarea">
    <div class="auther_img">
        <?php echo get_avatar(get_the_author_meta('email'), '75'); ?>
    </div>
    <div class="author_about">
        <div class="author-name"><?php echo(get_the_author_meta('display_name')); ?></a></div>
        <div class="author-date">
            <?php
            $user_id = $post->post_author;
            $reg_date = date_i18n('j F Y', strtotime(get_user_by("ID", $user_id)->user_registered));
            ?>
            <?php _e('Register date:', 'sigma-theme'); echo $reg_date; ?>
        </div>
        <p><?php the_author_meta('description'); ?></p>
    </div>

</div>

<?php } ?>

<?php if ($sigma['telegram_channel'] == 'inline') { ?>

<a class="telegram_chanel" style="display:inherit" href="<?php 
echo $sigma['link_btn_channel']; ?>" target="_blank">
    <i class="icon-telegram"></i>
    <span><?php echo $sigma['text_box_telegram']; ?></span>
    <span class="pull-left"><?php echo $sigma['text_btn_box_telegram']; ?></span>
</a>

<?php } ?>