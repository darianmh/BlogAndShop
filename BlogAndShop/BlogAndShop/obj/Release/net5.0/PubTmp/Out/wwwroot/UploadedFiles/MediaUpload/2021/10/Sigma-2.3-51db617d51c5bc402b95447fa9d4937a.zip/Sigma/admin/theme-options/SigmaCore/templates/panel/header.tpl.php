<?php
    /**
     * The template for the panel header area.
     * Override this template by specifying the path where it is stored (templates_path) in your Redux config.
     *
     * @author      Redux Framework
     * @package     ReduxFramework/Templates
     * @version:    3.5.4.18
     */

    $tip_title = __( 'Developer Mode Enabled', 'sigma-theme' );

    if ( $this->parent->dev_mode_forced ) {
        $is_debug     = false;
        $is_localhost = false;

        $debug_bit = '';
        if ( Redux_Helpers::isWpDebug() ) {
            $is_debug  = true;
            $debug_bit = __( 'WP_DEBUG is enabled', 'sigma-theme' );
        }

        $localhost_bit = '';
        if ( Redux_Helpers::isLocalHost() ) {
            $is_localhost  = true;
            $localhost_bit = __( 'you are working in a localhost environment', 'sigma-theme' );
        }

        $conjunction_bit = '';
        if ( $is_localhost && $is_debug ) {
            $conjunction_bit = ' ' . __( 'and', 'sigma-theme' ) . ' ';
        }

        $tip_msg = __( 'This has been automatically enabled because', 'sigma-theme' ) . ' ' . $debug_bit . $conjunction_bit . $localhost_bit . '.';
    } else {
        $tip_msg = __( 'If you are not a developer, your theme/plugin author shipped with developer mode enabled. Contact them directly to fix it.', 'sigma-theme' );
    }

?>
<!--
<div class="notice notice-warning is-dismissible sigma5-alert">
             <p><span class="dashicons dashicons-shield"></span>
اطلاعیه حذف برخی از قابلیت های قدیمی سیگما پلاس...
				 <a href="http://doc.hamkarwp.com/sigma/sigma5-alert/" target="_blank" class="go-panel-sigma">جزئیات بیشتر این اطلاعیه</a>
</p>
</div>
-->
<div id="redux-header">
    <?php if ( ! empty( $this->parent->args['display_name'] ) ) { ?>
        <div class="display_header">

            <?php if ( isset( $this->parent->args['dev_mode'] ) && $this->parent->args['dev_mode'] ) { ?>
                <div class="redux-dev-mode-notice-container redux-dev-qtip"
                     qtip-title="<?php echo esc_attr( $tip_title ); ?>"
                     qtip-content="<?php echo esc_attr( $tip_msg ); ?>">
                    <span>
                </div>
            <?php } elseif (isset($this->parent->args['forced_dev_mode_off']) && $this->parent->args['forced_dev_mode_off'] == true ) { ?>
                <?php $tip_title    = 'The "forced_dev_mode_off" argument has been set to true.'; ?>
                <?php $tip_msg      = 'Support options are not available while this argument is enabled.  You will also need to switch this argument to false before deploying your project.  If you are a user of this product and you are seeing this message, please contact the author of this theme/plugin.'; ?>
                <div class="redux-dev-mode-notice-container redux-dev-qtip" 
                     qtip-title="<?php echo esc_attr( $tip_title ); ?>"
                     qtip-content="<?php echo esc_attr( $tip_msg ); ?>">
                    <span
                        class="redux-dev-mode-notice" style="background-color: #FF001D;"><?php _e( 'FORCED DEV MODE OFF ENABLED', 'sigma-theme' ); ?></span>
                </div>
            
            <?php } ?>

            <h2><?php _e( 'SigmaPlus Woocommerce Theme', 'sigma-theme' ); ?></h2>

            <?php if ( ! empty( $this->parent->args['display_version'] ) ) { ?>
                <span><?php _e( 'Version: ', 'sigma-theme' ); ?><?php echo wp_kses_post( $this->parent->args['display_version'] ); ?></span>
            <?php } ?>

            <small class="hamkarwpco"><?php _e( 'Coding by a Hamkarwp programming group', 'sigma-theme' ); ?></small>

        </div>
    <?php } ?>

    <div class="clear"></div>
</div>