<?php

namespace Elementor;

class Alert_Sigma_Header extends Widget_Base
{

    public function get_name()
    {
        return 'alert-widget';
    }

    public function get_title()
    {
        return __('Alert Sigma', 'sigma-theme');
    }

    public function get_icon()
    {
        return 'eicon-alert';
    }

    public function get_categories()
    {
        return ['Sigma-Header'];
    }

    protected function _register_controls()
    {

        $this->start_controls_section(
            'section_title',
            [
                'label' => __('Sigma Alert', 'sigma-theme'),
            ]
        );

        $this->add_control(
            'alert_text',
            [
                'label' => __('Alert Text', 'sigma-theme'),
                'label_block' => true,
                'type' => Controls_Manager::WYSIWYG,
                'placeholder' => __('Enter Alert Text', 'sigma-theme'),
                'default' => __('You are viewing the preview of the Sigma Plus Iranian template, all products are demo.', 'sigma-theme'),
            ]
        );

        $this->add_control(
            'alert_active_close',
            [
                'label' => esc_html__('Active Alert Close', 'sigma-theme'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'alert_active_btn',
            [
                'label' => esc_html__('Active Alert Button', 'sigma-theme'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'alert_text_btn',
            [
                'label' => __('Alert Button Text', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('More information and purchase', 'plugin-domain'),
                'placeholder' => __('Alert Button Text', 'sigma-theme'),
                'condition' => [
                    'alert_active_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'alert_url_btn',
            [
                'label' => __('Alert Button Link', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => 'https://www.zhaket.com/web/sigma-wordpress-theme',
                'show_external' => true,
                'default' => [
                    'url' => 'https://www.zhaket.com/web/sigma-wordpress-theme',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'condition' => [
                    'alert_active_btn' => 'yes',
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_1',
            [
                'label' => __('Sigma Alert', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'alrt_bg',
                'label' => __( 'Alert Background Color', 'sigma-theme' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .alert.alert-warning.alert-dismissible.fade.show',
            ]
        );

        $this->add_control(
            'alrt_color',
            [
                'label' => __( 'Alert Text Color', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alert.alert-warning.alert-dismissible.fade.show ' => 'color: {{VALUE}}',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'alrt_close_color',
            [
                'label' => __( 'Alert Close Button Color', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} button.close span ' => 'color: {{VALUE}}',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'alrt_btn_color',
            [
                'label' => __( 'Alert Button Color', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} a.alert-link ' => 'color: {{VALUE}} !important ' ,
                ],
                'default' => '#ffffff',
            ]
        );

		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'alert_btn_border_color',
                'label' => __( 'Alert Button Border Color', 'sigma-theme' ),
                'selector' => '{{WRAPPER}}  a.alert-link ',
            ]
        );

		        $this->add_control(
                    'alrt_btn_bgcolor',
                    [
                        'label' => __( 'Alert Button Background Color', 'sigma-theme' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'scheme' => [
                            'type' => \Elementor\Scheme_Color::get_type(),
                            'value' => \Elementor\Scheme_Color::COLOR_1,
                        ],
                        'selectors' => [
                            '{{WRAPPER}} a.alert-link ' => 'background-color: {{VALUE}}  !important',
                ],
                'default' => '#ff3547',
            ]
        )
        ;
        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $target = $settings['alert_url_btn']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['alert_url_btn']['nofollow'] ? ' rel="nofollow"' : '';
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <div class="container">'; ?>
        <?php
        if ($settings['alert_active_close'] == 'yes') { ?>
            <?php echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>';
        } ?>

        <?php echo '<div class="row">
                <div class="col-lg-9">'?><?php echo $settings['alert_text']; ?>
        <?php echo '</div>' ?>

        <?php if ($settings['alert_active_btn'] == 'yes') {
        echo '<div class="col-lg-3 alert-btn">
            <a class="alert-link" href="' . $settings['alert_url_btn']['url'] . '" ' . $target . $nofollow . '> ' . $settings['alert_text_btn'] . ' </a>
          </div>
          </div></div>
        </div>';
    }
    }

}