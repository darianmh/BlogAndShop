<?php
add_action( 'init', 'sigma_theme_register_megamenu_post_type' );
function sigma_theme_register_megamenu_post_type() {
    $labels = array(
        'name'               => __( 'sigma megamenu', 'sigma-theme' ),
        'singular_name'      => __( 'sigma megamenu', 'sigma-theme' ),
        'menu_name'          => __( 'sigma megamenus', 'sigma-theme' ),
        'name_admin_bar'     => __( 'sigma megamenu', 'sigma-theme' ),
        'add_new'            => __( 'Add New', 'sigma-theme' ),
        'add_new_item'       => __( 'Add New megamenu', 'sigma-theme' ),
        'new_item'           => __( 'New megamenu', 'sigma-theme' ),
        'edit_item'          => __( 'Edit megamenu', 'sigma-theme' ),
        'view_item'          => __( 'View megamenu', 'sigma-theme' ),
        'all_items'          => __( 'All megamenus', 'sigma-theme' ),
        'search_items'       => __( 'Search megamenus', 'sigma-theme' ),
        'parent_item_colon'  => __( 'Parent megamenus:', 'sigma-theme' ),
        'not_found'          => __( 'No megamenus found.', 'sigma-theme' ),
        'not_found_in_trash' => __( 'No megamenus found in Trash.', 'sigma-theme' )
    );
    $args = array(
        'labels'             => $labels,
        'description'        => __( 'sigma megamenu builder', 'sigma-theme' ),
        'supports'           => array( 'title', 'editor'),
        'public'            => true,
        'has_archive'       => false,
        'show_in_nav_menus' => false,
        'menu_icon'         => 'dashicons-admin-post'
    );
    register_post_type( 'sigma-megamenu', $args );
}