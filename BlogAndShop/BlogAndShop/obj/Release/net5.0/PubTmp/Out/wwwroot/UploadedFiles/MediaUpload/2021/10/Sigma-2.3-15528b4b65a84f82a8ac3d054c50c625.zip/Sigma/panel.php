<?php 
/**
 * Template Name: panel Sigma
 *
 * Login Page Template.
 *
 * @author AminWEB
 * @since 1.0.0
 */
?>
<body style="margin-top: -32px;">
<head>
<meta charset="utf-8">
<title><?php the_title(); ?> | <?php echo ot_get_option("title"); ?></title>
<meta name="description" content="<?php echo ot_get_option("description"); ?>">
<meta name="keywords" content="<?php echo ot_get_option("keywords"); ?>">
<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
<link rel="icon" href="<?php echo ot_get_option("favicon"); ?>" type="image/x-icon" />
<link href="<?php bloginfo('template_url')?>/style.css" rel="stylesheet" type="text/css">
<link href="<?php bloginfo('template_url')?>/css/sigma.css" rel="stylesheet" type="text/css">

<link href="<?php bloginfo('template_url')?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">


<!--  jQuery 1.7+  -->
<script src="<?php bloginfo('template_url')?>/js/jquery-1.9.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/js/jquery-migrate-1.2.1.min.js"></script>

<?php wp_head(); ?>
</head>

			
<div class="container-register">
<div class="content-form">
	
	
	<div class="single-info">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php
setPostViews(get_the_ID());
?>
<?php endwhile; else: ?><?php endif; ?>
	

		</div>

	

<div class="content-post">

	
<?php the_content(__('')); ?>

		</div>

	
</div>	




</div>

<div class="crunchify-social" style="display:none">

<script>
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<style>
.um-form {
    padding: 40px;
    background: none;
    background-size: 160px;
    background-position-x: 50%;
    border-radius: 100px;
}
.content-post {
    padding: 105px 0px;
}
.crunchify-social {
    display: none !important;
}
</style>
</body>
</html>
