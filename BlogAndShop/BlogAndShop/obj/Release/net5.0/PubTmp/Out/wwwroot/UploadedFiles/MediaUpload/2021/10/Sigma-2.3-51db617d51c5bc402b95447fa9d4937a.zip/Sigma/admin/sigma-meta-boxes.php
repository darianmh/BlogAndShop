<?php
require_once trailingslashit(get_template_directory()) . 'includes/admin-page-framework/admin-page-framework.php';

class AddSigmaTemplatesPostTypesMetaBox extends SigmaThemeAdminPageFramework_MetaBox
{

    public function setUp()
    {
        $this->addSettingSections(
            array
            (
                'section_id' => 'sigma_header_section',
            ),
            array
            (
                'section_id' => 'sigma_footer_section',
            )
        );
        $this->addSettingFields(
            'sigma_header_section',
            array(
                'field_id' => 'default_header',
                'type' => 'select',
                'title' => __('choose header', 'sigma-theme'),
                'label' => sigma_admin_page_get_header_array()
            )
        );
        $this->addSettingFields(
            'sigma_footer_section',
            array(
                'field_id' => 'default_footer',
                'type' => 'select',
                'title' => __('choose footer', 'sigma-theme'),
                'label' => sigma_admin_page_get_footer_array()
            )
        );
    }
}

class AddSigmaTemplatesMetaBox extends SigmaThemeAdminPageFramework_MetaBox
{


    public function setUp()
    {
        $post_types = sigma_admin_page_get_included_post_types();
        $labels = array();
        foreach ($post_types as $post_type) {
            $labels[$post_type] = 'single ' . $post_type;
        }
        $this->addSettingSections(
            array
            (
                'section_id' => 'sigma_template_type',
                'title' => __('template type selection', 'sigma-theme')
            )
        );
        $this->addSettingFields(
            'sigma_template_type',
            array(
                'field_id' => 'template_type',
                'type' => 'select',
                'title' => __('choose type', 'sigma-theme'),
                'label' => $labels
            )
        );
    }
}


class AddSigmaJqueryMG extends SigmaThemeAdminPageFramework_MetaBox
{


    public function setUp()
    {
        $post_types = sigma_admin_page_get_included_post_types();
        $labels = array();
        foreach ($post_types as $post_type) {
            $labels[$post_type] = 'single ' . $post_type;
        }
        $this->addSettingSections(
            array
            (
                'section_id' => 'sigma_load_jquery',
            )
        );
        $this->addSettingFields(
            'sigma_load_jquery',
            array(
                'field_id' => 'load_jquery_type',
                'type' => 'radio',
                'title' => __('Manage jQuery in this content', 'sigma-theme'),
                'label' => array(
                    'theme' => __('from sigmaplus theme', 'sigma-theme'),
                    'wp' => __('from wordpress core', 'sigma-theme'),
                ),
                'default' => 'theme',
            )
        );
    }
}


class AddSigmaProductMetaBox extends SigmaThemeAdminPageFramework_MetaBox
{
    public function setUp()
    {
        $this->addSettingSections(
            array(
                'section_id' => 'general_info',
                'collapsible' => array(
                    'title' => __('general info', 'sigma-theme'),
                    'is_collapsed' => true
                ),
            ),
            array(
                'section_id' => 'physical_product',
                'collapsible' => array(
                    'title' => __('Physical products details', 'sigma-theme'),
                ),
                'description' => __('Check this section if your product is physical.', 'sigma-theme')
            ),            
            array(
                'section_id' => 'digital_product',
                'description' => __('if your product is not digital ignore this section', 'sigma-theme'),
                'collapsible' => array(
                    'title' => __('digital product info', 'sigma-theme'),
                    'is_collapsed' => true
                )
            ),
            array(
                'section_id' => 'tutorial_product',
                'collapsible' => array(
                    'title' => __('educational products details', 'sigma-theme'),
                    'is_collapsed' => true
                ),
                'description' => __('if your product is not tutorial ignore this section', 'sigma-theme')
            ),
            array(
                'section_id' => 'tutorial_parts',
                'repeatable' => true,
                'collapsible' => array(
                    'title' => __('tutorial parts', 'sigma-theme'),
                    'is_collapsed' => true
                )
            ),
            array(
                'section_id' => 'sigma_medal',
                'collapsible' => array(
                    'title' => __('medal creation', 'sigma-theme'),
                    'is_collapsed' => true
                ),
                'repeatable' => true,

            )            
        );
        $this->addSettingFields(
            'sigma_medal',
            array(
                'field_id' => 'medal_name',
                'type' => 'text',
                'title' => __('enter name', 'sigma-theme'),
            ),
            array(
                'field_id' => 'medal_pic',
                'type' => 'image',
                'title' => __('choose image', 'sigma-theme'),
            )
        );
        $this->addSettingFields(
            'general_info',
            array(
                'field_id' => 'product_type',
                'type' => 'radio',
                'title' => __('select product type', 'sigma-theme'),
                'label' => array(
                    'a' => __('physical product', 'sigma-theme'),
                    'b' => __('digital product', 'sigma-theme'),
                    'e' => __('digital product (new style)', 'sigma-theme'),
                    'c' => __('tutorial product', 'sigma-theme'),
                    'd' => __('defualt style theme option', 'sigma-theme')
                ),
                'default' => 'd',
            )
        );
        $this->addSettingFields(
            'physical_product',
            array(
                'field_id' => 'product_warranty',
                'title' => __('Product warranty', 'sigma-theme'),
                'type' => 'textarea',
                'label' => __('Product warranty', 'sigma-theme'),
                'default' => __('This product has a one week money back guarantee.' , 'sigma-theme'),
                'description' => __('Enter the default text or the warranty period of this product in this section, if you do not enter anything the default text of the settings will be displayed.', 'sigma-theme'),
            ),
            array(
                'field_id' => 'originality_product',
                'type' => 'checkbox',
                'label' => __('This product is original', 'sigma-theme'),
                'default' => true
            ),
            array(
                'field_id' => 'product_send_time',
                'title' => __('Product send time', 'sigma-theme'),
                'type' => 'textarea',
                'label' => __('Product send time', 'sigma-theme'),
                'default' => __('This product will be sending the next 7 working days.' , 'sigma-theme'),
                'description' => __('Enter the Send time product , if you do not enter anything the default text of the settings will be displayed.', 'sigma-theme'),
            )            
        );
        $this->addSettingFields(
            'digital_product',
            array(
                'field_id' => 'product_version',
                'title' => __('Product verion', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product verion', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_preview',
                'title' => __('Product preview', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product preview', 'sigma-theme'),
            ),
            array(
                'field_id' => 'en_product_preview',
                'title' => __('Product english preview', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product english preview', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_size',
                'title' => __('Product size', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product size', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_type',
                'title' => __('Product type', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product type', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_doc',
                'title' => __('Product help', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product help', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_include',
                'title' => __('Product includes', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product includes', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_license',
                'title' => __('Product license', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product license', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_compatibility',
                'title' => __('Product compatibility', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Product compatibility', 'sigma-theme'),
            )
        );
        $this->addSettingFields(
            'tutorial_product',
            array(
                'field_id' => 'product_part_number',
                'title' => __('Number of sessions', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Total Number of sessions', 'sigma-theme'),
            ),
            'tutorial_product',
            array(
                'field_id' => 'product_time',
                'title' => __('The duration of the course', 'sigma-theme'),
                'type' => 'text',
                'label' => __('The duration of the course', 'sigma-theme'),
            ),
            array(
                'field_id' => 'product_teacher',
                'title' => __('Course teacher', 'sigma-theme'),
                'type' => 'text',
                'label' => __('Course teacher', 'sigma-theme'),
            ),
            array(
                'field_id' => 'teacher_pic',
                'title' => __('Avatar teacher', 'sigma-theme'),
                'type' => 'image',
                'label' => __('Avatar teacher', 'sigma-theme'),
            ),
            array(
                'field_id' => 'teacher_about',
                'title' => __('About teacher', 'sigma-theme'),
                'type' => 'textarea',
                'label' => __('About teacher', 'sigma-theme'),
            ),
            array(
                'field_id' => 'teacher_number',
                'title' => __('Teacher phone number', 'sigma-theme'),
                'type' => 'textarea',
                'label' => __('Teacher phone number', 'sigma-theme'),
            )
        );
        $this->addSettingFields(
            'tutorial_parts',
            array(
                'field_id' => 'tutorial_part',
                'type' => 'text',
                'label' => __('session name', 'sigma-theme'),
            ),
            array(
                'field_id' => 'tutorial_title',
                'type' => 'text',
                'label' => __('session title', 'sigma-theme'),
            ),
            array(
                'field_id' => 'tutorial_time',
                'type' => 'text',
                'label' => __('session duration', 'sigma-theme'),
            ),
            array(
                'field_id' => 'tutorial_link',
                'type' => 'media',
                'label' => __('session link', 'sigma-theme'),
            ),
            array(
                'field_id' => 'tutorial_free',
                'type' => 'checkbox',
                'label' => __('This session is free', 'sigma-theme'),
            )
        );
    }
}

new AddSigmaTemplatesPostTypesMetaBox(null, __('Sigma template builder settings', 'sigma-theme'), sigma_admin_page_get_included_post_types(), 'normal', 'high');
new AddSigmaTemplatesMetaBox(null, __('sigma template builder meta box', 'sigma-theme'), array('sigma-template'), 'normal', 'high');
new AddSigmaProductMetaBox(null, __('Sigma single product settings', 'sigma-theme'), array('product'), 'normal', 'high');
new AddSigmaJqueryMG(null, __('Manage jQuery in this content', 'sigma-theme'), sigma_admin_page_get_included_post_types() , 'normal', 'high');

function sigma_admin_page_get_header_array()
{
    $args = array(
        'post_type' => 'sigma-header',
        'orderby' => 'date',
        'order' => 'DESC',
        'posts_per_page' => -1
    );
    $headers = new WP_Query($args);
    $headers = $headers->get_posts();
    $header_array = array('sigma_default_layout' => __('sigma default header layout', 'sigma-theme'), 'no_header' => __('no header', 'sigma-theme'));
    if (count($headers) > 0) {
        foreach ($headers as $header) {
            $header_array[$header->ID] = $header->post_title;
        }
    }
    return $header_array;
}

function sigma_admin_page_get_footer_array()
{
    $args = array(
        'post_type' => 'sigma-footer',
        'orderby' => 'date',
        'order' => 'DESC',
        'posts_per_page' => -1
    );
    $footers = new WP_Query($args);
    $footers = $footers->get_posts();
    $footer_array = array('sigma_default_layout' => __('sigma default footer layout', 'sigma-theme'), 'no_footer' => __('no footer', 'sigma-theme'));
    if (count($footers) > 0) {
        foreach ($footers as $footer) {
            $footer_array[$footer->ID] = $footer->post_title;
        }
    }
    return $footer_array;
}

function sigma_admin_page_get_included_post_types()
{
    $post_type_array = array('page', 'post', 'product');
    return $post_type_array;
}