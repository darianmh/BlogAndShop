<?php
namespace Elementor;

class Main_Grid_Posts extends Widget_Base {
	
	public function get_name() {
		return 'posts-grids';
	}
	
	public function get_title() {
		return esc_html__('Post Gird', 'sigma-theme');
	}
	
	public function get_icon() {
		return 'eicon-posts-grid';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

    
    function get_post_cat(){
        $terms = get_terms( array(
            'taxonomy' => 'category',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }
    
   protected function _register_controls() {

        $this->start_controls_section(
            'content_tab',
            [
                'label' => esc_html__('Post Gird', 'sigma-theme'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

		$this->add_control(
			'select_grid_posts_style',
			[
				'label'   => esc_html__( 'Select Post Grid Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_product_grid',
				'options' => [
                    'style01_product_grid' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_product_grid' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_product_grid' => esc_html__('Style 03', 'sigma-theme'),
                    'style04_product_grid' => esc_html__('Style 04', 'sigma-theme'),
                    'style05_product_grid' => esc_html__('Style 05', 'sigma-theme'),
                    'style06_product_grid' => esc_html__('Style 06', 'sigma-theme'),
                ],
			]
        );


		$this->add_control(
			'select_grid_posts_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style01_product_grid.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_grid_posts_style' => 'style01_product_grid',
                ],      				
			]
		);        

		$this->add_control(
			'select_grid_posts_style02',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style02_product_grid.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_grid_posts_style' => 'style02_product_grid',
                ],      				
			]
		);        

		$this->add_control(
			'select_grid_posts_style03',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style03_product_grid.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_grid_posts_style' => 'style03_product_grid',
                ],      				
			]
		);       
				
		$this->add_control(
			'select_grid_posts_style04',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style04_product_grid.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_grid_posts_style' => 'style04_product_grid',
                ],      				
			]
		);       

		$this->add_control(
			'select_grid_posts_style05',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style05_product_grid.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_grid_posts_style' => 'style05_product_grid',
                ],      				
			]
		);  

		$this->add_control(
			'select_grid_posts_style06',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style06_product_grid.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_grid_posts_style' => 'style06_product_grid',
                ],      				
			]
		);  		

 		$this->add_control(
			'gposts_title',
			[
				'label' => __( 'Grid Post Persian Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Grid Post Persian Title', 'sigma-theme' ),
                'default' => __( 'Latest Posts Blog', 'sigma-theme' ),
			]
		);

 		$this->add_control(
			'gposts_etitle',
			[
				'label' => __( 'Grid Post English Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Grid Post English Title', 'sigma-theme' ),
                'default' => 'Latest Posts Blog',
			]
		);
		
        $this->add_control(
            'post_cat',
            [
                'label' =>esc_html__('Select Categories', 'sigma-theme'),
                'type'      => Controls_Manager::SELECT2,
                'options'   => $this -> get_post_cat(),
                'label_block' => true,
                'multiple'  => true,
            ]
        );

		$this->add_control(
			'post_orderby',
			[
				'label'   => esc_html__( 'Order by', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'     => esc_html__( 'Date', 'sigma-theme' ),
					'title'    => esc_html__( 'Title', 'sigma-theme' ),
					'rand'     => esc_html__( 'Random', 'sigma-theme' ),
					'modified' => esc_html__( 'Updated', 'sigma-theme' ),
				],
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'   => esc_html__( 'Post Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);		
		
        $this->add_control(
            'post_count',
            [
              'label'         => esc_html__( 'Post count', 'sigma-theme' ),
              'type'          => Controls_Manager::NUMBER,
              'default'       => esc_html__( '3', 'sigma-theme' )
            ]
          );

          $this->add_control(
            'col_posts',
            [
                'label'     => esc_html__( 'Select Column', 'sigma-theme' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'columns-4',
                'options'   => [
                      'columns-2'     => esc_html__( '2 Column', 'sigma-theme' ),
                      'columns-3'     => esc_html__( '3 Column', 'sigma-theme' ),
                      'columns-4'     => esc_html__( '4 Column', 'sigma-theme' ),
                      'columns-5'     => esc_html__( '5 Column', 'sigma-theme' ),
                      'columns-6'     => esc_html__( '6 Column', 'sigma-theme' ),                      
                ]
            ]
        );
        
		$this->add_control(
			'btn_more_v3_active',
			[
				'label'     => esc_html__( 'More Post Button Active', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);

 		$this->add_control(
			'btn_more_v3_title',
			[
				'label'     => esc_html__( 'More Post Button Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter More Post Button Title', 'sigma-theme' ),
                'default' => __( 'More Posts Blog', 'sigma-theme' ),
                'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);
		
		$this->add_control(
			'btn_more_v3_url',
			[
				'label'     => esc_html__( 'More Post Button Link', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => get_site_url() . '/blog',
				'show_external' => true,
				'default' => [
					'url' => get_site_url() . '/blog',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);        

		$this->add_control(
			'btn_more_v4_active',
			[
				'label'     => esc_html__( 'More Post Button Active', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);

 		$this->add_control(
			'btn_more_v4_title',
			[
				'label'     => esc_html__( 'More Post Button Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter More Post Button Title', 'sigma-theme' ),
                'default' => __( 'More Posts Blog', 'sigma-theme' ),
                'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);

		$this->add_control(
			'btn_more_v4_url',
			[
				'label'     => esc_html__( 'More Post Button Link', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => get_site_url() . '/blog',
				'show_external' => true,
				'default' => [
					'url' => get_site_url() . '/blog',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);      
		
        $this->end_controls_section();

        // Style
		
        $this->start_controls_section(
        	'style_section_title',
        	[
				'label' => __( 'Main Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

//style 01

		$this->add_control(
			'title_s1_bg',
			[
				'label' => __( 'Title Area Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .titlearea' => 'background: {{VALUE}}',
				],			
				'condition' => [
					'select_grid_posts_style' => 'style01_product_grid',
				],   	
				'default' => '#f9f9f9'
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'title_s1_border',
				'label' => __( 'Title Area Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .titlearea',
				'condition' => [
					'select_grid_posts_style' => 'style01_product_grid',
				],    					
			]
		);		
		
		$this->add_control(
			'title_blog_color',
			[
				'label' => __( 'Grid Posts Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}}  .fss_title_area h2 , .titlearea h3 , .gird-posts-royal-title h4 , .box-gird-posts-royal .title__area p , .box-gird-posts-royal .title__area h3 , .title_warp_edc h3 ' => 'color: {{VALUE}}',
				],			
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_blog_tyoe',
				'label' => __( 'Grid Posts Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_title_area h2 , .titlearea h3 , .gird-posts-royal-title h4 , .box-gird-posts-royal .title__area h3 , .title_warp_edc h3 ',
			]
		);

		$this->add_control(
			'entitle_blog_color',
			[
				'label' => __( 'Grid Posts English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}}  .fss_title_area small , .titlearea small , .gird-posts-royal-title small , .box-gird-posts-royal .title__area p , .title_warp_edc small ' => 'color: {{VALUE}}',
				],			
				'default' => '#777777'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'entitle_blog_tyoe',
				'label' => __( 'Grid Posts English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .fss_title_area small , .titlearea small , .gird-posts-royal-title small , .box-gird-posts-royal .title__area p , .title_warp_edc small ',
			]
		);

		$this->add_control(
			'fa_title_align_s1',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .titlearea h3 ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
			]
		);		

		$this->add_control(
			'En_title_align_s1',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}}  .titlearea small ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
			]
		);				
		
		$this->add_control(
			'fa_title_align_s2',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .gird-posts-royal-title h4 ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
			]
		);		

		$this->add_control(
			'En_title_align_s2',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}}  .gird-posts-royal-title small' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
			]
		);				
		
		$this->add_control(
			'fa_title_align_s3',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .box-gird-posts-royal .title__area h3' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);		

		$this->add_control(
			'En_title_align_s3',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .box-gird-posts-royal .title__area p' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);				
		
		$this->add_control(
			'fa_title_align_s4',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .box-gird-posts-royal .title__area h3 ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);		

		$this->add_control(
			'En_title_align_s4',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}}  .box-gird-posts-royal .title__area p ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);				

		$this->add_control(
			'fa_title_align_s5',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .title_warp_edc h3' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);		

		$this->add_control(
			'En_title_align_s5',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}}  .title_warp_edc small ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);			
		
		$this->add_control(
			'fa_title_align_s6',
			[
				'label' => __( 'Persian Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .fss_title_area h2' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);		

		$this->add_control(
			'En_title_align_s6',
			[
				'label' => __( 'English Title Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}}  .fss_title_area small ' => 'text-align: {{VALUE}};'
                ],				
                'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);					
        $this->end_controls_section();       

        $this->start_controls_section(
            'style_tab_s1',
            [
                'label' => esc_html__( 'Posts Style', 'sigma-theme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
            ]
        );

// post style 02

		$this->add_control(
			'meta_s1_bg',
			[
				'label' => __( 'Posts Meta Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .post-meta' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
				'default' => '#fff'
			]
		);
		
        $this->add_control(
        	'post_s1_title_color',
        	[
        		'label' => __( 'Post Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .title-post h2 a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s1_title_typography',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title-post h2 a',
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
			]
		);
		
        $this->add_control(
        	'post_s1_des_color',
        	[
        		'label' => __( 'Post Title Description', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .post-meta p' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s1_des_typography',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .post-meta p',
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
			]
		);
		
        $this->add_control(
        	'post_s1_cat_color',
        	[
        		'label' => __( 'Post Meta Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .cat-post , .cat-post h5 a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s1_cat_typography',
				'label' => __( 'Post Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .cat-post , .cat-post h5 a',
				'condition' => [ 'select_grid_posts_style' => 'style01_product_grid', ],
			]
		);

		$this->add_control(
			'post_s1_meta_icon_size',
			[
				'label' => __( 'Meta Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cat-post i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'select_grid_posts_style' => 'style01_product_grid',
        		],    
			]
		);		
		$this->add_control(
			'morepost_s1_bg',
			[
				'label' => __( 'Post More Button Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .more-post' => 'background: {{VALUE}}',
				],			
				'condition' => [
					'select_grid_posts_style' => 'style01_product_grid',
				],   	
				'default' => '#9C27B0'
			]
		);
		
        $this->add_control(
        	'morepost_s1_color',
        	[
				'label' => __( 'Post More Button Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .more-post' => 'color: {{VALUE}}',
        		],		
				'condition' => [
					'select_grid_posts_style' => 'style01_product_grid',
				],   
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'morepost_s1_typography',
				'label' => __( 'Post More Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .more-post',
				'condition' => [
					'select_grid_posts_style' => 'style01_product_grid',
				],   
			]
		);
		
        $this->end_controls_section();

        $this->start_controls_section(
            'style_tab_s2',
            [
                'label' => esc_html__( 'Posts Style', 'sigma-theme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
            ]
        );

// post style 02

		$this->add_control(
			'posts_s2_bg',
			[
				'label' => __( 'Posts Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .card__post__hv2 ' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
				'default' => '#fff'
			]
		);

		$this->add_control(
			'meta_s2_bg',
			[
				'label' => __( 'Posts Meta Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .card__post__hv2__meta' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
				'default' => '#fff'
			]
		);

        $this->add_control(
        	'post_s2_title_color',
        	[
        		'label' => __( 'Post Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .card__post__hv2 h2 a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s2_title_typography',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .card__post__hv2 h2 a',
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
			]
		);

        $this->add_control(
        	'post_s2_des_color',
        	[
        		'label' => __( 'Post Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .card__post__hv2 p' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
        	]
        );
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s2_des_typography',
				'label' => __( 'Post Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .card__post__hv2 p',
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
			]
		);
        
        $this->add_control(
        	'post_s2_readmore_color',
        	[
        		'label' => __( 'Read More Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} a.readmore' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s2_readmore_typography',
				'label' => __( 'Read More Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} a.readmore',
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
			]
		); 

        $this->add_control(
        	'post_s2_cat_color',
        	[
        		'label' => __( 'Post Meta Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .card__post__hv2__meta , span.comment__nummber a ' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s2_cat_typography',
				'label' => __( 'Post Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .card__post__hv2__meta , span.comment__nummber a' ,
				'condition' => [ 'select_grid_posts_style' => 'style02_product_grid', ],
			]
		);
		

        $this->end_controls_section();

        $this->start_controls_section(
            'style_tab_s3',
            [
                'label' => esc_html__( 'Posts Style', 'sigma-theme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
            ]
        );
//post style 03

		$this->add_control(
			'meta_s3_bg',
			[
				'label' => __( 'Posts Meta Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .tops__posts__holder' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
				'default' => '#fff'
			]
		);
		
        $this->add_control(
        	'post_s3_title_color',
        	[
        		'label' => __( 'Post Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .tops__posts__holder h2 a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s3_title_typography',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .tops__posts__holder h2 a',
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);

		$this->add_control(
			'post_s3_cat_color',
			[
        		'label' => __( 'Post Meta Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__tops.col-lg-8, .auther__posts__tops.col-lg-8 a , .auther__posts__tops.col-lg-8 i ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s3_cat_type',
				'label' => __( 'Post Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .auther__posts__tops.col-lg-8, .auther__posts__tops.col-lg-8 a  ',
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);		

		$this->add_control(
			'zoom_icon_size',
			[
				'label' => __( 'Meta Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__tops.col-lg-8 i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);

		$this->add_control(
			'post_s3_day_color',
			[
				'label' => __( 'Day Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__date p ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
				'default' => '#e35744'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s3_day_typography',
				'label' => __( 'Day Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .auther__posts__date p',
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);

		$this->add_control(
			'post_s3_Month_color',
			[
				'label' => __( 'Month Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__date ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
				'default' => '#e35744'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s3_Month_typography',
				'label' => __( 'Month Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .auther__posts__date ',
				'condition' => [ 'select_grid_posts_style' => 'style03_product_grid', ],
			]
		);
		
        $this->end_controls_section();

		
        $this->start_controls_section(
        	'post_s3_more_button',
        	[
				'label' => __( 'Title Button', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'select_grid_posts_style' => [ 'style03_product_grid',  'style04_product_grid' ] ],
        	]
        );	 
        
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'post_s3_more_button_bg',
				'label' => __( 'Title Button Background Color', 'sigma-theme' ),
				'types' => ['gradient'],
        		'condition' => [ 'select_grid_posts_style' => [ 'style03_product_grid',  'style04_product_grid' ] ],
				'selector' => '{{WRAPPER}} .more__posts__e6 a ',
			]
		);        

		$this->add_control(
			'post_s3_more_button_color',
			[
				'label' => __( 'Title Button Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .more__posts__e6 a' => 'color: {{VALUE}}',
				],			
        		'condition' => [ 'select_grid_posts_style' => [ 'style03_product_grid',  'style04_product_grid' ] ],
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s3_more_button_type',
				'label' => __( 'Title Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .more__posts__e6 a',
        		'condition' => [ 'select_grid_posts_style' => [ 'style03_product_grid',  'style04_product_grid' ] ],
			]
		);
		
        $this->end_controls_section();       
        
        $this->start_controls_section(
            'style_tab_s4',
            [
                'label' => esc_html__( 'Posts Style', 'sigma-theme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
            ]
        );

// post style 04

		$this->add_control(
			'meta_s4_bg',
			[
				'label' => __( 'Posts Meta Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .grids__posts__holder__e6' => 'background: {{VALUE}}',
				],			
                'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
				'default' => '#fff'
			]
		);

        $this->add_control(
        	'post_s4_title_color',
        	[
        		'label' => __( 'Post Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .post__grid__holder h2 a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
        	]
        );
	

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s4_title_typography',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .post__grid__holder h2 a',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);
		
        $this->add_control(
        	'post_s4_des_color',
        	[
        		'label' => __( 'Post Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .post__grid__holder p' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
        	]
        );
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s4_des_typography',
				'label' => __( 'Post Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .post__grid__holder p',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);   

        $this->add_control(
        	'post_s4_cat_color',
        	[
        		'label' => __( 'Post Category Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .grids__posts__meta__holder h5 , .grids__posts__meta__holder h5 a , .grids__posts__meta__holder i ' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s4_cat_typography',
				'label' => __( 'Post Category Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .grids__posts__meta__holder h5 , .grids__posts__meta__holder h5 a ',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);

		$this->add_control(
			'post_s4_meta_icon_size',
			[
				'label' => __( 'Category Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .grids__posts__meta__holder i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'select_grid_posts_style' => 'style04_product_grid',
        		],    
			]
		);	

		$this->add_control(
			'post_s4_day_color',
			[
				'label' => __( 'Day Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__date p ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
				'default' => '#e35744'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s4_day_typography',
				'label' => __( 'Day Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .auther__posts__date p',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);

		$this->add_control(
			'post_s4_Month_color',
			[
				'label' => __( 'Month Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__date ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
				'default' => '#e35744'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s4_Month_typography',
				'label' => __( 'Month Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .auther__posts__date ',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);		

		$this->add_control(
			'post_s4_author_color',
			[
				'label' => __( 'Post Author Name Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .auther__posts__grids span' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
				'default' => '#888888'
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s4_author_typography',
				'label' => __( 'Post Author Name Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .auther__posts__grids span ',
				'condition' => [ 'select_grid_posts_style' => 'style04_product_grid', ],
			]
		);	
		
        $this->end_controls_section();



        $this->start_controls_section(
            'style_tab_s5',
            [
                'label' => esc_html__( 'Posts Style', 'sigma-theme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
            ]
        );
        
//posts style 05        

		$this->add_control(
			'meta_s5_bg',
			[
				'label' => __( 'Posts Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .last_blog_index_warp' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
				'default' => '#fff'
			]
		);
		
        $this->add_control(
        	'post_s5_title_color',
        	[
        		'label' => __( 'Post Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .last_blog_index_warp h3 a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s5_title_typography',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .last_blog_index_warp h3 a',
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);

        $this->add_control(
        	'post_s5_author_color',
        	[
        		'label' => __( 'Post Author Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .last_blog_index_warp p' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s5_author_typography',
				'label' => __( 'Post Author Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .last_blog_index_warp p',
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);		
		
        $this->add_control(
        	'post_s5_meta_color',
        	[
        		'label' => __( 'Post Meta Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .last_blog_edc_meta li , .last_blog_edc_meta li span a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s5_meta_typography',
				'label' => __( 'Post Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .last_blog_edc_meta li ',
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);				

		$this->add_control(
			'meta_s5_icon_size',
			[
				'label' => __( 'Meta Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .last_blog_edc_meta li i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);	
		
       $this->add_control(
        	'post_s5_meta_icon_color',
        	[
        		'label' => __( 'Post Meta Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#03A9F4',
        		'selectors' => [
        			'{{WRAPPER}} .last_blog_edc_meta li i ' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
        	]
        );	
        
		$this->add_control(
			'cat_bg_s5',
			[
				'label' => __( 'Posts Cagetory Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .last_blog_edc_tags a' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
				'default' => '#F44336'
			]
		);
		
        $this->add_control(
        	'cat_color_s5',
        	[
				'label' => __( 'Posts Cagetory Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .last_blog_edc_tags a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
        	]
        );		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_s5_typography',
				'label' => __( 'Posts Cagetory Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .last_blog_edc_tags a',
				'condition' => [ 'select_grid_posts_style' => 'style05_product_grid', ],
			]
		);
		
        $this->end_controls_section();




        $this->start_controls_section(
            'style_tab_s6',
            [
                'label' => esc_html__( 'Posts Style', 'sigma-theme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
            ]
        );

// posts s6

		$this->add_control(
			'meta_s6_bg',
			[
				'label' => __( 'Posts Content Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fss_last_blog_box' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
				'default' => '#fff'
			]
		);
    
        $this->add_control(
        	'post_s6_title_color',
        	[
        		'label' => __( 'Post Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#666666',
        		'selectors' => [
        			'{{WRAPPER}} .fss_last_blog_box h3 ' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s6_title_type',
				'label' => __( 'Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_last_blog_box h3 ',
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);

        $this->add_control(
        	'post_s6_des_color',
        	[
        		'label' => __( 'Post Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .fss_last_blog_box p' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s5_des_typography',
        		'label' => __( 'Post Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_last_blog_box p',
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);

        $this->add_control(
        	'post_s6_date_color',
        	[
        		'label' => __( 'Post Date Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .fss_last_blog_date  , .fss_last_blog_date p' => 'color: {{VALUE}} !important',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
        	]
        );	
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s6_date_typography',
        		'label' => __( 'Post Date Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_last_blog_date , .fss_last_blog_date p ',
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);

		$this->add_control(
			's6_date_icon_size',
			[
				'label' => __( 'Date Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_last_blog_date i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);

		$this->add_control(
			'more_btn_s6_bg',
			[
				'label' => __( 'Read More Button Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fss_last_blog_more a ' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
				'default' => '#f6ca16'
			]
		);

        $this->add_control(
        	'more_btn_s6_color',
        	[
				'label' => __( 'Read More Button Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .fss_last_blog_more a ' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'more_btn_s6_type',
				'label' => __( 'Read More Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_last_blog_more a',
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);	

        $this->add_control(
        	'post_s6_cat_color',
        	[
        		'label' => __( 'Post Meta Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .fss_last_blog_meta p , .fss_post_cat a' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_s6_cat_typography',
				'label' => __( 'Post Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_last_blog_meta p',
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
			]
		);

       $this->add_control(
        	'post_s6_cat_icon_color',
        	[
        		'label' => __( 'Post Meta Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .fss_last_blog_meta p i ' => 'color: {{VALUE}}',
        		],		
				'condition' => [ 'select_grid_posts_style' => 'style06_product_grid', ],
        	]
        );
        
		$this->add_control(
			'post_s6_meta_icon_size',
			[
				'label' => __( 'Meta Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_last_blog_meta p i' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'select_grid_posts_style' => 'style06_product_grid',
        		],    
			]
		);		
		
        $this->end_controls_section();
    }

    protected function render( ) {
	$settings = $this->get_settings_for_display();
        if($settings['select_grid_posts_style'] == 'style01_product_grid' && !empty($settings['select_grid_posts_style'])){    
        echo '<div class="gird-posts-plus"><div class="row titlearea darkeble"> <div class="col-lg-6 col-sm-6 col-6 title-sigma nopadding"><h3>'.$settings ['gposts_title'].'</h3></div> <div class="col-lg-6 col-sm-6 col-6 title-archive nopadding"><small>'.$settings ['gposts_etitle'].'</small></div></div>';
            $this->render_raw();
        echo '</div>';
        }
        
        if($settings['select_grid_posts_style'] == 'style02_product_grid'){    
        echo '<div class="gird-posts-royal"><div class="gird-posts-royal-title"><h4>'.$settings ['gposts_title'].'</h4><small>'.$settings ['gposts_etitle'].'</small></div><div class="row"></div>';
            $this->render_raw();
        echo '</div>';
        }     
        
        if($settings['select_grid_posts_style'] == 'style03_product_grid'){  
    	$target = $settings['btn_more_v3_url']['is_external'] ? ' target="_blank"' : '';
    	$nofollow = $settings['btn_more_v3_url']['nofollow'] ? ' rel="nofollow"' : '';            
        echo '<div class="box-gird-posts-royal"><div class="row"> <div class="col-lg-9 title__area"> <h3>'.$settings ['gposts_title'].'</h3> <p>'.$settings ['gposts_etitle'].'</p> </div> <div class="col-lg-3"> <div class="more__posts__e6">'?>
        <?php if($settings['btn_more_v3_active'] == 'yes'){
        echo'<a href="' . $settings['btn_more_v3_url']['url'] . '">' . $settings['btn_more_v3_title'] . '</a>';
        } ?>
        <?php
        echo'</div></div></div>';
            $this->render_raw();
        echo '</div>';
        }
        
        if($settings['select_grid_posts_style'] == 'style04_product_grid'){   
    	$target = $settings['btn_more_v4_url']['is_external'] ? ' target="_blank"' : '';
    	$nofollow = $settings['btn_more_v4_url']['nofollow'] ? ' rel="nofollow"' : '';	            
        echo '<div class="box-gird-posts-royal"><div class="row"> <div class="col-lg-9 title__area"> <h3>'.$settings ['gposts_title'].'</h3> <p>'.$settings ['gposts_etitle'].'</p> </div> <div class="col-lg-3 title__area"> <div class="more__posts__e6">'?>
        <?php if($settings['btn_more_v4_active'] == 'yes'){
        echo'<a href="' . $settings['btn_more_v4_url']['url'] . '">' . $settings['btn_more_v4_title'] . '</a>';
        } ?>
        <?php
        echo'</div> </div> </div>';
            $this->render_raw();
        echo '</div>';
        }
        
        if($settings['select_grid_posts_style'] == 'style05_product_grid'){    
        echo '<div class="box-gird-posts-edu"><div class="title_warp_edc title_edc_single"> <i class="far fa-ellipsis-h-alt"></i> <h3>'.$settings ['gposts_title'].'</h3> <small>'.$settings ['gposts_etitle'].'</small> </div>';
            $this->render_raw();
        echo '</div>';
        }  
        
        if($settings['select_grid_posts_style'] == 'style06_product_grid'){    
        echo '<div class="box-gird-posts-file"><div class="fss_title_area"> <h2>'.$settings ['gposts_title'].'</h2> <small>'.$settings ['gposts_etitle'].'</small> </div>';
            $this->render_raw();
        echo '</div>';
        }          
    }

    protected function render_raw( ) {
        $settings = $this->get_settings();

        extract($settings);

        $query = array(
            'post_type'         => 'post',
            'post_status'       => 'publish',
            'cat'               => $post_cat,
            'posts_per_page'    => $post_count,
			'orderby'             => $settings['post_orderby'],
			'order'               => $settings['post_order'],            
        );

        if($settings['select_grid_posts_style'] == 'style01_product_grid' && !empty($settings['select_grid_posts_style'])){            
        ?>
        <div class="cols-post <?php echo $settings['col_posts']; ?>"><div class="sgm_post_gird_area darkeble">
            <?php $xs_query = new \WP_Query( $query ); ?>
            <?php  if($xs_query->have_posts()): ?>
                <?php while ($xs_query->have_posts()) : ?>
                    <?php $xs_query->the_post(); ?>
                    <?php if(has_post_thumbnail()): ?>
                    <div class="index-posts">
                        <div class="last-posts darkeble">
                            <a href="<?php the_permalink() ?>">
                                <?php the_post_thumbnail('blog'); ?>
                            </a>
                        
                            <div class="post-meta">
                                <div class="title-post">
                                    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2></div>
                                <p>
                                    <?php echo wp_trim_words( get_the_content(), 30, '...' ); ?>
                                </p>
                        
                                <div class="row">
                                    <div class="cat-post col-lg-6 col-7">
                                        <h5><i class="fa fa-folder"></i> <?php the_category(', ') ?></h5></div>
                        
                                    <div class="cat-post col-lg-6 col-5">
                                        <i class="fa fa-eye"></i>
                                        <?php echo getPostViews(get_the_ID()); ?>
                                    </div>
                                </div>
                                <a class="more-post" href="<?php the_permalink() ?>" target="_blank"><i class="fa fa-list-ul"></i>توضیحات بیشتر</a>
                            </div>
                        </div>
                    </div>    
                    <?php endif; ?>
                    
                <?php endwhile;
            endif;
            wp_reset_postdata(); ?>
        </div></div>
        <?php 
        }
        if($settings['select_grid_posts_style'] == 'style02_product_grid'){ ?>
        <div class="cols-post <?php echo $settings['col_posts']; ?>"><div class="sgm_post_gird_area">
            <?php $xs_query = new \WP_Query( $query ); ?>
            <?php  if($xs_query->have_posts()): ?>
                <?php while ($xs_query->have_posts()) : ?>
                    <?php $xs_query->the_post(); ?>
                    <?php if(has_post_thumbnail()): ?>        
            <div class="last__posts__colhv2 grid_posts_sgm">
                <div class="sgm_post_s2_area darkeble">
                <a href="<?php the_permalink() ?>">
                    <?php the_post_thumbnail('blog'); ?>
                </a>
                <div class="card__post__hv2">
                    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                    <p>
                        <?php echo wp_trim_words( get_the_content(), 30, '...' ); ?>
                    </p>
                    <a class="readmore" href="<?php the_permalink() ?>">ادامه مطلب</a>
            
                </div>
                <div class="card__post__hv2_avatar">
                    <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>" target="_blank">
                        <?php echo get_avatar( get_the_author_meta('email'), '60' ); ?>
                    </a>
                </div>
                <div class="card__post__hv2__meta">
                    <?php echo get_the_date('l j F Y'); ?> <span class="comment__nummber"> <?php comments_popup_link('بدون نظر', 'يك نظر', '% نظر'); ?></span>
                </div>
            </div>
            </div>
                    <?php endif; ?>
                <?php endwhile;
            endif;
            wp_reset_postdata(); ?>    
        </div>
        </div>    
        <?php 
        }
        if($settings['select_grid_posts_style'] == 'style03_product_grid'){ ?>
        <div class="cols-post <?php echo $settings['col_posts']; ?>"><div class="sgm_post_gird_area">
            <?php $xs_query = new \WP_Query( $query ); ?>
            <?php  if($xs_query->have_posts()): ?>
                <?php while ($xs_query->have_posts()) : ?>
                    <?php $xs_query->the_post(); ?>
                    <?php if(has_post_thumbnail()): ?>      
                    <div class="grid_posts_sgm">
                        <div class="row tops__posts__holder darkeble">
                            <div class="col-lg-5 nopadding">
                                <a href="<?php the_permalink() ?>">
                                    <?php the_post_thumbnail('grids'); ?>
                                </a>
                            </div>
                            <div class="col-lg-7">
                                <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        
                                <div class="row">
                                    <div class="auther__posts__tops col-8 col-lg-8">
                                        <div class="row">
                                            <div class="col-12">
                                                <h5><i class="fal fa-file"></i><?php the_category(', ') ?></h5>
                                            </div>
                                            <div class="col-12 postviews__grid">
                                                <i class="fal fa-eye"></i>
                                                <?php echo getPostViews(get_the_ID()); ?>
                                            </div>
                                        </div>
                                    </div>
                                <div class="auther__posts__date auther__top__posts__date auther__top__posts__date_elementor col-lg-4 col-4">
                                        <?php the_time('<p> j </p> F'); ?>
                                    </div>
                                </div>
                        
                            </div>
                        
                        </div>
                    </div>    
                    <?php endif; ?>
                <?php endwhile;
            endif;
            wp_reset_postdata(); ?>       
        </div></div>    
        <?php 
        }
        if($settings['select_grid_posts_style'] == 'style04_product_grid'){ ?>
        <div class="cols-post <?php echo $settings['col_posts']; ?>"><div class="sgm_post_gird_area">
            <?php $xs_query = new \WP_Query( $query ); ?>
            <?php  if($xs_query->have_posts()): ?>
                <?php while ($xs_query->have_posts()) : ?>
                    <?php $xs_query->the_post(); ?>
                    <?php if(has_post_thumbnail()): ?>    
                    <div class="grid_posts_sgm">
                        <div class="row grids__posts__holder__e6">
                            <div class="col-lg-6 image__grid__holder nopadding">
                                <a href="<?php the_permalink() ?>">
                                    <?php the_post_thumbnail('blog'); ?>
                                </a>
                            </div>
                            <div class="col-lg-6 post__grid__holder darkeble">
                        
                                <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        
                                <p>
                                    <?php echo wp_trim_words( get_the_content(), 40, '...' ); ?>
                                </p>
                        
                                <div class="grids__posts__meta__holder">
                                    <div class="row">
                                        <div class="col-lg-12 col-12">
                                            <h5><i class="fal fa-file"></i><?php the_category(', ') ?></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="auther__posts__grids col-lg-8 col-8">
                                        <?php echo get_avatar( get_the_author_meta('email'), '40' ); ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>" target="_blank"> <span class="category"><?php the_author() ?> 
                                               </span></a>
                                            <br>
                        
                                    </div>
                        
                                    <div class="auther__posts__date col-lg-4 col-4">
                                        <?php the_time('<p> j </p> F'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <?php endif; ?>
                <?php endwhile;
            endif;
            wp_reset_postdata(); ?>      
        </div></div>    
        <?php 
        }
        if($settings['select_grid_posts_style'] == 'style05_product_grid'){ ?>
        <div class="cols-post <?php echo $settings['col_posts']; ?>"><div class="sgm_post_gird_area">
            <?php $xs_query = new \WP_Query( $query ); ?>
            <?php  if($xs_query->have_posts()): ?>
                <?php while ($xs_query->have_posts()) : ?>
                    <?php $xs_query->the_post(); ?>
                    <?php if(has_post_thumbnail()): ?>     
                    <div class="grid_posts_sgm">
                        <div class="last_blog_index_warp darkeble">
                            <div class="last_blog_photo">
                                <a href="#"><?php the_post_thumbnail('blog'); ?></a>
                                <div class="last_blog_bg_over"></div>
                            </div>
                            <div class="last_blog_edc_tags"><?php the_category('') ?></div>
                            <div class="last_blog_edc_avatar"><?php echo get_avatar( get_the_author_meta('email'), '60' ); ?></div>
                            <h3><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                            <p>توسط <?php echo get_the_author_meta( 'display_name' ); ?></p>
                            <ul class="last_blog_edc_meta">
                                <li><i class="far fa-eye"></i><span><?php echo getPostViews(get_the_ID()); ?></span></li>
                                <li><i class="far fa-comment"></i><span><?php comments_popup_link('بدون نظر', 'يك نظر', '% نظر'); ?></span></li>
                                <li><i class="far fa-calendar"></i><?php the_time('<p> j </p> F'); ?></li>
                            </ul>
                        </div>
                        </div>
                    <?php endif; ?>
                <?php endwhile;
            endif;
            wp_reset_postdata(); ?>   
        </div></div>    
        <?php 
        }
        if($settings['select_grid_posts_style'] == 'style06_product_grid'){ ?>
        <div class="cols-post <?php echo $settings['col_posts']; ?>"><div class="sgm_post_gird_area">
            <?php $xs_query = new \WP_Query( $query ); ?>
            <?php  if($xs_query->have_posts()): ?>
                <?php while ($xs_query->have_posts()) : ?>
                    <?php $xs_query->the_post(); ?>
                    <?php if(has_post_thumbnail()): ?>   
                    <div class="grid_posts_sgm">
                        <card class="fss_last_blog_card darkeble">
                            <figure class="fss_last_blog_photo" style="background: url(<?php the_post_thumbnail_url(); ?>) center center / cover no-repeat;">
                                <img alt="<?php the_title(); ?>" title="<?php the_title(); ?>" src="<?php the_post_thumbnail_url(); ?>" style="display:none">
                            </figure>
                            <div class="fss_last_blog_box">
                                <div class="fss_last_blog_date"><i class="fal fa-clock"></i><?php the_time('j F'); ?></div>
                                <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><h3><?php the_title(); ?></h3></a>
                                <p><?php echo wp_trim_words( get_the_content(), 40, '...' ); ?></p>
                                <div class="fss_last_blog_more">
                                    <a href="<?php the_permalink() ?>">بیشتر بخوانید...</a>
                                </div>
                            </div>
                            <div class="fss_last_blog_meta">
                                <div class="row">
                                    <div class="col-3 nopadding-left">
                                        <p><i class="fal fa-eye"></i><?php echo getPostViews(get_the_ID()); ?></p>
                                    </div>
                                    <div class="col-5 fss_post_cat nopadding">
                                        <p><i class="fal fa-file"></i><?php the_category(', ') ?></p>
                                    </div>
                                    <div class="col-4 nopadding-right">
                                        <p><i class="fal fa-user"></i><?php echo get_the_author_meta( 'display_name' ); ?></p>
                                    </div>
                                </div>
                            </div>
                        </card>
                    </div>
                    <?php endif; ?>
                <?php endwhile;
            endif;
            wp_reset_postdata(); ?>    
            </div></div>
        <?php 
        }

    }
}
