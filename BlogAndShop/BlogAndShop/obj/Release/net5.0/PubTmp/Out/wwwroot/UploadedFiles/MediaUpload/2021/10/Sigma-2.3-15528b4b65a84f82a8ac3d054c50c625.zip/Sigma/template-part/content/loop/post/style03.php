<div class="last_blog_index_warp darkeble">
    <?php global $sigma;
    if ($sigma['show_img_loop_v3'] == 'enable') {
        ?>
        <div class="last_blog_photo">
            <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
                <?php the_post_thumbnail('blog'); ?>
            </a>
            <div class="last_blog_bg_over"></div>
        </div>
    <?php }
    if ($sigma['show_cat_loop_v3'] == 'enable') { ?>
        <div class="last_blog_edc_tags">
            <?php the_category('') ?>
        </div>
    <?php }
    if ($sigma['show_avatar_loop_v3'] == 'enable') { ?>
        <div class="last_blog_edc_avatar">
            <?php echo get_avatar(get_the_author_meta('email'), '60'); ?>
        </div>
    <?php }
    if ($sigma['show_title_loop_v3'] == 'enable') { ?>
        <h3><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
    <?php }
    if ($sigma['show_author_loop_v3'] == 'enable') { ?>
        <p>توسط
            <?php echo get_the_author_meta('display_name'); ?>
        </p>
    <?php } ?>
    <ul class="last_blog_edc_meta">
        <?php if ($sigma['show_veiws_loop_v3'] == 'enable') { ?>
            <li><i class="far fa-eye"></i><span><?php echo getPostViews(get_the_ID()); ?></span></li>
        <?php } ?>

        <?php if ($sigma['show_comments_loop_v3'] == 'enable') { ?>
            <li>
                <i class="far fa-comment"></i>
                    <span>
                        <?php
                        $css_class = 'zero-comments';
                        $number = (int)get_comments_number(get_the_ID());

                        if (1 === $number)
                            $css_class = 'one-comment';
                        elseif (1 < $number)
                            $css_class = 'multiple-comments';

                        comments_popup_link(
                            __('No Comment', 'sigma-theme'),
                            __('1 Comment', 'sigma-theme'),
                            __('% Comments', 'sigma-theme'),
                            $css_class,
                            __('Comments are Closed', 'sigma-theme')
                        );
                        ?>
                    </span>
            </li>
        <?php } ?>

        <?php if ($sigma['show_date_loop_v3'] == 'enable') { ?>
            <li><i class="far fa-calendar"></i>
                <?php the_time('<p> j </p> F'); ?>
            </li>
        <?php } ?>

    </ul>
</div>