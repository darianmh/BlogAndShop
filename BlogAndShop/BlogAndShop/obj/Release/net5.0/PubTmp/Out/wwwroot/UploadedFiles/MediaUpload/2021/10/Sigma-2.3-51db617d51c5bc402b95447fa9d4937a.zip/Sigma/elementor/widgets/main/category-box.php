<?php
namespace Elementor;

class Main_Category_Box extends Widget_Base {

	public function get_name() {
		return 'main-category-box';
	}
	
	public function get_title() {
		return __( 'Category Box', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-info-box';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Category Box', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'select_category_style',
			[
				'label'   => esc_html__( 'Select Category Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_cat_box',
				'options' => [
                    'style01_cat_box' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_cat_box' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_cat_box' => esc_html__('Style 03', 'sigma-theme'),
                    'style04_cat_box' => esc_html__('Style 04', 'sigma-theme'),
                ],
			]
        );

		$this->add_control(
			'sigma_style01_cat_box',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style01_cat_box.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_category_style' => 'style01_cat_box',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_style02_cat_box',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style02_cat_box.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_category_style' => 'style02_cat_box',
                ],      				
			]
		);     

		$this->add_control(
			'sigma_style03_cat_box',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style03_cat_box.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_category_style' => 'style03_cat_box',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_style04_cat_box',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style04_cat_box.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_category_style' => 'style04_cat_box',
                ],      				
			]
		);        
		
		$this->add_control(
			'list',
			[
				'label' => __( 'Category Box List', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'title', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'List Item', 'sigma-theme' ),
						'default' => __( 'Free Download', 'sigma-theme' ),
					],
					[
						'name' => 'link',
						'label' => __( 'Link', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => get_site_url() .'/shop' ,
        				'default' => [
        					'url' => get_site_url() .'/shop' ,
        				]						
					],
					[
						'name' => 'icon',
						'label' => __( 'Icon', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
        				'default' => [
        					'value' => 'fas fa-shopping-bag',
        					'library' => 'light',
        				],
        			],	
				],
				'default' => [
					[
						'text' => __( 'Free Download', 'sigma-theme' ),
						'link' => get_site_url() .'/shop' ,
						'icon' => [ 'value' => 'fas fa-shopping-bag', 'library' => 'light', ],
					],
					[
						'text' => __( 'Free Coureses', 'sigma-theme' ),
						'link' => get_site_url() .'/shop' ,
						'icon' => [ 'value' => 'fas fa-graduation-cap', 'library' => 'light', ],
					],
					[
						'text' => __( 'Free book', 'sigma-theme' ),
						'link' => get_site_url() .'/shop' ,
						'icon' => [ 'value' => 'fas fa-book', 'library' => 'light', ],
					],
					[
						'text' => __( 'Free video', 'sigma-theme' ),
						'link' => get_site_url() .'/shop' ,
						'icon' => [ 'value' => 'fas fa-play', 'library' => 'light', ],
					],
					[
						'text' => __( 'Free content', 'sigma-theme' ),
						'link' => get_site_url() .'/shop' ,
						'icon' => [ 'value' => 'fas fa-text', 'library' => 'light', ],
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);

		$this->add_control(
			'title_icon',
			[
				'label' => __( 'Title Icon', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-send-backward',
					'library' => 'light',
				],
				'condition' => [ 'select_category_style' => 'style04_cat_box',]
			]
		);

		$this->add_control(
			'link_title',
			[
				'label' => __( 'Title Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => get_site_url() . '/shop',
				'condition' => [ 'select_category_style' => 'style04_cat_box',],
				'default' => [
					'url' => get_site_url() . '/shop',
				]
			]
		);

 		$this->add_control(
			'cat_title',
			[
				'label' => __( 'Category Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Category Title Enter', 'sigma-theme' ),
                'default' => __( 'Themes & Plugins', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'edc_cat_title',
			[
				'label' => __( 'Category Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Category Title', 'sigma-theme' ),
                'default' => 'Categories',
                'condition' => [ 'select_category_style' => 'style03_cat_box',]
			]
		);

		$this->add_control(
			'edc_cat_icon',
			[
				'label' => __( 'Category Icon', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-th',
					'library' => 'regular',
				],
				'condition' => [ 'select_category_style' => 'style03_cat_box',]
			]
		);	

		$this->add_control(
			'edc_cat_subtitle',
			[
				'label' => __( 'Category SubTitle', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Category SubTitle', 'sigma-theme' ),
                'default' => 'Papular Categories',
                'condition' => [ 'select_category_style' => 'style03_cat_box',]
			]
		);
		
		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Category Box List', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
        
        $this->add_control(
    	'dgs_color_text_category_box',
    	[
    		'label' => __( 'Category Box Text Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#f95678',
    		'selectors' => [
    			'{{WRAPPER}} .search__cat__box ul li a' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style01_cat_box',]
    	]
        );

        $this->add_control(
    	'dgs_color_icon_category_box',
    	[
    		'label' => __( 'Category Box Icon Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#333333',
    		'selectors' => [
    			'{{WRAPPER}} .search__cat__box ul li a i' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style01_cat_box',]
    	]
        );
        
        $this->add_group_control(
              Group_Control_Border::get_type(),
              [
                'name' => 'border_search__cat__box',
                'label' => __( 'Border Box', 'sigma-theme' ),
                'selector' => '{{WRAPPER}} .search__cat__box ul li',
                'condition' => [ 'select_category_style' => 'style01_cat_box',]
              ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_search__cat__box',
				'label' => __( 'Background Box', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .search__cat__box ul li',
                'condition' => [ 'select_category_style' => 'style01_cat_box',]
			]
		);


// style 02

        $this->add_control(
    	'color_text_category_box_s2',
    	[
    		'label' => __( 'Category Box Text Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#b9b9b9',
    		'selectors' => [
    			'{{WRAPPER}} .fss_header_cat ul li a' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style02_cat_box',]
    	]
        );

        $this->add_control(
    	'color_icon_category_box_s2',
    	[
    		'label' => __( 'Category Box Icon Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#f6ca16',
    		'selectors' => [
    			'{{WRAPPER}} .fss_header_cat ul li a i' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style02_cat_box',]
    	]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_search__cat__box__s2',
				'label' => __( 'Background Box', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fss_header_cat ul li',
                'condition' => [ 'select_category_style' => 'style02_cat_box',]
			]
		);

        $this->add_control(
    	'border_search_s2_border',
    	[
		    'label' => __( 'Border Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#99999954',
    		'selectors' => [
    			'{{WRAPPER}} .fss_header_cat ul li a i:after' => 'border-left: 1px dashed {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style02_cat_box',]
    	]
        );
        
// style 03

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_color_cat_s3',
				'label' => __( 'Category Box Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
				'selector' => '{{WRAPPER}} .quick-cat',
			]
		);        

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_color_cat_s3_hover',
				'label' => __( 'Category Box Hover Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
				'selector' => '{{WRAPPER}} .quick-cat:hover',
			]
		);            
 
		$this->add_control(
			'cat_box_s3_icon_color',
			[
				'label' => __( 'Category Box Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .quick-cat i' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
                'default' => '#9999999',
			]
		);        
		
		$this->add_control(
			'cat_box_s3_text_color',
			[
				'label' => __( 'Category Box Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .quick-cat' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
                'default' => '#888888',
			]
		);  		

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cat_box_s3_bg_list',
				'label' => __( 'Category Box Lists Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
				'selector' => '{{WRAPPER}} .category_menu_edc ul',
			]
		);		
		
		$this->add_control(
			'cat_box_s3_bg_list_title_color',
			[
				'label' => __( 'Category Box Lists Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .category-education p' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
                'default' => '#9c9c9c',
			]
		);  		
		

		$this->add_control(
			'cat_box_s3_bg_list_icon_color',
			[
				'label' => __( 'Category Box Lists Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .category-education ul li a' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
                'default' => '#888888',
			]
		);  			
		
		$this->add_control(
			'cat_box_s3_bg_list_item_icon_color',
			[
				'label' => __( 'Category Box Lists Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .category-education ul li a i' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'select_category_style' => 'style03_cat_box',],
                'default' => '#888888',
			]
		);  				

//style 04		

        $this->add_control(
    	'fss_cat_title_icon_color',
    	[
    		'label' => __( 'Category Box Title Icon Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#f6ca16',
    		'selectors' => [
    			'{{WRAPPER}} .fss_footer_col_nav h4 a i' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style04_cat_box',]
    	]
        );

        $this->add_control(
    	'fss_cat_title_color',
    	[
    		'label' => __( 'Category Box Title Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#afafaf',
    		'selectors' => [
    			'{{WRAPPER}} .fss_footer_col_nav h4 a' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style04_cat_box',]
    	]
        );   

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_area_title_typography',
    		    'label' => __( 'Category Box Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_footer_col_nav h4 a ',
				'condition' => [ 'select_category_style' => 'style04_cat_box',]
			]
		);               
        
        $this->add_control(
    	'fss_cat_title_border_color',
    	[
    		'label' => __( 'Category Box Title Border Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#f6ca16',
    		'selectors' => [
    			'{{WRAPPER}} .fss_footer_col_nav h4 a:after' => 'background: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style04_cat_box',]
    	]
        );                

        $this->add_control(
    	'fss_cat_item_color',
    	[
    		'label' => __( 'Category Box Item Color', 'sigma-theme' ),
    		'type' => \Elementor\Controls_Manager::COLOR,
    		'scheme' => [
    			'type' => \Elementor\Scheme_Color::get_type(),
    			'value' => \Elementor\Scheme_Color::COLOR_1,
    		],
    		'default' => '#a9a9a9',
    		'selectors' => [
    			'{{WRAPPER}} .fss_footer_col_nav ul li a' => 'color: {{VALUE}}',
    		],		
            'condition' => [ 'select_category_style' => 'style04_cat_box',]
    	]
        ); 
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'fss_cat_title_type',
    		    'label' => __( 'Category Box Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_footer_col_nav ul li a ',
				'condition' => [ 'select_category_style' => 'style04_cat_box',]
			]
		);        
        
		$this->add_control(
			'fss_cat_title_icon_size',
			[
    		    'label' => __( 'Category Box Title Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 45,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_footer_col_nav h4 a i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [ 'select_category_style' => 'style04_cat_box',]
			]
		);        
        
		$this->end_controls_section();		

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
        if($settings['select_category_style'] == 'style01_cat_box' && !empty($settings['select_category_style'])){    
		?>
		<div class="search__cat__box"><div class="row"><ul>
		<?php foreach ( $settings['list'] as $index => $item ) : ?>
			<li class="col-lg-2 col-3 darkeble">
                <a href="<?php echo esc_url( $item['link']['url'] ); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'] , [ 'aria-hidden' => 'true' ] ); ?><?php echo $item['text']; ?></a>
			</li>
		<?php endforeach; ?>
		</ul></div></div>
		<?php
        }
        if($settings['select_category_style'] == 'style02_cat_box' ){ 
        ?>
		<div class="fss_header_cat"><ul><div class="row">
		<?php foreach ( $settings['list'] as $index => $item ) : ?>
			<li>
                <a href="<?php echo esc_url( $item['link']['url'] ); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $item['text']; ?></a>
			</li>
		<?php endforeach; ?>
		</div></ul></div>
        <?php
        }    
        if($settings['select_category_style'] == 'style03_cat_box' ){ 
        ?>
		<div class="category-education"><a class="quick-cat" href="#"><?php \Elementor\Icons_Manager::render_icon( $settings['edc_cat_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $settings['edc_cat_title']; ?></a><div class="category_menu_edc"><ul><p><?php echo $settings['edc_cat_subtitle']; ?></p>
		<?php foreach ( $settings['list'] as $index => $item ) : ?>
			<li class="cat_edc">
                <a href="<?php echo esc_url( $item['link']['url'] ); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $item['text']; ?></a>
			</li>
		<?php endforeach; ?>
		</ul></div></div>        
        <?php
        }
        if($settings['select_category_style'] == 'style04_cat_box' ){ 
        ?>
		<div class="fss_footer_col_nav">
            <h4><a href="<?php echo esc_url( $settings['link_title']['url'] ); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['title_icon'], [ 'aria-hidden' => 'true' ] ); ?></i><?php echo $settings['cat_title']; ?></a></h4><ul>
		<?php foreach ( $settings['list'] as $index => $item ) : ?>
            <li><a href="<?php echo esc_url( $item['link']['url'] ); ?>"><?php echo $item['text']; ?></a></li>
		<?php endforeach; ?>
		</ul></div>
        <?php
        }           
	}

}
