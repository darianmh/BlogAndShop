<?php
namespace Elementor;

class Main_Courses_Deal extends Widget_Base {
	
	public function get_name() {
		return 'courses-deal';
	}
	
	public function get_title() {
		return __( 'Courses Deal', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-product-pages';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

    function get_product_cat(){
        $terms = get_terms( array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }
 
    function get_product_tag(){
        $terms = get_terms( array(
            'taxonomy' => 'product_tag',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }    
    
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Courses Deal', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_sigma_course_title',
			[
				'label'     => __( 'Show Course title', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => __( 'yes' , 'sigma-theme' ),
			]
		);		
		
		$this->add_control(
			'grid_products_title',
			[
				'label' => __( 'title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'title products title', 'sigma-theme' ),
                'default' => __( 'Digital and Electric Goods', 'sigma-theme' ),
                'condition' => [ 'show_sigma_course_title' => 'yes', ],                
			]
		);

		$this->add_control(
			'grid_products_en_title',
			[
				'label' => __( 'english title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'english title products title', 'sigma-theme' ),
                'default' => __( 'Digital and Electric Goods', 'sigma-theme' ),
                'condition' => [ 'show_sigma_course_title' => 'yes', ],                
			]
		);	
		
		$this->add_control(
			'icon_title',
			[
				'label' => __( 'Icon title', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'far fa-ellipsis-h-alt',
					'library' => 'light',
				],
                'condition' => [ 'show_sigma_course_title' => 'yes', ],                
			]
		);
		
		$this->add_control(
			'sigma_posts_per_page',
			[
				'label'   => esc_html__( 'Product Limit', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);
		
		$this->add_control(
			'sigma_orderby',
			[
				'label'   => esc_html__( 'Order by', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'     => esc_html__( 'Date', 'sigma-theme' ),
					'title'    => esc_html__( 'Title', 'sigma-theme' ),
					'category' => esc_html__( 'Category', 'sigma-theme' ),
					'rand'     => esc_html__( 'Random', 'sigma-theme' ),
					'total_sales'     => esc_html__( 'Sale', 'sigma-theme' ),
				],
			]
		);

		$this->add_control(
			'sigma_order',
			[
				'label'   => esc_html__( 'Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);		

		$this->add_control(
			'sigma_woo_product_select',
			[
				'label'   => esc_html__( 'Show product by ', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'category',
				'options' => [
                    'category' => esc_html__('Category', 'sigma-theme'),
                    'product' => esc_html__('Product', 'sigma-theme'),
                    'tag' => esc_html__('Tag', 'sigma-theme'),
                ],
			]
        );
        
		$this->add_control(
			'sigma_woo_cat',
			[
				'label'   => esc_html__( 'Category', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_cat(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'category',
                ],
			]
        );

		$this->add_control(
			'sigma_woo_tag',
			[
				'label'   => esc_html__( 'tag', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_tag(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'tag',
                ],
			]
        );     		
		
		$this->end_controls_section();


        $this->start_controls_section(
        	'section_style_title',
        	[
				'label' => __( 'Sigma Courses Title Section', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );

		$this->add_control(
			'courses_area_icon_color',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc i ' => 'color: {{VALUE}}',
				],			
				'default' => '#41d3e6'
			]
		);

		$this->add_control(
			'courses_area_title_color',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc h3 ' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_area_title_typography',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title_warp_edc h3 ',
			]
		);

		$this->add_control(
			'courses_area_en_title_color',
			[
				'label' => __( 'Sub Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc small ' => 'color: {{VALUE}}',
				],			
				'default' => '#bbbbbb'
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_area_subtitle_typography',
				'label' => __( 'Sub Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title_warp_edc small ',
			]
		);		

		$this->add_control(
			'courses_area_icon_size',
			[
				'label' => __( 'Title Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 35,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		$this->end_controls_section();
	
        $this->start_controls_section(
        	'course_single_style',
        	[
				'label' => __( 'Courses Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

//list style
        
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'course_single_bg_list',
				'label' => __( 'Course Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .special_class_item ',
			]
		);

		$this->add_control(
			'course_single_title_color_list',
			[
				'label' => __( 'Course Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .special_class_item h2' => 'color: {{VALUE}}',
				],			
				'default' => '#333333'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'course_single_title_type_list',
				'label' => __( 'Course Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .special_class_item h2',
			]
		);

		$this->add_control(
			'course_single_entitle_color_list',
			[
				'label' => __( 'Course English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .special_class_item small' => 'color: {{VALUE}}',
				],			
				'default' => '#aba6a6'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'course_single_entitle_type_list',
				'label' => __( 'Course English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .special_class_item small',
			]
		);

		$this->add_control(
			'courses_meta_count_color',
			[
				'label' => __( 'Courses Meta Counter Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta_qiuck_special_edc ul li p' => 'color: {{VALUE}}',
				],			
				'default' => '#656565',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_meta_count_tyoe',
				'label' => __( 'Courses Meta Counter Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .meta_qiuck_special_edc ul li p',
			]
		);

		$this->add_control(
			'courses_label_count_color',
			[
				'label' => __( 'Courses Meta Label Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta_qiuck_special_edc ul li span' => 'color: {{VALUE}}',
				],			
				'default' => '#656565',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_meta_label_tyoe',
				'label' => __( 'Courses Meta Label Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .meta_qiuck_special_edc ul li span',
			]
		);

		$this->add_control(
			'courses_price_color_s1',
			[
				'label' => __( 'Coureses Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .edc_special_price p span' => 'color: {{VALUE}}',
				],			
				'default' => '#41d3e6'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_price_type_s1',
				'label' => __( 'Coureses Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .edc_special_price p span',
			]
		);

		$this->add_control(
			'courses_currency_color_s1',
			[
				'label' => __( 'Coureses Currency Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .edc_special_price p' => 'color: {{VALUE}}',
				],			
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_currency_type_s1',
				'label' => __( 'Coureses Currency Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .edc_special_price p',
			]
		);

		$this->add_control(
			'courese_icon_size',
			[
				'label' => __( 'Coureses Qiuck Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .special_bookmark i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		$this->add_control(
			'courese_qicon_size',
			[
				'label' => __( 'Coureses Qiuck Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .special_bookmark i ' => 'color: {{VALUE}}',
				],			
				'default' => '#41d3e6'
			]
		);		

		$this->add_control(
			'courese_des_color',
			[
				'label' => __( 'Courses Descroption Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .special_class_item_meta_edc p' => 'color: {{VALUE}}',
				],			
				'default' => '#9e9e9e'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courese_des_typography',
				'label' => __( 'Courses Descroption Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .special_class_item_meta_edc p',
			]
		);
        
        /**
        
		$this->add_control(
			'courses_timer_color_first',
			[
				'label' => __( 'Courses Firts Timer Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .timer_products_edc p span' => 'color: {{VALUE}}',
				],			
				'default' => '#999999'
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'courses_timer_bg',
				'label' => __( 'Courses Timer Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .timer_products_edc p span',
			]
		);

		$this->add_control(
			'courses_timer_color_last',
			[
				'label' => __( 'Courses Last Timer Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .timer_products_edc p:last-child span' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'courses_timer_last_bg',
				'label' => __( 'Courses Last Timer Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .timer_products_edc p:last-child span',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_timer_typography',
				'label' => __( 'Courses Timer Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .timer_products_edc p:last-child span , .timer_products_edc p span',
			]
		);

		$this->add_control(
			'courses_timer_label_color',
			[
				'label' => __( 'Courses Timer Label Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .timer_products_edc small' => 'color: {{VALUE}}',
				],			
				'default' => '#666666'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_timer_label_type',
				'label' => __( 'Courses Timer Label Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .timer_products_edc small',
			]
		);
		
		*/
		
		$this->end_controls_section();
	}

	public function render_description() {
		$settings = $this->get_settings();
		global $product;
		echo '<div class="row items_class">
                    <div class="col-md-7 col-sm-12 special_class_item_meta_edc">
                        <a href="'.get_the_permalink().'" title="'.get_the_title().'"><h2>'.get_the_title().'</h2></a>' ?>
                        <!--
                        <div class="timer_products_edc">
                            <p><span>02</span><small>روز</small></p>
                            <p><span>12</span><small>ساعت</small></p>
                            <p><span>54</span><small>دقیقه</small></p>
                            <p><span>34</span> <small>ثانیه</small></p>
                        </div>   
                        -->
                        <?php echo'<small>'.( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ).'</small>
                        <p class="description_edc_special">'.wp_trim_words( get_the_content(), 60, '...' ).'</p>
                        <hr>
                        <div class="meta_qiuck_special_edc">
                        <ul>
                            <li> '?>
                            <?php
                            $id = get_the_ID();
                            $info = sigma_get_tutorial_info($id);        
                            ?>                            
                                <p><?php 
                                if($info > 1 ) {
                                echo $info['product_time'];
                                }
                                else {
                                    echo'-';
                                }
                                ?></p><span>طول دوره</span></li>
                            <li>
                                <?php echo'<p>'.get_comments_number().'</p><span>تعداد دیدگاه</span></li>
                            <li>
                                <p>'.( get_post_meta( get_the_ID(), 'total_sales', true ) ).'</p><span>تعداد دانشجو</span></li>
                        </ul>
                        </div>
                        <div class="row">
                            <div class="col-md-7 col-sm-7 edc_badges">
                                <ul>' ?>
                            <?php
                            $id = get_the_ID();
                            $medals = sigma_get_product_medals($id);
                            if(false != $medals)
                            {
                                foreach ($medals as $medal)
                                    {
                                        ?>
                                        <li id="hexagon" class="badge_singel pink_badge"><img src="<?php echo $medal['medal_pic'] ?>" alt="<?php echo $medal['medal_name'] ?>"><span class="badge-tooltip"><?php echo $medal['medal_name'] ?></span></li>
                                        <?php
                                    }    
                            }        
                            ?>
                            <?php echo'</ul>
                            </div>
                            <div class="col-md-5 col-sm-5 edc_special_price">'?>
                               <?php woocommerce_template_single_price(); ?>
                            <?php echo'</div>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-12 special_class_item_photo_edc">
                        <a href="'.get_the_permalink().'">'?> <?php the_post_thumbnail( 'blog' ); ?> <?php echo'</a>' ?>
                        <?php
                            
                            if(!sigma_is_in_wishlist(''))
                            {
                                ?>
                                <div class="special_bookmark"><a class="sigma-add-to-wishlist" data-product-id="<?php the_ID(); ?>"><i class="far fa-bookmark"></i></a> </div>
                                <?php
                            }
                            else
                            {
                                ?>
                                <div class="special_bookmark"> <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank" class="sigma-add-to-wishlist-added" data-product-id="<?php the_ID(); ?>"><span class="badge-tooltip-all">مشاهده علاقه مندی ها</span><i class="far fa-bookmark"></i></a> </div>
                                <?php
                            }
                        ?>    
                        
                        <?php 
                        $id = get_the_ID();
                        $info = sigma_get_tutorial_info($id);                           
                        echo'<div id="hexagon_teacher"><img alt="avatar" title="avatar" src="'.$info['teacher_pic'].'"></div>
                    </div>            
                </div>';
	}
	
	public function render_query() {
		$settings = $this->get_settings();

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } 
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } 
		else { $paged = 1; }

        $args = array(
            'post_type'      => 'product',
            'orderby' => 'rand',
            'posts_per_page' => 10, //If you want all the post replace 4 with -1.
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_type',
                        'field' => 'slug',
                        'terms' => 'simple',
                    ),
                    array(
                        'taxonomy' => 'product_visibility',
                        'field' => 'name',
                        'terms' => array('outofstock'),
                        'operator' => 'NOT IN'
                    )
                ),                    
            'meta_query'     => array(
                    'relation' => 'OR',
                    array( // Simple products type
                        'key'           => '_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    ),
                    array( // Variable products type
                        'key'           => '_min_variation_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    )
                )
        );
    
        if($settings['sigma_woo_product_select'] == 'category'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_cat',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_cat'],
                    ],
                ]
        ];

            $args = array_merge($args, $arg_tax);
		}

        if($settings['sigma_woo_product_select'] == 'tag'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_tag',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_tag'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}
		
        if($settings['sigma_woo_product_select'] == 'product' && !empty($settings['sigma_woo_product'])){
            $arg_product = [
				'post__in' => $settings['sigma_woo_product'],
			];
			$args = array_merge($args, $arg_product);
		}

		$wp_query = new \WP_Query($args);

		return $wp_query;
	}

	public function render_loop_item() {
		$settings = $this->get_settings();
		global $post;

        $wp_query = $this->render_query();

		if($wp_query->have_posts()) {

			$this->add_render_attribute('sigma-wc-products-wrapper', 'sigma-grid', '');
			?>
			<div <?php echo $this->get_render_attribute_string( 'sigma-wc-products-wrapper' ); ?>>
			<?php			

			$this->add_render_attribute('sigma-wc-product', 'class', [
				'sigma-wc-product',
				]); 
				?>
				<ul class="owl-carousel owl-theme courses_sigma_area darkeble" id="course_slider_edc">
					<?php $count = 1; while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
						<li class="modern_gird_products_warp sigma-wc-product product">
							<div class="sigma-course-list-style">

							<?php 
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php $count++; endwhile;	?>
				</ul>
			</div>
			<?php

			wp_reset_postdata();
			
		} else {
			echo '<div class="attr-alert-warning attr-alert no-products">' . esc_html__( 'Oops! No products were found.', 'sigma-theme' ) .'<div>';
		}
	}	

	
	protected function render() {
		$settings = $this->get_settings_for_display();
		echo'<div class="title_warp_edc title_edc_single">' ?>
        <?php \Elementor\Icons_Manager::render_icon( $settings['icon_title'], [ 'aria-hidden' => 'true' ] ); ?>
		<?php echo'<h3>'.$settings['grid_products_title'].'</h3> <small>'.$settings['grid_products_en_title'].'</small></div><div class="special_class_item">';		
		$this->render_loop_item();
    	echo'</div>';
	}
	
}