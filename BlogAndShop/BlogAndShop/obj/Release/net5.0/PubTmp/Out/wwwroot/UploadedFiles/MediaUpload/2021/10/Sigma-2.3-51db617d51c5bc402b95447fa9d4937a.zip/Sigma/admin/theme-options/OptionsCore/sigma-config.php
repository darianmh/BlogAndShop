<?php

if (!class_exists('Redux')) {
    return;
}


// This is your option name where all the Redux data is stored.
$opt_name = "sigma";

// This line is only for altering the demo. Can be easily removed.
$opt_name = apply_filters('sigma/opt_name', $opt_name);


$sampleHTML = '';
if (file_exists(dirname(__FILE__) . '/info-html.html')) {
    Redux_Functions::initWpFilesystem();

    global $wp_filesystem;

    $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
}

// Background Patterns Reader
$sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
$sample_patterns_url = ReduxFramework::$_url . '../sample/patterns/';
$sample_patterns = array();

if (is_dir($sample_patterns_path)) {

    if ($sample_patterns_dir = opendir($sample_patterns_path)) {
        $sample_patterns = array();

        while (($sample_patterns_file = readdir($sample_patterns_dir)) !== false) {

            if (stristr($sample_patterns_file, '.png') !== false || stristr($sample_patterns_file, '.jpg') !== false) {
                $name = explode('.', $sample_patterns_file);
                $name = str_replace('.' . end($name), '', $sample_patterns_file);
                $sample_patterns[] = array(
                    'alt' => $name,
                    'img' => $sample_patterns_url . $sample_patterns_file
                );
            }
        }
    }
}

/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name' => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name' => $theme->get('Name','sigma-theme'),
    // Name that appears at the top of your panel
    'display_version' => $theme->get('Version','sigma-theme'),
    // Version that appears at the top of your panel
    'menu_type' => 'menu',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu' => true,
    // Show the sections below the admin menu item or not
    'menu_title' => __('Sigma Settings' ,'sigma-theme'),
    'page_title' => __('Sigma Settings', 'sigma-theme'),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key' => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography' => false,
    // Use a asynchronous font on the front end or font string
    //'disable_google_fonts_link' => true,        // Disable this in case you want to create your own google fonts loader
    'admin_bar' => true,
    // Show the panel pages on the admin bar
    'admin_bar_icon' => 'dashicons-portfolio',
    // Choose an icon for the admin bar menu
    'admin_bar_priority' => 50,
    // Choose an priority for the admin bar menu
    'global_variable' => '',
    // Set a different name for your global variable other than the opt_name
    'dev_mode' => false,
    // Show the time the page took to load, etc
    'update_notice' => true,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer' => false,
    // Enable basic customizer support
    //'open_expanded'     => true,        // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,        // Disable the save warning when a user changes a field

    // OPTIONAL -> Give you extra features
    'page_priority' => null,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent' => 'themes.php',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions' => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon' => '',
    // Specify a custom URL to an icon
    'last_tab' => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon' => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug' => '',
    // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
    'save_defaults' => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show' => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark' => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export' => true,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time' => 60 * MINUTE_IN_SECONDS,
    'output' => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag' => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit'     => '',       // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database' => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn' => true,
    // If you prefer not to use the CDN for button_set2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    // HINTS
    'hints' => array(
        'icon' => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color' => 'lightgray',
        'icon_size' => 'normal',
        'tip_style' => array(
            'color' => 'red',
            'shadow' => true,
            'rounded' => false,
            'style' => '',
        ),
        'tip_position' => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect' => array(
            'show' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'mouseover',
            ),
            'hide' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'click mouseleave',
            ),
        ),
    )
);
// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['admin_bar_links'][] = array(
    'id' => 'redux-docs',
    'href' => 'http://doc.hamkarwp.com/sigma/',
    'title' => __('tutorials', 'sigma-theme'),
);

$args['admin_bar_links'][] = array(
    //'id'    => 'redux-support',
    'href' => 'https://zhaket.com/product/sigma-wordpress-theme/support',
    'title' => __('support', 'sigma-theme'),
);

$args['admin_bar_links'][] = array(
    'id' => 'redux-extensions',
    'href' => 'http://hamkarwp.com',
    'title' => __('developers website', 'sigma-theme'),
);

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
    'url' => 'https://www.facebook.com/pages/hamkarwp/243141545850368',
    'title' => __('Like us on Facebook', 'sigma-theme'),
    'icon' => 'el el-facebook'
);
$args['share_icons'][] = array(
    'url' => 'http://twitter.com/hamkarwp',
    'title' => __('Follow us on Twitter', 'sigma-theme'),
    'icon' => 'el el-twitter'
);
$args['share_icons'][] = array(
    'url' => 'http://www.linkedin.com/company/hamkarwp',
    'title' => __('Find us on LinkedIn', 'sigma-theme'),
    'icon' => 'el el-linkedin'
);

// Panel Intro text -> before the form
if (!isset($args['global_variable']) || $args['global_variable'] !== false) {
    if (!empty($args['global_variable'])) {
        $v = $args['global_variable'];
    } else {
        $v = str_replace('-', '_', $args['opt_name']);
    }
    $args['intro_text'] = sprintf(__('intro text', 'sigma-theme'), $v);
} else {
    $args['intro_text'] = __('<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'sigma-theme');
}

// Add content after the form.
$args['footer_text'] = __('all rights reserved for the developers team.', 'sigma-theme');
//echo '<div class="fix-disimce"><a id="remove" class="is-dismissible-alert"> v </a><a href="http://doc.hamkarwp.com/sigma/faq-sigma/training-video-works-with-the-new-features-of-sigma-plus/" target="_blank" class="go-video-alert"> مشاهده ویدئو آموزشی </a></div>';
Redux::setArgs($opt_name, $args);

/*
		 * ---> END ARGUMENTS
		 */


/*
		 * ---> START HELP TABS
		 */

$tabs = array(
    array(
        'id' => 'redux-help-tab-1',
        'title' => __('guide 1', 'sigma-theme'),
        'content' => __('<p>choosing a template will set the default style of the selected one</p>', 'sigma-theme')
    ),
    array(
        'id' => 'redux-help-tab-2',
        'title' => __('guide 2', 'sigma-theme'),
        'content' => __('<p>sigma plus settings connot be copied on another theme</p>', 'sigma-theme')
    )
);
Redux::setHelpTab($opt_name, $tabs);

// Set the help sidebar
$content = __('<p>you can buy this theme in zhaket only!</p>', 'sigma-theme');
Redux::setHelpSidebar($opt_name, $content);


/*
		 * <--- END HELP TABS
		 */


/*
		 *
		 * ---> START SECTIONS
		 *
		 */

/*

			As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


		 */

// -> START Generan Setting

Redux::setSection($opt_name, array(
    'title' => __('General settings','sigma-theme'),
    'id' => 'generan-setting',
    'customizer_width' => '700px',
));
Redux::setSection($opt_name, array(
    'title' => __('primery settings','sigma-theme'),
    'subsection' => true,
    'id' => 'public_options',
    'customizer_width' => '400px',
    'fields' => array(
        array(
            'id' => 'section_02',
            'title' => __('general settings','sigma-theme'),
            'type' => 'section',
            'class' => 'ruby-section-start',
            'indent' => true
        ),
        array(
            'id' => 'dark_version',
            'type' => 'button_set',
            'title' => __('night mode','sigma-theme'),
            'subtitle' => __('you can set the night mode/dark mode for whole site','sigma-theme'),
            'default' => 'light-sigma',
            'options' => array(
                'dark-sigma' => __('On','sigma-theme'),
                'light-sigma' => __('Off','sigma-theme'),
            ),
        ),
        array(
            'id' => 'dark_version_img_filter',
            'type' => 'button_set',
            'title' => __('dark filter for pictures','sigma-theme'),
            'subtitle' => __('turnin this on changes the color of the pictures into black and white','sigma-theme'),
            'default' => 'grayscale(100%) !important',
            'options' => array(
                'grayscale(100%) !important' => __('On','sigma-theme'),
                'none !important' => __('Off','sigma-theme'),
            ),
        ),
        array(
            'id' => 'socials_box',
            'type' => 'button_set',
            'title' => __('social media buttons','sigma-theme'),
            'subtitle' => __('you can turn off/on the fixed button on the left side here!','sigma-theme'),
            'default' => 'inherit',
            'options' => array(
                'inherit' => __('On','sigma-theme'),
                'none' => __('Off','sigma-theme'),
            ),
        ),
        array(
            'id' => 'social_style',
            'type' => 'select',
            'required' => array('socials_box', '=', 'inherit'),
            'title' => __('choose the social media icons here  ','sigma-theme'),
            'subtitle' => __('choose one of the icons below for the social media icons','sigma-theme'),
            'options' => array(
                'template-part/fix-bars' => __('Default','sigma-theme'),
                'template-part/fix-bars-light' => __('Naterial','sigma-theme'),
            ),
            'default' => 'template-part/fix-bars-light'
        ),
        array(
            'id' => 'cart_active',
            'type' => 'button_set',
            'title' => __('shopping cart  ','sigma-theme'),
            'subtitle' => __('From this section you can manage the fixed icon of the shopping cart.!','sigma-theme'),
            'default' => 'inherit',
            'options' => array(
                'inherit' => __('On','sigma-theme'),
                'none' => __('Off','sigma-theme'),
            ),
        ),
        array(
            'id' => 'cart_style',
            'required' => array('cart_active', '=', 'inherit'),
            'type' => 'select',
            'title' => __('Choose a fixed shopping cart design','sigma-theme'),
            'subtitle' => __('Choose one of the available designs for your sites fixed shopping cart.','sigma-theme'),
            'options' => array(
                'template-part/cart-fix' => __('Default','sigma-theme'),
                'template-part/cart-fix-light' => __('Naterial','sigma-theme'),
            ),
            'default' => 'template-part/cart-fix-light'
        ),
        array(
            'id' => 'cart_fix_bg_style01',
            'title' => __('Shopping cart icon background color','sigma-theme'),
            'required' => array('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'subtitle' => __('Select the desired color for the background of the default style shopping cart icon!','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array(
                'background-color' => '#0da3f4',),
        ),
        array(
            'id' => 'cart_fix_count_style01',
            'title' => __('Background color Product number','sigma-theme'),
            'required' => array('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'subtitle' => __('Background Color Choose the number of products in the cart!','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array(
                'background-color' => '#0b7cb9',),
        ),
        array(
            'id' => 'cart_fix_color_style01',
            'required' => array('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'type' => 'color',
            'title' => __('Icon color and product number','sigma-theme'),
            'subtitle' => __('Icon color Specify the number of products in the cart to do!','sigma-theme'),
            'default' => '#FFFFFF',
        ),
        array(
            'id' => 'cart_fix_count_style022',
            'title' => __('Background color Product number','sigma-theme'),
            'required' => array('cart_style', '=', 'template-part/cart-fix-light','sigma-theme'),
            'subtitle' => __('Background Color Choose the number of products in the cart!','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array(
                'background-color' => '#ff5722',),
        ),
        array(
            'id' => 'cart_fix_color_style02',
            'required' => array('cart_style', '=', 'template-part/cart-fix-light','sigma-theme'),
            'type' => 'color',
            'title' => __('Color Number of product','sigma-theme'),
            'subtitle' => __('Specify the number of products in the cart color!','sigma-theme'),
            'default' => '#FFFFFF',
        ),
        array(
            'id' => 'cart_fix_count_style02',
            'title' => __('Border colors and shopping cart icons','sigma-theme'),
            'required' => array('cart_style', '=', 'template-part/cart-fix-light','sigma-theme'),
            'subtitle' => __('Select the border color of the shopping cart icon!','sigma-theme'),
            'type' => 'color',
            'default' => '#ff5722',
        ),

        array(
            'id' => 'cart_poss_fix',
            'required' => array('cart_active', '=', 'inherit'),
            'title' => __('Fixed cart position','sigma-theme'),
            'subtitle' => __('Select a fixed cart position.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'right',
            'options' => array(
                'left' => __('Bottom left','sigma-theme'),
                'right' => __('Bottom right','sigma-theme'),
            ),
        ),
        array(
            'id' => 'ajax_login_bg',
            'title' => __('Ajax Form Login and Membership Background','sigma-theme'),
            'subtitle' => __('From this section, you can change the image of Ajax login and membership form.','sigma-theme'),
            'type' => 'background',
            'class' => 'dnone_v5',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-color' => false,
            'background-attachment' => false,
            'default' => array(
                'background-image' => '' . get_template_directory_uri() . '/assets/img/bg_login_popup.png'
            )
        ),
        array(
            'id' => 'link_color',
            'type' => 'color',
            'title' => __('Color site links','sigma-theme'),
            'class' => 'dnone_v5',
            'subtitle' => __('Specify the desired color for all links on your site. The color of the links in menus and footers that have separate color settings will not change from this section.','sigma-theme'),
            'default' => '#8C8B8B',
        ),
        array(
            'id' => 'body_back',
            'title' => __('Site background color','sigma-theme'),
            'subtitle' => __('Choose the background color of the site. This color is only adjustable in box mode.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array(
                'background-color' => '#fafafc',),
        ),
        array(
            'id' => 'backtop_show',
            'type' => 'button_set',
            'title' => __('Show back button','sigma-theme'),
            'default' => 'inherit',
            'class' => 'dnone_v5',
            'subtitle' => __('From this section you can manage the display of the back button at the top of the site.!','sigma-theme'),
            'options' => array(
                'inherit' => __('On','sigma-theme'),
                'none' => __('Off','sigma-theme'),
            ),
        ),
        array(
            'id' => 'role_comment_pro',
            'type' => 'button_set',
            'default' => 'inherit',
            'title' => __('Show comment posting rules','sigma-theme'),
            'subtitle' => __('Post comment rules should be displayed at the bottom of the description of the content and products or not ?.','sigma-theme'),
            'options' => array(
                'inherit' => __('On','sigma-theme'),
                'none' => __('Off','sigma-theme'),
            ),
        ),
        array(
            'id' => 'role_post_content',
            'title' => __('Content Rules Comments','sigma-theme'),
            'subtitle' => __('Change the content of the comments posting rules displayed at the bottom of the site posts and products.!','sigma-theme'),
            'required' => array('role_comment_pro', '=', 'inherit'),
            'default' => __('<h4>Rules for posting comments on the site</h4>
            <ul class="before-note">
		<li class="before-comment"><i class="fal fa-caret-left"></i> If the view is offensive and directed at administrators, writers and other users, it will not be approved.</li>
		<li class="before-comment"><i class="fal fa-caret-left"></i> If your comment has an advertising aspect, it will not be approved.</li>
		<li class="before-comment"><i class="fal fa-caret-left"></i>  If you have used the link of other websites or your website in the comment will not be approved.</li>
		<li class="before-comment"><i class="fal fa-caret-left"></i>  		If you have used the contact number, email and Telegram ID in your comment, it will not be approved.</li>
		<li class="before-comment"><i class="fal fa-caret-left"></i>  If a view unrelated to the subject of education is raised, it will not be approved.</li>
	        </ul>','sigma-theme'),
            'type' => 'editor',
        ),
        array(
            'id' => 'share_posts',
            'default' => 'inherit',
            'type' => 'button_set',
            'title' => __('Display content sharing buttons','sigma-theme'),
            'subtitle' => __('The share button is displayed at the bottom of the product details and posts.','sigma-theme'),
            'options' => array(
                'inherit' => __('On','sigma-theme'),
                'none' => __('Off','sigma-theme'),
            ),
        ),
    ),

));

Redux::setSection($opt_name, array(
    'title' => __('Loading settings','sigma-theme'),
    'subsection' => true,
    'id' => 'loader_options',
    'customizer_width' => '400px',
    'fields' => array(
        array (
            'id' => 'section_loader_options',
            'title' => __('Loading Settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'page_loader',
            'type' => 'button_set',
            'title' => __('Site Loader','sigma-theme'),
            'subtitle' => __('From this section you can enable/disable the loader before loading the site ..','sigma-theme'),
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'page_custom_loader',
            'type' => 'button_set',
            'title' => __('Enable custom loader','sigma-theme'),
            'subtitle' => __('From this section you can select the order preloader for your site.','sigma-theme'),
            'default' => 'disable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'page_custom_loader_imga',
            'required' => array ('page_custom_loader', '=', 'enable','sigma-theme'),
            'title' => __('Custom Loader Image','sigma-theme'),
            'subtitle' => __('It is recommended to use square images such as your site logo or icon.','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/favicon-sigma.png'),
        ),
        array (
            'id' => 'page_loader_style',
            'type' => 'image_select',
            'required' => array ('page_loader', '=', 'inherit'),
            'required' => array ('page_custom_loader', '=', 'disable','sigma-theme'),
            'title' => __('Site Preloader Plan', 'sigma-theme'),
            'subtitle' => __('Choose one of the available designs to load or preload your site!', 'sigma-theme'),
            'options' => array (
                'z' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/loader_00.png'
                ),
                '1' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_1.gif'
                ),
                '2' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_2.gif'
                ),
                '3' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_3.gif'
                ),
                '4' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_4.gif'
                ),
                '5' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_5.gif'
                ),
                '6' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_6.gif'
                ),
                '7' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_7.gif'
                ),
                '8' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_8.gif'
                ),
                '9' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_9.gif'
                ),
                'q' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_10.gif'
                ),
                'o' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_11.gif'
                ),
                't' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_12.gif'
                ),
                'h' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_13.gif'
                ),
                'v' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_14.gif'
                ),
                's' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_15.gif'
                ),
                'a' => array(
                    'img' => ReduxFramework::$_url . 'assets/img/Preloader_16.gif'
                )
            ),
            'default' => 'z'
        ),
        array (
            'id' => 'page_loader_icon',
            'title' => __('Site upload icon color','sigma-theme'),
            'subtitle' => __('Specify the color of the site preload icon!','sigma-theme'),
            'type' => 'color',
            'default' => '#ff3547',
            'required' => array ('page_loader', '=', 'inherit'),
            'required' => array ('page_loader_style', '=', 'z','sigma-theme'),
            'required' => array ('page_custom_loader', '=', 'disable','sigma-theme'),
        ),
        array (
            'id' => 'page_loader_bg',
            'title' => __('Site loader background color','sigma-theme'),
            'subtitle' => __('This color is displayed for the background of the entire page builder when loading.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#FFF','sigma-theme'),
            'required' => array ('page_loader', '=', 'inherit'),
            'required' => array ('page_loader_style', '=', 'z','sigma-theme'),
            'required' => array ('page_custom_loader', '=', 'disable','sigma-theme'),
        ),
    )
));
Redux::setSection($opt_name, array (
    'title' => __('Pop-up settings','sigma-theme'),
    'subsection' => true,
    'id' => 'popup_options',
    'customizer_width' => '400px',
    'fields' => array (
        array (
            'id' => 'popup_options_options',
            'title' => __('Newsletter pop-up settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'popup_options_active',
            'type' => 'button_set',
            'title' => __('Popup Newsletter','sigma-theme'),
            'subtitle' => __('will be displayed to each user if closed every 72 hours.','sigma-theme'),
            'default' => 'none',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'icon_popup',
            'title' => __('Newsletter pop-up icon','sigma-theme'),
            'required' => array ('popup_options_active', '=', 'block'),
            'subtitle' => __('Select the pop-up icon of the newsletter here, the size of the offer is 160 * 160.','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => __('true','sigma-theme'),
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/newslatter.svg'),
        ),
        array (
            'id' => 'title_popup',
            'required' => array ('popup_options_active', '=', 'block'),
            'title' => __('Newsletter subscription title','sigma-theme'),
            'subtitle' => __('Enter the title of the newsletter pop-up form!','sigma-theme'),
            'type' => 'text',
            'default' => __('Subscribe to Sigma Plus Customer Newsletter')
        ),
        array (
            'id' => 'subtitle_popup',
            'required' => array ('popup_options_active', '=', 'block'),
            'title' => __('Subtitle subscription','sigma-theme'),
            'subtitle' => __('Enter the newsletter subscription pop-up form!','sigma-theme'),
            'type' => 'text',
            'default' => __('Subscribe to Sigma Plus newsletter to be informed about the latest festivals on the site!')
        ),
        array (
            'id' => 'popup_color_title',
            'required' => array ('popup_options_active', '=', 'block'),
            'title' => __('Pop-up title color','sigma-theme'),
            'subtitle' => __('This color applies to the newsletter subscription window title','sigma-theme'),
            'type' => 'color',
            'default' => '#607d8b'
        ),
        array (
            'id' => 'popup_color_subtitle',
            'required' => array ('popup_options_active', '=', 'block'),
            'title' => __('Pop-up color','sigma-theme'),
            'subtitle' => __('This color is used for the subtitle and the text of the newsletter membership form holder','sigma-theme'),
            'type' => 'color',
            'default' => '#b7b7b7'
        ),
        array (
            'id' => 'popup_color_border',
            'required' => array ('popup_options_active', '=', 'block'),
            'title' => __('Color of the bottom margin of the newsletter form','sigma-theme'),
            'subtitle' => __('This color will be applied to the bottom margin of the newsletter form!','sigma-theme'),
            'type' => 'color',
            'default' => '#ffc107'
        ),
        array (
            'id' => 'popup_color',
            'required' => array ('popup_options_active', '=', 'block'),
            'title' => __('Pop-up membership button color','sigma-theme'),
            'subtitle' => __('This color is applied to the membership button.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array(
                'background-color' => '#ffc107',),
        ),
    )
));


Redux::setSection($opt_name, array (
    'title' => __('Social Networks','sigma-theme'),
    'subsection' => true,
    'id' => 'fix_icon_options',
    'customizer_width' => '400px',
    'fields' => array (
        array (
            'id' => 'section_fix_icon_options',
            'title' => __('Social Networks','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'youtube_show',
            'title' => __('Enable the display of YouTube icons on the site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the YouTube icon.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline-block',
            'options' => array (
                'inline-block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_040',
            'required' => array ('youtube_show', '=', 'inline-block','sigma-theme'),
            'title' => __('YouTube icon change','sigma-theme'),
            'subtitle' => __('From this section you can change the "YouTube" icon in the header.','sigma-theme'),
            'type' => 'text',
            'default' => 'fab fa-youtube'
        ),
        array (
                'id' => 'heaader_v1_042',
            'required' => array ('youtube_show', '=', 'inline-block','sigma-theme'),
            'title' => __('YouTube Page Link','sigma-theme'),
            'subtitle' => __('Youtube page link The selection of this icon will be displayed in the header of your site and next to the main menu.','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => 'https://www.youtube.com/sigma'
        ),
        array (
            'id' => 'instagram_show',
            'title' => __('Enable the display of Instagram icons on the site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the Instagram icon.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline-block',
            'options' => array (
                'inline-block' => __('enable','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_038',
            'required' => array ('instagram_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Change Instagram Icon','sigma-theme'),
            'subtitle' => __('From this section you can change the "Instagram" icon in the header.','sigma-theme'),
            'type' => 'text',
            'default' => 'fab fa-instagram'
        ),
        array (
            'id' => 'heaader_v1_046',
            'required' => array ('instagram_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Link to Instagram Page','sigma-theme'),
            'subtitle' => __('The link to the Instagram page, select this icon will be displayed in the header of your site and next to the main menu.','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => 'https://instagram.com/hamakrwpcom'
        ),
        array (
            'id' => 'facebook_show',
            'title' => __('Enable Facebook icon display on site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the Facebook icon.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline-block',
            'options' => array (
                'inline-block' => __('enable','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_037',
            'required' => array ('facebook_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Change Facebook Icon','sigma-theme'),
            'subtitle' => __('From this section you can change the "Facebook" icon in the header.','sigma-theme'),
            'type' => 'text',
            'default' => 'fab fa-facebook'
        ),
        array (
            'id' => 'heaader_v1_043',
            'required' => array ('facebook_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Facebook page link','sigma-theme'),
            'subtitle' => __('The link to the Facebook page Select this icon to be displayed in the header of your site and next to the main menu.','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => 'https://www.facebook.com/sigma'
        ),
        array (
            'id' => 'telegram_show',
            'title' => __('Enable Telegram Icon Display on Site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the Telegram icon.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline-block',
            'options' => array (
                'inline-block' => __('enable','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_039',
            'required' => array ('telegram_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Change Telegram Icon','sigma-theme'),
            'subtitle' => __('From this section you can change the "Telegram" icon in the header.','sigma-theme'),
            'type' => 'text',
            'default' => 'fab fa-telegram'
        ),
        array (
            'id' => 'heaader_v1_044',
            'required' => array ('telegram_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Telegram Page Link','sigma-theme'),
            'subtitle' => __('The link to the Telegram page Select this icon to be displayed in the header of your site and next to the main menu.','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => 'https://telegram.me/hamkarwp'
        ),
        array (
            'id' => 'twitter_show',
            'title' => __('Enable Twitter icon display on site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the Twitter icon.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline-block',
            'options' => array (
                'inline-block' => __('enable','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_041',
            'required' => array ('twitter_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Change Twitter Icon','sigma-theme'),
            'subtitle' => __('From this section you can change the "Twitter" icon in the header.','sigma-theme'),
            'type' => 'text',
            'default' => 'fab fa-twitter'
        ),
        array (
            'id' => 'heaader_v1_045',
            'required' => array ('twitter_show', '=', 'inline-block','sigma-theme'),
            'title' => __('Twitter page link','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => 'https://twitter.com/sigma'

        ),
    )
));

// -> START Header Setting

Redux::setSection($opt_name, array(
    'title' => __('Header Settings','sigma-theme'),
    'id' => 'headers',
    'class' => 'blur-panel',
    'customizer_width' => '400px',
    'icon' => 'el el-list',
    'fields' => array (
        array (
            'id' => 'def_header_all_pages_activator',
            'title' => __('Enable custom headers','sigma-theme'),
            'subtitle' => __('By activating this section, headers designed with Mentor will be displayed as the default header of all pages whose headers are in the default state.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'disable',
             'options' => array (
                'enable' => __('Enabled','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
        'id' => 'def_header_all_pages',
        'type' => 'select',
        'multi' => false,
        'data' => 'posts',
        'args' => array ('post_type' => array ('sigma-header','sigma-theme'), 'numberposts' => -1),
        'title' => __('Default header','sigma-theme'),
        'subtitle' => __('A list of all headers created with the Sigma Plus header system is displayed in front of you. You can select a header.','sigma-theme'),
        'default' => 'null',
            'required' => array ('def_header_all_pages_activator', '=', 'enable','sigma-theme'),

        ),
        array (
            'id' => 'heaader_public_setting_section',
            'type' => 'section',
            'indent' => true,
            'title' => __('General settings of site header','sigma-theme'),
        ),
    ),
));


// -> START Footer Setting

Redux::setSection($opt_name, array(
    'title' => __('Footer Settings','sigma-theme'),
    'id' => 'footer_setting',
    'class' => 'blur-panel',
    'class' => 'blur-panel',
    'customizer_width' => '400px',
    'icon' => 'el el-indent-left',
    'fields' => array (
        array (
            'id' => 'def_footer_all_pages_activator',
            'title' => __('Enable custom footers','sigma-theme'),
            'subtitle' => __('By activating this section, footers designed with Mentor will be displayed as the default footer of all pages whose footer is in the default state.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'disable',
             'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'def_footer_all_pages',
            'type' => 'select',
            'multi' => false,
            'data' => 'posts',
            'args' => array ('post_type' => array ('sigma-footer','sigma-theme'), 'numberposts' => -1),
            'title' => __('Default footer','sigma-theme'),
            'subtitle' => __('A list of all footers created with the Sigma Plus footer system is displayed in front of you. You can select a footer.','sigma-theme'),
                'default' => 'null',
                'required' => array ('def_footer_all_pages_activator', '=', 'enable','sigma-theme'),

        ),
    ),

));

// -> START Post Setting
Redux::setSection($opt_name, array(
    'title' => __('Content Settings','sigma-theme'),
    'id' => 'post_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-pencil',
    'fields' => array (
        array (
            'id' => 'section_post',
            'title' => __('Content Settings','sigma-theme'),
            'type' => 'section',
            'indent' => true
        ),
        array (
            'id' => 'blog_page_layout',
            'title' => __('Mode display site content archive','sigma-theme'),
            'subtitle' => __('From this section you can specify the box style or the full width of the content archive page.','sigma-theme'),
            'type' => 'button_set',
            'default' => '',
            'options' => array (
                '' => 'Box',
                '-fluid' => __('Full width','sigma-theme'),
            ),
        ),
        array (
            'id' => 'blog_sidebar',
            'type' => 'radio',
            'title' => __('Sidebar Archive Page','sigma-theme'),
            'subtitle' => __('From this section you can specify the sidebar display style of the content archive page. These settings will apply to the content search page, author page, and tags. ','sigma-theme'),
            'default' => 'right-sidebar',
            'options' => array (
                'left-sidebar' => __('Left sidebar','sigma-theme'),
                'right-sidebar' => __('Right-sidebar','sigma-theme'),
                'none-sidebar' => __('None sidebar','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_box_dl',
            'type' => 'button_set',
            'default' => 'inherit',
            'title' => __('Enable or disable content download box','sigma-theme'),
            'subtitle' => __('Specify show or hide the download box slider box!','sigma-theme'),
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'box_dl_image',
            'required' => array ('show_box_dl', '=', 'inherit'),
            'title' => __('Icon Download Box','sigma-theme'),
            'subtitle' => __('Upload the desired image to display. Standard size: 300 * 300 ','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => get_template_directory_uri (). '/assets/img/download.png',
        ),
        array (
            'id' => 'box_dl_title',
            'title' => __('Text title box download','sigma-theme'),
            'required' => array ('show_box_dl', '=', 'inherit'),
            'subtitle' => __('You can change the text of the title of the download box from this section ...','sigma-theme'),
            'type' => 'text',
            'default' => __('Download and more information')
        ),
        array(
            'id' => 'box_dl_content',
            'required' => array ('show_box_dl', '=', 'inherit'),
            'title' => __('Description before download','sigma-theme'),
            'subtitle' => __('Enter more description than download box in this section. Make a list of these items .. ','sigma-theme'),
            'default' => __('<ul>
<li> Do not use VPN for fast download .. </li>
<li> All files have been checked before insertion. </li>
<li> The download link is from two different servers. </li>
<li> It is possible to stop downloading files. </li>
<li> Use IDM to download .. </li>
<li> Contact us if needed. </li>
</ul> ','sigma-theme'),
            'type' => 'textarea',
        ),
        array (
            'id' => 'relate_post_title',
            'title' => __('Title of Related Content','sigma-theme'),
            'subtitle' => __('Specify the related content for the posts ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Be sure to read the following:')
        ),
        array (
            'id' => 'show_box_pass',
            'title' => __('Password Download File Box','sigma-theme'),
            'subtitle' => __('Enable or disable the download box password ..','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_box_meta',
            'title' => __('Meta Box Download Content','sigma-theme'),
            'subtitle' => __('The meta box contains the size and type of the file, etc., which you can disable from this section ..','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'telegram_channel',
            'title' => __('Show Telegram Channel Box','sigma-theme'),
            'subtitle' => __(' Whether the Telegram channel box should be displayed at the bottom of the content or not ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'text_box_telegram',
            'required' => array ('telegram_channel', '=', 'inline','sigma-theme'),
            'title' => __('Text box of Telegram channel','sigma-theme'),
            'subtitle' => __('Specify the text box of the Telegram channel.','sigma-theme'),
            'type' => 'text',
            'default' => __('We have found an easier way to communicate with our users :')
        ),
        array (
            'id' => 'text_btn_box_telegram',
            'required' => array ('telegram_channel', '=', 'inline','sigma-theme'),
            'title' => __('Text Telegram Channel Button','sigma-theme'),
            'subtitle' => __('Specify the text of the Telegram channel button.','sigma-theme'),
            'type' => 'text',
            'default' => __('Subscribe to channel')

        ),
        array (
            'id' => 'link_btn_channel',
            'required' => array ('telegram_channel', '=', 'inline','sigma-theme'),
            'title' => __('Telegram Channel Button Link','sigma-theme'),
            'subtitle' => __('Enter the link of the Telegram channel button .. Be sure to enter the link with http or https ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => 'https://telegram.me/hamkarwp'
        ),
        array(
            'id' => 'show_thumnail',
            'title' => __('Show index image in description','sigma-theme'),
            'subtitle' => __('. Do you want the index image to be displayed in the website posts or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'cat',
            'title' => __('Show Content Category','sigma-theme'),
            'subtitle' => __('. Do you want the category to be displayed in the posts of the website or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'date',
            'title' => __('Show Post Date','sigma-theme'),
            'subtitle' => __('. Do you want the posting date to be displayed in the posts of the website or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'author',
            'title' => __('Show Author Name','sigma-theme'),
            'subtitle' => __(' Do you want the authors name to appear in the website posts or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'view',
            'title' => __('Show Visit Count','sigma-theme'),
            'subtitle' => __(' Do you want the number of views of the content to be displayed in the posts of the website or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'tags',
            'title' => __('Show Tags','sigma-theme'),
            'subtitle' => __('. Do you want the content tag to be displayed in the posts of the website or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'user_auther_box',
            'title' => __('Show Site Author Box','sigma-theme'),
            'subtitle' => __('. Whether the author box is displayed at the bottom of the content ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'ralated_post',
            'title' => __('Show related content','sigma-theme'),
            'subtitle' => __(' Do you want the content related to the posts to be displayed at the bottom of the posts or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
    ),
));

// start loop post setting

Redux::setSection($opt_name, array(
    'title' => __('Content Loop Settings','sigma-theme'),
    'id' => 'loops_posts_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'post_style_loop',
            'type' => 'select',
            'title' => __('Style Loop Content','sigma-theme'),
            'subtitle' => __('You can specify the looping style of your content based on the structure of your site!','sigma-theme'),
            'options' => array (
                'template-part/content/loop/post/style01' => __('Style one','sigma-theme'),
                'template-part/content/loop/post/style02' => __('Style two','sigma-theme'),
                'template-part/content/loop/post/style03' => __('Style three','sigma-theme'),
                'template-part/content/loop/post/style04' => __('Style four','sigma-theme'),
            ),
            'default' => 'template-part/content/loop/post/style01'
        ),
        array (
            'id' => 'show_img_loop_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Enable/Disable Content Images','sigma-theme'),
            'subtitle' => __('You can enable or disable style one content loop images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_loop_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Enable/Disable Content Title','sigma-theme'),
            'subtitle' => __('You can enable or disable style one loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_desc_loop_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Enable/Disable Content Description','sigma-theme'),
            'subtitle' => __('You can enable or disable style one content loop descriptions from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cat_loop_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Enable/Disable Content Category','sigma-theme'),
            'subtitle' => __('You can enable or disable the category 1 content loop from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_veiws_loop_v1',
            'required' => array('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Enable/disable content viewing','sigma-theme'),
            'subtitle' => __('You can enable or disable style one loop views from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_btn_loop_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Enable/Disable Continue Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Lightweight Content Loop Content button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'tite_loop_color_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Color Title Loop Content Style One','sigma-theme'),
            'subtitle' => __('You can change the color of the title of the style one content loop from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array (
            'id' => 'des_loop_color_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Color Description Loop Content Style One','sigma-theme'),
            'subtitle' => __('You can change the color of the description of the style ones content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array (
            'id' => 'cat_loop_color_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Category color and number of views loop content style one','sigma-theme'),
            'subtitle' => __('You can change the color of the loop content of style one from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array (
            'id' => 'btn_loop_color_v1',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style01'),
            'title' => __('Color Button Read more Loop Content Style One','sigma-theme'),
            'subtitle' => __('You can change the color of the Read More loop content button from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'show_img_loop_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Content Images','sigma-theme'),
            'subtitle' => __('You can enable or disable one or two style content loop images.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_avatar_loop_v2',
            'required' => array('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Content Avatar','sigma-theme'),
            'subtitle' => __('You can enable or disable style two content content avatars from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_loop_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Content Title','sigma-theme'),
            'subtitle' => __('You can enable or disable style two loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_desc_loop_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Content Description','sigma-theme'),
            'subtitle' => __('You can enable or disable style two content loop descriptions from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_date_loop_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Content History','sigma-theme'),
            'subtitle' => __('You can enable or disable the history of loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_comments_loop_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Content View','sigma-theme'),
            'subtitle' => __('You can enable or disable style two content loop views from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_btn_loop_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Enable/Disable Continue Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the continue content loop button in this style.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'tite_loop_color_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Color Title Loop Content Style Two','sigma-theme'),
            'subtitle' => __('You can change the color of the title of the second style content loop from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array(
            'id' => 'des_loop_color_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Color Description Loop Content Style Two','sigma-theme'),
            'subtitle' => __('You can change the color of the description of the contents of the second style content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'cat_loop_color_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Date color and number of comments','sigma-theme'),
            'subtitle' => __('You can change the color of the date and the number of views of the content of Style 2 from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array (
            'id' => 'btn_loop_color_v2',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style02'),
            'title' => __('Color Button Read More Loop Content Style Two','sigma-theme'),
            'subtitle' => __('You can change the color of the Read More loop content button from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#e92b5f'
        ),
        array (
            'id' => 'show_img_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content Images','sigma-theme'),
            'subtitle' => __('You can enable or disable one-third of the content loop images of this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_avatar_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content Avatar','sigma-theme'),
            'subtitle' => __('You can enable or disable style 3 content loop avatars from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content Title','sigma-theme'),
            'subtitle' => __('You can enable or disable style subtitle loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_author_loop_v3',
            'required' => array('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content Author','sigma-theme'),
            'subtitle' => __('You can enable or disable style subwoofer content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_date_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content History','sigma-theme'),
            'subtitle' => __('You can enable or disable style 3 content loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_comments_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content View','sigma-theme'),
            'subtitle' => __('You can enable or disable the style content loop view from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_veiws_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/disable content viewing'),
            'subtitle' => __('You can enable or disable the viewing of loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cat_loop_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Enable/Disable Content Category','sigma-theme'),
            'subtitle' => __('You can enable or disable the subtitle loop content category from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'tite_loop_color_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Color title loop content style three','sigma-theme'),
            'subtitle' => __('You can change the color of the title of the style three content loop from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#444444'
        ),
        array(
            'id' => 'author_loop_color_v3',
            'required' => array('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Author Name Color Loop Content Style Three','sigma-theme'),
            'subtitle' => __('You can change the authors names style loop content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'meta_loop_color_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Date color and number of comments and views','sigma-theme'),
            'subtitle' => __('You can change the color of the date and the number of views and views of Style 3 content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'meta_icon_loop_color_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Date icon color and number of comments and views','sigma-theme'),
            'subtitle' => __('You can change the color of the date icon and the number of views and views of Style 3 content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#03A9F4'
        ),
        array (
            'id' => 'cat_loop_bg_v3',
            'title' => __('Background Color Category Loop Content Style Three','sigma-theme'),
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'subtitle' => __('You can change the background color of the style three content loop category from this section.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#F44336',),
        ),
        array (
            'id' => 'cat_loop_color_v3',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style03'),
            'title' => __('Color Category Loop Content Style Three','sigma-theme'),
            'subtitle' => __('You can change the color of the category 3 content loop from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#ffffff'
        ),
        array (
            'id' => 'show_img_loop_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/Disable Content Images','sigma-theme'),
            'subtitle' => __('You can enable or disable one-fourth of the loop content images of this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_loop_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/Disable Content Title','sigma-theme'),
            'subtitle' => __('You can enable or disable style four loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_author_loop_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/Disable Content Author','sigma-theme'),
            'subtitle' => __('You can enable or disable style subwoofer content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_date_loop_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/Disable Content History','sigma-theme'),
            'subtitle' => __('You can enable or disable style four content loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_veiws_loop_v4',
            'required' => array('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/disable content viewing'),
            'subtitle' => __('You can enable or disable the viewing of loop content from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cat_loop_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/Disable Content Category','sigma-theme'),
            'subtitle' => __('You can enable or disable the Category 4 content loop from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_btn_loop_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Enable/Disable Continue Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Lightweight Content Loop Content button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'tite_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Color title loop content style four','sigma-theme'),
            'subtitle' => __('You can change the color of the title of the style four content loop from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#444444'
        ),
        array (
            'id' => 'author_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Author Name Loop Content Style Four','sigma-theme'),
            'subtitle' => __('You can change the authors name color loop content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'des_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Color Name Description Description Loop Content Style Four','sigma-theme'),
            'subtitle' => __('You can change the color name of the description of the contents of the fourth style content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'date_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Color Date Loop Content Style Four','sigma-theme'),
            'subtitle' => __('You can change the color history of style four content loops from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'meta_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Color number of comments and views','sigma-theme'),
            'subtitle' => __('You can change the number of views and views of Style 4 content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#777777'
        ),
        array (
            'id' => 'meta_icon_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Date icon color and number of comments and views','sigma-theme'),
            'subtitle' => __('You can change the color of the date icon and the number of views and views of Style 4 content from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#d6ae6c'
        ),
        array(
            'id' => 'btn_loop_bg_v4',
            'title' => __('Background color of the continue button of style four','sigma-theme'),
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'subtitle' => __('You can change the background color of the Read More loop in this section.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#d6ae6c',),
        ),
        array (
            'id' => 'btn_loop_color_v4',
            'required' => array ('post_style_loop', '=', 'template-part/content/loop/post/style04'),
            'title' => __('Color Button Read More Loop Content Style Four','sigma-theme'),
            'subtitle' => __('You can change the color of the Read More Loop Content Loop from this section.','sigma-theme'),
            'type' => 'color',
            'default' => '#ffffff'
        ),
    ),
));
// -> START Footer Setting
Redux::setSection($opt_name, array(
    'title' => __('Ads settings','sigma-theme'),
    'id' => 'ads_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-check',
    'fields' => array (
        array (
            'id' => 'ads_section',
            'title' => __('Ads settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'side_ads',
            'title' => __('Activate sidebar ads','sigma-theme'),
            'subtitle' =>  __('Do you want ads to be displayed on the sidebar or not','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'ads_side_banner',
            'required' => array ('side_ads', '=', 'inherit'),
            'title' => __('Sidebar Banner Image','sigma-theme'),
            'subtitle' => __('Upload the banner image to display. Standard size: 300 * 300 ','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/ads300-1.png'),
        ),
        array (
            'id' => 'ads_side_link',
            'required' => array ('side_ads', '=', 'inherit'),
            'title' => __('Link Banner Sidebar','sigma-theme'),
            'subtitle' => __('Specify the sidebar banner ad link .. The link should preferably be entered with http.','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/'
        ),
        array (
            'id' => 'ads_side_target',
            'required' => array ('side_ads', '=', 'inherit'),
            'title' => __('The purpose of the sidebar banner link','sigma-theme'),
            'subtitle' => __('Specify the target banner link .. Default: in the new window','sigma-theme'),
            'type' => 'button_set',
            'default' => '_blank',
            'options' => array (
                '_blank' => __('New window','sigma-theme'),
                '_self' => __('In the same window','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_ads_product',
            'title' => __('Activate the ads below the posts and products of the site','sigma-theme'),
            'subtitle' => __('Display ads at the bottom of product and content descriptions?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'ads_post_link',
            'required' => array ('show_ads_product', '=', 'inherit'),
            'title' => __('Banner link read more','sigma-theme'),
            'subtitle' => __('Specify the banner ad link to read more .. The link should preferably be entered with http.','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/shop'
        ),
        array (
            'id' => 'single_ads_image',
            'required' => array ('show_ads_product', '=', 'inherit'),
            'title' => __('Banner image read more','sigma-theme'),
            'subtitle' => __('Upload a banner ad image Read more. Standard size: 728 * 80 ','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/ads728.png'),
        ),
        array (
            'id' => 'single_ads_target',
            'required' => array ('show_ads_product', '=', 'inherit'),
            'title' => __('The purpose of the banner link read more','sigma-theme'),
            'subtitle' => __('Specify the target banner link .. Default: in the new window','sigma-theme'),
            'type' => 'button_set',
            'default' => '_blank',
            'options' => array (
                '_blank' => __('New window','sigma-theme'),
                '_self' => __('In the same window','sigma-theme'),
            ),
        ),

    ),
));


// -> START shop Setting

Redux::setSection($opt_name, array(
    'title' => __('WooCommerce Settings','sigma-theme'),
    'id' => 'woo_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-shopping-cart-sign',
    'fields' => array (
    ),
));


Redux::setSection($opt_name, array (
    'title' => __('Single Product Settings','sigma-theme'),
    'id' => 'shop_setting',
    'subsection' => true,
    'customizer_width' => '400px',
    'fields' => array (
        array (
            'id' => 'products_style_page',
            'type' => 'select',
            'title' => __('Product Details Display Style','sigma-theme'),
            'subtitle' => __('You can specify the display style of your products based on the structure of your site!','sigma-theme'),
            'options' => array (
                'template-part/content/product/signle-product-style01/single' => __('Style one (for download products)','sigma-theme'),
                'template-part/content/product/signle-product-style02/single' => __('Style two (for physical products)','sigma-theme'),
                'template-part/content/product/signle-product-style03/single' => __('Style three (special training course)','sigma-theme'),
                'template-part/content/product/signle-product-style04/single' => __('Style four (new download style)','sigma-theme'),
            ),
            'default' => 'template-part/content/product/signle-product-style02/single'
        ),
        array (
            'id' => 'woocommerce_post_1',
            'type' => 'section',
            'indent' => true,
            'title' => __('General Page Store Settings','sigma-theme'),
        ),

        // style 04

        array (
            'id' => 'single_product_color1_v4',
            'required' => array ('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'type' => 'color',
            'title' => __('The main color of a single style four product','sigma-theme'),
            'subtitle' => __('You can enter the main color of the download style product from this section.','sigma-theme'),
            'default' => '#d6ae6d',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),
        array (
            'id' => 'single_product_demo_v4',
            'required' => array ('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'type' => 'color',
            'title' => __('Persian Preview Button Background','sigma-theme'),
            'subtitle' => __('Select the background color of the Persian preview button of the product.','sigma-theme'),
            'default' => '#17c5e3',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),
        array (
            'id' => 'single_product_demo_en_v4',
            'required' => array ('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'type' => 'color',
            'title' => __('Latin preview button background','sigma-theme'),
            'subtitle' => __('Select the background color of the Latin product preview button.','sigma-theme'),
            'default' => '#ff5721',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),
        array (
            'id' => 'sales_count_v4',
            'title' => __('Activate sales count','sigma-theme'),
            'subtitle' => __('Show/do not show product sales','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'price_count_v4',
            'title' => __('Product price activation','sigma-theme'),
            'subtitle' => __('Show/do not show product price','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'date_active_v4',
            'title' => __('Activate release date','sigma-theme'),
            'subtitle' => __('Show/do not show release date','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array(
            'id' => 'update_active_v4',
            'title' => __('Activate update date','sigma-theme'),
            'subtitle' => __('Show/do not show update date','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'demo_btn_active_v4',
            'title' => __('Activate preview button','sigma-theme'),
            'subtitle' => __('Show/do not show preview button','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),


        array (
            'id' => 'add_cart_active_v4',
            'title' => __('Activate shopping cart button','sigma-theme'),
            'subtitle' => __('Show/do not show add to cart button','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'badge_right_active_v4',
            'title' => __('Activate the right product medal','sigma-theme'),
            'subtitle' => __('Show/do not display product medals next to the index image (right)','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'comment_tab_active_v4',
            'title' => __('Activate user comments tab','sigma-theme'),
            'subtitle' => __('Show/Display Product Comments Tab','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'support_tab_active_v4',
            'title' => __('Activate Product Support Tab','sigma-theme'),
            'subtitle' => __('Show/Display Product Support Tab','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'seller_tab_active_v4',
            'title' => __('Activate seller info tab','sigma-theme'),
            'subtitle' => __('Show/do not show seller info tab','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'wishlist_nav_active_v4',
            'title' => __('Activate Favorite Icon','sigma-theme'),
            'subtitle' => __('Show/Display Product Favorite Icons','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'share_nav_active_v4',
            'title' => __('Enable sharing icon','sigma-theme'),
            'subtitle' => __('Show/hide product sharing icon','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'url_nav_active_v4',
            'title' => __('Activate short link icon','sigma-theme'),
            'subtitle' => __('Show/do not display short link icon','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),


        array (
            'id' => 'salles_sidebar_active_v4',
            'title' => __('Enable Sidebar Sales','sigma-theme'),
            'subtitle' => __('Show/hide the number of sidebar sales','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'price_sidebar_active_v4',
            'title' => __('Sidebar product price activation','sigma-theme'),
            'subtitle' => __('Show/do not show product price in sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),
        array(
            'id' => 'medal_sidebar_active_v4',
            'title' => __('Activate Sidebar Product Medal','sigma-theme'),
            'subtitle' => __('Show/do not display the product medal in the sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'license_sidebar_active_v4',
            'title' => __('Enable product license text in sidebar','sigma-theme'),
            'subtitle' => __('Display/no product license text in sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'license_text_sidebar_v4',
            'title' => __('Content of Sidebar Product License','sigma-theme'),
            'subtitle' => __('Use the span tag to insert the content title and the ul <li tag to display the list of tips and licenses.','sigma-theme'),
            'required' => array ('license_sidebar_active_v4', '=', 'block'),
            'default' => __('<span> Enjoy the following benefits by purchasing this product: </span> <ul> <li> Lifetime access to the product file </li> <li> 6 Month completely free and guaranteed support </li> </ul> ','sigma-theme'),
            'type' => 'editor',
        ),

        array (
            'id' => 'addcart_sidebar_active_v4',
            'title' => __('Activate the Add to Cart sidebar button','sigma-theme'),
            'subtitle' => __('Show/hide the Add to Cart button in the sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'after_addcart_text_v4',
            'title' => __('Content text after the Add to Cart button','sigma-theme'),
            'subtitle' => __('In this section you can enter content and tips for your products before or after the purchase. Do not put content to not show. ','sigma-theme'),
            'required' => array ('license_sidebar_active_v4', '=', 'block'),
            'default' => __('Product purchase is possible by all acceleration cards and immediately after purchase, the product download link will be provided to you.','sigma-theme'),
            'type' => 'editor',
        ),

        array (
            'id' => 'meta_sidebar_active_v4',
            'title' => __('Enable/disable product meta','sigma-theme'),
            'subtitle' => __('You can disable product meta including volume, number of views, views, etc. from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'tags_sidebar_active_v4',
            'title' => __('Activate Product Tags','sigma-theme'),
            'subtitle' => __('Show/hide the product tag in the sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),

        array (
            'id' => 'related_active_v4',
            'title' => __('Activate Related Products','sigma-theme'),
            'subtitle' => __('Show/hide related products at the bottom of product details','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array('products_style_page', '=', 'template-part/content/product/signle-product-style04/single'),
        ),


        //style 04

        array(
            'id' => 'sticky_sidebar_active_v3',
            'title' => __('Activate Adhesive Sidebar','sigma-theme'),
            'subtitle' => __('Enable/disable course sticker sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'teacher_username_active_v3',
            'title' => __('Activate Teacher Username','sigma-theme'),
            'subtitle' => __('Enable/disable teacher Username in the course sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'teacher_active_v3',
            'title' => __('Activate Teacher Information','sigma-theme'),
            'subtitle' => __('Enable/disable teacher instruction in the course sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'teacher_active_meta_v3',
            'title' => __('Activate Avatar and Teacher Name','sigma-theme'),
            'subtitle' => __('Enable/disable avatar and teacher name in course sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'teacher_phone_active_v3',
            'title' => __('Activate the teachers contact number section','sigma-theme'),
            'subtitle' => __('Activate/deactivate the instructors contact number in the course sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_sales_active_v3',
            'title' => __('Activate the number of students section','sigma-theme'),
            'subtitle' => __('Activate/deactivate the number of students in the course sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_3meta_active_v3',
            'title' => __('Activate 3 course meta','sigma-theme'),
            'subtitle' => __('Enable/disable time, number of sessions and course scores in the sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_qiuck_active_v3',
            'title' => __('Enable Quick Access Menu','sigma-theme'),
            'subtitle' => __('Enable/disable the quick access menu for course sections in the sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_buy_active_v3',
            'title' => __('Price activation and course purchase button','sigma-theme'),
            'subtitle' => __('Activate/deactivate the price and purchase button of the course in the sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array(
            'id' => 'courese_badge_active_v3',
            'title' => __('Activate course medals','sigma-theme'),
            'subtitle' => __('Enable/disable course medals in sidebar','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_date_publish_active_v3',
            'title' => __('Activate course release date','sigma-theme'),
            'subtitle' => __('Enable/disable course release date','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_date_update_active_v3',
            'title' => __('Enable course update date','sigma-theme'),
            'subtitle' => __('Enable/disable course update date','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_views_active_v3',
            'title' => __('Enable course views','sigma-theme'),
            'subtitle' => __('Enable/disable course views','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_cm_active_v3',
            'title' => __('Enable course views','sigma-theme'),
            'subtitle' => __('Enable/disable course views','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_cat_active_v3',
            'title' => __('Activate course category','sigma-theme'),
            'subtitle' => __('Enable/disable course category','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),


        array (
            'id' => 'courese_share_active_v3',
            'title' => __('Enable Course Sharing','sigma-theme'),
            'subtitle' => __('Enable/disable course sharing','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_bookmart_active_v3',
            'title' => __('Activate Course Favorites Button','sigma-theme'),
            'subtitle' => __('Enable/Disable Add to Favorites Course','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_tag_active_v3',
            'title' => __('Activate course tag','sigma-theme'),
            'subtitle' => __('Enable/disable course tag','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array(
            'id' => 'courese_related_active_v3',
            'title' => __('Activate related courses','sigma-theme'),
            'subtitle' => __('Enable/disable related courses','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_parts_active_v3',
            'title' => __('Activate course titles','sigma-theme'),
            'subtitle' => __('Enable/disable course titles','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        array (
            'id' => 'courese_comments_active_v3',
            'title' => __('Activate Course Comments','sigma-theme'),
            'subtitle' => __('Enable/disable course comments','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),

        // style 02
        array (
            'id' => 'single_product_full_width',
            'title' => __('Single Product Display Style','sigma-theme'),
            'subtitle' => __('From this section you can specify that the product page is full width or box.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('Box','sigma-theme'),
                'disable' => __('Full width','sigma-theme'),
            )
        ),
        array (
            'id' => 'single_product_des_font_size',
            'type' => 'select',
            'title' => __('Product Description Font Size','sigma-theme'),
            'subtitle' => __('From this section you can select the font size of the product description.','sigma-theme'),
            'options' => array (
                '14px' => '14px',
                '15px' => '15px',
                '16px' => '16px',
                '17px' => '17px',
                '18px' => '18px',
                '19px' => '19px',
                '20px' => '20px',
            ),
            'default' => '14px',
        ),
        array (
            'id' => 'single_courses_popup_part',
            'title' => __('Enable/disable pop-up video sessions','sigma-theme'),
            'subtitle' => __('From this section you can enable or disable the pop-up display of video sessions of educational products.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'disable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style03/single'),
        ),
        array (
            'id' => 'signle_product_v2_atcive_default_tab',
            'title' => __('Enable WooCommerce Default Tabs','sigma-theme'),
            'subtitle' => __('By activating this section you can add new dedicated tabs to digital product style tabs.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'disable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
            'required' => array('products_style_page', '=',
                array (
                    'template-part/content/product/signle-product-style02/single',
                    'template-part/content/product/signle-product-style04/single'
                )),
        ),
        array(
            'id' => 'thumbnail_image_counter',
            'title' => __('Number of product index images','sigma-theme'),
            'subtitle' => __('You can change the number of product index images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => '3',
            'options' => array (
                '3' => __('The first three images','sigma-theme'),
                'all' => __('All Images','sigma-theme'),
            ),
            'required' => array (
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
        ),
        array (
            'id' => 'signle_product_v2_report',
            'title' => __('Activate Product Report Button','sigma-theme'),
            'subtitle' => __('From this section you can disable the product report button on the left side of a single digital product.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'single_product_color1_v2',
            'required' => array ('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'type' => 'color',
            'title' => __('Physical style product primary color','sigma-theme'),
            'subtitle' => __('You can enter the primary color of a single download style product from this section.','sigma-theme'),
            'default' => '#05aced',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'single_product_color2_v2',
            'required' => array ('cart_style', '=', 'template-part/cart-fix','sigma-theme'),
            'type' => 'color',
            'title' => __('Physical style product secondary color','sigma-theme'),
            'subtitle' => __('You can enter the secondary color of a single download style product from this section.','sigma-theme'),
            'default' => '#009688',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'vendor_show_sgm',
            'title' => __('Activate Seller','sigma-theme'),
            'subtitle' => __('Show seller name on product page','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'vendor_sgm_subtitle',
            'title' => __('Text under seller title','sigma-theme'),
            'subtitle' => __('Enter the text below the sellers title!','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('vendor_show_sgm', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Send goods from seller s warehouse ','sigma-theme'),
        ),
        array (
            'id' => 'show_product_ratting_counter',
            'title' => __('Activate the number of reviews section','sigma-theme'),
            'subtitle' => __('Show Product ratting count on Product Page','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' =>  __('Enabled','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
            'required' => array (
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
        ),        
        array (
            'id' => 'stock_show_sgm',
            'title' => __('Activate Inventory Status','sigma-theme'),
            'subtitle' => __('Show Inventory Status on Product Page','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array (
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
        ),
        array (
            'id' => 'stock_sgm_subtitle',
            'title' => __('Subtitle text in stock','sigma-theme'),
            'subtitle' => __('Enter the text below the title in the repository.','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('stock_show_sgm', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Ready to send from store','sigma-theme'),
        ),
        array (
            'id' => 'out_stock_sgm_subtitle',
            'title' => __('Text under the title not in stock','sigma-theme'),
            'subtitle' => __('Enter the text below the subtitle not in stock.','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('stock_show_sgm', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('This product is not available in the store.','sigma-theme'),
        ),
        array(
            'id' => 'guarantee_active',
            'title' => __('Activate Warranty Text','sigma-theme'),
            'subtitle' => __('Show product warranty text on product page','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'guarantee_bold_title',
            'title' => __('Basic product warranty text','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('guarantee_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Guarantee','sigma-theme'),
        ),
        array (
            'id' => 'guarantee_title',
            'title' => __('Full product warranty text','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('guarantee_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Return money and originality of goods','sigma-theme'),
        ),
        array (
            'id' => 'guarantee_subtitle',
            'title' => __('Under the title of product warranty','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('guarantee_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('with best product warranty','sigma-theme'),
        ),
        array (
            'id' => 'delivery_active',
            'title' => __('Enable product submission and payment text','sigma-theme'),
            'subtitle' => __('Submit product post text on product page','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'delivery_bold_title',
            'title' => __('Initial text of the product submission section','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('delivery_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Possibility','sigma-theme'),
        ),
        array (
            'id' => 'delivery_title',
            'title' => __('Full text of product submission section','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('delivery_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Delivery and payment on site','sigma-theme'),
        ),
        array (
            'id' => 'delivery_subtitle',
            'title' => __('Subject of product submission section','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('delivery_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('With all Shtab member cards','sigma-theme'),
        ),
        array (
            'id' => 'total_sale_sgm_active',
            'title' => __('Show/do not show product sales','sigma-theme'),
            'subtitle' => __('Submit product post text on product page','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array(
            'id' => 'gaurantee_time_active',
            'title' => __('Show/do not show warranty period','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'gaurantee_time_title',
            'title' => __('Product warranty title','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('gaurantee_time_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('This product has a one week money back guarantee.','sigma-theme'),
        ),
        array (
            'id' => 'country_send_active',
            'title' => __('Show/do not send to all parts of the country','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'country_send_title',
            'title' => __('Title of sending to all parts of the country','sigma-theme'),
            'type' => 'text',
            'required' => array (
                array ('country_send_active', '=', 'block'),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
            ),
            'default' => __('Send to all parts of the country','sigma-theme'),
        ),
        array (
            'id' => 'badges_dgs_active',
            'title' => __('Enable/disable product medals','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
                array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'comment_tab_active',
            'title' => __('Enable/Disable Comments tab','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'more_dec_tab_active',
            'title' => __('Enable/disable other profile tab','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'seller_tab_active',
            'title' => __('Enable/disable seller tab','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array (
            'id' => 'related_active',
            'title' => __('Enable/Disable Related Products','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array(
            'id' => 'tags_active',
            'title' => __('Enable/disable product tag','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),
        array(
            'id' => 'orginlity_product',
            'title' => __('Enable/disable orginiality prodcut','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style02/single'),
        ),

        // style 01 start
        array (
            'id' => 'license_productv2',
            'title' => __('Show product use license','sigma-theme'),
            'subtitle' => __(' Whether the content of the license or product rules should be displayed or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'title_license',
            'title' => __('Title of product usage rules','sigma-theme'),
            'required' => array ('license_productv2', '=', 'inherit'),
            'subtitle' => __('Enter the title of the product usage rules that are displayed in the sidebar next to the products ..','sigma-theme'),
            'default' => __('Rules for using the product','sigma-theme'),
            'type' => 'text',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'img_license',
            'required' => array ('license_productv2', '=', 'inherit'),
            'title' => __('Image of product usage rules','sigma-theme'),
            'subtitle' => __('Upload product usage icon icon image. , The size of the offer is 100 * 100 pixels. ','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/license.svg'),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'title_detial',
            'title' => __('Title Product Details','sigma-theme'),
            'subtitle' => __('Enter the title of the product details displayed in the sidebar next to the products ..','sigma-theme'),
            'default' => __('More details and product purchase','sigma-theme'),
            'type' => 'text',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'img_detial',
            'title' => __('Product Details Icon Image','sigma-theme'),
            'subtitle' => __('Upload product details icon icon. , The size of the offer is 100 * 100 pixels. ','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/info.svg'),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'license_product',
            'title' => __('Show Product License','sigma-theme'),
            'subtitle' => __(' Will the content of the product license be displayed in full or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array(
            'id' => 'license_content',
            'required' => array('license_product', '=', 'inherit'),
            'title' => __('Product License Content','sigma-theme'),
             'subtitle' => __('Enter the product license content in this field. Make a list of these items .. ','sigma-theme'),
             'default' => __('<ul>
                         <li> Installation package + Persian installation guide </li>
                         <li> Infinitely beautiful Persian fonts </li>
                         <li> Free Iransense Font License </li>
                         <li> Interface and direct payment gateways </li>
                         <li> 24-hour product support </li>
                         <li> Original product with free update </li>
                         <li> Unconditional refund </li>
                         </ul> ','sigma-theme'),
             'type' => 'textarea',
            'required' => array('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array(
            'id' => 'payment_img_active',
            'title' => __('Show product payment gateways','sigma-theme'),
            'subtitle' => __('Will the image of payment gateways be displayed or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'payment_img_title',
            'required' => array ('payment_img_active', '=', 'inherit'),
            'title' => __('Title Online Payment Image section','sigma-theme'),
            'subtitle' => __('Enter the title of the payment section displayed on the sidebar of the products ..','sigma-theme'),
            'default' => __('Secure payment with all Shtab member cards','sigma-theme'),
            'type' => 'text',
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'payment_img',
            'required' => array ('payment_img_active', '=', 'inherit'),
            'title' => __('Image of payment gateways','sigma-theme'),
            'subtitle' => __('Upload and select the desired image for the payment gateway section ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/shopping-cart.png'),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'woocommerce_show_hide',
            'type' => 'section',
            'indent' => true,
            'title' => __('Show/Hide Settings','sigma-theme'),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'show_price',
            'title' => __('Activate Catalog Mode','sigma-theme'),
            'subtitle' => __('By activating this feature, you will be able to purchase disabled products online and the products will be introduced and cataloged!','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Inactive','sigma-theme'),
                'none' => __('Enabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'show_demo_en',
            'title' => __('Show Low Pricing Buttons','sigma-theme'),
            'subtitle' => __('Do you want buttons such as Persian, English preview, product manual to be displayed at the bottom of the cart or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'info_product',
            'title' => __('View Product Information','sigma-theme'),
            'subtitle' => __('Should product information such as volume, shipping date, etc. be displayed on the product details page or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'info_product',
            'title' => __('View Product Information','sigma-theme'),
            'subtitle' => __('Should product information such as volume, shipping date, etc. be displayed on the product details page or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array(
            'id' => 'vendor_show',
            'title' => __('Show seller box','sigma-theme'),
            'subtitle' => __('Should the seller box be displayed on the product details page or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'vendor_show_btn',
            'title' => __('Show more designer products button','sigma-theme'),
            'subtitle' => __('Should more product buttons be displayed on the product details page? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'sales',
            'title' => __('Show product sales number','sigma-theme'),
            'subtitle' => __('Do you want the number of product purchases to be displayed in the sidebar of the product or not ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'update_show',
            'title' => __('Show Last Updated Date','sigma-theme'),
            'subtitle' => __('Do you want the date of the last update to be displayed in the product details or not? ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'support_show',
            'title' => __('Show Support Button','sigma-theme'),
            'subtitle' => __('Enable or disable support button display','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),

        array (
            'id' => 'report_show',
            'title' => __('Show Product Report Button','sigma-theme'),
            'subtitle' => __('Enable or disable the pop-up product report button','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'report_title',
            'title' => __('Report Button Text','sigma-theme'),
            'required' => array ('report_show', '=', 'inherit'),
            'subtitle' => __('Enter the contact number of the support panel header support ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Product Report','sigma-theme'),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'support_link',
            'title' => __('Product Report Button Link','sigma-theme'),
            'subtitle' => __('Enter the link for the product report button in this section!','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/submit-ticket',
            'required' => array ('report_show', '=', 'inherit'),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
        array (
            'id' => 'urlshort_show',
            'title' => __('Show short link','sigma-theme'),
            'subtitle' => __('Enable or disable short link display','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
            'required' => array ('products_style_page', '=', 'template-part/content/product/signle-product-style01/single'),
        ),
    ),

));

Redux::setSection($opt_name, array(
    'title' => __('Product Archive Settings','sigma-theme'),
    'id' => 'archive_products_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'free_products_checkout',
            'title' => __('Activate Free Product Settlement','sigma-theme'),
            'subtitle' => __('By activating this feature, free products, like other products, will have a button to add to cart and normal WooCommerce settlement.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'disable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'free_product_text',
            'title' => __('Custom text for free products','sigma-theme'),
            'subtitle' => __('Free text is displayed by default for products with zero price. You can change this text from this. For example: call. ','sigma-theme'),
            'type' => 'text',
            'default' => __('Call!','sigma-theme'),
        ),
        array (
            'id' => 'sold_out_product_text',
            'title' => __('Custom text for finished products','sigma-theme'),
            'subtitle' => __('You can enter custom text for finished products in the Product Archive list.','sigma-theme'),
            'type' => 'text',
            'default' => __('Finished!','sigma-theme'),
        ),
        array (
            'id' => 'shop_page_layout',
            'title' => __('Store page display mode and product archive','sigma-theme'),
            'subtitle' => __('From this section you can specify the box style or full width of the store page and product archive.','sigma-theme'),
            'type' => 'button_set',
            'default' => '',
            'options' => array (
                '' => 'Box',
                '-fluid' => __('Full width','sigma-theme'),
            ),
        ),
        array (
            'id' => 'shop_descreption',
            'title' => __('Enable/disable product category descriptions','sigma-theme'),
            'subtitle' => __('From this section you can delete/deactivate the description of the product category.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'shop_sidebar',
            'type' => 'radio',
            'title' => __('Store Page Sidebar','sigma-theme'),
            'subtitle' => __('From the section you can change the sidebar view mode of the store page or product archive.','sigma-theme'),
            'default' => 'right-sidebar',
            'options' => array (
                'left-sidebar' => __('Left sidebar','sigma-theme'),
                'right-sidebar' => __('Right-sidebar','sigma-theme'),
                'none-sidebar' => __('None sidebar','sigma-theme'),
            ),
        ),
    ),
));


Redux::setSection($opt_name, array (
    'title' => __('Product Loop Settings','sigma-theme'),
    'id' => 'loops_products_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'products_style_loops',
            'type' => 'select',
            'title' => __('Product Loop Display Style','sigma-theme'),
            'subtitle' => __('The settings in this section apply to display product archives, brand archives, and product categories and labels.','sigma-theme'),
            'options' => array (
                'template-part/content/loop/product/style01' => __('Style one (for downloadable products)','sigma-theme'),
                'template-part/content/loop/product/style02' => __('Style two (for physical products)','sigma-theme'),
                'template-part/content/loop/product/style03' => __('Style three (for downloadable products)','sigma-theme'),
                'template-part/content/loop/product/style04' => __('Style Four (for downloadable products)','sigma-theme'),
                'template-part/content/loop/product/style05' => __('Style five (special course)','sigma-theme'),
            ),
            'default' => 'template-part/content/loop/product/style02'
        ),
        array (
            'id' => 'show_img_product_loop_v1',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style01'),
            'title' => __('Enable/disable product images','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_product_loop_v1',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style01'),
            'title' => __('Enable/disable product titles','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop title from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_desc_product_loop_v1',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style01'),
            'title' => __('Enable/disable product descriptions','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop descriptions from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cat_product_loop_v1',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style01'),
            'title' => __('Enable/Disable Product Categories','sigma-theme'),
            'subtitle' => __('You can enable or disable the category one loop product category from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_price_product_loop_v1',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style01'),
            'title' => __('Enable/disable product prices','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop price from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_btn_product_loop_v1',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style01'),
            'title' => __('Enable/Disable Product Details Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Product Details Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
//style 02

        array(
            'id' => 'show_img_product_loop_v2',
            'required' => array('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/disable product images','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_product_loop_v2',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/disable product titles','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop title from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_en_title_product_loop_v2',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/disable product English title','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop title from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_price_product_loop_v2',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/disable product prices','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop price from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cart_product_loop_v2',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/Disable Add to Cart Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Add to Cart button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_discount_product_loop_v2',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/disable product discount percentage','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop discount percentage from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_qviews_product_loop_v2',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style02'),
            'title' => __('Enable/Disable Quick View Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Quick View Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),

//style 03

        array(
            'id' => 'show_img_product_loop_v3',
            'required' => array('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product images','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product titles','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop title from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cat_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/Disable Product Categories','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop categories from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_price_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product prices','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop price from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cart_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/Disable Product Details Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Product Details Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_discount_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product discount percentage','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop discount percentage from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_qviews_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/Disable Quick View Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Quick View Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_sale_product_loop_v3',
            'required' => array('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product purchases','sigma-theme'),
            'subtitle' => __('You can enable or disable the number of quick purchase products from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_date_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product release date','sigma-theme'),
            'subtitle' => __('You can enable or disable the release date of products from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_vendor_product_loop_v3',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style03'),
            'title' => __('Enable/disable product seller','sigma-theme'),
            'subtitle' => __('You can enable or disable the seller button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),

// style 04

        array (
            'id' => 'show_img_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product images','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product titles','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop title from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_en_title_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable English product title','sigma-theme'),
            'subtitle' => __('You can enable or disable the English title of the product loop from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_desc_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product descriptions','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop descriptions from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cat_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/Disable Product Categories','sigma-theme'),
            'subtitle' => __('You can enable or disable product loop categories from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_price_product_loop_v4',
            'required' => array('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product prices','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop price from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_cart_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/Disable Product Details Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Product Details Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_discount_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product discount percentage','sigma-theme'),
            'subtitle' => __('You can enable or disable the product loop discount percentage from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_qviews_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/Disable Quick View Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Quick View Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_sale_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product purchases','sigma-theme'),
            'subtitle' => __('You can enable or disable the number of quick purchase products from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_vendor_product_loop_v4',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style04'),
            'title' => __('Enable/disable product seller','sigma-theme'),
            'subtitle' => __('You can enable or disable the seller button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),

//style 05

        array(
            'id' => 'show_img_product_loop_v5',
            'required' => array('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/Disable Course Images','sigma-theme'),
            'subtitle' => __('You can enable or disable course loop images from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_title_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/disable course title','sigma-theme'),
            'subtitle' => __('You can enable or disable the course loop title from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_en_title_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/Disable English Course Title','sigma-theme'),
            'subtitle' => __('You can enable or disable the English title of the course loop from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_wishlist_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/Disable Course Favorites','sigma-theme'),
            'subtitle' => __('You can enable or disable course interest from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_desc_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/disable course information','sigma-theme'),
            'subtitle' => __('You can enable or disable course information from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_badge_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/disable course medals','sigma-theme'),
            'subtitle' => __('You can enable or disable course loop medals from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_avatar_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/Disable Teacher Avatar','sigma-theme'),
            'subtitle' => __('You can enable or disable the teachers avatar from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'show_cart_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/Disable Product Details Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Product Details Button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'show_qviews_product_loop_v5',
            'required' => array ('products_style_loops', '=', 'template-part/content/loop/product/style05'),
            'title' => __('Enable/Disable Add to Course Button','sigma-theme'),
            'subtitle' => __('You can enable or disable the Add to Cart button from this section.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
    ),
));


Redux::setSection($opt_name, array (
    'title' => __('Shopping Cart','sigma-theme'),
    'id' => 'cart_chekcout_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'woo_bg_btn',
            'type' => 'color_gradient',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'from' => '#00BCD4',
                'to' => '#07a8f4',
            ),
            'title' => __('WooCommerce Buttons Background Color','sigma-theme'),
            'subtitle' => __('This color will be applied to the background of all WooCommerce buttons.','sigma-theme'),
        ),
        array (
            'id' => 'woo_color_btn',
            'title' => __('WooCommerce Button Colors','sigma-theme'),
            'subtitle' => __('This color will be applied to all WooCommerce buttons.','sigma-theme'),
            'type' => 'color',
            'default' => '#ffffff'
        ),
        array (
            'id' => 'woo_size_btn',
            'type' => 'select',
            'title' => __('WooCommerce Button Size','sigma-theme'),
            'subtitle' => __('This size will apply to WooCommerce buttons.','sigma-theme'),
            'options' => array (
                '13px' => '13px',
                '14px' => '14px',
                '15px' => '15px',
                '16px' => '16px',
                '17px' => '17px',
                '18px' => '18px',
                '19px' => '19px',
                '20px' => '20px',
            ),
            'default' => '13px',
        ),
        array(
            'id' => 'woo_input_color',
            'title' => __('Color WooCommerce Inputs','sigma-theme'),
            'subtitle' => __('This color will be applied to WooCommerce imports.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array (
            'id' => 'woo_input_size',
            'type' => 'select',
            'title' => __('WooCommerce Input Size','sigma-theme'),
            'subtitle' => __('This size will apply to WooCommerce imports.','sigma-theme'),
            'options' => array (
                '13px' => '13px',
                '14px' => '14px',
                '15px' => '15px',
                '16px' => '16px',
                '17px' => '17px',
                '18px' => '18px',
                '19px' => '19px',
                '20px' => '20px',
            ),
            'default' => '13px',
        ),
        array (
            'id' => 'woo_label_color',
            'title' => __('WooCommerce Label Colors','sigma-theme'),
            'subtitle' => __('This color will be applied to WooCommerce labels.','sigma-theme'),
            'type' => 'color',
            'default' => '#666666'
        ),
        array (
            'id' => 'woo_label_size',
            'type' => 'select',
            'title' => __('Size of WooCommerce Labels','sigma-theme'),
            'subtitle' => __('This size will apply to WooCommerce labels.','sigma-theme'),
            'options' => array (
                '13px' => '13px',
                '14px' => '14px',
                '15px' => '15px',
                '16px' => '16px',
                '17px' => '17px',
                '18px' => '18px',
                '19px' => '19px',
                '20px' => '20px',
            ),
            'default' => '13px',
        ),
    ),
));

// -> START font Setting
Redux::setSection($opt_name, array(
    'title' => __('Font settings','sigma-theme'),
     'id' => 'font_setting',
     'customizer_width' => '400px',
     'icon' => 'el el-fontsize',
     'fields' => array (
         array (
             'id' => 'font_family_section',
             'title' => __('Template typography settings','sigma-theme'),
             'type' => 'section',
             'indent' => true
         ),
        array(
            'id' => 'body_font',
             'type' => 'select',
             'title' => __('Site Body Font','sigma-theme'),
             'subtitle' => __('Choose one of the available fonts for your site body font!','sigma-theme'),
             'options' => array(
                'DanaFont' => __('DanaFont','sigma-theme'),
                'sahelfont' => __('sahelfont','sigma-theme'),
                'gandomfont' => __('gandomfont','sigma-theme'),
                'tanhafont' => __('tanhafont','sigma-theme'),
                'parsatofont' => __('parsatofont','sigma-theme'),
                'nahidfont' => __('nahidfont','sigma-theme'),
                'IRANSans' => __('IRANSans','sigma-theme'),
                'iranyekan' => __('iranyekan','sigma-theme'),
                'naskhfont' => __('naskhfont','sigma-theme'),
                'tahoma' => __('tahoma','sigma-theme'),
                'samimwp' => __('samimwp','sigma-theme'),
                'yekanwp' => __('yekanwp','sigma-theme'),
                'shabnamwp' => __('shabnamwp','sigma-theme'),
                'vazirwp' => __('vazirwp','sigma-theme'),
                'koodakwp' => __('koodakwp','sigma-theme'),
                'mitrawp' => __('mitrawp','sigma-theme'),
                'nazaninwp' => __('nazaninwp','sigma-theme'),
            ),
            'default' => __('DanaFont','sigma-theme'),
        ),
        array(
            'id' => 'head_font',
             'type' => 'select',
             'title' => __('Site heading fonts','sigma-theme'),
             'subtitle' => __('Choose from the available fonts the font for your site heading font!','sigma-theme'),
             'options' => array(
                'DanaFont' => __('DanaFont','sigma-theme'),
                'sahelfont' => __('sahelfont','sigma-theme'),
                'gandomfont' => __('gandomfont','sigma-theme'),
                'tanhafont' => __('tanhafont','sigma-theme'),
                'parsatofont' => __('parsatofont','sigma-theme'),
                'nahidfont' => __('nahidfont','sigma-theme'),
                'IRANSans' => __('IRANSans','sigma-theme'),
                'iranyekan' => __('iranyekan','sigma-theme'),
                'naskhfont' => __('naskhfont','sigma-theme'),
                'tahoma' => __('tahoma','sigma-theme'),
                'samimwp' => __('samimwp','sigma-theme'),
                'yekanwp' => __('yekanwp','sigma-theme'),
                'shabnamwp' => __('shabnamwp','sigma-theme'),
                'vazirwp' => __('vazirwp','sigma-theme'),
                'koodakwp' => __('koodakwp','sigma-theme'),
                'mitrawp' => __('mitrawp','sigma-theme'),
                'nazaninwp' => __('nazaninwp','sigma-theme'),
            ),
            'default' => __('DanaFont','sigma-theme'),
        ),
        array(
            'id' => 'lists_font',
             'type' => 'select',
             'title' => __('List fonts or site menus','sigma-theme'),
             'subtitle' => __('Choose a font from the available fonts for your site list or menu fonts!','sigma-theme'),             
             'options' => array(
                'DanaFont' => __('DanaFont','sigma-theme'),
                'sahelfont' => __('sahelfont','sigma-theme'),
                'gandomfont' => __('gandomfont','sigma-theme'),
                'tanhafont' => __('tanhafont','sigma-theme'),
                'parsatofont' => __('parsatofont','sigma-theme'),
                'nahidfont' => __('nahidfont','sigma-theme'),
                'IRANSans' => __('IRANSans','sigma-theme'),
                'iranyekan' => __('iranyekan','sigma-theme'),
                'naskhfont' => __('naskhfont','sigma-theme'),
                'tahoma' => __('tahoma','sigma-theme'),
                'samimwp' => __('samimwp','sigma-theme'),
                'yekanwp' => __('yekanwp','sigma-theme'),
                'shabnamwp' => __('shabnamwp','sigma-theme'),
                'vazirwp' => __('vazirwp','sigma-theme'),
                'koodakwp' => __('koodakwp','sigma-theme'),
                'mitrawp' => __('mitrawp','sigma-theme'),
                'nazaninwp' => __('nazaninwp','sigma-theme'),
            ),
            'default' => __('DanaFont','sigma-theme'),
        ),
    )));

// -> START User Dashbaard Setting
Redux::setSection($opt_name, array(
    'title' => __('User section settings','sigma-theme'),
    'id' => 'dashbaord_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-user',
));
// -> START LastPass Setting
Redux::setSection($opt_name, array (
    'title' => __('Reset Password Change','sigma-theme'),
    'id' => 'lost_pass_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'lostt_style_page',
            'type' => 'select',
            'title' => __('Choose a design from the available designs for your password forgetting page ..','sigma-theme'),
            'options' => array (
                'dashboard/last-password/last-password-style-one' => __('Style one','sigma-theme'),
                'dashboard/last-password/last-password-style-two' => __('Style two','sigma-theme'),
                'dashboard/last-password/last-password-style-three' => __('Style three','sigma-theme'),
                'dashboard/last-password/last-password-style-four' => __('Style four','sigma-theme'),
            ),
            'default' => 'dashboard/last-password/last-password-style-four'
        ),
        array(
            'id' => 'lost_section_v1',
            'required' => array('lostt_style_page', '=', 'dashboard/last-password/last-password-style-one'),
            'title' => __('Settings for forgetting a style pass','sigma-theme'),
            'type' => 'section',
            'indent' => true
        ),
        array (
            'id' => 'reset_page_back',
            'title' => __('Password Forget Screen Background','sigma-theme'),
            'subtitle' => __('Choose the background color of the forgotten password page ...','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#2dc1e5',),
        ),
        array (
            'id' => 'reset_form_back',
            'title' => __('Form background color','sigma-theme'),
            'subtitle' => __('Background Color Forgetting Form - Style One','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'default' => array (
                'background-color' => '#ffffff',
                'background-image' => ''. get_template_directory_uri (). '/assets/img/loginwp.png'),
        ),
        array (
            'id' => 'lost_section_v2',
            'required' => array ('lostt_style_page', '=', 'dashboard/last-password/last-password-style-two'),
            'title' => __('Settings for forgetting the double style pass','sigma-theme'),
            'type' => 'section',
            'indent' => true
        ),
        array (
            'id' => 'reset_v2_bg',
            'title' => __('Apply image to full page','sigma-theme'),
            'subtitle' => __('Upload a two-page version of the forgotten site password or enter the URL ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-color' => false,
            'default' => array (
                'background-image' => ''. get_template_directory_uri (). '/assets/img/login_bg_v2.jpg'),
        ),
        array (
            'id' => 'lost_pass_v2_left_box_back_photo',
            'title' => __('Apply background image to frame - left','sigma-theme'),
            'subtitle' => __('Change the background image of the two-page password-forgetting page on the left.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-color' => false,
            'default' => array (
                'background-image' => ''. get_template_directory_uri (). '/assets/img/login_bg-final-1.png'),
        ),
        array (
            'id' => 'content_reset_form_text',
            'title' => __('Text above forgetting form','sigma-theme'),
            'subtitle' => __('Enter the text above the passphrase form!','sigma-theme'),
            'default' => __('To access the features of the user panel, it is necessary to log in to the site, enter the user panel using the available form using the following form.','sigma-theme'),
            'type' => 'text',
        ),
        array (
            'id' => 'lost_image_v2',
            'title' => __('Site logo in the left description','sigma-theme'),
            'subtitle' => __('You can select a custom logo from your multimedia file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/logo-light.png'),
        ),
        array (
            'id' => 'losst_user_image_v2',
            'title' => __('Picture of the password forgetfulness section on the left description site','sigma-theme'),
            'subtitle' => __('You can select a custom image from your media file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/boy-150x150.png'),
        ),
        array(
            'id' => 'content_reset',
            'title' => __('Content Description of the Forgot Password section of the site','sigma-theme'),
            'subtitle' => __('Enter the content of the password forgetting section description in this section. Make a list of these items .. ','sigma-theme'),
            'default' => __('<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true" > </i> & nbsp; Please use up-to-date browsers such as Google Chrome and Firefox. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp Please change your password at short intervals. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp This site will never request your confidential information via email. Let us know immediately if this happens. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp Please note the page address is on the Hamkarwp.com domain. Otherwise, it is strongly recommended that you refrain from entering login information. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp ; The Sigma Plus store layout has been coded by the WordPress partner team and can only be purchased and supported on the Jacket Sell website. </span> </p> ','sigma-theme'),
            'type' => 'editor',
        ),
        array (
            'id' => 'content_reset_btn_text',
            'title' => __('More Info Button Text','sigma-theme'),
            'subtitle' => __('Enter the text button for more information on the page!','sigma-theme'),
            'default' => __('Click to see more!','sigma-theme'),
            'type' => 'text',
        ),
        array (
            'id' => 'content_reset_btn_link',
            'title' => __('Link More Info Button','sigma-theme'),
            'subtitle' => __('Enter the button for more information on this page.!','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/'
        ),
        array (
            'id' => 'lost_section_v3',
            'required' => array ('lostt_style_page', '=', 'dashboard/last-password/last-password-style-three'),
            'title' => __('Settings page forget style pass','sigma-theme'),
            'type' => 'section',
            'indent' => true
        ),
        array (
            'id' => 'lost_pass_v3_box_back',
            'title' => __('Change the background on the Forgot Password page','sigma-theme'),
            'subtitle' => __('From this section you can change the password forgetting page style ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-image' => false,
            'background-attachment' => false,
            'default' => array (
                'background-color' => '#E0E0E0','sigma-theme'),

        ),
        array (
            'id' => 'lost_pass_v13_box_back',
            'title' => __('Change the background in the Forgot Password box','sigma-theme'),
            'subtitle' => __('From this section you can change the password forgetting box style ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-image' => false,
            'background-attachment' => false,
            'default' => array (
                'background-color' => '#0140C3',)
        ),
        array (
            'id' => 'lost_section_v4',
            'required' => array ('lostt_style_page', '=', 'dashboard/last-password/last-password-style-four'),
            'title' => __('Settings page forget style pass four','sigma-theme'),
            'type' => 'section',
            'indent' => true
        ),
        array (
            'id' => 'lost_pass_v4_full_back',
            'title' => __('Background color of the whole page Forgot password','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the entire password forgetting page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#212942',)
        ),
        array (
            'id' => 'lost_pass_v4_back',
            'title' => __('Password Forget Box Background Color','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the password forgetting box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#212942','sigma-theme'),
        ),
        array(
            'id' => 'lost_pass_v4_back_border_top_color',
            'title' => __('Set top border color','sigma-theme'),
            'subtitle' => __('From this section you can change the color of the top margin of the password forgetting box ..','sigma-theme'),
            'type' => 'color',
            'default' => '#79a6fe'
        ),
    ),
));


// -> START register Setting
Redux::setSection($opt_name, array(
    'title' => __('Membership page settings','sigma-theme'),
    'id' => 'register_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'regiss_style_page',
            'type' => 'select',
            'title' => __('Choose a design from the available designs for your site membership page ..','sigma-theme'),
            'options' => array (
                'dashboard/register/register-style-one' => __('Style one','sigma-theme'),
                'dashboard/register/register-style-two' => __('Style two','sigma-theme'),
                'dashboard/register/register-style-three' => __('Style three','sigma-theme'),
                'dashboard/register/register-style-four' => __('Style four','sigma-theme'),
            ),
            'default' => 'dashboard/register/register-style-four'
        ),
        array (
            'id' => 'regiss_v1_full',
            'type' => 'section',
            'indent' => true,
            'required' => array ('regiss_style_page', '=', 'dashboard/register/register-style-one'),
            'title' => __('Number one style membership page settings','sigma-theme'),
        ),
        array (
            'id' => 'register_container_bg',
            'title' => __('Registration Form Background','sigma-theme'),
            'subtitle' => __('Select the background color of the registration form here!','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'default' => array (
                'background-color' => '#ffffff',
                'background-image' => ''. get_template_directory_uri (). '/assets/img/loginwp.png'),
        ),
        array (
            'id' => 'register_page_back',
            'title' => __('Membership page background color','sigma-theme'),
            'subtitle' => __('Choose the background color of the membership page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#2dc1e5',),
        ),
        array (
            'id' => 'regiss_v1_full_2',
            'type' => 'section',
            'indent' => true,
            'required' => array ('regiss_style_page', '=', 'dashboard/register/register-style-two'),
            'title' => __('Settings page number two style','sigma-theme'),
        ),
        array (
            'id' => 'register_v2_bg',
            'title' => __('Apply image to full page','sigma-theme'),
            'subtitle' => __('Upload a two-page version of the site membership page or enter the URL ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-color' => false,
            'default' => array (
                'background-image' => ''. get_template_directory_uri (). '/assets/img/login_bg_v2.jpg'),
        ),
        array (
            'id' => 'register_v2_left_box_back_photo',
            'title' => __('Apply background image to frame - left','sigma-theme'),
            'subtitle' => __('Change the background image of the two-page membership page on the left.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-color' => false,
            'default' => array (
                'background-image' => ''. get_template_directory_uri (). '/assets/img/login_bg-final-1.png'),
        ),
        array(
            'id' => 'register_user_image_v2',
            'title' => __('Image of a member of the membership section of the site on the left','sigma-theme'),
            'subtitle' => __('You can select a custom image from your media file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/boy-150x150.png'),
        ),
        array (
            'id' => 'content_register_form_text',
            'title' => __('Text above the membership form','sigma-theme'),
            'subtitle' => __('Enter the text above the membership form!','sigma-theme'),
            'default' => __('To access the features of the user panel, it is necessary to log in to the site, enter the user panel using the available form using the following form.','sigma-theme'),
            'type' => 'text',
        ),
        array (
            'id' => 'register_image_v2',
            'title' => __('Site logo in the left description','sigma-theme'),
            'subtitle' => __('You can select a custom logo from your multimedia file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/logo-light.png'),
        ),
        array (
            'id' => 'register_user_image_v2',
            'title' => __('Image of a member of the membership section of the site on the left','sigma-theme'),
            'subtitle' => __('You can select a custom image from your media file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/boy-150x150.png'),
        ),
        array (
            'id' => 'content_register',
            'title' => __('Content description of the membership section of the site','sigma-theme'),
            'subtitle' => __('Enter the content of the subscription description in this section. Make a list of these items .. ','sigma-theme'),
            'default' => __('<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true" > </i> & nbsp; Please use up-to-date browsers such as Google Chrome and Firefox. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp Please change your password at short intervals. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp This site will never request your confidential information via email. Let us know immediately if this happens. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp Please note the page address is on the Hamkarwp.com domain. Otherwise, it is strongly recommended that you refrain from entering login information. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp ; The Sigma Plus store layout has been coded by the WordPress partner team and can only be purchased and supported on the Jacket Sell website. </span> </p> ','sigma-theme'),
            'type' => 'editor',
        ),
        array (
            'id' => 'content_register_btn_text',
            'title' => __('More Info Button Text','sigma-theme'),
            'subtitle' => __('Enter the text button for more information on the page!','sigma-theme'),
            'default' => __('Click to see more!','sigma-theme'),
            'type' => 'text',
        ),
        array (
            'id' => 'content_register_btn_link',
            'title' => __('Link More Info Button','sigma-theme'),
            'subtitle' => __('Enter the button for more information on this page.!','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/'
        ),
        array(
            'id' => 'register_v3_full',
            'type' => 'section',
            'indent' => true,
            'required' => array('regiss_style_page', '=', 'dashboard/register/register-style-three'),
            'title' => __('Settings page style number three','sigma-theme'),
        ),
        array (
            'id' => 'register_v3_box_back',
            'title' => __('Membership box background color','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the membership box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#074cca',),
        ),
        array (
            'id' => 'register_v3_full_back',
            'title' => __('Full background of the membership page','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the whole membership page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#E0E0E0',),
        ),
        array (
            'id' => 'regiss_v4_full',
            'type' => 'section',
            'indent' => true,
            'required' => array ('regiss_style_page', '=', 'dashboard/register/register-style-four'),
            'title' => __('Settings for page number four style','sigma-theme'),
        ),
        array (
            'id' => 'register_v4_back',
            'title' => __('Sites box background color','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the membership page box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#212942',),
        ),
        array (
            'id' => 'register_v4_full_back',
            'title' => __('Full background page of membership page','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the whole page of the membership page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#212942',),
        ),
        array (
            'id' => 'register_v4_back_border_top_color',
            'title' => __('Set top border color','sigma-theme'),
            'subtitle' => __('From this section you can change the color of the top margin of the membership page box ..','sigma-theme'),
            'type' => 'color',
            'default' => '#79a6fe'
        ),
    )
));

// -> START Loign Setting
Redux::setSection($opt_name, array(
    'title' => __('Login page settings','sigma-theme'),
    'id' => 'login_setting',
    'customizer_width' => '400px',
    'subsection' => true,
    'fields' => array (
        array (
            'id' => 'logiin_style_page',
            'type' => 'select',
            'title' => __('Choose a design from the available designs for your site login page ..','sigma-theme'),
            'options' => array (
                'dashboard/login/login-style-one' => __('Style one','sigma-theme'),
                'dashboard/login/login-style-two' => __('Style two','sigma-theme'),
                'dashboard/login/login-style-three' => __('Style three','sigma-theme'),
                'dashboard/login/login-style-four' => __('Style four','sigma-theme'),
            ),
            'default' => 'dashboard/login/login-style-four'
        ),
        array (
            'id' => 'logiin_v1_full',
            'type' => 'section',
            'indent' => true,
            'required' => array ('logiin_style_page', '=', 'dashboard/login/login-style-one'),
            'title' => __('Settings page style entry number one','sigma-theme'),
        ),
        array (
            'id' => 'logiin_page_back',
            'title' => __('Login page background color','sigma-theme'),
            'subtitle' => __('Select the background color of the login page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#2dc1e5',),
        ),
        array (
            'id' => 'logiin_container_bg',
            'title' => __('Login Form Background','sigma-theme'),
            'subtitle' => __('Select the background color of the login form here!','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'default' => array (
                'background-color' => '#ffffff',
                'background-image' => ''. get_template_directory_uri (). '/assets/img/loginwp.png'),
        ),
        array (
            'id' => 'logiin_2_title1',
            'type' => 'section',
            'indent' => true,
            'required' => array ('logiin_style_page', '=', 'dashboard/login/login-style-two'),
            'title' => __('Settings page style entry number two','sigma-theme'),
        ),
        array (
            'id' => 'logiin_v2_bg',
            'title' => __('Apply image to full page','sigma-theme'),
            'subtitle' => __('Upload a two-page login background image or enter an address ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-color' => false,
            'default' => array (
                'background-image' => ''. get_template_directory_uri (). '/assets/img/login_bg_v2.jpg'),
        ),
        array (
            'id' => 'logiin_v2_left_box_back_photo',
            'title' => __('Apply background image to frame - left','sigma-theme'),
            'subtitle' => __('Change the background image of the two-page left entry page.','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-color' => false,
            'default' => array (
                'background-image' => ''. get_template_directory_uri (). '/assets/img/login_bg-final-1.png'),
        ),
        array(
            'id' => 'logiin_user_image_v2',
            'title' => __('Image of a member of the membership section of the site on the left','sigma-theme'),
            'subtitle' => __('You can select a custom image from your media file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/boy-150x150.png'),
        ),
        array (
            'id' => 'content_logiin_form_text',
            'title' => __('Text above the login form','sigma-theme'),
            'subtitle' => __('Enter the text above the login form!','sigma-theme'),
            'default' => __('To access the features of the user panel, it is necessary to log in to the site, enter the user panel using the available form using the following form.','sigma-theme'),
            'type' => 'text',
        ),
        array (
            'id' => 'logiin_image_v2',
            'title' => __('Site logo in the left description','sigma-theme'),
            'subtitle' => __('You can select a custom logo from your multimedia file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/logo-light.png'),
        ),
        array (
            'id' => 'logiin_user_image_v2',
            'title' => __('Image of a member of the membership section of the site on the left','sigma-theme'),
            'subtitle' => __('You can select a custom image from your media file library ..','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/boy-150x150.png'),
        ),
        array (
            'id' => 'content_logiin',
            'title' => __('Content description of the login section','sigma-theme'),
            'subtitle' => __('Enter the content of the subscription description in this section. Make a list of these items .. ','sigma-theme'),
            'default' => __('<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true" > </i> & nbsp; Please use up-to-date browsers such as Google Chrome and Firefox. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp Please change your password at short intervals. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp This site will never request your confidential information via email. Let us know immediately if this happens. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp Please note the page address is on the Hamkarwp.com domain. Otherwise, it is strongly recommended that you refrain from entering login information. </span> </p>
<p style = "text-align: right;"> <span style = "color: #ffffff;"> <i class = "fal fa-angle-left" aria-hidden = "true"> </i> & nbsp ; The Sigma Plus store layout has been coded by the WordPress partner team and can only be purchased and supported on the Jacket Sell website. </span> </p> ','sigma-theme'),
            'type' => 'editor',
        ),
        array (
            'id' => 'content_logiin_btn_text',
            'title' => __('More Info Button Text','sigma-theme'),
            'subtitle' => __('Enter the text button for more information on the page!','sigma-theme'),
            'default' => __('Click to see more!','sigma-theme'),
            'type' => 'text',
        ),
        array (
            'id' => 'content_logiin_btn_link',
            'title' => __('Link More Info Button','sigma-theme'),
            'subtitle' => __('Enter the button for more information on this page.!','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/'
        ),
        array (
            'id' => 'logiin_33_t_full',
            'type' => 'section',
            'indent' => true,
            'required' => array ('logiin_style_page', '=', 'dashboard/login/login-style-three'),
            'title' => __('Settings page style entry number three','sigma-theme'),
        ),
        array (
            'id' => 'logiin_v3_box_back',
            'title' => __('Login page background color','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the input box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#074cca',),
        ),
        array (
            'id' => 'logiin_v3_full_back',
            'title' => __('Full login page background','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the entire login page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#E0E0E0',),
        ),
        array (
            'id' => 'logiin_v4_full',
            'type' => 'section',
            'indent' => true,
            'required' => array ('logiin_style_page', '=', 'dashboard/login/login-style-four','sigma-theme'),
            'title' => __('Settings page style entry number four','sigma-theme'),
        ),
        array (
            'id' => 'logiin_v4_full_back',
            'title' => __('Full page entry page background color','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the entire login page ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#212942',),
        ),
        array (
            'id' => 'logiin_v4_back',
            'title' => __('Sites box background color','sigma-theme'),
            'subtitle' => __('From this section you can change the background color of the login box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#212942',),
        ),
        array (
            'id' => 'logiin_v4_back_border_top_color',
            'title' => __('Set top border color','sigma-theme'),
            'subtitle' => __('From this section you can change the color of the top margin of the login page ..','sigma-theme'),
            'type' => 'color',
            'default' => '#79a6fe'
        ),
    )
));
Redux::setSection($opt_name, array (
    'title' => __('Seller Panel','sigma-theme'),
    'id' => 'vendor_setting',
    'subsection' => true,
    'customizer_width' => '400px',
    'fields' => array (
        array (
            'id' => 'dokan-show',
            'title' => __('Deactivate Vendors Panel','sigma-theme'),
            'subtitle' => __('Only if this section is disabled. If you decide to delete the sellers section of the site. , Also delete the shop plugin after disabling this section. ','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' => __('Enable','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'vendor_sidebar',
            'title' => __('Activate Vendors Menu','sigma-theme'),
            'subtitle' => __('If you nedd deactive vendor menu disable this options','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('Enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),        
        array (
            'id' => 'vendor_panel_style',
            'type' => 'select',
            'title' => __('Choose a design from the available designs for your vendors panel ..','sigma-theme'),
            'subtitle' => __('This design is for internal user panel pages and pages with Dokan Panel template set!','sigma-theme'),
            'options' => array (
                'dashboard/vendor/vendor-v1' => __('Style one','sigma-theme'),
                'dashboard/vendor/vendor-v2' => __('Style two','sigma-theme'),
            ),
            'default' => 'dashboard/vendor/vendor-v2'
        ),
        array(
            'id' => 'dokan_btn_title',
            'title' => __('Title of Vendors Panel Button','sigma-theme'),
            'subtitle' => __('Enter the title of the vendors panel button!','sigma-theme'),
            'type' => 'text',
            'required' => array ('dokan-show', '=', 'block'),
            'default' => __('Login to sellers panel','sigma-theme'),
        ),
        array (
            'id' => 'dokan_btn_link',
            'title' => __('Seller Button Button Link','sigma-theme'),
            'subtitle' => __('Enter the seller panel button link!','sigma-theme'),
            'type' => 'text',
            'required' => array ('dokan-show', '=', 'block'),
            'default' => ''. get_site_url (). '/dashboard'
        ),
        array (
            'id' => 'dokan_btn_icon',
            'title' => __('Vendors Panel Button Icon','sigma-theme'),
            'subtitle' => __('Enter the seller support button icon from here!','sigma-theme'),
            'type' => 'text',
            'required' => array ('dokan-show', '=', 'block'),
            'default' => 'fal fa-hourglass-1',
        ),
        array (
            'id' => 'dokan_btn_icon',
            'title' => __('Vendors Panel Button Icon','sigma-theme'),
            'subtitle' => __('Enter the seller support button icon from here!','sigma-theme'),
            'type' => 'text',
            'required' => array ('dokan-show', '=', 'block'),
            'default' => 'fal fa-hourglass-1',
        ),
    )
));

Redux::setSection($opt_name, array (
    'title' => __('User Panel','sigma-theme'),
    'subsection' => true,
    'id' => 'user_setting_panel',
    'customizer_width' => '400px',
    'fields' => array (
        array (
            'id' => 'active_woo_my_account_nav',
            'title' => __('Activate the default WooCommerce menu','sigma-theme'),
            'subtitle' => __('By disabling this section, the default menu of my WooCommerce account has been removed from the users menu and you can display the custom menu that you selected from the Show/Lists/Places Manager as the User Panel menu.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('Yes','sigma-theme'),
                'disbale' => __('No','sigma-theme'),
            ),
        ),
        array (
            'id' => 'panel_logo',
            'title' => __('User Panel Logo','sigma-theme'),
            'subtitle' => __('You can select a custom logo from your multimedia file library. Recommended size: 40 * 40','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/favicon-v2.png'),
        ),
        array (
            'id' => 'user_panel_style_index',
            'type' => 'select',
            'title' => __('Choose a design from the available designs for the internal page of your user panel ..','sigma-theme'),
            'subtitle' => __('This design is for the internal pages of the user panel and pages whose template is Profile New Sigma!','sigma-theme'),
            'options' => array (
                'dashboard/user/panel-v1' => __('Style One','sigma-theme'),
                'dashboard/user/panel-v2' => __('Style two','sigma-theme'),
            ),
            'default' => 'dashboard/user/panel-v1'
        ),
        array (
            'id' => 'user_panel_style',
            'type' => 'select',
            'title' => __('Choose a design from the available designs for your users panel ..','sigma-theme'),
            'desc' => __('By selecting each design, the relevant settings are displayed and that design is selected as the user panel design!','sigma-theme'),
            'options' => array (
                'dashboard/user/dashboard-v1' => __('Style one','sigma-theme'),
                'dashboard/user/dashboard-v2' => __('Style two','sigma-theme'),
            ),
            'default' => 'dashboard/user/dashboard-v1'
        ),
        array (
            'id' => 'section_01_01_general',
            'title' => __('General settings of the user panel','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'welcome_panel_active',
            'title' => __('Show user panel welcome message','sigma-theme'),
            'subtitle' => __('Is the welcome message displayed at the beginning of the user panel or not?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Yes','sigma-theme'),
                'none' => __('No','sigma-theme'),
            ),
        ),
        array(
            'id' => 'codeoff_active',
            'title' => __('Show discount box in user panel','sigma-theme'),
            'subtitle' => __('Specify whether you want the discount box to be displayed in the user panel?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'codeoff_panel',
            'title' => __('User Panel Discount Code','sigma-theme'),
            'required' => array ('codeoff_active', '=', 'inherit'),
            'subtitle' => __('Enter the user panel discount code to display to users ..','sigma-theme'),
            'type' => 'text',
            'default' => __('HiSigmaZhaket')
        ),
        array (
            'id' => 'codeoff_panel_icon',
            'title' => __('User Panel Discount Code Icon','sigma-theme'),
            'required' => array ('codeoff_active', '=', 'inherit'),
            'subtitle' => __('Enter the icon for the user panel discount code. All Font Awesome icons are supported. Enter as fal fa-send .. ','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-gift'
        ),
        array (
            'id' => 'codeoff_title_panel',
            'required' => array ('codeoff_active', '=', 'inherit'),
            'title' => __('User Panel Discount Code Text','sigma-theme'),
            'subtitle' => __('Enter the text of the user panel discount code to display to users ..','sigma-theme'),
            'type' => 'text',
            'default' => __('20% off discount code for your next purchase','sigma-theme'),
        ),
        array (
            'id' => 'usermeta_box_panel',
            'title' => __('Box number of purchases, orders, tickets, etc.','sigma-theme'),
            'subtitle' => __('Show/hide user performance link box in user panel','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'usermeta_title_01',
            'title' => __('Title Number of Comments','sigma-theme'),
            'required' => array ('usermeta_box_panel', '=', 'block'),
            'subtitle' => __('Enter the desired title in the Number of User Comments section!','sigma-theme'),
            'type' => 'text',
            'default' => __('Comments submitted','sigma-theme'),
        ),
        array (
            'id' => 'usermeta_title_02',
            'title' => __('Title Number of Products Purchased','sigma-theme'),
            'required' => array ('usermeta_box_panel', '=', 'block'),
            'subtitle' => __('Enter the desired title in the number of products the user has purchased!','sigma-theme'),
            'type' => 'text',
            'default' => __('Products purchased','sigma-theme'),
        ),
        array (
            'id' => 'usermeta_link_02',
            'required' => array ('usermeta_box_panel', '=', 'block'),
            'title' => __('Link number of products purchased','sigma-theme'),
            'subtitle' => __('Enter the number of products purchased!','sigma-theme'),
            'type' => 'text',
            'default' => ''. get_site_url (). '/my-account/downloads'
        ),
        array (
            'id' => 'usermeta_title_03',
            'title' => __('Title Number of Support Tickets','sigma-theme'),
            'required' => array ('usermeta_box_panel', '=', 'block'),
            'subtitle' => __('Enter the desired title in the Number of User Support Tickets section!','sigma-theme'),
            'type' => 'text',
            'default' => __('Support Tickets','sigma-theme'),
        ),
        array (
            'id' => 'usermeta_link_03',
            'required' => array ('usermeta_box_panel', '=', 'block'),
            'title' => __('Link number of support tickets','sigma-theme'),
            'subtitle' => __('Enter the number of support tickets!','sigma-theme'),
            'type' => 'text',
            'default' => ''. get_site_url (). '/tickets'
        ),
        array (
            'id' => 'usermeta_title_04',
            'title' => __( 'Title Amount of Orders Completed','sigma-theme'),
            'required' => array ('usermeta_box_panel', '=', 'block'),
            'subtitle' => __('Enter the desired title in the number of products the user has purchased!','sigma-theme'),
            'type' => 'text',
            'default' => __('Orders Done','sigma-theme'),
        ),
        array(
            'id' => 'usermeta_link_04',
            'required' => array('usermeta_box_panel', '=', 'block'),
            'title' => __('Link for the amount of orders made','sigma-theme'),
            'subtitle' => __('Enter the amount of orders placed!','sigma-theme'),
            'type' => 'text',
            'default' => ''. get_site_url (). '/my-account/orders'
        ),
        array (
            'id' => 'notif_active',
            'title' => __('Show notification box in user panel','sigma-theme'),
            'subtitle' => __('Specify whether you want the notification box to be displayed in the user panel?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'notif_title_panel',
            'required' => array ('notif_active', '=', 'block'),
            'title' => __('Title of the latest announcements','sigma-theme'),
            'subtitle' => __('Enter the title of the latest notifications section ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Last Notifications','sigma-theme'),
        ),
        array (
            'id' => 'notif_cat_panel',
            'required' => array ('notif_active', '=', 'block'),
            'title' => __('Category Announcements','sigma-theme'),
            'subtitle' => __('Enter the ID of the category in which you want the contents of that category to be displayed as the latest notifications in this section ..','sigma-theme'),
            'type' => 'select',
            'data' => 'categories',
            'default' => '58'
        ),
        array (
            'id' => 'notif_counter_panel',
            'required' => array ('notif_active', '=', 'block'),
            'title' => __('Number of notifications to display','sigma-theme'),
            'subtitle' => __('Enter the number of notifications to display ..','sigma-theme'),
            'type' => 'text',
            'default' => '3'
        ),
        array (
            'id' => 'section_01_0101',
            'title' => __('User panel settings version one','sigma-theme'),
            'type' => 'section',
            'indent' => true,
            'required' => array ('user_panel_style', '=', 'dashboard/user/dashboard-v1'),
        ),
        array (
            'id' => 'show_support_phone',
            'title' => __('Show Support Contact Number','sigma-theme'),
            'subtitle' => __('Enable or disable support contact number in user panel header','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'supp_phone',
            'title' => __('Support Contact Number','sigma-theme'),
            'subtitle' => __('Enter the contact number of the support panel header support ..','sigma-theme'),
            'type' => 'text',
            'required' => array ('show_support_phone', '=', 'inherit'),
            'default' => '5652-021',
        ),
        array (
            'id' => 'show_deposit',
            'title' => __('Show user balance','sigma-theme'),
            'subtitle' => __('Enable or disable user inventory in the user panel header','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' =>__('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'section_01_01',
            'title' => __('Main Panel Settings User Panel Version Two','sigma-theme'),
            'type' => 'section',
            'indent' => true,
            'required' => array ('user_panel_style', '=', 'dashboard/user/dashboard-v2'),
        ),
        array (
            'id' => 'telegram_box_panel',
            'title' => __('View the first social network link box','sigma-theme'),
            'subtitle' => __('Show/hide the first social network link box in the user panel','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'social_01_icon',
            'title' => __('First Social Network Icon Box','sigma-theme'),
            'required' => array ('telegram_box_panel', '=', 'inherit'),
            'subtitle' => __('Enter the social network box icon first. All Font Awesome icons are supported. Enter as fal fa-send .. ','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-send',
        ),
        array(
            'id' => 'telegram_panel',
            'required' => array('telegram_box_panel', '=', 'inherit'),
            'title' => __('Link to the first social network','sigma-theme'),
            'subtitle' => __('Enter the link of the first social network ..','sigma-theme'),
            'type' => 'text',
            'default' => 'https://telegram.me/hamkarwp'
        ),
        array (
            'id' => 'head_telegram_panel',
            'required' => array ('telegram_box_panel', '=', 'inherit'),
            'title' => __('Title of the first social network box','sigma-theme'),
            'subtitle' => __('Enter the title of the first social network box ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Channel Telegram Website','sigma-theme'),
        ),
        array (
            'id' => 'subtitle_telegram_panel',
            'required' => array ('telegram_box_panel', '=', 'inherit'),
            'title' => __('Under the title of the first social network box','sigma-theme'),
            'subtitle' => __('Enter the title of the first social network box ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Always be updated by subscribing to our Telegram channel.','sigma-theme'),
        ),
        array (
            'id' => 'social_01_icon_bg',
            'title' => __('Background color of the first social network box','sigma-theme'),
            'required' => array ('telegram_box_panel', '=', 'inherit'),
            'subtitle' => __('Enter the background color of the first social network box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#2196F3',)
        ),
        array (
            'id' => 'instagram_box_panel',
            'title' => __('View the second social network link box','sigma-theme'),
            'subtitle' => __('Show/hide the second social network link box in the user panel','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'social_02_icon',
            'title' => __('Icon of the second social network','sigma-theme'),
            'required' => array ('instagram_box_panel', '=', 'inherit'),
            'subtitle' => __('Enter the second social network box icon. All Font Awesome icons are supported. Enter as fal fa-send .. ','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-instagram'
        ),
        array (
            'id' => 'instagram_panel',
            'required' => array ('instagram_box_panel', '=', 'inherit'),
            'title' => __('Link to the second social network','sigma-theme'),
            'subtitle' => __('Enter the link box ..','sigma-theme'),
            'type' => 'text',
            'default' => 'http://instagram.com/hamakrwpcom'
        ),
        array (
            'id' => 'head_instagram_panel',
            'required' => array ('instagram_box_panel', '=', 'inherit'),
            'title' => __('Title of the second social network box','sigma-theme'),
            'subtitle' => __('Enter the title of the box ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Our Instagram Page','sigma-theme'),
        ),
        array (
            'id' => 'subtitle_instagram_panel',
            'required' => array ('instagram_box_panel', '=', 'inherit'),
            'title' => __('Under the title of the second social network box','sigma-theme'),
            'subtitle' => __('Enter the subtitle of the Instagram box ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Always be updated by subscribing to our Telegram channel.','sigma-theme'),
        ),
        array (
            'id' => 'social_02_icon_bg',
            'title' => __('Background color of the second social network box','sigma-theme'),
            'required' => array ('instagram_box_panel', '=', 'inherit'),
            'subtitle' => __('Enter the background color of the second social network box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#7232bd',)
        ),
        array (
            'id' => 'blog_box_active',
            'title' => __('Show the latest content in the user panel','sigma-theme'),
            'subtitle' => __('Specify whether you want the latest content box to be displayed in the user panel?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'blog_title_panel',
            'required' => array('blog_box_active', '=', 'inherit'),
            'title' => __('Title of Latest Content','sigma-theme'),
            'subtitle' => __('Enter the title of the latest content section ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Latest Content','sigma-theme'),
        ),
        array (
            'id' => 'blog_cat_panel',
            'required' => array ('blog_box_active', '=', 'inherit'),
            'title' => __('Latest Content Category','sigma-theme'),
            'subtitle' => __('Enter the category you want the content of that category to be displayed as the last content in this section ..','sigma-theme'),
            'type' => 'select',
            'data' => 'categories',
            'required' => array ('blog_box_active', '=', 'inherit'),
            'default' => '1'
        ),
        array (
            'id' => 'blog_count_panel',
            'required' => array ('blog_box_active', '=', 'inherit'),
            'title' => __('Number of contents to display','sigma-theme'),
            'subtitle' => __('Enter the number of items to display ..','sigma-theme'),
            'type' => 'text',
            'default' => '4'
        ),
        array (
            'id' => 'blog_btn_title_panel',
            'required' => array ('blog_box_active', '=', 'inherit'),
            'title' => __('Text More Button','sigma-theme'),
            'subtitle' => __('Enter the text of the More Content Button section ..','sigma-theme'),
            'type' => 'text',
            'default' => __('View more content','sigma-theme'),
        ),
        array (
            'id' => 'blog_btn_link_panel',
            'required' => array ('blog_box_active', '=', 'inherit'),
            'title' => __('Link to more content button','sigma-theme'),
            'subtitle' => __(' link more ','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/blog'
        ),
        array (
            'id' => 'deposit_panel_active',
            'title' => __('Show Inventory Box in User Panel','sigma-theme'),
            'subtitle' => __('Specify whether you want the inventory box to be displayed in the user panel?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'deposit_panel_title',
            'title' => __('User Panel Inventory Title Box','sigma-theme'),
            'required' => array ('deposit_panel_active', '=', 'inherit'),
            'subtitle' => __('You can change the title of the user panel inventory box here!','sigma-theme'),
            'type' => 'text',
            'default' => __('Your balance:','sigma-theme'),
        ),
        array (
            'id' => 'deposit_panel_link',
            'required' => array ('deposit_panel_active', '=', 'inherit'),
            'title' => __('Inventory panel account link','sigma-theme'),
            'subtitle' => __('Enter the account balance section of the account charge section ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/echarge'
        ),
        array (
            'id' => 'deposit_panel_icon',
            'title' => __('User Panel Inventory Icon','sigma-theme'),
            'required' => array ('deposit_panel_active', '=', 'inherit'),
            'subtitle' => __('Enter the user panel inventory icon. All Font Awesome icons are supported. Enter as fal fa-send .. ','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-money'
        ),
        array (
            'id' => 'deposit_panel_bg',
            'title' => __('Background panel inventory box background color','sigma-theme'),
            'required' => array ('deposit_panel_active', '=', 'inherit'),
            'subtitle' => __('Select the background color of the user panel inventory box ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#428bca',)
        ),
        array (
            'id' => 'section_01_01_panel',
            'title' => __('Dual User Panel Header Settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
            'required' => array ('user_panel_style', '=', 'dashboard/user/dashboard-v2'),
        ),
        array (
            'id' => 'panel_box_top_menu',
            'title' => __('Show Quick Access Menu in User Panel Header','sigma-theme'),
            'subtitle' => __('Specify whether you want the quick access menu in the header to be displayed in the user panel?','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'menu_panel_01_icon',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number one icon','sigma-theme'),
            'subtitle' => __('Enter and enter the desired icon code to display from https://fontawesome.com/v4.7.0/icons/ ..','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-support'
        ),
        array(
            'id' => 'menu_panel_01_title',
            'required' => array('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number one','sigma-theme'),
            'subtitle' => __('Enter the title you want to display ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Send Ticket','sigma-theme'),
        ),
        array (
            'id' => 'menu_panel_01_link',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number one link','sigma-theme'),
            'subtitle' => __('Enter the link of the page to display ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/submit-ticket'
        ),
        array (
            'id' => 'menu_panel_02_icon',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number two icon','sigma-theme'),
            'subtitle' => __('Enter and enter the desired icon code to display from https://fontawesome.com/v4.7.0/icons/ ..','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-money'
        ),
        array (
            'id' => 'menu_panel_02_title',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Title Menu Number Two','sigma-theme'),
            'subtitle' => __('Enter the title you want to display ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Charge Account','sigma-theme'),
        ),
        array (
            'id' => 'menu_panel_02_link',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number two','sigma-theme'),
            'subtitle' => __('Enter the link of the page to display ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/echarge'
        ),
        array (
            'id' => 'menu_panel_03_icon',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number three icon','sigma-theme'),
            'subtitle' => __('Enter and enter the desired icon code to display from https://fontawesome.com/v4.7.0/icons/ ..','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-shopping-cart'
        ),
        array (
            'id' => 'menu_panel_03_title',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Title Menu Number Three','sigma-theme'),
            'subtitle' => __('Enter the title you want to display ..','sigma-theme'),
            'type' => 'text',
            'default' => __('My Purchases','sigma-theme'),
        ),
        array (
            'id' => 'menu_panel_03_link',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number three link','sigma-theme'),
            'subtitle' => __('Enter the link of the page to display ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/my-account/downloads'
        ),
        array (
            'id' => 'menu_panel_04_icon',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu icon number four','sigma-theme'),
            'subtitle' => __('Enter and enter the desired icon code to display from https://fontawesome.com/v4.7.0/icons/ ..','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-users'
        ),
        array (
            'id' => 'menu_panel_04_title',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number four','sigma-theme'),
            'subtitle' => __('Enter the title you want to display ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Marketing','sigma-theme'),
        ),
        array (
            'id' => 'menu_panel_04_link',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number four link','sigma-theme'),
            'subtitle' => __('Enter the link of the page to display ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/affiliate-dashboard'
        ),
        array(
            'id' => 'menu_panel_05_icon',
            'required' => array('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu icon number five','sigma-theme'),
            'subtitle' => __('Enter and enter the desired icon code to display from https://fontawesome.com/v4.7.0/icons/ ..','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-paypal'
        ),
        array (
            'id' => 'menu_panel_05_title',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number five','sigma-theme'),
            'subtitle' => __('Enter the title you want to display ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Online payment','sigma-theme'),
        ),
        array (
            'id' => 'menu_panel_05_link',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number five link','sigma-theme'),
            'subtitle' => __('Enter the link of the page to display ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/payment'
        ),
        array (
            'id' => 'menu_panel_06_icon',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu icon number six','sigma-theme'),
            'subtitle' => __('Enter and enter the desired icon code to display from https://fontawesome.com/v4.7.0/icons/ ..','sigma-theme'),
            'type' => 'text',
            'default' => 'fal fa-heart'
        ),
        array (
            'id' => 'menu_panel_06_title',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number six','sigma-theme'),
            'subtitle' => __('Enter the title you want to display ..','sigma-theme'),
            'type' => 'text',
            'default' => __('Favorites','sigma-theme'),
        ),
        array (
            'id' => 'menu_panel_06_link',
            'required' => array ('panel_box_top_menu', '=', 'inherit'),
            'title' => __('Menu number six link','sigma-theme'),
            'subtitle' => __('Enter the link of the page to display ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/favorites'
        ),
        array (
            'id' => 'search_v2_show',
            'title' => __('Show search form in user panel header','sigma-theme'),
            'subtitle' => __('Show/hide Show search form in user panel header','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'cart_v2_show',
            'title' => __('Show Shopping Cart in User Panel Header','sigma-theme'),
            'subtitle' => __('Show/hide shopping cart in user panel header','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'panel_menu_v2_show',
            'title' => __('Show user menu','sigma-theme'),
            'subtitle' => __('Show user menu section on the left side of the user panel header','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
    ),
));


Redux::setSection($opt_name, array(
    'title' => __('Mobile version settings','sigma-theme'),
    'id' => 'menu_setting_mobile',
    'customizer_width' => '400px',
    'icon' => 'el el-iphone-home',
    'fields' => array (
        array (
            'id' => 'menu_section_mobile',
            'title' => __('Mobile Menu Settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'logo_mobile',
            'title' => __('Mobile version logo','sigma-theme'),
            'subtitle' => __('Depending on the structure of the mobile menu, be sure to use your icon for the mobile version. The suggested size is 50 * 50. ','sigma-theme'),
            'type' => 'media',
            'url' => true,
            'compiler' => 'true',
            'default' => array ('url' => ''. get_template_directory_uri (). '/assets/img/favicon-v2.png'),
        ),
        array (
            'id' => 'mobile_search_post_type',
            'type' => 'select',
            'title' => __('Mobile version of the site search style','sigma-theme'),
            'subtitle' => __('From this section you can specify whether to search for mobile versions of products or content or both.','sigma-theme'),
            'options' => array (
                'post' => __('Posts','sigma-theme'),
                'product' => __('Products','sigma-theme'),
                'any' => __('both','sigma-theme'),
            ),
            'default' => 'product',
        ),
        array (
            'id' => 'userarea_mobile',
            'title' => __('Mobile User Login Area','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'subtitle' => __('This section can enable or disable the user login and profile section in the mobile version.','sigma-theme'),
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'cart_icon_mobile',
            'title' => __('Mobile Shopping Cart Icon','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'subtitle' => __('This section can enable or disable the mobile version shopping cart icon.','sigma-theme'),
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'wishlist_icon_mobile',
            'title' => __('Mobile Favorite Icon','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'subtitle' => __('This section allows you to enable or disable the mobile version icon.','sigma-theme'),
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'search_icon_mobile',
            'title' => __('Mobile Search Icon','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'subtitle' => __('This section can enable or disable the mobile version search icon.','sigma-theme'),
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'advanced_search_icon_mobile',
            'title' => __('Advanced Mobile Search','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'subtitle' => __('This section can enable or disable the Advanced Mobile Search.','sigma-theme'),
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),        
        array (
            'id' => 'add_cart_mobile',
            'title' => __('Single product sticky shopping cart','sigma-theme'),
            'subtitle' => __('From this section you can enable or disable the sticky shopping cart of the mobile version of the single product.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'popup_options_active_mobile',
            'type' => 'button_set',
            'title' => __('Popup Newsletter on Mobile','sigma-theme'),
            'subtitle' => __('From this section you can manage the pop-up newsletter in the responsive version!','sigma-theme'),
            'default' => 'none',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'socials_box_mobile',
            'type' => 'button_set',
            'title' => __('Show fixed social icon button in Responsive version','sigma-theme'),
            'subtitle' => __('From this section you can manage the fixed icon on the left side of the site in the responsive version.! The link of each of these icons changes from the social network settings. ','sigma-theme'),
            'default' => 'none',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'social_active_mobile',
            'type' => 'button_set',
            'title' => __('Mobile Social Network Icons','sigma-theme'),
            'subtitle' => __('From this section you can manage social network icons on mobile!','sigma-theme'),
            'default' => 'enable',
            'options' => array (
                'enable' => __('enable','sigma-theme'),
                'disable' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'cart_active_mobile',
            'type' => 'button_set',
            'title' => __('Mobile Shopping Cart Icon','sigma-theme'),
            'subtitle' => __('From this section you can manage the fixed shopping cart icon on mobile!','sigma-theme'),
            'default' => 'inherit',
            'options' => array (
                'inherit' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'mobilemenu_header_bg',
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'background-color' => '#ffffff','sigma-theme'),
            'title' => __('Mobile menu heading background color','sigma-theme'),
            'subtitle' => __('This color will be applied to the top of the mobile menu!','sigma-theme'),
        ),
        array(
            'id' => 'mobilemenu_header_title',
            'title' => __('Welcome text color','sigma-theme'),
            'subtitle' => __('This color applies to welcome text!','sigma-theme'),
            'type' => 'color',
            'default' => '#8C8B8B'
        ),
        array (
            'id' => 'mobilemenu_header_btn',
            'title' => __('Mobile menu header button color','sigma-theme'),
            'subtitle' => __('This button is displayed as a login or membership when not logged in and as a user panel after logging in.','sigma-theme'),
            'type' => 'color',
            'default' => '#ff7f68'
        ),
        array (
            'id' => 'mobilemenu_bg',
            'type' => 'color_gradient',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'background-image' => false,
            'default' => array (
                'from' => '#ed5565',
                'to' => '#ed7f5d',
            ),
            'title' => __('Mobile menu body background color','sigma-theme'),
            'subtitle' => __('This color will be applied to the main part of the mobile menu items!','sigma-theme'),
        ),
        array (
            'id' => 'mobilemenu_iteme',
            'title' => __('User menu item color','sigma-theme'),
            'subtitle' => __('This color applies to all user menu items!','sigma-theme'),
            'type' => 'color',
            'default' => '#ffffff'
        ),
    ),
));



Redux::setSection($opt_name, array (
    'title' => __('Social Networks','sigma-theme'),
    'id' => 'social_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-share',
    'class' => 'dnone_v5',
    'fields' => array (
        array (
            'id' => 'section_menu_social',
            'title' => __('Social Network Settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),
        array (
            'id' => 'heaader_v1_0012',
            'title' => __('Show social media box in header','sigma-theme'),
            'subtitle' => __('Disabling this section will disable the display of all social network icons on the site.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'block',
            'class' => 'dnone_v5',
            'options' => array (
                'block' =>  __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_0013',
            'title' => __('Enable the display of YouTube icons on the site','sigma-theme'),
            'required' => array ('heaader_v1_0012', '=', 'block'),
            'subtitle' => __('From this section you can show or hide the YouTube icon.','sigma-theme'),
            'type' => 'button_set',
            'class' => 'dnone_v5',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_0014',
            'title' => __('Enable the display of Instagram icons on the site','sigma-theme'),
            'required' => array ('heaader_v1_0012', '=', 'block'),
            'subtitle' => __('From this section you can show or hide the Instagram icon.','sigma-theme'),
            'type' => 'button_set',
            'class' => 'dnone_v5',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array(
            'id' => 'heaader_v1_0015',
            'title' => __('Enable Facebook icon display on site','sigma-theme'),
            'required' => array ('heaader_v1_0012', '=', 'block'),
            'subtitle' => __('From this section you can show or hide the Facebook icon.','sigma-theme'),
            'type' => 'button_set',
            'class' => 'dnone_v5',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_0016',
            'required' => array ('heaader_v1_0012', '=', 'block'),
            'title' => __('Enable Telegram Icon Display on Site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the Telegram icon.','sigma-theme'),
            'type' => 'button_set',
            'default' => 'inline',
            'class' => 'dnone_v5',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
        array (
            'id' => 'heaader_v1_0017',
            'required' => array ('heaader_v1_0012', '=', 'block'),
            'title' => __('Enable Twitter icon display on site','sigma-theme'),
            'subtitle' => __('From this section you can show or hide the Twitter icon.','sigma-theme'),
            'type' => 'button_set',
            'class' => 'dnone_v5',
            'default' => 'inline',
            'options' => array (
                'inline' => __('Enabled','sigma-theme'),
                'none' => __('Disabled','sigma-theme'),
            ),
        ),
    )
));
// -> START 404 Setting
Redux::setSection($opt_name, array (
    'title' => __('404 Page settings','sigma-theme'),
    'id' => '404_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-remove',
    'fields' => array (
        array (
            'id' => 'section_menu_404',
            'title' => __('404 Page settings','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),

        array (
            'id' => '404_bg',
            'title' => __('Apply Image or Color to 404 Page Background','sigma-theme'),
            'subtitle' => __('Select an image or color for the 404 page background ..','sigma-theme'),
            'type' => 'background',
            'background-repeat' => false,
            'background-position' => false,
            'background-size' => false,
            'background-attachment' => false,
            'default' => array (
                'background-color' => '#24344c',
                'background-image' => ''. get_template_directory_uri (). '','sigma-theme'),
        ),
        array (
            'id' => '404_title',
            'title' => __('Title 404 Page','sigma-theme'),
            'subtitle' => __('Enter page title 404 ..','sigma-theme'),
            'type' => 'text',
            'default' => '404'
        ),
        array (
            'id' => '404_subtitle',
            'title' => __('Subtitle 404 Page','sigma-theme'),
            'subtitle' => __('Enter the subtitle of 404 Page ..','sigma-theme'),
            'type' => 'text',
            'default' => __('The page you are looking for does not exist!','sigma-theme'),
        ),
        array (
            'id' => '404_btn_link',
            'title' => __('Link Button Back to Home','sigma-theme'),
            'subtitle' => __('Enter the button to return to the main page of 404 Page ..','sigma-theme'),
            'type' => 'text',
            'validate' => 'url',
            'default' => ''. get_site_url (). '/'
        ),
        array(
            'id' => '404_btn_title',
            'title' => __('Title Button Return to Home Page','sigma-theme'),
             'subtitle' => __('Enter the title of the button to return to the main page of 404 Page ..','sigma-theme'),
             'type' => 'text',
             'default' => __('Return to Home Page','sigma-theme'),
        ),
    )
));

Redux::setSection($opt_name, array(
    'title' => __('Custom Codes','sigma-theme'),
    'id' => 'custom_code_setting',
    'customizer_width' => '400px',
    'icon' => 'el el-css',
    'fields' => array (
        array (
            'id' => 'section_menu_code',
            'title' => __('Custom Codes','sigma-theme'),
            'type' => 'section',
            'indent' => true,
        ),

        array (
            'id' => 'custom_css',
            'type' => 'ace_editor',
            'title' => __('custom css codes','sigma-theme'),
            'subtitle' => __('Enter any custom css code for Sigma in this box. To apply the changes faster than anywhere else on your site .. ','sigma-theme'),
            'mode' => 'css',
            'theme' => 'monokai',
        ),
        array (
            'id' => 'custom_js',
            'type' => 'ace_editor',
            'title' => __('custom codes js','sigma-theme'),
            'subtitle' => __('Enter any custom js code for Sigma in this box. To apply the changes faster than anywhere else on your site .. ','sigma-theme'),
            'mode' => 'javascript',
            'theme' => 'monokai',
        ),
    )

));

if (!function_exists('compiler_action')) {
    function compiler_action($options, $css, $changed_values)
    {
        echo '<h1>The compiler hook has run!</h1>';
        echo "<pre>";
        print_r($changed_values); // Values that have changed since the last save
        echo "</pre>";
        //print_r($options); //Option values
        //print_r($css); // Compiler button_setor CSS values  compiler => array( CSS button_setORS )
    }
}

/**
 * Custom function for the callback validation referenced above
 * */
if (!function_exists('redux_validate_callback_function')) {
    function redux_validate_callback_function($field, $value, $existing_value)
    {
        $error = false;
        $warning = false;

        //do your validation
        if ($value == 1) {
            $error = true;
            $value = $existing_value;
        } elseif ($value == 2) {
            $warning = true;
            $value = $existing_value;
        }

        $return['value'] = $value;

        if ($error == true) {
            $field['msg'] = 'your custom error message';
            $return['error'] = $field;
        }

        if ($warning == true) {
            $field['msg'] = 'your custom warning message';
            $return['warning'] = $field;
        }

        return $return;
    }
}

/**
 * Custom function for the callback referenced above
 */
if (!function_exists('redux_my_custom_field')) {
    function redux_my_custom_field($field, $value)
    {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
}

/**
 * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
 * so you must use get_template_directory_uri() if you want to use any of the built in icons
 * */
if (!function_exists('dynamic_section')) {
    function dynamic_section($sections)
    {
        //$sections = array();
        $sections[] = array(
            'title' => __('Section via hook', 'sigma-theme'),
            'subtitle' => __('<p class="subtitleription">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'sigma-theme'),
            'icon' => 'el el-paper-clip',
            // Leave this as a blank section, no options just some intro text set above.
            'fields' => array()
        );

        return $sections;
    }
}

/**
 * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
 * */
if (!function_exists('change_arguments')) {
    function change_arguments($args)
    {
        //$args['dev_mode'] = false;

        return $args;
    }
}

/**
 * Filter hook for filtering the default value of any given field. Very useful in development mode.
 * */
if (!function_exists('change_defaults')) {
    function change_defaults($defaults)
    {
        $defaults['str_replace'] = 'Testing filter hook!';

        return $defaults;
    }
}

/**
 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
 */
if (!function_exists('remove_demo')) {
    function remove_demo()
    {
        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
        if (class_exists('ReduxFrameworkPlugin')) {
            remove_filter('plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2);

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
        }
    }
}