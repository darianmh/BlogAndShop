<?php
namespace Elementor;

class Post_Thumbnail extends Widget_Base {
	
	public function get_name() {
		return 'post-thumbnail';
	}
	
	public function get_title() {
		return __( 'Single Thumbnail', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-featured-image';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Single Thumbnail', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'icons_align',
			[
				'label' => __( 'Thumbnail Alignment', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'plugin-domain' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'plugin-domain' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'plugin-domain' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .dgs_topbar_menuicons' => 'text-align: {{VALUE}};'
                ],				
			]
		);
		
        $this->end_controls_section();       
	}

    protected function render() {
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            $thumbnail = get_the_post_thumbnail_url($template->GetRelatedPostId());
            echo "<div class='post_thumb post_thumb_elementor'><img class='entry-thumbnail' src='".$thumbnail."'></div>";
        }
        else
        {
            echo "<div class='post_thumb'><img src='". get_template_directory_uri() ."/assets/img/no_thumbnail_sigma.jpg'></div>";
        }
    }
}