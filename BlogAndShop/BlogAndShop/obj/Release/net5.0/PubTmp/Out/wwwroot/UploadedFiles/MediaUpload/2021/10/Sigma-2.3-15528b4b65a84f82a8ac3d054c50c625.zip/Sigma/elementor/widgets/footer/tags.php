<?php
namespace Elementor;

class Footer_Sigma_Tag extends Widget_Base {
	
	public function get_name() {
		return 'footer-tag';
	}
	
	public function get_title() {
		return __( 'Sigma Tags', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-tags';
	}
	
	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Sigma Tags', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'tag_title',
			[
				'label' => __( 'Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'title products title', 'sigma-theme' ),
                'default' => __( 'Popular tags', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'sigma_tag_per_page',
			[
				'label'   => esc_html__( 'Tag Limit', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);

		$this->add_control(
			'tag_type',
			[
				'label'   => esc_html__( 'Tag Type', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'options'        => [
					'post_tag' => 'Post Tag',
					'product_tag' => 'Product Tag',
                ],
                'default' => 'post_tag',				
			]
		);

		$this->add_control(
			'course_style',
			[
				'label'     => esc_html__( 'Hide Empty Tag', 'sigma-theme' ),
				'type'      => Controls_Manager::CHOOSE,
				'options' => [
					'true' => [
						'title' => __( 'Yes', 'sigma-theme' ),
						'icon' => 'fa fa-pause-circle',
					],
					'false' => [
						'title' => __( 'No', 'sigma-theme' ),
						'icon' => 'fa fa-play-circle',
					],
				],
				'default' => 'no',
				'toggle' => true,
			]
		);
		
		$this->add_control(
			'tag_order',
			[
				'label'   => esc_html__( 'Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);	
		
		$this->end_controls_section();


        $this->start_controls_section(
        	'section_style',
        	[
				'label' => __( 'Sigma Tags', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_widget_edc' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title_widget_edc',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bottom_line_color',
				'label' => __( 'Bottom Line Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .title_widget_edc:after',
			]
		);

		$this->add_control(
			'tag_color',
			[
				'label' => __( 'Tag Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .edc_vertical_nav_footer ul li a' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tag_typography',
				'label' => __( 'Tag Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .edc_vertical_nav_footer ul li a',
			]
		);

		$this->add_control(
			'tag_dot_color',
			[
				'label' => __( 'Tag Dot Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .edc_vertical_nav_footer ul li a:before ' => 'background: {{VALUE}}',
				],			
				'default' => '#41d3e6'
			]
		);
				
		$this->end_controls_section();
	}

    public function render_tags() {
		$settings = $this->get_settings_for_display();
		$args = array(
        'number' => $settings['sigma_tag_per_page'],
        'order' => $settings['tag_order'],
        'hide_empty' => false, 
        'taxonomy'   => $settings['tag_type'],    
    );
    $tags = get_tags( $args );
    foreach ( $tags as $tag ) {
        $tag_link = get_tag_link( $tag->term_id );  
        $html = "<li><a href='{$tag_link}' title='{$tag->name}' class='{$tag->slug}'>";
        $html .= " {$tag->name} </a></li>";
        echo $html;
        }        
    }
    
	protected function render() {
		$settings = $this->get_settings_for_display();
        echo'<h3 class="title_widget_edc">'.$settings['tag_title'].'</h3><div class="edc_vertical_nav_footer"><ul>';
		$this->render_tags();
		echo'</ul></div>';
    }
}