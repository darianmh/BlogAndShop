<?php
namespace Elementor;

class Post_Comments extends Widget_Base {
	
	public function get_name() {
		return 'post-commnents';
	}
	
	public function get_title() {
		return  __( 'Post Comments', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-comments';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Post Comments', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'active_comments',
			[
				'label'   => esc_html__( 'Active Comment Box', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
        $this->end_controls_section();       
        
		
        $this->start_controls_section(
        	'style_section_style',
        	[
				'label' => __( 'Post Comments', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	
        
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} div#commentsarea',
				'condition' => [ 'active_comments' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} div#commentsarea',
                'condition' => [ 'active_comments' => 'yes', ],					
			]
		);
		
        $this->end_controls_section();       
        
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender() & comments_open())
        {
            if($settings['active_comments'] == 'yes'){
                echo '<div id="commentsarea">';
                comment_form_cd();
                echo '</div>';
            }
        }
        else
        {
            if($settings['active_comments'] == 'yes'){
            echo'<div id="commentsarea">
            <h4><i class="fa fa-comment"></i>'. __('User comments','sigma-theme') .'</h4>
            <div id="comments" class="comment-respond comment-respond-elementor">
            <form action="#" method="post" id="commentform" class="comment-form"><p class="comment-notes"><span id="email-notes">'. __('Your email address will not be published.','sigma-theme') .'</span>'. __('Required fields are marked','sigma-theme') .'<span class="required">*</span></p><p class="comment-form-comment"><label for="comment">دیدگاه</label> <textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required"></textarea></p><p class="comment-form-author"><label for="author">نام <span class="required">*</span></label> <input id="author" name="author" type="text" value="" size="30" maxlength="245" required="required"></p>
            <p class="comment-form-email"><label for="email">'. __('email','sigma-theme') .' <span class="required">*</span></label> <input id="email" name="email" type="text" value="" size="30" maxlength="100" aria-describedby="email-notes" required="required"></p>
            <p class="comment-form-url"><label for="url">'. __('website','sigma-theme') .'</label> <input id="url" name="url" type="text" value="" size="30" maxlength="200"></p>
            <p class="comment-form-cookies-consent"><input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"> <label for="wp-comment-cookies-consent">'. __('Save my name, email, and website in the browser for when I write a comment again.','sigma-theme') .'</label></p>
            <p class="form-submit"><input name="submit" type="submit" id="submit" class="submit" value="'. __('Send comment','sigma-theme') .'"> <input type="hidden" name="comment_post_ID" value="242" id="comment_post_ID">
            <input type="hidden" name="comment_parent" id="comment_parent" value="0">
            </p></form>	</div><!-- #respond -->
            	<div class="clear"></div>
            </div>';
            }
        }
    }
}