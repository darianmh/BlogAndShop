<?php
namespace Elementor;

class Main_Advanced_Search extends Widget_Base {
	
	public function get_name() {
		return 'advanced-search';
	}
	
	public function get_title() {
		return __( 'Advanced Search', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-site-search';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Advanced Search', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'select_advenced_search',
			[
				'label'   => esc_html__( 'Select Advanced Search Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_advanced_search',
				'options' => [
                    'style01_advanced_search' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_advanced_search' => esc_html__('Style 02', 'sigma-theme'),
                ],
			]
        );

		$this->add_control(
			'sigma_style01_advanced_search',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style01_advanced_search.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_advenced_search' => 'style01_advanced_search',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_style02_advanced_search',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style02_advanced_search.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_advenced_search' => 'style02_advanced_search',
                ],      				
			]
		);     
		
		
		$this->add_control(
			'advanced_search_description_active',
			[
				'label'   => esc_html__( 'Active Advanced Search Text', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'item_description',
			[
				'label' => __( 'Advanced Search Text', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __( '<h2> Search In <span class="product__number">[product_count]</span> Products And <span class="post__number"> [total_posts]</span> Tutorial Available On The Site.</h2>', 'sigma-theme' ),
				'placeholder' => __( 'Type your text Advanced Search Here', 'sigma-theme' ),
                'condition' => [
                    'advanced_search_description_active' => 'yes',
                ],  				
			]
		);
		
		$this->add_control(
			'select_type_search_text',
			[
				'label' => __( 'Select Type Search Text' , 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Select Type Search Text', 'sigma-theme' ),
                'default' => __( 'Search Type', 'sigma-theme' ),
                'condition' => [
                    'advanced_search_description_active' => 'yes',
                ],  			
            ]
		);
		
		$this->add_control(
			'select_cat_text',
			[
				'label' => __( 'Select Category Search Text' , 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Select Category Search Text', 'sigma-theme' ),
                'default' => __( 'Search Category', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'search_text_placeholder',
			[
				'label' => __( 'Search Text Placeholder' , 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Search Text Placeholder', 'sigma-theme' ),
                'default' => __( 'What Are You Looking For?', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'search_submit_text',
			[
				'label' => __( 'Search Submit Text' , 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Search Submit Text', 'sigma-theme' ),
                'default' => __( 'Search', 'sigma-theme' ),
			]
		);		

		$this->add_control(
			'active_type_search',
			[
				'label'   => esc_html__( 'Active type and category search', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'select_types_search',
			[
				'label'   => esc_html__( 'select search type', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
                    'all' => esc_html__('all', 'sigma-theme'),
                    'products' => esc_html__('products', 'sigma-theme'),
                    'posts' => esc_html__('posts', 'sigma-theme'),
                ],
                'condition' => [
                    'active_type_search' => 'yes',
                ],                    
			]
        );
        
		$this->end_controls_section();

		
        $this->start_controls_section(
        	'style_section_search_advanced',
        	[
				'label' => __( 'Advanced Search Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	

        $this->add_control(
        	'fss_select_search_color',
        	[
        		'label' => __( 'Search select search Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#999999',
        		'selectors' => [
        			'{{WRAPPER}} .fss_site_slide_seo #thf_ajax_search select' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],         
        	]
        );
        
        $this->add_control(
        	'dgs_color_fss_site_slide_button',
        	[
        		'label' => __( 'Search Submit Button Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .fss_site_slide_seo button' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],         
        	]
        );

        $this->add_control(
        	'search_title_color',
        	[
        		'label' => __( 'Search Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#7777',
        		'selectors' => [
        			'{{WRAPPER}} .fss_site_slide_seo h2 , .searchbar__v4__elementor h2' => 'color: {{VALUE}}',
        		],		
        	]
        );

        $this->add_control(
        	'search_title_number_color',
        	[
        		'label' => __( 'Search Title Number Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#35c39f',
        		'selectors' => [
        			'{{WRAPPER}} .fss_site_slide_seo h2 span , .searchbar__v4__elementor h2 span' => 'color: {{VALUE}}',
        		],		
        	]
        );
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_down_products',
        		'label' => _x( 'Search Submit Button Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .fss_site_slide_seo button',
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],      		
        	]
        );
       
        $this->add_control(
        	'dgs_color_icon_atuor_date',
        	[
        		'label' => __( 'Select Type Category Search Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#888888',
        		'selectors' => [
        			'{{WRAPPER}} .fss_site_slide_seo form select' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],         
        	]
        );
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'search_background_form',
        		'label' => _x( 'Search Form Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .fss_site_slide_seo form',
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],      		
        	]
        );

        $this->add_control(
        	'dgs_color_fss_site_slide_seo',
        	[
        		'label' => __( 'Search Input Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#B3B3B3',
        		'selectors' => [
        			'{{WRAPPER}} .fss_site_slide_seo form input::placeholder' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],         
        	]
        );
        
        
        $this->add_group_control(
              Group_Control_Border::get_type(),
              [
                'name' => 'border',
                'label' => __( 'Border Search Box', 'sigma-theme' ),
                'selector' => '{{WRAPPER}} .search_input',
                        'condition' => [
                            'sigma_select_search' => 'style02_advanced_search',
                        ],                
              ]
        );

        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'search_background_submit',
        		'label' => _x( 'Search submit Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .fss_site_slide_seo input#thf_btn',
        		'condition' => [
        			'select_advenced_search' => 'style02_advanced_search',
        		],      		
        	]
        );
        
        
        $this->add_group_control(
              Group_Control_Border::get_type(),
              [
                'name' => 'border_input_search',
                'label' => __( 'Search Input Border', 'sigma-theme' ),
                'selector' => '{{WRAPPER}} .input_search',
                        'condition' => [
                            'select_advenced_search' => 'style01_advanced_search',
                        ],                
              ]
        );
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_box_search_submit_home',
        		'label' => _x( 'Category Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} form.form__holder_v3',
        		'condition' => [
        			'select_advenced_search' => 'style01_advanced_search',
        		],      		
        	]
        );   
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_input_search_submit_home',
        		'label' => __( 'Search Submit Background Color ', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} input.search-submit-home',
        		'condition' => [
        			'select_advenced_search' => 'style01_advanced_search',
        		],      		
        	]
        );    
        
        
        $this->add_control(
        	'dgs_color_thf_ajax_search',
        	[
        		'label' => __( 'Selector Search Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#999999',
        		'selectors' => [
        			'{{WRAPPER}} #thf_ajax_search select, #thf_ajax_search input[type="search"]' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'select_advenced_search' => 'style01_advanced_search',
        		],         
        	]
        );

        $this->add_control(
        	'dgs_color_search_submit_home',
        	[
        		'label' => __( 'Text Search Submit Home Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} input.search-submit-home' => 'color: {{VALUE}}',
        		],		
        		'condition' => [
        			'select_advenced_search' => 'style01_advanced_search',
        		],         
        	]
        );
        
        
        $this->add_group_control(
              Group_Control_Border::get_type(),
              [
                'name' => 'border_search_submit_home',
                'label' => __( 'Border', 'sigma-theme' ),
                'selector' => '{{WRAPPER}} input.search-submit-home',
                        'condition' => [
                            'select_advenced_search' => 'style01_advanced_search',
                        ],                
              ]
        );

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['select_advenced_search'] == 'style01_advanced_search' && !empty($settings['select_advenced_search'])){    
        echo '<div class="advansed_searcharea"><div class="searchbar__v4__elementor">' ?>
        <?php if($settings['advanced_search_description_active'] == 'yes'){    
            echo $settings['item_description'];
        }
        ?>
        <?php echo '<form class="form__holder_v3" id="thf_ajax_search">
            <div class="input_search row">' ?>
               <?php echo'<ul class="row">
                    <li class="col-lg-5">
                        <div class="row h-100">
                            <div class="col-sm-6 nopadding">'?>
                                <select name="post_type" id="thf_type">
                                    <option value="" disabled hidden ><?php _e('Search type', 'sigma-theme'); ?></option>
                                    <?php if ($settings['select_types_search'] == 'all') { ?>
                                        <option value="all"><?php _e('all', 'sigma-theme'); ?></option>
                                        <option value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                        <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                    <?php } ?>
                                    <?php if ($settings['select_types_search'] == 'posts') { ?>
                                        <option selected value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                    <?php } ?>
                                    <?php if ($settings['select_types_search'] == 'products') { ?>
                                        <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                    <?php } ?>
                                </select>
                            <?php echo'</div>
                            <div class="col-sm-6 nopadding">
                                <select name="cat" id="thf_cat">
                                    <option value="" disabled hidden selected>'.$settings['select_cat_text'].'</option>' ?>
    								<?php $cats = thf_get_cats(); ?>
    								<?php foreach ( $cats as $cat ): ?>
                                        <option value="<?= $cat->cat_ID ?>"><?= $cat->name ?></option>
    								<?php endforeach; ?>
                            <?php echo'</select>
                            </div>
                        </div>
                    </li>
                    <li class="col-lg-5 nopadding">
                        <input type="search" value="" name="s" id="thf_input" placeholder="'.$settings['search_text_placeholder'].'" autocomplete="off" required>
                    </li>
                    <li class="col-lg-2">
                        <input type="button" class="search-submit-home" id="thf_btn" value="'.$settings['search_submit_text'].'">
                    </li>
                </ul>
            </div>
            <div id="thf_result" class="mt-4">
            </div>
        </form>
        ';
		}
		if($settings['select_advenced_search'] == 'style02_advanced_search' ){ 
		    echo'<div class="fss_site_slide_seo">' ?>
            <?php if($settings['advanced_search_description_active'] == 'yes'){    
                echo $settings['item_description'];
            } ?>
            <?php echo'<form class="form__holder_v3" id="thf_ajax_search">
            <div class="input_search row">' ?>
               <?php echo'<ul class="row">
                    <li class="col-lg-5">
                        <div class="row h-100">
                            <div class="col-sm-6 nopadding">'?>
                                <select name="post_type" id="thf_type">
                                    <option value="" disabled hidden ><?php _e('Search type', 'sigma-theme'); ?></option>
                                    <?php if ($settings['select_types_search'] == 'all') { ?>
                                        <option value="all"><?php _e('all', 'sigma-theme'); ?></option>
                                        <option value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                        <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                    <?php } ?>
                                    <?php if ($settings['select_types_search'] == 'posts') { ?>
                                        <option selected value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                    <?php } ?>
                                    <?php if ($settings['select_types_search'] == 'products') { ?>
                                        <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                    <?php } ?>
                                </select>
                            <?php echo'</div>
                            <div class="col-sm-6 nopadding">
                                <select name="cat" id="thf_cat">
                                    <option value="" disabled hidden selected>'.$settings['select_cat_text'].'</option>' ?>
    								<?php $cats = thf_get_cats(); ?>
    								<?php foreach ( $cats as $cat ): ?>
                                        <option value="<?= $cat->cat_ID ?>"><?= $cat->name ?></option>
    								<?php endforeach; ?>
                            <?php echo'</select>
                            </div>
                        </div>
                    </li>
                    <li class="col-lg-5 nopadding">
                        <input type="search" value="" name="s" id="thf_input" placeholder="'.$settings['search_text_placeholder'].'" autocomplete="off" required>
                    </li>
                    <li class="col-lg-2">
                        <input type="button" class="search-submit-home" id="thf_btn" value="'.$settings['search_submit_text'].'">
                    </li>
                </ul>
            </div>
            <div id="thf_result" class="mt-4">
            </div>
        </form></div>';
		}    
	}
}