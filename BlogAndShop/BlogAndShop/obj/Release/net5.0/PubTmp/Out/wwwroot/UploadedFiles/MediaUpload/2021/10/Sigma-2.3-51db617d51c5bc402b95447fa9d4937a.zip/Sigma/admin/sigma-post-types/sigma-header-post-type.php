<?php
add_action( 'init', 'sigma_theme_register_header_post_type' );
function sigma_theme_register_header_post_type() {
    $labels = array(
        'name'               => __( 'sigma header', 'sigma-theme' ),
        'singular_name'      => __( 'sigma header', 'sigma-theme' ),
        'menu_name'          => __( 'sigma headers', 'sigma-theme' ),
        'name_admin_bar'     => __( 'sigma header', 'sigma-theme' ),
        'add_new'            => __( 'Add New', 'sigma-theme' ),
        'add_new_item'       => __( 'Add New header', 'sigma-theme' ),
        'new_item'           => __( 'New header', 'sigma-theme' ),
        'edit_item'          => __( 'Edit header', 'sigma-theme' ),
        'view_item'          => __( 'View header', 'sigma-theme' ),
        'all_items'          => __( 'All headers', 'sigma-theme' ),
        'search_items'       => __( 'Search headers', 'sigma-theme' ),
        'parent_item_colon'  => __( 'Parent headers:', 'sigma-theme' ),
        'not_found'          => __( 'No headers found.', 'sigma-theme' ),
        'not_found_in_trash' => __( 'No headers found in Trash.', 'sigma-theme' )
    );
    $args = array(
        'labels'             => $labels,
        'description'        => __( 'sigma header builder', 'sigma-theme' ),
        'supports'           => array( 'title', 'editor'),
        'public'            => true,
        'has_archive'       => false,
        'show_in_nav_menus' => false,
        'menu_icon'         => 'dashicons-admin-post'
    );
    register_post_type( 'sigma-header', $args );
}