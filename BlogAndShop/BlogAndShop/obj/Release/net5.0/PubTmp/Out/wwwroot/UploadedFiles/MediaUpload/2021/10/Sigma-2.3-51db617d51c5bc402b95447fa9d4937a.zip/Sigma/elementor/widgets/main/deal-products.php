<?php
namespace Elementor;

class Deal_Poroducts_Widget  extends Widget_Base  {
	
	public function get_name() {
		return 'deal-products';
	}
	
	public function get_title() {
		return __( 'deal products', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-product-related';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

    function get_product_cat(){
        $terms = get_terms( array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }
 
    function get_product_tag(){
        $terms = get_terms( array(
            'taxonomy' => 'product_tag',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }    
	protected function _register_controls() {

		$this->start_controls_section(
			'deal_products_select_styles',
			[
				'label' => __( 'deal products', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'deal_products_list_styles',
			[
				'label'   => esc_html__( 'Select deal products Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_deal_products',
				'options' => [
                    'style01_deal_products' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_deal_products' => esc_html__('Style 02', 'sigma-theme'),
                ],
			]
        );


		$this->add_control(
			'deal_products_list_styles01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style01_deal_products.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'deal_products_list_styles' => 'style01_deal_products',
                ],      				
			]
		);        

		$this->add_control(
			'deal_products_list_styles02',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/style02_deal_products.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'deal_products_list_styles' => 'style02_deal_products',
                ],      				
			]
		);        

		$this->add_control(
			'active_deal_carousel',
			[
				'label'     => esc_html__( 'active deal carousel', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value'	=> 'yes',
			]
		);

		$this->add_control(
			'active_deal_box',
			[
				'label'     => esc_html__( 'active deal box', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value'	=> 'yes',
			]
		);
		
		$this->add_control(
			'deal_products_title',
			[
				'label' => __( 'title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'enter Special Porducts title', 'sigma-theme' ),
                'default' => __( 'Special Porducts', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'deal_products_en_title',
			[
				'label' => __( 'english title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'english title products deal', 'sigma-theme' ),
                'default' => __( 'Special Products', 'sigma-theme' ),
			]
		);		
		
		$this->add_control(
			'deal_products_offer_text',
			[
				'label' => __( 'offer text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'enter offer text', 'sigma-theme' ),
                'default' => __( 'Until 90% Off', 'sigma-theme' ),
                'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],                
			]
		);	

		$this->add_control(
			'deal_products_button_text',
			[
				'label' => __( 'more products button text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'enter more products button text', 'sigma-theme' ),
                'default' => __( 'View all discounts', 'sigma-theme' ),
                'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ]            
			]
		);	

		$this->add_control(
			'deal_products_button_link',
			[
				'label' => __( 'more products button link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'enter more products button link', 'sigma-theme' ),
				'default' => [
					'url' => get_site_url() . '/shop',
				],
                'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ]
			]
		);
		
		$this->add_responsive_control(
			'sigma_columns',
			[
				'label'          => esc_html__( 'Columns', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
                'default' => '4',
				'condition' => [
					'active_deal_carousel' => ['no'],
					'deal_products_list_styles' => ['style01_deal_products']
				]                
			]
		);		
		
		$this->add_control(
			'sigma_posts_per_page',
			[
				'label'   => esc_html__( 'Product Limit', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);
		
		$this->add_control(
			'sigma_orderby',
			[
				'label'   => esc_html__( 'Order by', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'     => esc_html__( 'Date', 'sigma-theme' ),
					'title'    => esc_html__( 'Title', 'sigma-theme' ),
					'category' => esc_html__( 'Category', 'sigma-theme' ),
					'rand'     => esc_html__( 'Random', 'sigma-theme' ),
					'total_sales'     => esc_html__( 'Sale', 'sigma-theme' ),
				],
			]
		);

		$this->add_control(
			'sigma_order',
			[
				'label'   => esc_html__( 'Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);		

		$this->add_control(
			'sigma_woo_product_select',
			[
				'label'   => esc_html__( 'Show product by ', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'category',
				'options' => [
                    'category' => esc_html__('Category', 'sigma-theme'),
                    'product' => esc_html__('Product', 'sigma-theme'),
                    'tag' => esc_html__('Tag', 'sigma-theme'),
                ],
			]
        );
        
		$this->add_control(
			'sigma_woo_cat',
			[
				'label'   => esc_html__( 'Category', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_cat(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'category',
                ],
			]
        );

		$this->add_control(
			'sigma_woo_tag',
			[
				'label'   => esc_html__( 'tag', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_tag(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'tag',
                ],
			]
        );        
		$this->add_control(
			'sigma_open_thumb_in_popup',
			[
				'label'     => esc_html__( 'Open Thumb in Popup', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
                'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],				
			]
		);

		$this->add_control(
			'sigma_show_badge',
			[
				'label'     => esc_html__( 'Show Badge', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
                'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],				
			]
		);

		$this->add_control(
			'sigma_show_title',
			[
				'label'   => esc_html__( 'Title', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_categories',
			[
				'label'     => esc_html__( 'Categories', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
                'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);

		$this->add_control(
			'sigma_show_price',
			[
				'label'   => esc_html__( 'Price', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],                
				
			]
		);

		$this->add_control(
			'sigma_show_cart',
			[
				'label'   => esc_html__( 'Add to Cart', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sigma_show_readmore',
			[
				'label'   => esc_html__( 'more bottom', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],                
			]
		);

        /**
		$this->add_control(
			'sigma_show_countdown',
			[
				'label'   => esc_html__( 'countdown', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],                
			]
		);
        */
        
		$this->add_control(
			'sigma_show_wishlist',
			[
				'label'   => esc_html__( 'wishlist', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],                
			]
		);
		
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'sigma_image',
				'label'     => esc_html__( 'Image Size', 'sigma-theme' ),
				'exclude'   => [ 'custom' ],
				'default'   => 'medium',
			]
		);
		
		$this->end_controls_section();	

		$this->start_controls_section(
			'deal_setting',
			[
				'label' => __( 'deal carousel Setting', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        		'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);
		
		$this->add_control(
			'deal_coulmns_deal_desktop',
			[
				'label'   => esc_html__( 'deal carousel Coulmns desktop', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min' => 1,
				'max' => 6,
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);		

		$this->add_control(
			'deal_coulmns_deal_tablet',
			[
				'label'   => esc_html__( 'deal carousel Coulmns tablet', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 2,
				'min' => 1,
				'max' => 4,
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);	

		$this->add_control(
			'deal_coulmns_deal_mobile',
			[
				'label'   => esc_html__( 'deal carousel Coulmns mobile', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
				'min' => 1,
				'max' => 8,
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);	
		
		$this->add_control(
			'active_nav_deal',
			[
				'label'   => esc_html__( 'Active Nav deal carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);

		$this->add_control(
			'active_dots_deal',
			[
				'label'   => esc_html__( 'Active dots deal carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);

		$this->add_control( 
			'active_autoplay_deal',
			[
				'label'   => esc_html__( 'Active autoplay deal carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);

		$this->add_control(
			'active_autoplay_speed_deal',
			[
				'label'   => esc_html__( 'autoplay speed deal carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 5000,
				'min' => 1,
				'max' => 20000,
				'condition' => [
					'active_deal_carousel' => ['yes'],
					'active_autoplay_deal' => ['yes']
				]				
			]
		);	
		
		$this->add_control( 
			'active_loop_deal',
			[
				'label'   => esc_html__( 'Active loop deal carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [ 'active_deal_carousel' => 'yes', ],
			]
		);

		
		$this->end_controls_section();	
		
		
		$this->start_controls_section(
			'grid_products_style_section',
			[
				'label' => __( 'Deal Products Settings', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);

        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_specials_products',
        		'label' => _x( 'Deal Products Area Backgroud Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .fss_specials_products',
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ],      		
        	]
        );		

        $this->add_control(
        	'dgs_color_fss_specials_products_title',
        	[
        		'label' => __( 'Deal Product Area Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#a58506',
        		'selectors' => [
        			'{{WRAPPER}} .fss_specials_products_title h3' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ],         
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_type_fss_specials_products_title',
				'label' => __( 'Deal Product Area Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .fss_specials_products_title h3',
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ], 
            ]
		);	


		$this->add_control(
        	'dgs_special_icon_color_top',
        	[
        		'label' => __( 'Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#dcb10d',
        		'selectors' => [
        			'{{WRAPPER}} .fss_specials_products_title:after' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ],         
        	]
        );
        
		$this->add_control(
			'dgs_special_icon_size_top',
			[
				'label' => __( 'Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 100,
				],
				'range' => [	
					'px' => [
						'min'  => 50,
						'max'  => 200,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_title:after ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'deal_products_list_styles' => 'style02_deal_products',
        		],    
			]
		);
		
        $this->add_control(
        	'dgs_color_fss_specials_products_title_small',
        	[
        		'label' => __( 'Deal Product Area English Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .fss_specials_products_title small' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ],         
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dgs_type_fss_specials_products_entitle',
				'label' => __( 'Deal Product Area English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .fss_specials_products_title small ',
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ], 
            ]
		);	
		
		$this->end_controls_section();		



		$this->start_controls_section(
			'single_products_style_section',
			[
				'label' => __( 'Deal Products Right Side', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);
        
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_specials_prodcust_nav',
        		'label' => _x( 'Color Background Specials Prodcust Nav', 'sigma-theme' ),
        		'types' => ['gradient'],
        		'selector' => '{{WRAPPER}} .dgs_specials_prodcust_nav',
                        'condition' => [
                            'deal_products_list_styles' => 'style01_deal_products',
                        ],      		
        	]
        );


        $this->add_control(
        	'dgs_color_specials_prodcust_nav_h3',
        	[
        		'label' => __( 'Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .dgs_specials_prodcust_nav h3' => 'color: {{VALUE}}',
        		],		
                'condition' => [
                    'deal_products_list_styles' => 'style01_deal_products',
                ],         
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Main Menu item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-main-menu ul li a',
				'condition' => [ 'sigma_select_products_lists_style' => 'style01_products_lists', ],
			]
		);	

        $this->add_control(
        	'dgs_color_specials_prodcust_nav_small',
        	[
        		'label' => __( 'English Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .dgs_specials_prodcust_nav small' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style01_deal_products',
                        ],         
        	]
        );

        $this->add_control(
        	'dgs_color_specials_prodcust_nav_area',
        	[
        		'label' => __( 'Off Text Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .dgs_specials_price_area' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style01_deal_products',
                        ],         
        	]
        );

        $this->add_control(
        	'dgs_color_specials_prodcust_nav',
        	[
        		'label' => __( 'Button ColorButton Background Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#5f5cc1',
        		'selectors' => [
        			'{{WRAPPER}} .dgs_special_more_products' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style01_deal_products',
                        ],         
        	]
        );
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_specials_prodcust',
        		'label' => _x( 'Button Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .dgs_special_more_products',
                        'condition' => [
                            'deal_products_list_styles' => 'style01_deal_products',
                        ],      		
        	]
        );

        $this->end_controls_section();       

        $this->start_controls_section(
        	'image_style',
        	[
				'label' => __( 'Zoom', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
        	]
        );	 

		$this->add_control(
			'zoom_icon_color',
			[
				'label' => __( 'Zoom Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-popop--link' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);        

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'zoom_icon_bg',
				'label' => __( 'Zoom Iocn Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .sigma-wc-product-popop--link',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);

		$this->add_control(
			'zoom_icon_size',
			[
				'label' => __( 'Zoom Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-popop--link ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();

		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Sale Badge', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
        	]
        );	 

		$this->add_control(
			'sale_badge_color',
			[
				'label' => __( 'Sale Badge Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .filedemo_gird_products_warp span.onsale, .modern_gird_products_warp span.onsale, .products_index_plus span.onsale ' => 'color: {{VALUE}}',
				],	
				'default' => '#ffffff',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sale_badge_background',
				'label' => __( 'Sale Badge Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp .sigma-wc-products-badge span.onsale , .filedemo_gird_products_warp span.onsale, .modern_gird_products_warp span.onsale, .products_index_plus span.onsale',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sale_badge_typography',
				'label' => __( 'Badge Sale Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp .sigma-wc-products-badge span.onsale , .filedemo_gird_products_warp span.onsale, .modern_gird_products_warp span.onsale, .products_index_plus span.onsale ',
			]
		);	
		
        $this->end_controls_section();               


        $this->start_controls_section(
        	'title_style_setting',
        	[
				'label' => __( 'Title Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	

	
		$this->add_control(
			'gp_title_s1_color',
			[
				'label' => __( 'Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_gird_products_warp h2' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
				'default' => '#444444'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_title_s1_type',
				'label' => __( 'Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp h2',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);	

		$this->add_control(
			'gp_entitle_s1_color',
			[
				'label' => __( 'English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_gird_products_warp small' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
				'default' => '#999999'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_entitle_s1_type',
				'label' => __( 'English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_gird_products_warp small',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);	

//style 02

        $this->add_control(
        	'products_title_s2_color',
        	[
				'label' => __( 'Persian Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .fss_specials_products_area h2' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ],         
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'products_title_s2_type',
				'label' => __( 'Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_area h2',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);	
		
        $this->add_control(
        	'products_entitle_s2_color',
        	[
				'label' => __( 'English Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#c39c0c',
        		'selectors' => [
        			'{{WRAPPER}} .fss_specials_products_area small' => 'color: {{VALUE}}',
        		],		
                        'condition' => [
                            'deal_products_list_styles' => 'style02_deal_products',
                        ],         
        	]
        );		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'products_entitle_s2_type',
				'label' => __( 'English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_area small',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);	
		
        $this->end_controls_section();       


		
        $this->start_controls_section(
        	'price_box_s1',
        	[
				'label' => __( 'Price Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
// price style 02

		$this->add_control(
			'price_regular_s2_color',
			[
				'label' => __( 'Regular Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_price ins' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
				'default' => '#9c7e0c'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_regular_s2_type',
				'label' => __( 'Regular Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_price ins',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);	
		

		$this->add_control(
			'price_sale_s2_color',
			[
				'label' => __( 'Sale Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}}  .fss_specials_products_price del , .fss_specials_products_price del:after' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
				'default' => '#a08618'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_sale_s2_type',
				'label' => __( 'Sale Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_price del',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
        );	


// price style 01

		$this->add_control(
			'price_regular_s1_color',
			[
				'label' => __( 'Regular Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-price p ins' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
				'default' => '#f45b66'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_regular_s1_type',
				'label' => __( 'Regular Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-price p ins',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
		);	
		

		$this->add_control(
			'price_sale_s1_color',
			[
				'label' => __( 'Sale Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-price del span' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
				'default' => '#555555'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_sale_s1_type',
				'label' => __( 'Sale Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-price del span',
				'condition' => [ 'deal_products_list_styles' => 'style01_deal_products', ],
			]
        );	
        
		
        $this->end_controls_section();

        $this->start_controls_section(
        	'product_meta_s1',
        	[
				'label' => __( 'Product Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );
//meta s2

		$this->add_control(
			'wishlish_icon_size',
			[
				'label' => __( 'Wishlist Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 17,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_love a i' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
        		],    
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'wishlist_icon_bg',
				'label' => __( 'Wishlist Icon Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ], 
				'selector' => '{{WRAPPER}}  .fss_specials_products_love a',
			]
		);
		
		$this->add_control(
			'wish_icon_color',
			[
				'label' => __( 'Wishlist Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_love a i ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ],   	
				'default' => '#888888'
			]
		);		

		$this->add_control(
			'go_product_color_s2',
			[
				'label' => __( 'Go Product Page Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_more a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ],   	
				'default' => '#888888'
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'go_product_bg_s2',
				'label' => __( 'Go Product Page Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ], 
				'selector' => '{{WRAPPER}} .fss_specials_products_more a ',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'go_product_type_s2',
				'label' => __( 'Go Product Page Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_more a',
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ], 			
            ]
		);	

		$this->add_control(
			'go_product_icon_size_s2',
			[
				'label' => __( 'Go Product Page Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_more a i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
        		],    
			]
		);
		
		$this->add_control(
			'go_product_icon_color_s2',
			[
				'label' => __( 'Go Product Page Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_more a i ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ],   	
				'default' => '#888888'
			]
		);        
        		
//meta s1

		$this->add_control(
			'cat_s2_color',
			[
				'label' => __( 'Product Category Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-product-categories ul li a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => ['style01_deal_products' ],
                ],   	
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cat_s2_bg',
				'label' => __( 'Product Category Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'deal_products_list_styles' => ['style01_deal_products' ],
                ], 
				'selector' => '{{WRAPPER}} .sigma-wc-product-categories ul li a ',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_s2_typography',
				'label' => __( 'Product Category typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-product-categories ul li a ',
				'condition' => [
        			'deal_products_list_styles' => ['style01_deal_products' ],
                ], 			]
		);	

        $this->end_controls_section();       


        $this->start_controls_section(
        	'add_cart_style',
        	[
				'label' => __( 'Add To Cart', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	
        
//style 02

		$this->add_control(
			'addcart_color_s2',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_basket a' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ],   	
				'default' => '#888888'
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'addcart_bg_s2',
				'label' => __( 'Add To Cart Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ], 
				'selector' => '{{WRAPPER}} .fss_specials_products_basket a ',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'addcart_type_s2',
				'label' => __( 'Add To Cart Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_basket a',
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ], 			
            ]
		);	

		$this->add_control(
			'addcart_icon_size_s2',
			[
				'label' => __( 'Add To Cart Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_basket a i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
        		],    
			]
		);
		
		$this->add_control(
			'addcart_icon_color_s2',
			[
				'label' => __( 'Add To Cart Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_basket a i ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => ['style02_deal_products' ],
                ],   	
				'default' => '#888888'
			]
		);      

//style 01

		$this->add_control(
			'add_cart_color_s1',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sigma-wc-add-to-cart a ' => 'color: {{VALUE}}',
				],			
				'condition' => [
        			'deal_products_list_styles' => 'style01_deal_products',
                ],   	
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'add_cart_s1_typography',
				'label' => __( 'Add To Cart typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-wc-add-to-cart a',
				'condition' => [
        			'deal_products_list_styles' => 'style01_deal_products',
                ], 
            ]
		);			
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'add_cart_bg_s1',
				'label' => __( 'Add To Cart Background Color', 'sigma-theme' ),
				'types' => [ 'gradient' ],
				'condition' => [
        			'deal_products_list_styles' => 'style01_deal_products',
                ], 
				'selector' => '{{WRAPPER}} .sigma-wc-add-to-cart a ',
			]
		);        
        		
        $this->end_controls_section();       
		
       $this->start_controls_section(
        	'description_product',
        	[
				'label' => __( 'Description', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
            ]
        );	 

		$this->add_control(
			'des_height_s4',
			[
				'label' => __( 'Description Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 120,
				],
				'range' => [
					'px' => [
						'min'  => 50,
						'max'  => 250,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_desc ' => 'height:{{SIZE}}px',
				],
                'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);
		
		$this->add_control(
			'des_color_s4',
			[
				'label' => __( 'Description Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_desc p ' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
                'default' => '#ffffff'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'des_s4_typography',
				'label' => __( 'Description typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_desc p',
                'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);	
		
        $this->end_controls_section();
        
		
        $this->start_controls_section(
        	'Countdown_style_section',
        	[
				'label' => __( 'Countdown', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
        	]
        );	 

		$this->add_control(
			'color_part_countdown',
			[
				'label' => __( 'Countdown Parts Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_countdown_past p' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
				'default' => '#dcb00d'
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_part_countdown',
				'label' => __( 'Countdown Parts Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
				'selector' => '{{WRAPPER}} .fss_countdown_past p ',
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'part_countdown_typography',
				'label' => __( 'Countdown Parts Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_countdown_past p',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);	

		$this->add_control(
			'countdown_label_color',
			[
				'label' => __( 'Countdown Parts Label Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_countdown_past span ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'countdown_label_typography',
				'label' => __( 'Countdown Parts Label Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_countdown_past span ',
				'condition' => [ 'deal_products_list_styles' => 'style02_deal_products', ],
			]
		);	

        $this->end_controls_section();       
        
	}
	
    protected function render(){
		$settings = $this->get_settings();
		if($settings['active_deal_box'] == 'yes'){
		    echo'<div class="have_dealbox">';
		}
		else {
		    echo'<div class="no_dealbox">';
		}
        if($settings['deal_products_list_styles'] == 'style01_deal_products' && !empty($settings['deal_products_list_styles'])){    
        echo '<div class="'?><?php if($settings['active_deal_carousel'] == 'yes'){ echo'yes-carousel'; } else { echo'no-carousel'; } ?> <?php echo'dgs_products_area_deal darkeble">'?>
        <?php
        if($settings['active_deal_box'] == 'yes'){ ?>
        <?php echo'<div class="dgs_specials_products_warp"> <div class="dgs_specials_prodcust_nav"> <h3>'.$settings['deal_products_title'].'</h3> <small>'.$settings['deal_products_en_title'].'</small> <div class="dgs_specials_price_area">'.$settings['deal_products_offer_text'].'</div> <a href="'.$settings['deal_products_button_link']['url'].'" class="dgs_special_more_products">'.$settings['deal_products_button_text'].'</a> </div> </div>';       }
		$this->render_loop_item();
        echo '</div>';
        }
        if($settings['deal_products_list_styles'] == 'style02_deal_products'){    
        echo '<div class="fss_specials_products darkeble"><div class="container"> <div class="row">';    
        echo '<div class="fss_specials_products_title"> <h3>'.$settings['deal_products_title'].'</h3> <small>'.$settings['deal_products_en_title'].'</small> </div>';
		$this->render_loop_item();
        echo '</div></div></div>';
        }        
		if($settings['active_deal_box'] == 'yes'){
		    echo'</div>';
		}
		else {
		    echo'</div>';
		}        
    }

    public function render_image() {
		$settings = $this->get_settings();
		?>
		<?php
        if($settings['deal_products_list_styles'] == 'style01_deal_products' && !empty($settings['deal_products_list_styles'])){    
		?>
		<div class="sigma-wc-product-image sigma-background-cover">
			<!-- popup content -->
			<?php if($settings['sigma_open_thumb_in_popup'] === 'yes') :
				$popupHorizontal_align = !empty($settings['sigma_popup_alignment']) ? ' popup-' . esc_attr( $settings['sigma_popup_alignment'] ) : '';	
				$popupVertical_align = !empty($settings['sigma_popup_vertical_alignment']) ? ' popup-vertical-' . esc_attr( $settings['sigma_popup_vertical_alignment'] ) : '';
			?>
				<div class="sigma-wc-product-popop <?php echo esc_attr( $popupHorizontal_align ); ?> <?php echo esc_attr( $popupVertical_align ); ?>">
            <div class="sigma-fast-preview" data-product-id="<?php echo get_the_ID() ?>"><a class="sigma-wc-product-popop--link"><i class="fa fa-eye" aria-hidden="true"></i></a></div>
				</div>
			<?php endif; ?>

			<!-- badge content -->
			<?php if ('yes' == $settings['sigma_show_badge']) : 
				$horizontal_align = !empty($settings['ekti_badge_alignment']) ? ' badge-' . esc_attr( $settings['ekti_badge_alignment'] ) : '';	
				$vertical_align = !empty($settings['ekti_badge_vertical_alignment']) ? ' badge-vertical-' . esc_attr( $settings['ekti_badge_vertical_alignment'] ) : '';	
			?>
				<div class="sigma-wc-products-badge <?php echo esc_attr( $horizontal_align ); ?> <?php echo esc_attr( $vertical_align ); ?>">
					<?php woocommerce_show_product_loop_sale_flash(); ?>
				</div>
			<?php endif; ?>

			<!-- Thumb content -->
			<a class="sigma_woo_product_img_link" href="<?php the_permalink(); ?>">
				<img alt="<?php the_title(); ?>" src="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(), $settings['sigma_image_size']); ?>" width="300" height="300">
			</a>

			<!-- Add to cart button -->
			<?php if ('yes' == $settings['sigma_show_cart']) :
				// new icon
				$migrated = isset( $settings['__fa4_migrated']['sigma_tab_cart_icons'] );
				$is_new = empty( $settings['sigma_tab_cart_icon'] );

			?>
				<div class="sigma-wc-add-to-cart">
					<?php woocommerce_template_loop_add_to_cart([
						'class button product_type_simple add_to_cart_button ajax_add_to_cart'
					]);?>

				</div>
			<?php endif; ?>
		</div>
		
		<?php
        }
        if($settings['deal_products_list_styles'] == 'style02_deal_products'){
        echo '<div class="col-md-3 col-xs-12 fss_sgm_deal_product_img">
                    <a href="'.get_the_permalink().'"><img src="'.wp_get_attachment_image_url(get_post_thumbnail_id(), $settings['sigma_image_size']).'"></a>
                </div>';
        }   
	}

	public function render_description() {
		$settings = $this->get_settings();
		global $product;
		?>
		<?php
        if($settings['deal_products_list_styles'] == 'style01_deal_products' && !empty($settings['deal_products_list_styles'])){    
        ?>
			<div class="sigma-wc-product-desc">
				<div class="sigma-wc-product-desc-inner">
					<!-- categories -->
					<?php 
						if($settings['sigma_show_categories'] === 'yes'){
							$terms = get_the_terms( get_the_ID(), 'product_cat' );
							$terms_count = count($terms);

							if($terms_count > 0){
								echo "<div class='sigma-wc-product-categories'><ul>";
								foreach($terms as $key => $term){
									$sperator = $key !== ($terms_count -1) ? '' : '';
									echo "<li><a href='". get_term_link($term->term_id) ."'>". esc_html( $term->name ) . $sperator . "</a></li>";
								}
								echo "</ul></div>";
							}
						}
					?>
					<!-- end categories -->
					<?php if ( 'yes' == $settings['sigma_show_title']) : ?>
					    <div class="dgs_gird_products_title">
						<a href="<?php the_permalink(); ?>" class="sigma-link-reset">
							<h2 class="sigma-wc-product-title">
								<?php the_title(); ?>
							</h2>
							<small><?php echo ( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ); ?></small>
						</a>
						</div>
					<?php endif; ?>

							<div class="sigma-wc-rating">

								<?php 
									if($product->get_rating_count() > 0){
										woocommerce_template_loop_rating();
									} else {
										$rating_html  = '<div class="star-rating">';
										$rating_html .= wc_get_star_rating_html( 0, 0 );
										$rating_html .= '</div>';

										//echo \sigma-theme\Utils::render($rating_html);
									}
								?>
							</div>

					<?php if (('yes' == $settings['sigma_show_price'])) : ?>
						<?php if ( 'yes' == $settings['sigma_show_price']) : ?>
							<div class="sigma-wc-product-price">
								<?php woocommerce_template_single_price(); ?>
							</div>
						<?php endif; ?>
							

					<?php endif; ?>
				</div>
			</div>
		<?php
        }
        if($settings['deal_products_list_styles'] == 'style02_deal_products'){
            echo '<div class="col-md-9 col-sx-12 fss_sgm_deal_product">
                    <div class="fss_specials_products_area">' ?>
					<?php if ( 'yes' == $settings['sigma_show_title']) : ?>
						<a href="<?php the_permalink(); ?>"><h2><?php the_title(); ?></h2>
                        <small><?php echo ( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ); ?></small></a>
					<?php endif; ?>
                    <?php 
                    echo'</div>   
                    <div class="row">
                        <div class="fss_specials_products_desc">    
                            <p>'.wp_trim_words( get_the_content(), 150, '...' ).'</p>
                        </div>
                        </div>' ?>
                        <!--
                        <div class="col-4 nopadding-left">
                            <div class="fss_specials_products_countdown">
                                <div class="fss_countdown_past"><p>34</p><span>روز</span></div>
                                <div class="fss_countdown_past"><p>21</p><span>ساعت</span></div>
                                <div class="fss_countdown_past"><p>03</p><span>دقیقه</span></div>
                                <div class="fss_countdown_past"><p>46</p><span>ثانیه</span></div>
                            </div>
                        </div>
            		    -->
            			
                        <?php echo'<div class="row">
                                <div class="col-md-5 col-sx-12 fss_products_badge">
                                <div class="edc_badges edc_badges_signle">
                                    <ul>' ?>
                                <?php
                                $id = get_the_ID();
                                $medals = sigma_get_product_medals($id);
                                if(false != $medals)
                                {
                                    foreach ($medals as $medal)
                                        {
                                            ?>
                                            <li id="hexagon" class="badge_singel pink_badge"><img src="<?php echo $medal['medal_pic'] ?>" alt="<?php echo $medal['medal_name'] ?>"><span class="badge-tooltip"><?php echo $medal['medal_name'] ?></span></li>
                                            <?php
                                        }    
                                }        
                                ?>
                                <?php echo'</ul>
                                </div>
                                </div>
                                <div class="col-md-7 col-sx-12"><div class="fss_specials_products_button">
                                <div class="fss_specials_products_price">
                                '.esc_attr( apply_filters( 'woocommerce_product_price_class', '' ) ).' '.$product->get_price_html().'
                                </div>' ?>
            					<?php 
            					if ( 'yes' == $settings['sigma_show_cart']) : ?>
                                <div class="fss_specials_products_basket">
                                    <a href="<?php the_permalink(); ?>"><i class="fal fa-shopping-bag"></i>خرید این محصول</a>
                                </div>
            					<?php endif; 
					            if ( 'yes' == $settings['sigma_show_wishlist']) : ?>
                                <div class="fss_specials_products_love">
                                    <?php
                                        if(!sigma_is_in_wishlist(''))
                                        {
                                            ?>
                                            <a class="sigma-add-to-wishlist" data-product-id="<?php the_ID(); ?>"><i class="fal fa-heart"></i></a>
                                            <?php
                                        }
                                        else
                                        {
                                            ?>
                                            <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank" class="sigma-add-to-wishlist-added" data-product-id="<?php the_ID(); ?>"><span class="badge-tooltip-all">مشاهده علاقه مندی ها</span><i class="fal fa-hearn"></i></a>
                                            <?php
                                        }
                                    ?>                                    
                                </div>
                                <?php endif;
                                $id = get_the_ID();
                                $info = sigma_get_digital_product_info($id);                                
                                if ( 'yes' == $settings['sigma_show_readmore'] && !empty($info['product_preview']) ) :
                                ?>
                                <div class="fss_specials_products_more">
                                    <a href="<?php echo $info['product_preview'] ?>"><i class="fal fa-eye"></i>پیش نمایش محصول</a>
                                </div>
            					<?php endif; ?>
            					<?php echo'</div></div></div>';    
        }    
	}

	public function render_query() {
		$settings = $this->get_settings();

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } 
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } 
		else { $paged = 1; }

        if($settings['sigma_orderby'] == 'total_sales'){
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'order'               => $settings['sigma_order'],
            'meta_key'            => 'total_sales',
            'orderby'             => 'meta_value_num',			
			'paged'               => $paged,
            'meta_query'     => array(
                'relation' => 'OR',
                array( // Simple products type
                    'key'           => '_sale_price',
                    'value'         => 0,
                    'compare'       => '>',
                    'type'          => 'numeric'
                ),
                array( // Variable products type
                    'key'           => '_min_variation_sale_price',
                    'value'         => 0,
                    'compare'       => '>',
                    'type'          => 'numeric'
                )
            )				
        );
        }
        else {
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'orderby'             => $settings['sigma_orderby'],
			'order'               => $settings['sigma_order'],
			'paged'               => $paged,
        );
        }
    
        
        if($settings['sigma_woo_product_select'] == 'category'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_cat',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_cat'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}

        if($settings['sigma_woo_product_select'] == 'tag'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_tag',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_tag'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}
		
        if($settings['sigma_woo_product_select'] == 'product' && !empty($settings['sigma_woo_product'])){
            $arg_product = [
				'post__in' => $settings['sigma_woo_product'],
			];
			$args = array_merge($args, $arg_product);
		}

		$wp_query = new \WP_Query($args);

		return $wp_query;
	}

	public function render_loop_item() {
		$settings = $this->get_settings();
		global $post;

        $wp_query = $this->render_query();

		if($wp_query->have_posts()) {

			$this->add_render_attribute('sigma-wc-products-wrapper', 'sigma-grid', '');
            if($settings['deal_products_list_styles'] == 'style01_deal_products' && !empty($settings['deal_products_list_styles']) ){    
			$this->add_render_attribute(
				[
					'sigma-wc-products-wrapper' => [
						'class' => [
							'sigma-wc-products-wrapper sigma-dgs-deal',
							'sigma-grid',
							'sigma-grid-medium',
							'woocommerce',
							'columns-' . $settings['sigma_columns'],
						],
					],
				]
			);
            }
            if($settings['deal_products_list_styles'] == 'style02_deal_products' ){    
			$this->add_render_attribute(
				[
					'sigma-wc-products-wrapper' => [
						'class' => [
							'fss_full_content',
						],
					],
				]
			);
            }            
			?>
			<div <?php echo $this->get_render_attribute_string( 'sigma-wc-products-wrapper' ); ?>>
			<?php			

			$this->add_render_attribute('sigma-wc-product', 'class', [
				'sigma-wc-product',
				]); 
				$id_element = $this->get_id();
				?>
				<script>
                $(function(){
                $("#deal-carousel-<?php echo $id_element; ?>").owlCarousel( {
                	nav: <?php if($settings['active_nav_deal'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	rtl:!0,
                	margin:30,
                	loop:<?php if($settings['active_loop_deal'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	dots:<?php if($settings['active_dots_deal'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	autoplay:<?php if($settings['active_autoplay_deal'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	autoplayTimeout:<?php echo $settings['active_autoplay_speed_deal']; ?>,
                	responsive: {
                	0: {
                	items:<?php echo $settings['deal_coulmns_deal_mobile']; ?>
                }
                ,600: {
                	items:<?php echo $settings['deal_coulmns_deal_tablet']; ?>
                }
                ,1000: {
                	items: <?php echo $settings['deal_coulmns_deal_desktop']; ?>
                }}})});				
				    
				</script>				
				<ul class="products">
				    <?php
			        if( $settings['active_deal_carousel'] == 'yes' ){
			        ?>
				    <div id="deal-carousel-<?php echo $id_element; ?>" class="carousel-products-sgm owl-theme owl-carousel owl-rtl owl-loaded owl-drag">			
				    <?php } ?>
					<?php $count = 1; while ( $wp_query->have_posts() ) : $wp_query->the_post(); 
			        if($settings['deal_products_list_styles'] == 'style01_deal_products') {
			        global $product;
                    if ( $product->is_on_sale() ) {       
					?>
						<li class="dgs_gird_products_warp sigma-wc-product product">
							<div class="sigma-wc-product-inner">

							<?php 
								$this->render_image();
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php }
			        }
			        if($settings['deal_products_list_styles'] == 'style02_deal_products') {
			        global $product;
                    if ( $product->is_on_sale() ) {        
					?>
						<li class="fss_gird_products_warp product">
							<div class="row">

							<?php 
								$this->render_image();
								$this->render_description();
							?>
							</div>
						</li>
					<?php }
			        }
					?>					
					
						<?php if($count % $settings['sigma_columns'] === 0 ) : ?>
						<?php endif; ?>
					<?php $count++; endwhile;	?>
				    <?php
			        if($settings['active_deal_carousel'] == 'yes') {
			        ?>
				    </div>		
				    <?php } ?>					
				</ul>
			</div>
			<?php

			wp_reset_postdata();
			
		} else {
			echo '<div class="attr-alert-warning attr-alert no-products">' . esc_html__( 'Oops! No products were found.', 'sigma-theme' ) .'<div>';
		}
	}	
}	