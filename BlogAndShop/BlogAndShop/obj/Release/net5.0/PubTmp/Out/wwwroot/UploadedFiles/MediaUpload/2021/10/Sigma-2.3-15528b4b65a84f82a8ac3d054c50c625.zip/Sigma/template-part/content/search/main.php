<div class="content-post">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <?php get_template_part('template-part/content/search/all'); ?>
            </div>
            <div class="col-lg-3 sidebar-post nopadding-right">
                <?php get_template_part('template-part/content/archive/sidebar'); ?>
            </div>
        </div>
    </div>
</div>