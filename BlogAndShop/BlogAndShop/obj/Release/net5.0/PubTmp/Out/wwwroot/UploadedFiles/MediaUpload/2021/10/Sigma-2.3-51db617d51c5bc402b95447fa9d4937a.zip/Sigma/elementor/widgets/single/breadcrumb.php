<?php
namespace Elementor;

class Post_Breadcrumbs extends Widget_Base {
	
	public function get_name() {
		return 'post-breadcrumbs';
	}
	
	public function get_title() {
		return __( 'Single Breadcrumbs', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-product-breadcrumbs';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_title_style',
        	[
				'label' => __( 'Single Breadcrumbs', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'breadcrumbs_active',
			[
				'label'   => esc_html__( 'Active logout link', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
 		$this->add_control(
			'breadcrumbs_bg',
			[
				'label' => __( 'Breadcrumbs Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-breadcrumb-elemenor' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'breadcrumbs_active' => 'yes', ],
				'default' => '#fff'
			]
		);
		
		$this->add_control(
			'breadcrumbs_color',
			[
				'label' => __( 'Breadcrumbs Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} nav.woocommerce-breadcrumb a ,  nav.woocommerce-breadcrumb , .woocommerce-breadcrumb-elemenor , .woocommerce-breadcrumb-elemenor  a' => 'color: {{VALUE}}',
				],			
				'default' => '#777777',
				'condition' => [ 'breadcrumbs_active' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'breadcrumbs_type',
				'label' => __( 'Breadcrumbs Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .woocommerce-breadcrumb-elemenor , .woocommerce-breadcrumb-elemenor  a ',
				'condition' => [ 'breadcrumbs_active' => 'yes', ],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .woocommerce-breadcrumb-elemenor',
				'condition' => [ 'breadcrumbs_active' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .woocommerce-breadcrumb-elemenor',
				'condition' => [ 'breadcrumbs_active' => 'yes', ],
			]
		);
		
        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            if($settings['breadcrumbs_active'] == 'yes'){
            echo '<div class="breadcrumb_post breadcrumb_post_elementor">'?>
                <?php 
                $args = array(
                'delimiter' => ' <i></i> ',
                'home' => __( 'home', 'sigma-theme' ));
                woocommerce_breadcrumb($args); ?>
            <?php echo'</div>';
            }
        }
        else
        {
            if($settings['breadcrumbs_active'] == 'yes'){
            echo '<div class="breadcrumb_post breadcrumb_post_elementor"><nav class="woocommerce-breadcrumb woocommerce-breadcrumb-elemenor"><a href="'.get_bloginfo('url').'">خانه</a> <i></i>عنوان نوشته یا برگه</nav></div>';
            }
        }
    }
}