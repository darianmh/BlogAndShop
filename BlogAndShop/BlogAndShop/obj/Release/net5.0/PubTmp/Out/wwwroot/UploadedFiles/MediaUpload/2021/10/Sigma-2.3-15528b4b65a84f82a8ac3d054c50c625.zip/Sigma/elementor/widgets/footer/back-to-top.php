<?php
namespace Elementor;

class Footer_Sigma_BackToTop extends Widget_Base {

    public function get_name() {
        return 'footer-backtotop';
    }

    public function get_title() {
        return __( 'Sigma Back To Top', 'sigma-theme' );
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return [ 'Sigma-Footer' ];
    }

    protected function _register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Sigma Back To Top', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'backtotop_title',
            [
                'label' => __( 'Back To Top Title', 'sigma-theme' ),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Back To Top Title', 'sigma-theme' ),
                'default' => __( 'Back To Top', 'sigma-theme' ),
            ]
        );

        $this->add_control(
            'backtotop_icon',
            [
                'label' => __( 'Back To Top Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fal fa-chevron-up',
                    'library' => 'light',
                ],
            ]
        );

        $this->add_control(
            'backtotop_alignment',
            [
                'label' => __( 'Back To Top Alignment', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'sigma-theme' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'sigma-theme' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'sigma-theme' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .backtopsigma ' => 'text-align: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Sigma Back To Top', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'backtop_icon_size',
            [
                'label' => __( 'Back To Top Icon Size', 'sigma-theme' ),
                'type'    => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 13,
                ],
                'range' => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bktop_sgm' => 'font-size:{{SIZE}}px',
                ],
            ]
        );

        $this->add_control(
            'backtop_icon_bg',
            [
                'label' => __( 'Back To Top Background Color', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .bktop_sgm' => 'background: {{VALUE}}',
                ],
                'default' => '#ff3542',
            ]
        );

        $this->add_control(
            'backtop_icon_color',
            [
                'label' => __( 'Back To Top Color', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .bktop_sgm' => 'color: {{VALUE}}',
                ],
                'default' => '#ffffff',
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo'<div class="backtopsigma"><a class="bktop_sgm" id="back2Top" title="'.$settings['backtotop_title'].'" href="#top">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['backtotop_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo '</a></div>';
    }
}