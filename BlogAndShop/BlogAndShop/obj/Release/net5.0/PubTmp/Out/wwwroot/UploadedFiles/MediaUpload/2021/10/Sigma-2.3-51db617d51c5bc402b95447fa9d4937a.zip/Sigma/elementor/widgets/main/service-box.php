<?php
namespace Elementor;

class Main_Service_Box extends Widget_Base {
	
	public function get_name() {
		return 'service-box';
	}
	
	public function get_title() {
		return __( 'Service Box', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-info-box';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Service Box', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'service_box_select_style',
			[
				'label'   => esc_html__( 'Select service box Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'service_box_style01',
				'options' => [
                    'service_box_style01' => esc_html__('Style 01', 'sigma-theme'),
                    'service_box_style02' => esc_html__('Style 02', 'sigma-theme'),
                ],
			]
        );

		$this->add_control(
			'sigma_select_header_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/service_box_style01.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'service_box_select_style' => 'service_box_style01',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_select_header_style02',
			[
				'raw' => '<img  
				    class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/main/service_box_style02.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'service_box_select_style' => 'service_box_style02',
                ],      				
			]
		);     
		
		$this->add_responsive_control(
			'service_box_col',
			[
				'label'          => esc_html__( 'Service Box Columns', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
                'default' => '4',
			]
		);			

		$this->add_control(
			'list_sevicebox',
			[
				'label' => __( 'Service Box List', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'title',
						'label' => __( 'Service Title', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Service Title Enter', 'sigma-theme' ),
						'default' => __( 'Standard Design', 'sigma-theme' ),
					],
					[
						'name' => 'subtitle',
						'label' => __( 'Service Subtitle', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Service Subtitle Enter', 'sigma-theme' ),
						'default' => __( 'Submitted Designs', 'sigma-theme' ),
					],	
                    [
						'name' => 'img_box',
                        'label' => __( 'Service Image', 'sigma-theme' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'dynamic' => [
                                      'active' => true,
                                     ],
						'default' => [ 'url' => get_template_directory_uri() . '/assets/img/s1.png' ],
						
                    ]			
				],
				'default' => [
					[
						'title' => __( 'Standard Design', 'sigma-theme' ),
						'subtitle' => __( 'Submitted Design', 'sigma-theme' ),
						'img_box' => [ 'url' => get_template_directory_uri() . '/assets/img/s1.png' ],
					],
					[
						'title' => __( 'Refund Money', 'sigma-theme' ),
						'subtitle' => __( 'One Week From Purchase', 'sigma-theme' ),
						'img_box' => [ 'url' => get_template_directory_uri() . '/assets/img/s2.png' ],
					],
					[
						'title' => __( 'Easy To Install', 'sigma-theme' ),
						'subtitle' => __( 'At All Hosts', 'sigma-theme' ),
						'img_box' => [ 'url' => get_template_directory_uri() . '/assets/img/s3.png' ],
					],
					[
						'title' => __( 'Secure Payment', 'sigma-theme' ),
						'subtitle' => __( 'With All Credit Cards', 'sigma-theme' ),
						'img_box' => [ 'url' => get_template_directory_uri() . '/assets/img/s4.png' ],
					],					
				],
				'title_field' => '{{{ title }}}',
				'condition' => [ 'service_box_select_style' => 'service_box_style01', ],
			]
		);

		$this->add_control(
			'list_sevicebox_v2',
			[
				'label' => __( 'Service Box List', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'title',
						'label' => __( 'Service Title', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Service Title Enter', 'sigma-theme' ),
						'default' => __( 'Fast And Easy Download', 'sigma-theme' ),
					],
					[
						'name' => 'subtitle',
						'label' => __( 'Service Subtitle', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Service Subtitle Enter', 'sigma-theme' ),
						'default' => __( 'Site Products Are Available For Download After Purchase.', 'sigma-theme' ),
					],	
                    [
						'name' => 'icon',
        				'label' => __( 'Service Icon', 'text-domain' ),
        				'type' => \Elementor\Controls_Manager::ICONS,
        				'default' => [ 'value' => 'fal fa-shopping-bag', 'library' => 'light', ],
                    ]			
				],
				'default' => [
					[
						'title' => __( 'Fast And Easy Download', 'sigma-theme' ),
						'subtitle' => __( 'Site Products Are Available For Download After Purchase.', 'sigma-theme' ),
						'icon' => [ 'value' => 'fal fa-shopping-bag', 'library' => 'light', ],
					],
					[
						'title' => __( 'Professional Professors', 'sigma-theme' ),
						'subtitle' => __( 'Site Instructors Are The Best Instructors In The World.', 'sigma-theme' ),
						'icon' => [ 'value' => 'fal fa-user-graduate', 'library' => 'light', ],
					],
					[
						'title' => __( 'Intensive Courses', 'sigma-theme' ),
						'subtitle' => __( 'Courses Are Published Compactly And Professionally.', 'sigma-theme' ),
						'icon' => [ 'value' => 'fal fa-atom-alt', 'library' => 'light', ],
					],
					[
						'title' => __( 'world Standards', 'sigma-theme' ),
						'subtitle' => __( 'Courses Are Published According To The Latest World Standards.', 'sigma-theme' ),
						'icon' => [ 'value' => 'fal fa-ruler-triangle', 'library' => 'light', ],
					],		
					[
						'title' => __( 'Persian Courses', 'sigma-theme' ),
						'subtitle' => __( 'All Courses Are Published In Farsi And Professional Languages', 'sigma-theme' ),
						'icon' => [ 'value' => 'fal fa-backpack', 'library' => 'light', ],
					],
					[
						'title' => __( 'Money Back Guarantee', 'sigma-theme' ),
						'subtitle' => __( 'All Courses Have a 7 Day Money Back Guarantee.', 'sigma-theme' ),
						'icon' => [ 'value' => 'fal fa-globe-stand', 'library' => 'light', ],
					],							
				],
				'title_field' => '{{{ title }}}',
				'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
			]
		);


		$this->end_controls_section();


        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Service Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	
        
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_service_box',
        		'label' => _x( 'Service Box Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .service_box',
        		'condition' => [ 'service_box_select_style' => 'service_box_style01', ],
        	]
        );
        
        $this->add_control(
        	'sevicebox_title_color_s1',
        	[
        		'label' => _x( 'Service Box Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .service_box p' => 'color: {{VALUE}}',
        		],		
        		'condition' => [ 'service_box_select_style' => 'service_box_style01', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sevicebox_title_typography_s1',
        		'label' => _x( 'Service Box Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .service_box p',
				'condition' => [ 'service_box_select_style' => 'service_box_style01', ],
			]
		);	
		
        $this->add_control(
        	'sevicebox_subtitle_color_s1',
        	[
        		'label' => _x( 'Service Box SubTitle Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .service_box span' => 'color: {{VALUE}}',
        		],		
        		'condition' => [ 'service_box_select_style' => 'service_box_style01', ],
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sevicebox_subtitle_typography_s1',
        		'label' => _x( 'Service Box SubTitle Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .service_box span',
				'condition' => [ 'service_box_select_style' => 'service_box_style01', ],
			]
		);	

        $this->add_control(
        	'sevicebox_icon_color_s2',
        	[
        		'label' => _x( 'Service Box Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .edc_footer_counter i' => 'color: {{VALUE}}',
        		],		
        		'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
        	]
        );

		$this->add_control(
			'sevicebox_icon_size_s2',
			[
        		'label' => _x( 'Service Box Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 35,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .edc_footer_counter i ' => 'font-size:{{SIZE}}px',
				],
        		'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
			]
		);
		
        $this->add_control(
        	'sevicebox_title_color_s2',
        	[
        		'label' => _x( 'Service Box Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .edc_footer_counter p' => 'color: {{VALUE}}',
        		],		
        		'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
        	]
        );
        
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sevicebox_title_type_s2',
        		'label' => _x( 'Service Box Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .edc_footer_counter p',
				'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
			]
		);	

        $this->add_control(
        	'sevicebox_des_color_s2',
        	[
        		'label' => _x( 'Service Box Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#777777',
        		'selectors' => [
        			'{{WRAPPER}} .edc_footer_counter span ' => 'color: {{VALUE}}',
        		],		
        		'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
        	]
        );
        
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sevicebox_des_type_s2',
        		'label' => _x( 'Service Box Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .edc_footer_counter span ',
				'condition' => [ 'service_box_select_style' => 'service_box_style02', ],
			]
		);	
        
		$this->end_controls_section();
	}

	protected function render() {
		
		$settings = $this->get_settings_for_display(); 
        if($settings['service_box_select_style'] == 'service_box_style01' && !empty($settings['service_box_select_style'])){  		
		?>
		<div class="darkeble service_box columns-<?php echo $settings['service_box_col']; ?>">
        <?php foreach ( $settings['list_sevicebox'] as $index => $item ) :
		echo '<div class="service_box_single"><img alt="'.$item['title'].'" title="'.$item['title'].'" src="'.$item['img_box']['url'].'"><p>'.$item['title'].'</p><span>'.$item['subtitle'].'</span></div>';  
        ?>
		<?php
		endforeach;
        }
        if($settings['service_box_select_style'] == 'service_box_style02') {
		?>
		<div class="service_box_v2 columns-<?php echo $settings['service_box_col']; ?>">
        <?php foreach ( $settings['list_sevicebox_v2'] as $index => $item ) :
		echo '<div class="edc_footer_counter">' ?>
		<?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] );
		echo'<p>'.$item['title'].'</p><span>'.$item['subtitle'].'</span> </div>';  
        ?>
		<?php
		endforeach;
        }        
		?>
		</div> <?php
    }
}