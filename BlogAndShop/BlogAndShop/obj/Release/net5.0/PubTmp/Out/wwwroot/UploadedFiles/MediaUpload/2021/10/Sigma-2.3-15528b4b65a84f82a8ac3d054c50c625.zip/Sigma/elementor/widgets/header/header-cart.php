<?php
namespace Elementor;

class Header_Cart extends Widget_Base {
	
	public function get_name() {
		return 'header-cart';
	}
	
	public function get_title() {
		return __( 'Cart Icon', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-bag-light';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}
	
    protected function _register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Cart Icon', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'simga_woo_mini_cart_icon',
			[
				'label' => __( 'Icon', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-shopping-bag',
					'library' => 'solid',
				],				
			]
        );
        
        $this->add_responsive_control(
            'simga_woo_mini_cart_alignment',
            [
                'label' =>esc_html__( 'Alignment', 'sigma-theme' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left'    => [
                        'title' =>esc_html__( 'Left', 'sigma-theme' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' =>esc_html__( 'Center', 'sigma-theme' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' =>esc_html__( 'Right', 'sigma-theme' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .simga-mini-cart' => 'text-align: {{VALUE}};'
                ],
                'default' => 'left',
            ]
        );

        $this->end_controls_section();

		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Cart Icon Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'color_cart_icon',
			[
				'label' => __( 'Cart Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_cart_shop i' => 'color: {{VALUE}}',
				],
				'default' => '#555555',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_count_cart',
				'label' => __( 'Cart Count Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .dgs_cart_shop span',
			]
		);		
 
		$this->add_control(
			'colr_count_cart',
			[
				'label' => __( 'Cart Count Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_cart_shop span' => 'color: {{VALUE}}',
				],
				'default' => '#ffffff'
			]
		);  

		$this->add_control(
			'cart_icon_size',
			[
				'label' => __( 'Cart Icon typography', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 25,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_cart_shop i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cart_count_type',
				'label' => __( 'Cart Count typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_cart_shop span',
			]
		);	
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'cart_content_style',
        	[
				'label' => __( 'Cart Header Content Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cart_content_bg',
				'label' => __( 'Cart Content Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .simga-mini-cart-container',
			]
		);

		$this->add_control(
			'cart_items_count_color',
			[
				'label' => __( 'Number Of Items Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .mini-cart-header ul li:first-child' => 'color: {{VALUE}}',
				],		
				'default' => '#333333',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cart_items_count_typography',
				'label' => __( 'Number Of Items Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mini-cart-header ul li:first-child',
			]
		);	


		$this->add_control(
			'go_cart_color',
			[
				'label' => __( 'Go To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .mini-cart-header ul a' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
			]
		);

		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'go_cart_bg',
				'label' => __( 'Go To Cart Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}}  .simga-mini-cart .simga-mini-cart-container .mini-cart-header ul a',
			]
		);		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'go_cart_typography',
				'label' => __( 'Go To Cart Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .mini-cart-header ul a',
			]
		);			
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'cart_items_style',
        	[
				'label' => __( 'Cart Items Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
        $this->add_control(
			'color_item_name',
			[
				'label' => __( 'Item Color Name', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li a' => 'color: {{VALUE}}',
				],		
				'default' => '#465157',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'color_item_type',
				'label' => __( 'Item Color Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li a',
			]
		);	

        $this->add_control(
			'color_item_price',
			[
				'label' => __( 'Item Remove Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li .quantity' => 'color: {{VALUE}}',
				],		
				'default' => '#465157',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'type_item_price',
				'label' => __( 'Item Quantity Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li .quantity',
			]
		);	

        $this->add_control(
			'remove_qu_color',
			[
				'label' => __( 'Item Quantity Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li .quantity ' => 'color: {{VALUE}}',
				],		
				'default' => '#465157',
			]
		);
		
        $this->add_control(
			'remove_icon_color',
			[
				'label' => __( 'Remove Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li a.remove ' => 'color: {{VALUE}}',
				],		
				'default' => '#465157',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'item_remove_bg_wish',
				'label' => __( 'Item Remove Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li a.remove  ',
			]
		);
		
		$this->add_control(
			'remove_icon_size',
			[
				'label' => __( 'Remove Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart ul li a.remove ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();               
        
        $this->start_controls_section(
        	'footer_cart_style',
        	[
				'label' => __( 'Cart Footer', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
        $this->add_control(
			'subtotal_color',
			[
				'label' => __( 'Cart Subtotal Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} p.woocommerce-mini-cart__total strong' => 'color: {{VALUE}}',
				],		
				'default' => '#333333',
			]
		);

        $this->add_control(
			'subtotal_amount_color',
			[
				'label' => __( 'Cart Subtotal Amount Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart .woocommerce-mini-cart__total .amount' => 'color: {{VALUE}}',
				],		
				'default' => '#333333',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'go_to_checkout_bg',
				'label' => __( 'Go To Checkout Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart .woocommerce-mini-cart__buttons .wc-forward.checkout',
			]
		);

        $this->add_control(
			'go_to_checkout_color',
			[
				'label' => __( 'Go To Checkout Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .simga-mini-cart .simga-mini-cart-container .simga-dropdown-menu-mini-cart .woocommerce-mini-cart__buttons .wc-forward.checkout' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
			]
		);
		
        $this->end_controls_section();               
    }	
	protected function render() {

        $settings = $this->get_settings_for_display();
        echo '<div class="simga-mini-cart"><a href="'.wc_get_cart_url().'" class="dgs_cart_shop">'?><?php \Elementor\Icons_Manager::render_icon( $settings['simga_woo_mini_cart_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</i><span>'.(( WC()->cart != '' ) ? WC()->cart->get_cart_contents_count()."" : '' ).'</span></a>'; ?>
            <div href="#" class="simga-dropdown-back">
                <div class="simga-mini-cart-container">
                    <div class="mini-cart-header">
                        <ul>
                            <li><?php echo (( WC()->cart != '' ) )?  WC()->cart->get_cart_contents_count() : '' ; ?> <?php esc_html_e( 'items', 'sigma-theme' ); ?></li>
                            <li><a href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'view cart', 'sigma-theme' ); ?></a></li>
                        </ul>
                    </div>
                    <div class="simga-dropdown-menu simga-dropdown-menu-mini-cart">
                        <div class="widget_shopping_cart_content">
                            <?php (( WC()->cart != '' ) ? woocommerce_mini_cart() : '' ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php	}

}