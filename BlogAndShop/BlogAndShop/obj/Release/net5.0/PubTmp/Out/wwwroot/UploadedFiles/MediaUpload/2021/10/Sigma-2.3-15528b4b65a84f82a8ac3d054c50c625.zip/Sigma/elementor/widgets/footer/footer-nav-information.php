<?php
namespace Elementor;

class Footer_Nav_Information extends Widget_Base {

	public function get_name() {
		return 'footer-nav-information';
	}
	
	public function get_title() {
		return  __( 'Footer Nav Information', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-navigation-vertical';
	}
	
	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_nav_footer',
			[
				'label' => __( 'Footer Nav Information', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'list',
			[
				'label' => __( 'List', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'Text Prefix', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'List Item', 'sigma-theme' ),
						'default' => __( 'List Item', 'sigma-theme' ),
					],					
					[
						'name' => 'text1',
						'label' => __( 'Text Sufix', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'List Item', 'sigma-theme' ),
						'default' => __( 'List Item', 'sigma-theme' ),
					],									
					[
						'name' => 'link',
						'label' => __( 'Link', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => __( 'https://your-link.com', 'sigma-theme' ),
        				'default' => [
        					'url' => 'http://hamkarwp.com',
        				]						
					],
					[
						'name' => 'icon',
						'label' => __( 'Icon Nav', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
        				'default' => [
        					'value' => 'fal fa-phone-square',
        					'library' => 'light',
        				],						
					],
					[
						'name' => 'class',
						'label' => __( 'Nav class', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
					],					
				],
				'default' => [
					[
						'text' => __( 'Prefix Nav num #1', 'sigma-theme' ),
						'text1' => __( 'Sufix Nav num #1', 'sigma-theme' ),
						'link' => 'https://elementor.com/',
						'icon' => [ 'value' => 'fal fa-phone-square', 'library' => 'light', ],
					],
					[
						'text' => __( 'Prefix Nav num #2', 'sigma-theme' ),
						'text1' => __( 'Sufix Nav num #2', 'sigma-theme' ),
						'link' => 'https://elementor.com/',
						'icon' => [ 'value' => 'fal fa-phone-square', 'library' => 'light', ],
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);


		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section_nav',
        	[
				'label' => __( 'Nac Text Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_control(
			'nav-gap',
			[
				'label' => __( 'Nav Gaps', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_location ' => 'margin:{{SIZE}}px 0',
				],
			]
		);
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'style_nav_informaion',
				'label' => __( 'Footer Nav Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_footer_location.phone p b , .dgs_footer_location.phone p',
			]
		);

		
		$this->add_control(
			'footer_nav_prefix_color',
			[
				'label' => __( 'Prefix Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#ff6c00',
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_location.phone p' => 'color: {{VALUE}}',
				],		
			]
		);
		
		$this->add_control(
			'footer_nav_suffix_color',
			[
				'label' => __( 'Suffix Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#888888',
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_location.phone p b' => 'color: {{VALUE}}',
				],		
			]
		);
		
		$this->end_controls_section();

        $this->start_controls_section(
        	'style_section_nav_icon',
        	[
				'label' => __( 'Nav Icon Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
		
		$this->add_control(
			'nav_icon_size',
			[
				'label' => __( 'Nav Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 18,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_location i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		
		$this->add_control(
			'footer_nav_icon_color',
			[
				'label' => __( 'Footer Nav Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_location i' => 'color: {{VALUE}}',
				],		
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'footer_nav_bg_icon',
		    	'label' => _x( 'Footer Nav Icon Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .dgs_footer_location i',
                'defualt' => '#add4d4',
			]
		);
		
		$this->end_controls_section();		

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="dgs_sigma_footer_about">
		<?php foreach ( $settings['list'] as $index => $item ) : ?>
			<div class="dgs_footer_location phone <?php echo $item['class']; ?>">
				<?php
                    echo '<a href="'.$item['link']['url'].'">'?> <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo'<p>'.$item['text'].'<b>'.$item['text1'].'</b></p></a>';
				?>
			</div>
		<?php endforeach; ?>
		</div>
		<?php
	}
}