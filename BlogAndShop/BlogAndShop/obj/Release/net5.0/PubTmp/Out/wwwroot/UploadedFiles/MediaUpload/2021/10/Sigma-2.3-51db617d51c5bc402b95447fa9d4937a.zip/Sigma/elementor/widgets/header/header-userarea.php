<?php
namespace Elementor;

class Header_Login_Area extends Widget_Base {

	public function get_name() {
		return 'header-login-area';
	}
	
	public function get_title() {
		return __( 'Header Login Area', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-lock-user';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}

    public function get_menus(){
        $list = [];
        $menus = wp_get_nav_menus();
        foreach($menus as $menu){
            $list[$menu->slug] = $menu->name;
        }

        return $list;	
    }
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_1',
			[
				'label' => __( 'user panel Content', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'user_login_select_style',
			[
				'label'   => esc_html__( 'Select User Panel Content Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_login',
				'options' => [
                    'style01_login' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_login' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_login' => esc_html__('Style 03', 'sigma-theme'),
                ],
			]
        );


		$this->add_control(
			'sigma_select_login_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_out_select_style01.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_select_style' => 'style01_login',
                ],      				
			]
		);        

        $this->add_control(
			'sigma_select_login_style02',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_out_select_style02.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_select_style' => 'style02_login',
                ],      				
			]
		);        
		
		$this->add_control(
			'sigma_select_login_style03',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_out_select_style03.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_select_style' => 'style03_login',
                ],      				
			]
		);        

		$this->add_control(
			'loginarea_alignment',
			[
				'label' => __( 'Login Aarea Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .sgm_login_area ' => 'text-align: {{VALUE}};'
                ],				
			]
		);	
		
		$this->add_control(
			'logged_in_text',
			[
				'label' => __( 'Text For Logged In Users', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Text For Logged In Users', 'sigma-theme' ),
                'condition' => [
                    'user_login_select_style' => 'style03_login',
                ],      	                
                'default' => __( 'Users panel', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'logged_in_link',
			[
				'label' => __( 'Link For Logged In Users', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => get_site_url() . '/my-account',
                'condition' => [
                    'user_login_select_style' => 'style03_login',
                ],      					
				'default' => [
					'url' => get_site_url() . '/my-account',
				]
			]
		);

		$this->add_control(
			'userpanel_in_link',
			[
				'label' => __( 'Link For User Panel', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => get_site_url() .'/my-account' ,
				'default' => [
					'url' => get_site_url() .'/my-account' ,
				]
			]
		);
		
		$this->add_control(
			'logged_in_icon',
            [
                'label' => __( 'Icon For Logged In Users', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-user',
					'library' => 'light',
				],            
				]
		);

		$this->add_control(
			'login_v1_header_logout_text',
			[
				'label' => __( 'Logout Text' , 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Logout', 'sigma-theme' ),
                'condition' => [
					'user_login_select_style' => 'style01_login',
                ],      	                
                'default' => __( 'Logout', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'login_v1_header_logout_icon',
            [
                'label' => __( 'Logout Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-power-off',
					'library' => 'light',
				],                  
                'condition' => [
					'user_login_select_style' => 'style01_login',
                ],                      
            ]
		);
		
		$this->add_control(
			'login_v1_active_logout',
			[
				'label'   => esc_html__( 'Active Logout Link', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style01_login',
                ],      				
			]
		);

		$this->add_control(
			'login_v1_active_name',
			[
				'label'   => esc_html__( 'Active Show User Name', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style01_login',
                ],      				
			]
		);

		$this->add_control(
			'login_v1_active_balance',
			[
				'label'   => esc_html__( 'Active Balance Wallet', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style01_login',
                ],      				
			]
		);

		$this->add_control(
			'login_v2_header_logout_text',
			[
				'label' => __( 'Logout Text' , 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Logout', 'sigma-theme' ),
                'condition' => [
					'user_login_select_style' => 'style02_login',
                ],      	                
                'default' => __( 'Logout', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'login_v2_header_logout_icon',
            [
                'label' => __( 'Logout Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-power-off',
					'library' => 'light',
				],                  'condition' => [
					'user_login_select_style' => 'style02_login',
                ],                      
            ]
		);
		
		$this->add_control(
			'login_v2_active_logout',
			[
				'label'   => esc_html__( 'Active Logout Link', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style02_login',
                ],      				
			]
		);

		$this->add_control(
			'login_v2_active_name',
			[
				'label'   => esc_html__( 'Active Show User Name', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style02_login',
                ],      				
			]
		);

		$this->add_control(
			'login_v2_active_balance',
			[
				'label'   => esc_html__( 'Active Balance Wallet', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style02_login',
                ],      				
			]
		);		

		$this->add_control(
			'login_v3_active_avatar',
			[
				'label'   => esc_html__( 'Active Avatar', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
                'condition' => [
					'user_login_select_style' => 'style03_login',
                ],      				
			]
		);

				
        $this->add_control(
            'sigma_user_menu',
            [
                'label'     =>esc_html__( 'Select Menu User Panel', 'sigma-theme' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->get_menus(),
            ]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_content_2',
			[
				'label' => __( 'Login / Register Content', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'user_login_out_select_style',
			[
				'label'   => esc_html__( 'Select Login / Register Content Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_login_out',
				'options' => [
                    'style01_login_out' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_login_out' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_login_out' => esc_html__('Style 03', 'sigma-theme'),
                    'style04_login_out' => esc_html__('Style 04', 'sigma-theme'),
                ],
			]
        );


		$this->add_control(
			'sigma_select_login_out_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_select_style01.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_out_select_style' => 'style01_login_out',
                ],      				
			]
		);        

        $this->add_control(
			'sigma_select_login_out_style02',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_select_style02.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_out_select_style' => 'style02_login_out',
                ],      				
			]
		);        
		
		$this->add_control(
			'sigma_select_login_out_style03',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_select_style03.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_out_select_style' => 'style03_login_out',
                ],      				
			]
		);        
		
		$this->add_control(
			'sigma_select_login_out_style04',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/user_login_select_style04.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ],      				
			]
		);        

		$this->add_control(
			'login_v1_text',
			[
				'label' => __( 'Login Text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Login Text', 'sigma-theme' ),
                'default' => __( 'Login', 'sigma-theme' ),
                'condition' => [
					'user_login_out_select_style' => ['style01_login_out', 'style02_login_out', 'style03_login_out'],
                ],              
			]
		);

		$this->add_control(
			'login_v1_icon',
            [
                'label' => __( 'Login Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-users',
					'library' => 'light',
				],                  'condition' => [
					'user_login_out_select_style' => ['style01_login_out', 'style02_login_out', 'style03_login_out'],
                ],
            ]
		);

		$this->add_control(
			'login_v1_link',
			[
				'label' => __( 'Login Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => get_site_url() .'/my-account' ,
				'default' => [
					'url' => get_site_url() .'/my-account' ,
				]
			]
		);

		$this->add_control(
			'register_v1_text',
			[
				'label' => __( 'Register Text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Register text', 'sigma-theme' ),
                'default' => __( 'Register', 'sigma-theme' ),
                'condition' => [
					'user_login_out_select_style' => ['style01_login_out', 'style02_login_out', 'style03_login_out'],
                ],              
			]
		);


		$this->add_control(
			'register_v1_link',
			[
				'label' => __( 'Register Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => get_site_url() .'/my-account/register' ,
				'default' => [
					'url' => get_site_url() .'/my-account/register' ,
				]
			]
		);

		$this->add_control(
			'register_v1_icon',
            [
                'label' => __( 'Register Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-users',
					'library' => 'light',
				],                  'condition' => [
					'user_login_out_select_style' => ['style01_login_out', 'style02_login_out', 'style03_login_out'],
                ],     				
            ]
		);
		
		$this->add_control(
			'logged_out_text',
			[
				'label' => __( 'Text For Login / Register ', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Text For login / register ', 'sigma-theme' ),
                'default' => __( 'Login / register', 'sigma-theme' ),
                'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ],                     
			]
		);
		
		$this->add_control(
			'logged_out_link',
			[
				'label' => __( 'Login / Register Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => get_site_url() . '/my-account',
				'default' => [
					'url' => get_site_url() . '/my-account',
				],
				'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ], 
			]
		);

		$this->add_control(
			'logged_out_icon',
            [
                'label' => __( 'Icon For Login / Register', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-user',
					'library' => 'light',
				],                  
				'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ],                 
            ]
		);
		
		$this->end_controls_section();		

        $this->start_controls_section(
        	'ajax_content',
        	[
				'label' => __( 'Ajax Login/Regsiter Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	
        
		$this->add_control(
			'active_ajax_login',
			[
				'label'   => esc_html__( 'Active Ajax Login / Register', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ajax_login_bg',
				'label' => __( 'Login Box Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'active_ajax_login' => 'yes',
                ],
				'selector' => '{{WRAPPER}} .form-bg',
			]
		);
		
		
        $this->end_controls_section();		
        
        $this->start_controls_section(
        	'style_section_1',
        	[
				'label' => __( 'User Panel Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background_dgs_signin',
				'label' => __( 'User Panel Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'user_login_select_style' => 'style03_login',
                ],
				'selector' => '{{WRAPPER}} .dgs_sign_in_top',
			]
		);

		
		$this->add_control(
			'color_logged_in',
			[
				'label' => __( 'Color User Panel Text', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sign_in_top' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => 'style03_login',
                ],   	
                'default' => '#ffffff',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_size_logged_in',
				'label' => __( 'User Panel Test Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_sign_in_top',
			]
		);	
		
		$this->add_control(
			'color_logged_in_icon',
			[
				'label' => __( 'Color User Panel Icon', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sign_in_top i' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => 'style03_login',
                ],   	
                'default' => '#ffffff',
			]
		);

		$this->add_control(
			'size_logged_in_icon',
			[
				'label' => __( 'User Panel Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 17,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sign_in_top i' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_header_submenu',
				'label' => __( 'User Panel Header Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'user_login_select_style' => 'style03_login',
                ], 
				'selector' => '{{WRAPPER}} .dgs_panel_active',
			]
		);		

        $this->add_control(
			'header_submenu_user_name_color',
			[
				'label' => __( 'User Name Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'condition' => [ 'user_login_select_style' => 'style03_login', ],
				'selectors' => [
					'{{WRAPPER}} .dgs_user_name' => 'color: {{VALUE}}',
				],		
				'default' => '#333333',
			]
		);

        $this->add_control(
			'header_submenu_go_panel_color',
			[
				'label' => __( 'Go Panel Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_user_panel' => 'color: {{VALUE}}',
				],		
				'condition' => [ 'user_login_select_style' => 'style03_login', ],
				'default' => '#999999',
			]
		);

        $this->add_control(
			'header_submenu_go_panel_color_icon',
			[
				'label' => __( 'Go Panel Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_user_panel i' => 'color: {{VALUE}}',
				],		
				'condition' => [ 'user_login_select_style' => 'style03_login', ],
				'default' => '#999999',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'header_submenu_user_name_typography',
				'label' => __( 'Username Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_user_name',
				'condition' => [ 'user_login_select_style' => 'style03_login', ],
			]
		);	

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'header_submenu_go_panel_typography',
				'label' => __( 'Go Panel Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_user_panel',
				'condition' => [ 'user_login_select_style' => 'style03_login', ],
			]
		);	

		$this->add_control(
			'go_panel_icon_size',
			[
				'label' => __( 'Go Panel Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_user_panel i' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'user_login_select_style' => 'style03_login', ],
			]
		);
		
// style 01 & 02

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_loginv2_user',
				'label' => __( 'User Panel Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'user_login_select_style' => ['style01_login' , 'style02_login'],
                ], 
				'selector' => '{{WRAPPER}} .user-top-right , .top__user__profile_d5',
			]
		);

		$this->add_control(
			'color_logged_in_icon_v1',
			[
				'label' => __( 'Color User Panel Icon', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .user-top-right a i , .top__user__profile_d5 a i' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => ['style01_login' , 'style02_login'],
                ],   	
                'default' => '#ffffff',
                
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_logged_in_text_v1',
				'label' => __( 'Color User Panel Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'user_login_select_style' => 'style02_login',
                ], 
				'selector' => '{{WRAPPER}} .user-top-right',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_logged_in_text_v2',
				'label' => __( 'Color User Panel Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'user_login_select_style' => 'style02_login',
                ], 
				'selector' => '{{WRAPPER}} .top__user__profile_d5',
			]
		);
		
		$this->add_control(
			'color_logged_in_text_v1',
			[
				'label' => __( 'Color User Panel Text', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .user-top-right a ' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => 'style01_login',
                ],   	
                'default' => '#555555',
			]
		);
		
		$this->add_control(
			'color_logged_in_text_v2',
			[
				'label' => __( 'Color User Panel Text 2', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .top__user__profile_d5 a' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => 'style02_login',
                ],   	
                'default' => '#ffffff',
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_logout_user',
				'label' => __( 'User Panel Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
					'user_login_select_style' => 'style01_login',
                ], 
				'selector' => '{{WRAPPER}} .user-top-left , .top__user__logout_d5 a',
			]
		);

		$this->add_control(
			'color_logged_out_text_v1',
			[
				'label' => __( 'Color User Logout Text Panel ', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .user-top-left a , .top__user__logout_d5 a' => 'color: {{VALUE}}',
				],			
				'condition' => [
					'user_login_select_style' => ['style01_login', 'style02_login'],
                ],   	
                'default' => '#ffffff',
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_submenu_v1',
				'label' => __( 'User Panel Background Submenu', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .user_menu_v1_panel ul , .sigma-user-menu-nav',
			]
		);


		$this->add_control(
			'user_submenu_text_v1',
			[
				'label' => __( 'User Panel Submenu Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .user_menu_v1_panel ul li a , .sigma-user-menu-nav ul li a' => 'color: {{VALUE}}',
				],			
                'default' => '#333333',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'user_submenu_text_v1_typography',
				'label' => __( 'User Panel Submenu typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .user_menu_v1_panel ul li a , .sigma-user-menu-nav ul li a',
			]
		);	
		$this->end_controls_section();		
		
        $this->start_controls_section(
        	'style_section_2',
        	[
				'label' => __( 'Login / Register Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
        
        // style 1

        $this->add_control(
			'icon_login_reg_v1_color',
			[
				'label' => __( 'Register / Loign Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .login-v1 , .reg-v1' => 'color: {{VALUE}}',
				],		
				'default' => '#333',
				'condition' => [
                    'user_login_out_select_style' => 'style01_login_out',
                ],    				
			]
		);

        $this->add_control(
			'icon_login_reg_v1_icon_color',
			[
				'label' => __( 'Icon Register / Loign Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}}  .nologin-btn i' => 'color: {{VALUE}}',
				],		
				'default' => '#333',
				'condition' => [
                    'user_login_out_select_style' => 'style01_login_out',
                ],    				
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'icon_login_reg_v1_icon_bg',
				'label' => __( 'Icon Register / Loign Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
                    'user_login_out_select_style' => 'style01_login_out',
                ], 
				'selector' => '{{WRAPPER}} .login-v1 , .reg-v1',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_login_reg_v1_border',
				'label' => __( 'Border Login / Register Text', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .login-v1 , .reg-v1',
				'condition' => [
                    'user_login_out_select_style' => 'style01_login_out',
                ], 
			]
		);
		
        // style 2

		
        $this->add_control(
			'color_login_v2',
			[
				'label' => __( 'Login Bottun Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .btn-login' => 'color: {{VALUE}}',
				],		
				'default' => '#999999',
				'condition' => [
                    'user_login_out_select_style' => 'style02_login_out',
                ], 			]
		);        	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_login_v2',
				'label' => __( 'Login Bottun Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
                    'user_login_out_select_style' => 'style02_login_out',
                ], 
				'selector' => '{{WRAPPER}} .btn-login',
			]
		);		
		
        $this->add_control(
			'color_reg_v2',
			[
				'label' => __( 'Register Bottun Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .btn-register' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
				'condition' => [
                    'user_login_out_select_style' => 'style02_login_out',
                ], 			
                ]
		);        	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_reg_v2',
				'label' => __( 'Register Bottun Background', 'sigma-theme' ),
				'types' => ['gradient'],
				'condition' => [
                    'user_login_out_select_style' => 'style02_login_out',
                ], 
				'selector' => '{{WRAPPER}} .btn-register',
			]
		);		

        // style 3

		
        $this->add_control(
			'color_login_v3',
			[
				'label' => __( 'Login Bottun Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .login__v3__header' => 'color: {{VALUE}}',
				],		
				'default' => '#999999',
				'condition' => [
                    'user_login_out_select_style' => 'style03_login_out',
                ], 			
                ]
		);        	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_login_v3',
				'label' => __( 'Login Bottun Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
                    'user_login_out_select_style' => 'style03_login_out',
                ], 
				'selector' => '{{WRAPPER}} .login__v3__header ',
			]
		);		

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border_login_v3',
				'label' => __( 'Border Login Button', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .login__v3__header',
                'condition' => [
                    'user_login_out_select_style' => 'style03_login_out',
                ],      					
			]
		);
		
        $this->add_control(
			'color_reg_v3',
			[
				'label' => __( 'Register Bottun Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .register__v3__header' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff',
				'condition' => [
                    'user_login_out_select_style' => 'style03_login_out',
                ], 			
                ]
		);        	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg_reg_v3',
				'label' => __( 'Register Bottun Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
                    'user_login_out_select_style' => 'style03_login_out',
                ], 
				'selector' => '{{WRAPPER}} .register__v3__header',
			]
		);
		
		// style 4
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background_1',
				'label' => __( 'Login / Register Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .dgs_sign_in_top_out',
				'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ],    
			]
		);
		
		
		$this->add_control(
			'color_logged_out',
			[
				'label' => __( 'Login  / Register Icon Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sign_in_top_out' => 'color: {{VALUE}}',
				],				
				'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ],    
                'default' => '#ffffff',
			]
		);

		$this->add_control(
			'color_logged_out_icon',
			[
				'label' => __( 'Login  / Register Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sign_in_top_out i' => 'color: {{VALUE}}',
				],				
				'condition' => [
                    'user_login_out_select_style' => 'style04_login_out',
                ],    
                'default' => '#ffffff',
			]
		);
		
		$this->end_controls_section();				

	}

	protected function render() {
        $settings = $this->get_settings_for_display();
        echo '<div class="sgm_login_area">';
        if($settings['user_login_select_style'] == 'style01_login' && !empty($settings['user_login_select_style'])){    
        if ( is_user_logged_in() ) {
		$url_logged_panel_h1 = $settings['userpanel_in_link']['url'];
        echo '<div class="top-panel-v2"> <div class="user-top-right"><a href="'.$url_logged_panel_h1.'">'?><?php \Elementor\Icons_Manager::render_icon( $settings['logged_in_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php  
        if($settings['login_v1_active_name'] == 'yes' ){  
        $current_user = wp_get_current_user();
        echo '' . $current_user->display_name . '';
        }
        if($settings['login_v1_active_balance'] == 'yes'  && class_exists('WooWallet')){  
    	echo  ' | موجودی : ' . woo_wallet()->wallet->get_wallet_balance(get_current_user_id());
        }
        ?>
        </a>
            <div class="user_menu_v1_panel">
                <?php
                    $args = array(
                        'container_class' => 'collapse navbar-collapse no-padding',
                        'fallback_cb' => '',
                        'menu_id' => 'header-menu',
        				'menu'         	  => $settings['sigma_user_menu'],
                    );
                    wp_nav_menu($args);
                ?>            </div></div>
            <?php
            if($settings['login_v1_active_logout'] == 'yes' ){  
            ?>
            <div class="user-top-left">
                <a href="<?php echo wp_logout_url( home_url() ); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_header_logout_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $settings['login_v1_header_logout_text'] ?> </a>
            </div>
            <?php } ?> 
        </div>
         <?php }} 

        if($settings['user_login_select_style'] == 'style02_login' && !empty($settings['user_login_select_style'])){    
        if ( is_user_logged_in() ) {
		$url_logged_panel_h1 = $settings['userpanel_in_link']['url'];
        echo '<div class="top-panel-v2"> <div class="top__user__profile_d5"><a href="'.$url_logged_panel_h1.'">'?><?php \Elementor\Icons_Manager::render_icon( $settings['logged_in_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php  
        if($settings['login_v2_active_name'] == 'yes' ){  
        $current_user = wp_get_current_user();
        echo '' . $current_user->display_name . '';
        }
        if($settings['login_v2_active_balance'] == 'yes'  && class_exists('WooWallet')){  
    	echo  ' | موجودی : ' . woo_wallet()->wallet->get_wallet_balance(get_current_user_id());
        }
        ?>
        </a>
            <div class="user_menu_v1_panel">
                <?php
                    $args = array(
                        'container_class' => 'collapse navbar-collapse no-padding',
                        'fallback_cb' => '',
                        'menu_id' => 'header-menu',
        				'menu'         	  => $settings['sigma_user_menu'],
                    );
                    wp_nav_menu($args);
                ?>
                </div>
        </div>
		<?php
            if($settings['login_v2_active_logout'] == 'yes' ){  
        ?>
        <div class="top__user__logout_d5">
            <a href="<?php echo wp_logout_url( home_url() ); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['login_v2_header_logout_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $settings['login_v2_header_logout_text'];?></a>
        </div>
		<?php
			}
		?>
        </div>
         <?php }} 

        if($settings['user_login_select_style'] == 'style03_login' && !empty($settings['user_login_select_style'])){    
        $url_logged_in = $settings['logged_in_link']['url'];
        $url_logged_panel = $settings['userpanel_in_link']['url'];
        if ( is_user_logged_in() ) {
        echo '<div class="dgs_user_action"><a href="'.$url_logged_in.'" class="dgs_sign_in_top">'?><?php \Elementor\Icons_Manager::render_icon( $settings['logged_in_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo ''.$settings['logged_in_text'].'</a>'
        ?>
        
        <div class="dgs_panel_menu">
        <div class="dgs_panel_active">
		<?php    
			global $current_user;
			wp_get_current_user();  
		  if ($settings['login_v3_active_avatar'] == 'yes') {
			global $current_user;
			wp_get_current_user();  			  
			echo '<div class="dgs_user_avatar">';
			echo '' . get_avatar( $current_user->ID, 64 ) . "</div>";
		  }
          echo '<div class="dgs_user_name">' . $current_user->display_name . "\n" . '<a href="'.$url_logged_panel.'" class="dgs_user_panel"> مشاهده پنل کاربری <i class="fal fa-chevron-left"></i></a>';
        ?>
        </div></div>
        <div class="sigma-user-menu">
                <nav class="sigma-user-menu-nav" role="navigation">
                <?php
                    $args = array(
                        'container_class' => 'collapse navbar-collapse no-padding',
                        'menu_class' => '',
                        'fallback_cb' => '',
                        'menu_id' => 'header-menu',
        				'menu'         	  => $settings['sigma_user_menu'],
                    );
                    wp_nav_menu($args);
                ?>
                    <li class="dgs_logout_url"><a href="<?php echo wp_logout_url( home_url() ); ?>">خروج</a></li>
                </nav>
            </div>
        </div>
         </div>
         <?php }} 

        if( !is_user_logged_in() && $settings['user_login_out_select_style'] == 'style01_login_out'){    
            if( $settings['active_ajax_login'] == 'yes' ) {
                get_template_part('ajax', 'auth');
                echo '<div class="nologin-btn"> <a href="'.$settings['login_v1_link']['url'].'" id="show_login" class="login-v1">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['login_v1_text'].'</a> <a href="'. $settings['register_v1_link']['url'].'" id="show_signup" class="reg-v1">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['register_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['register_v1_text'].'</a> </div>';   
            }
            else {
                echo '<div class="nologin-btn"> <a href="'.$settings['login_v1_link']['url'].'" class="login-v1">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['login_v1_text'].'</a> <a href="'. $settings['register_v1_link']['url'].'" class="reg-v1">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['register_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['register_v1_text'].'</a> </div>';                   
            }
        }
        if( !is_user_logged_in() && $settings['user_login_out_select_style'] == 'style02_login_out'){   
            if( $settings['active_ajax_login'] == 'yes' ) {
                get_template_part('ajax', 'auth');
                echo '<div class="panelbar"><a href="'.$settings['login_v1_link']['url'].'" class="btn-login login_button" id="show_login">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['login_v1_text'].'</a><a href="'. $settings['register_v1_link']['url'].'" class="btn-register login_button" id="show_signup">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['register_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['register_v1_text'].'</a></div>';   
            }
            else {
                echo '<div class="panelbar"><a href="'.$settings['login_v1_link']['url'].'" class="btn-login login_button">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['login_v1_text'].'</a><a href="'. $settings['register_v1_link']['url'].'" class="btn-register login_button"'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['register_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['register_v1_text'].'</a></div>';                   
            }
        }
        if( !is_user_logged_in() && $settings['user_login_out_select_style'] == 'style03_login_out'){ 
            if( $settings['active_ajax_login'] == 'yes' ) {
                echo '<a class="login__v3__header" id="show_login" href="'.$settings['login_v1_link']['url'].'">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['login_v1_text'].'</a><a class="register__v3__header" id="show_signup" href="'. $settings['register_v1_link']['url'].'">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['register_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo ''. $settings['register_v1_text'].'</a>';   
                get_template_part('ajax', 'auth');
            }
            else {
                echo '<a class="login__v3__header" href="'.$settings['login_v1_link']['url'].'">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['login_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''. $settings['login_v1_text'].'</a><a class="register__v3__header" href="'. $settings['register_v1_link']['url'].'">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['register_v1_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo ''. $settings['register_v1_text'].'</a>';                   
            }
        }
        if( !is_user_logged_in() && $settings['user_login_out_select_style'] == 'style04_login_out' ) {    
            if( $settings['active_ajax_login'] == 'yes' ) {
                get_template_part('ajax', 'auth');
                echo '<a id="show_login" class="dgs_signin_ajax dgs_sign_in_top_out">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['logged_out_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''.$settings['logged_out_text'].'</a>';                      
            } 
            else {
                echo '<a href="'.$settings['logged_out_link']['url'].'" class="dgs_sign_in_top_out">'?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['logged_out_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo ''.$settings['logged_out_text'].'</a>';                
            }
        }
        echo'</div>';
	}

	protected function _content_template() {

	}

}