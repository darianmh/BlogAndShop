<?php
namespace Elementor;

class Header_Logo_Widget extends Widget_Base {
	
	public function get_name() {
		return 'logo-widget';
	}
	
	public function get_title() {
		return __( 'Sigma Logo', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-logo';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}

    public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->add_script_depends('ekit-nav-menu');
	}
	
    public function get_menu(){
        $list = [];
        $menus = wp_get_nav_menus();
        foreach($menus as $menu){
            $list[$menu->slug] = $menu->name;
        }

        return $list;
    }
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Sigma Logo', 'sigma-theme' ),
			]
		);

        $this->add_control(
			'logo_alignment',
			[
				'label' => __( 'Logo Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .logo_sigma_full ' => 'text-align: {{VALUE}};'
                ],				
			]
		);		
		
		$this->add_control(
			'logo_image',
                   [
                    'label' => __( 'Choose Logo Image', 'sigma-theme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'dynamic' => [
                                  'active' => true,
                                 ],
                    'default' => [
                     'url' => get_template_directory_uri() . '/assets/img/logo.png',
                    ],
                  ]
		);


		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://hamkarwp.com', 'sigma-theme' ),
				'default' => [
					'url' => get_site_url(),
				]
			]
		);
		
		$this->end_controls_section();


        $this->start_controls_section(
        	'style_section_logo',
        	[
				'label' => __( 'Sigma Logo', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
	
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'thumbnail',
				'include' => [],
				'default' => 'large',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
        $url = $settings['link']['url'];
		$img = Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'logo_image' );
		echo '<a class="logo_sigma_full" href="'.$url.'" title="'.get_bloginfo('name').'" >'.$img.'</a>';  
	}
	
	
	protected function _content_template() {

    }
	
	
}