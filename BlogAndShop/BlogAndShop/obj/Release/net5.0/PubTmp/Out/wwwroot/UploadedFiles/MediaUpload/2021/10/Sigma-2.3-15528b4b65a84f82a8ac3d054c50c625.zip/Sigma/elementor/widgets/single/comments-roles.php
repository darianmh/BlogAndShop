<?php
namespace Elementor;

class Comments_Roles extends Widget_Base {
	
	public function get_name() {
		return 'comments-roles';
	}
	
	public function get_title() {
		return  __( 'Comment Role', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-blockquote';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_content',
        	[
				'label' => __( 'Comment Role', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'active_role_comments',
			[
				'label'   => esc_html__( 'Active Comment Role', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'comment_role_text',
			[
				'label' => __( 'Comment Role Text', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<ul>
                    <li><i class="fa fa-caret-left"></i> چنانچه دیدگاهی توهین آمیز باشد و متوجه اشخاص مدیر، نویسندگان و سایر کاربران باشد تایید نخواهد شد.</li>
                    <li><i class="fa fa-caret-left"></i> چنانچه دیدگاه شما جنبه ی تبلیغاتی داشته باشد تایید نخواهد شد.</li>
                    <li><i class="fa fa-caret-left"></i> چنانچه از لینک سایر وبسایت ها و یا وبسایت خود در دیدگاه استفاده کرده باشید تایید نخواهد شد.</li>
                    <li><i class="fa fa-caret-left"></i> چنانچه در دیدگاه خود از شماره تماس، ایمیل و آیدی تلگرام استفاده کرده باشید تایید نخواهد شد.</li>
                    <li><i class="fa fa-caret-left"></i> چنانچه دیدگاهی بی ارتباط با موضوع آموزش مطرح شود تایید نخواهد شد.</li>
                </ul>', 'sigma-theme' ),
				'condition' => [ 'active_role_comments' => 'yes', ],
			]
		);
		
        $this->end_controls_section();       
        
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Comment Role', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cm_role_box_bg',
				'label' => __( 'Comment Box Roles Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .role-comment.role-comment-elementor ',
				'condition' => [ 'active_role_comments' => 'yes', ],
			]
		);

		$this->add_control(
			'cm_role_box_arrow_color',
			[
				'label' => __( 'Comment Box Roles Arrow Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .role-comment.role-comment-elementor ul li:before' => 'color: {{VALUE}}',
				],			
				'default' => '#555555',
				'condition' => [ 'active_role_comments' => 'yes', ],
			]
		);

		$this->add_control(
			'cm_role_box_arrow_size',
			[
				'label' => __( 'Comment Box Roles Arrow Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .role-comment.role-comment-elementor ul li:before' => 'font-size:{{size}}px',
				],		
				'condition' => [ 'active_role_comments' => 'yes', ],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .role-comment.role-comment-elementor',
				'condition' => [ 'active_role_comments' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .role-comment.role-comment-elementor',
                'condition' => [ 'active_role_comments' => 'yes', ],					
			]
		);
		
        $this->end_controls_section();       
        
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            echo'<div class="role-comment role-comment-elementor darkeble">';
            echo $settings['comment_role_text'];
            echo '</div>';
        }
        else
        {
            echo'<div class="role-comment role-comment-elementor darkeble">';
            echo $settings['comment_role_text'];
            echo '</div>';
        }
    }
}