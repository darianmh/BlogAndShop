<div class="last__posts__colhv2 grid_posts_sgm">
    <div class="sgm_post_s2_area darkeble">
        <?php global $sigma;
        if ($sigma['show_img_loop_v2'] == 'enable') {
            ?>
            <a href="<?php the_permalink() ?>">
                <?php the_post_thumbnail('blog'); ?>
            </a>
        <?php } ?>
        <div class="card__post__hv2">
            <?php if ($sigma['show_title_loop_v2'] == 'enable') { ?>
                <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
            <?php }
            if ($sigma['show_desc_loop_v2'] == 'enable') {
                ?>
                <p>
                    <?php echo wp_trim_words(get_the_content(), 30, '...'); ?>
                </p>
            <?php }
            if ($sigma['show_btn_loop_v2'] == 'enable') { ?>
                <a class="readmore" href="<?php the_permalink() ?>"><?php _e('more details', 'sigma-theme'); ?></a>
            <?php } ?>
        </div>
        <?php if ($sigma['show_avatar_loop_v2'] == 'enable') { ?>
            <div class="card__post__hv2_avatar">
                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>"
                   target="_blank">
                    <?php echo get_avatar(get_the_author_meta('email'), '60'); ?>
                </a>
            </div>
        <?php } ?>

        <div class="card__post__hv2__meta">

            <?php
            if ($sigma['show_date_loop_v2'] == 'enable') {
                echo get_the_date('l j F Y');
            }
            if ($sigma['show_comments_loop_v2'] == 'enable') {
                ?>
                <span class="comment__nummber">
                        <?php
                        $css_class = 'zero-comments';
                        $number = (int)get_comments_number(get_the_ID());

                        if (1 === $number)
                            $css_class = 'one-comment';
                        elseif (1 < $number)
                            $css_class = 'multiple-comments';

                        comments_popup_link(
                            __('No Comment', 'sigma-theme'),
                            __('1 Comment', 'sigma-theme'),
                            __('% Comments', 'sigma-theme'),
                            $css_class,
                            __('Comments are Closed', 'sigma-theme')
                        );
                        ?>
                    </span>
            <?php } ?>
        </div>

    </div>
</div>