<card class="fss_last_blog_card darkeble">
    <figure class="fss_last_blog_photo"
            style="background: url(<?php the_post_thumbnail_url(); ?>) center center / cover no-repeat;">
        <img src="<?php the_post_thumbnail_url(); ?>" style="display:none">
    </figure>
    <div class="fss_last_blog_box">
        <div class="fss_last_blog_date"><i class="fal fa-clock"></i>
            <?php the_time('j F'); ?>
        </div>
        <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><h3><?php the_title(); ?></h3></a>
        <p>
            <?php echo wp_trim_words(get_the_content(), 40, '...'); ?>
        </p>
        <div class="fss_last_blog_more">
            <a href="<?php the_permalink() ?>"><?php _e('more details', 'sigma-theme'); ?></a>
        </div>
    </div>
    <div class="fss_last_blog_meta">
        <div class="row">
            <div class="col-3 nopadding-left">
                <p><i class="fal fa-eye"></i>
                    <?php echo getPostViews(get_the_ID()); ?>
                </p>
            </div>
            <div class="col-5 fss_post_cat nopadding">
                <p><i class="fal fa-file"></i>
                    <?php the_category(', ') ?>
                </p>
            </div>
            <div class="col-4 nopadding-right">
                <p><i class="fal fa-user"></i>
                    <?php echo get_the_author_meta('display_name'); ?>
                </p>
            </div>
        </div>
    </div>
</card>