<?php
namespace Elementor;

class Vertical_Menu extends Widget_Base {

	public function get_name() {
		return 'vertical-menu';
	}

	public function get_title() {
		return __( 'Menu Vertical', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}

    public function get_menus(){
        $list = [];
        $menus = wp_get_nav_menus();
        foreach($menus as $menu){
            $list[$menu->slug] = $menu->name;
        }

        return $list;	
    }
    
   protected function _register_controls() {

		$this->start_controls_section(
			'section_vertical_menu',
			[
				'label' => __( 'Menu Vertical', 'sigma-theme' ),
			]
		); 
		
        $this->add_control(
            'sigma_vertical_menu',
            [
                'label'     =>esc_html__( 'Select Menu', 'sigma-theme' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->get_menus(),
            ]
		);

		$this->add_control(
			'vertical_menu_title',
			[
				'label' => __( 'Vertical Menu Title', 'sigma-theme' ),
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Vertical Menu Title', 'sigma-theme' ),
                'default' => __( 'Vertical Menu Title', 'sigma-theme' ),
			]
		);
		
		
		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_sigma_footer_menu',
        	[
				'label' => __( 'Menu Item', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Vertical Menu Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_sigma_footer ul li a',
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vertical_title_menu_type',
				'label' => __( 'Vertical Menu Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_sigma_footer h5',
			]
		);	

		$this->add_control(
			'color_logged_in',
			[
				'label' => __( 'Vertical Menu Title Dot Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sigma_footer h5:after' => 'background: {{VALUE}}',
				],			
				'default' => '#9bc7c7'
			]
		);
		
		$this->add_control(
			'sigma_vertical_menu_title_color',
			[
				'label' => __( 'Vertical Menu Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sigma_footer h5' => 'color: {{VALUE}}',
				],				
				'default' => '#333333'
			]
		);
		
		$this->add_control(
			'item_footer_menu_color',
			[
				'label' => __( 'Vertical Menu Item Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sigma_footer ul li a' => 'color: {{VALUE}}',
				],	
                'default' => '#737373',
			]
		);

		$this->add_control(
			'item_footer_menu_hover_color',
			[
				'label' => __( 'Vertical Menu Item Hover Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_sigma_footer ul li a:hover' => 'color: {{VALUE}}',
				],	
                'default' => '#de9412',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'vertical_menu_hover_icon',
				'label' => __( 'Vertical Menu Hover Icon Color', 'sigma-theme' ),
				'types' => [ 'classic' ],
				'selector' => '{{WRAPPER}} .dgs_sigma_footer ul li a:after',
                'default' => '#f3f3f3',
			]
		);
		
		$this->end_controls_section();	
		
    }


	protected function render() {
        $settings = $this->get_settings();
        extract( $settings );
            ?>
            <div class="sigma-vertical-menu dgs_sigma_footer">
            <h5><?php echo $settings['vertical_menu_title']; ?></h5>
                <nav class="sigma-main-menu-nav" role="navigation">
                <?php
                    $args = array(
                        'container_class' => 'collapse navbar-collapse no-padding',
                        'fallback_cb' => '',
        				'menu'         	  => $settings['sigma_vertical_menu'],
                    );
                    wp_nav_menu($args);
                ?>
                
                </nav>
            </div>
            <?php

    }
}    
