<?php
namespace Elementor;

class Header_Contact_Information extends Widget_Base {
	
	public function get_name() {
		return 'header-information-widget';
	}
	
	public function get_title() {
		return __( 'Header Contact Information', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-email-field';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}
	
	protected function _register_controls() {
        
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Header Contact Information', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'sigma_select_header_information',
			[
				'label'   => esc_html__( 'Select Header Information Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_head_inf',
				'options' => [
                    'style01_head_inf' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_head_inf' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_head_inf' => esc_html__('Style 03', 'sigma-theme'),
                ],
			]
        );

		$this->add_control(
			'sigma_select_header_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/header_information_style_01.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_header_information' => 'style01_head_inf',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_select_header_style02',
			[
				'raw' => '<img  
				    class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/header_information_style_02.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_header_information' => 'style02_head_inf',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_select_header_style03',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/headers/header_information_style_03.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      				
			]
		);        

		$this->add_control(
			'list_icon_information',
			[
				'label' => __( 'List', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text_prefix',
						'label' => __( 'Text Suffix', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Text Suffix Item', 'sigma-theme' ),
						'default' => '021-',
					],
					[
						'name' => 'text_suffix',
						'label' => __( 'Text Prefix', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Text Prefix Item', 'sigma-theme' ),
						'default' => '33450444',
					],					
					[
						'name' => 'link_item_information',
						'label' => __( 'Link Item Information', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => __( 'https://your-link.com', 'sigma-theme' ),
        				'default' => [
        					'url' => 'tell://+982133450444',
        				]						
					],
					[
						'name' => 'icon_item_information',
						'label' => __( 'Item Information Icon', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
						'default' => [ 'value' => 'far fa-microphone-alt', 'library' => 'regular', ],
					],					
				],
				'default' => [
					[
						'text_prefix' => '021-',
						'text_suffix' => '33459000',
						'link_item_information' => 'tell://+982133450444',
						'icon_item_information' => [ 'value' => 'far fa-microphone-alt', 'library' => 'regular', ],
					],
					[
						'text_prefix' => __( 'info@', 'sigma-theme' ),
						'text_suffix' => __( 'hamakrwp.com', 'sigma-theme' ),
						'link_item_information' => 'mailto://info@hamkarwp.com',
						'icon_item_information' => [ 'value' => 'far fa-at', 'library' => 'regular', ],
					],
				],
				'title_field' => '{{{ text_suffix }}}',
			]
		);


		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Header Contact Information', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

        $this->add_control(
			'header_information_alignment',
			[
				'label' => __( 'Header Information Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .sgm_information_header ' => 'text-align: {{VALUE}};'
                ],				
			]
		);		
		$this->add_control(
			'icon_color_s1',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#6f6b6b',
				'selectors' => [
					'{{WRAPPER}} .top-contact-v1 span a i' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style01_head_inf',
                ],      
			]
		);

		$this->add_control(
			'icon_color_s2',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#333',
				'selectors' => [
					'{{WRAPPER}} .top-contact-v2 span a i' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style02_head_inf',
                ],      				
			]
		);

		$this->add_control(
			'icon_color_s3',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#fca803',
				'selectors' => [
					'{{WRAPPER}} .dgs_information_topbar a i' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      				
			]
		);

		$this->add_control(
			'icon_v1_typography',
			[
				'label' => __( 'Information Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .top-contact-v1 span a i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [
                    'sigma_select_header_information' => 'style01_head_inf',
                ],      
			]
		);

		$this->add_control(
			'icon_v2_typography',
			[
				'label' => __( 'Information Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .top-contact-v2 span a i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [
                    'sigma_select_header_information' => 'style02_head_inf',
                ],      
			]
		);

		$this->add_control(
			'icon_v3_typography',
			[
				'label' => __( 'Information Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 13,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_information_topbar a i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      
			]
		);		
		$this->add_control(
			'meta_color_s1',
			[
				'label' => __( 'Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#6f6b6b',
				'selectors' => [
					'{{WRAPPER}} .top-contact-v1 span a' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style01_head_inf',
                ],      
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_color_type',
				'label' => __( 'Text Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .top-contact-v1 span a',
                'condition' => [
                    'sigma_select_header_information' => 'style01_head_inf',
                ],      				
			]
		);

		$this->add_control(
			'meta_color_s2',
			[
				'label' => __( 'Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#333333',
				'selectors' => [
					'{{WRAPPER}} .top-contact-v2 span a' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style02_head_inf',
                ],      				
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_color_s2_type',
				'label' => __( 'Text Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .top-contact-v2 span a',
                'condition' => [
                    'sigma_select_header_information' => 'style02_head_inf',
                ],      				
			]
		);
		
		$this->add_control(
			'prefix_color_s3',
			[
				'label' => __( 'Prefix Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#f99432',
				'selectors' => [
					'{{WRAPPER}} .dgs_information_topbar p b' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      				
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_color_prefix_s3_type',
				'label' => __( 'Prefix Text Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_information_topbar p b',
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      				
			]
		);
		
		$this->add_control(
			'suffix_color_s3',
			[
				'label' => __( 'Suffix Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#8a8a8a',
				'selectors' => [
					'{{WRAPPER}} .dgs_information_topbar p' => 'color: {{VALUE}}',
				],		
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      				
			]
		);			

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_color_suffix_s3_type',
				'label' => __( 'Suffix Text Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_information_topbar p',
                'condition' => [
                    'sigma_select_header_information' => 'style03_head_inf',
                ],      				
			]
		);        
		
		$this->add_control(
			'information_row_gap_right',
			[
				'label'   => esc_html__( 'Information Margin Right', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .information_topbar , .dgs_information_topbar ' => 'margin-right:{{SIZE}}px',
				],
			]
		);

		$this->add_control(
			'information_row_gap_left',
			[
				'label'   => esc_html__( 'Information Margin Left', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .information_topbar , .dgs_information_topbar ' => 'margin-left:{{SIZE}}px',
				],
			]
		);
		
		$this->end_controls_section();
				
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		echo'<div class="sgm_information_header">';
        foreach ( $settings['list_icon_information'] as $index => $item ) :
        if($settings['sigma_select_header_information'] == 'style01_head_inf' && !empty($settings['sigma_select_header_information'])){    
	        echo '<div class="top-contact-v1 information_topbar"><span ><a href="'.$item['link_item_information']['url'].'">'.$item['text_prefix'].''.$item['text_suffix'].''?><?php \Elementor\Icons_Manager::render_icon( $item['icon_item_information'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</a></span></div>'; 
        }
        if($settings['sigma_select_header_information'] == 'style02_head_inf') {
            echo '<div class="top-contact-v2 information_topbar"><span ><a href="'.$item['link_item_information']['url'].'">'.$item['text_prefix'].''.$item['text_suffix'].''?><?php \Elementor\Icons_Manager::render_icon( $item['icon_item_information'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</a></span></div>'; 
        }
        if($settings['sigma_select_header_information'] == 'style03_head_inf') {
            echo '<div class="dgs_phone_topbar dgs_information_topbar"><a href="'.$item['link_item_information']['url'].'">'?><?php \Elementor\Icons_Manager::render_icon( $item['icon_item_information'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'<p><b>'.$item['text_prefix'].'</b>'.$item['text_suffix'].'</p></a></div>'; 
        }      
		endforeach;
		echo '</div>';
	}
	
}