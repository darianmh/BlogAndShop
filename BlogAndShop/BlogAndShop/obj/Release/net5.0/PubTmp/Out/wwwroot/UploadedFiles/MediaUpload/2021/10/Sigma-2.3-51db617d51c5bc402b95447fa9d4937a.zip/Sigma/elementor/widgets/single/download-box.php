<?php
namespace Elementor;

class Download_Box extends Widget_Base {
	
	public function get_name() {
		return 'download-box';
	}
	
	public function get_title() {
		return  __( 'Download Box', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-download-button';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {

        $this->start_controls_section(
        	'section_content',
        	[
				'label' => __( 'Download Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'active_dl_box',
			[
				'label'   => esc_html__( 'Active Download Box', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'dl_box_img',
                   [
                    'label' => __( 'Choose Download Box Image', 'sigma-theme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'dynamic' => [
                                  'active' => true,
                                 ],
                    'default' => [
                     'url' => get_template_directory_uri() . '/assets/img/download.png',
                    ],
                    'condition' => [ 'active_dl_box' => 'yes', ],
                  ]
		);

 		$this->add_control(
			'dl_box_title',
			[
                'label' => __( 'Download Box Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Download Box Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],
                'default' => __( 'Download and more information', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'dl_box_roles',
			[
				'label' => __( 'Download Box Note', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<div class="license"><ul> <li>جهت دانلود سریع از VPN استفاده نکنید..</li> <li>تمامی فایل ها قبل از درج بررسی شده اند.</li> <li>لینک دانلود از دو سرور مختلف است.</li> <li>امکان قطع دانلود فایل ها وجود دارد.</li> <li>جهت دانلود از IDM استفاده کنید..</li> <li>در صورت نیاز با ما تماس بگیرید.</li> </ul></div>', 'sigma-theme' ),
				'condition' => [ 'active_dl_box' => 'yes', ],
			]
		);		

		$this->add_control(
			'dl_box_active_meta',
			[
				'label'   => esc_html__( 'Active Meta Download Box', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'active_dl_box' => 'yes', ],
			]
		);

		$this->add_control(
			'dl_box_active_more_meta',
			[
				'label'   => esc_html__( 'Active More Meta Download Box', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'active_dl_box' => 'yes', ],
			]
		);
		
        $this->end_controls_section();
        
        
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Download Box Main Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'active_dl_box' => 'yes', ],
        	]
        );	 

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} span.title-dlbox' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'active_dl_box' => 'yes', ], 	
				'default' => '#666666'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_type',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} span.title-dlbox',
				'condition' => [ 'active_dl_box' => 'yes', ], 	
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .dl_box_siderbar',
				'condition' => [ 'active_dl_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .dl_box_siderbar',
                'condition' => [ 'active_dl_box' => 'yes', ],					
			]
		);
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'dl_btn_s1',
        	[
				'label' => __( 'Server 01 Link Dowloads', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

 		$this->add_control(
			'dl_btn_s1_title',
			[
				'label' => __( 'Server 01 Link Dowloads Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Server 01 Link Dowloads Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],					
                'default' => __( 'Download direct link (server 1)', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'dl_btn_bg_s1',
			[
				'label' => __( 'Server 01 Link Dowloads Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .dl_server1' => 'background: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#9C27B0'
			]
		);

		$this->add_control(
			'dl_btn_color_s1',
			[
				'label' => __( 'Server 01 Link Dowloads Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dl_server1' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dl_btn_type_s1',
				'label' => __( 'Server 01 Link Dowloads Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dl_server1 ',
                'condition' => [ 'active_dl_box' => 'yes', ],					
			]
		);
		
        $this->end_controls_section();   
        
        $this->start_controls_section(
        	'dl_btn_s2',
        	[
				'label' => __( 'Server 02 Link Dowloads', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

 		$this->add_control(
			'dl_btn_s2_title',
			[
				'label' => __( 'Server 02 Link Dowloads Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Server 02 Link Dowloads Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],					
                'default' => __( 'Download direct link (server 2)', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'dl_btn_bg_s2',
			[
				'label' => __( 'Server 02 Link Dowloads Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .dl_server2' => 'background: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#dc5462'
			]
		);

		$this->add_control(
			'dl_btn_color_s2',
			[
				'label' => __( 'Server 02 Link Dowloads Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dl_server2' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dl_btn_type_s2',
				'label' => __( 'Server 02 Link Dowloads Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dl_server2 ',
                'condition' => [ 'active_dl_box' => 'yes', ],					
			]
		);
		
        $this->end_controls_section();           
        
        $this->start_controls_section(
        	'dl_btn_s3',
        	[
				'label' => __( 'Creator Site Button', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

 		$this->add_control(
			'dl_btn_s3_title',
			[
				'label' => __( 'Creator Site Button Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Creator Site Button Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],					
                'default' => __( 'Go To Creator Site', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'dl_btn_bg_s3',
			[
				'label' => __( 'Creator Site Button Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .siteurl' => 'background: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#FF9800'
			]
		);

		$this->add_control(
			'dl_btn_color_s3',
			[
				'label' => __( 'Creator Site Button Dowloads Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .siteurl' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dl_btn_type_s3',
				'label' => __( 'Creator Site Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .siteurl ',
                'condition' => [ 'active_dl_box' => 'yes', ],					
			]
		);
        $this->end_controls_section();           

        $this->start_controls_section(
        	'dl_btn_s4',
        	[
				'label' => __( 'Password Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

 		$this->add_control(
			'dl_btn_s4_title',
			[
				'label' => __( 'Password Meta Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Password Meta Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],					
                'default' => __( 'File Password', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'dl_btn_s4_icon',
			[
				'label' => __( 'Password Meta Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-lock',
					'library' => 'light',
				],
			]
		);
		
		$this->add_control(
			'dl_btn_bg_s4',
			[
				'label' => __( 'Password Meta Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .password_file' => 'background: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#fafafc'
			]
		);

		$this->add_control(
			'dl_btn_color_s4',
			[
				'label' => __( 'Password Meta Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cpassword_file' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dl_btn_type_s4',
				'label' => __( 'Password Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .cpassword_file ',
                'condition' => [ 'active_dl_box' => 'yes', ],					
			]
		);


		$this->add_control(
			'dl_btn_type_icon_size',
			[
				'label' => __( 'Password Meta Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .password_file i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [ 'active_dl_box' => 'yes', ],
			]
		);

		$this->add_control(
			'dl_btn_type_icon_color',
			[
				'label' => __( 'Password Meta Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .password_file i' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#777777'
			]
		);
		
        $this->end_controls_section();           

        $this->start_controls_section(
        	'dl_btn_s5',
        	[
				'label' => __( 'Size & Type Meta', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

 		$this->add_control(
			'dl_btn_s5_title',
			[
				'label' => __( 'Size Meta Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Size Meta Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],					
                'default' => __( 'File Size', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'dl_btn_s5_icon',
			[
				'label' => __( 'Size Meta Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-image',
					'library' => 'light',
				],
			]
		);
		
		$this->add_control(
			'dl_btn_s6_title',
			[
				'label' => __( 'Size Type Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Size Type Title', 'sigma-theme' ),
                'condition' => [ 'active_dl_box' => 'yes', ],					
                'default' => __( 'Type', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'dl_btn_s6_icon',
			[
				'label' => __( 'Password Type Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-file',
					'library' => 'light',
				],
			]
		);
		
		$this->add_control(
			'dl_btn_bg_s5',
			[
				'label' => __( 'Size Meta Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .info-box-dt' => 'background: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#fafafc'
			]
		);

		$this->add_control(
			'dl_btn_color_s5',
			[
				'label' => __( 'Size Meta Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .info-box-dt span' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dl_btn_type_s5',
				'label' => __( 'Size Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .info-box-dt p , .info-box-dt strong ',
                'condition' => [ 'active_dl_box' => 'yes', ],					
			]
		);


		$this->add_control(
			'dl_btn_type_icon_size_s5',
			[
				'label' => __( 'Size Meta Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .info-box-dt i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [ 'active_dl_box' => 'yes', ],
			]
		);

		$this->add_control(
			'dl_btn_type_icon_color_s5',
			[
				'label' => __( 'Size Meta Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .info-box-dt i' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'active_dl_box' => 'yes', ],					
				'default' => '#777777'
			]
		);
		
        $this->end_controls_section();  
        
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        $dl_link01 = get_post_meta($template->GetRelatedPostId(),"dl_server1",true);
        $dl_link02 = get_post_meta($template->GetRelatedPostId(),"dl_server2",true);
        $dl_link03 = get_post_meta($template->GetRelatedPostId(),"siteurl",true);
        $dl_link04 = get_post_meta($template->GetRelatedPostId(),"password_file",true);
        $dl_link05 = get_post_meta($template->GetRelatedPostId(),"size",true);
        $dl_link06 = get_post_meta($template->GetRelatedPostId(),"type",true);        
        if($template->IsRealRender())
        {
            if($settings['active_dl_box'] == 'yes'){
            echo'<div class="post-sidebar dl_box_siderbar dl_box_siderbar_elementor"><img alt="" src="'.$settings['dl_box_img']['url'].'"><span class="title-dlbox">'.$settings['dl_box_title'].'</span>'.$settings['dl_box_roles'].'';?>
            <?php if($settings['dl_box_active_meta'] == 'yes'){
            if(isset($dl_link01) && !empty($dl_link01)) {
            echo'<div class="dl_server1"> <div class="dl_server1"><a href="'.$dl_link01.'" target="_blank" class="dl_server1">'.$settings['dl_btn_s1_title'].'</a></div> </div>'; ?>
            <?php } ?>
            
            <?php 
            if(isset($dl_link02) && !empty($dl_link02)) {
            echo'<div class="dl_server2"> <div class="dl_server2"><a href="'.$dl_link02.'" target="_blank" class="dl_server2">'.$settings['dl_btn_s2_title'].'</a></div> </div>'; ?>
            <?php } ?>
            
            <?php 
            if(isset($dl_link03) && !empty($dl_link03)) {
            echo'<div class="siteurl"> <div class="siteurl"><a href="'.$dl_link02.'" target="_blank" class="siteurl">'.$settings['dl_btn_s3_title'].'</a></div> </div> '; ?>
            <?php } ?>
            
            <?php 
            if(isset($dl_link04) && !empty($dl_link04)) {
            echo'<div class="password_file"> <div class="password_file2">'?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['dl_btn_s4_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php echo'<span class="cpassword_file">'.$settings['dl_btn_s4_title'].' '.$dl_link04.'</span></div> </div>' ;?>
            <?php }
            
            if($settings['dl_box_active_more_meta'] == 'yes'){ ?>
            <?php echo'<div class="info-box-dt">'; ?>
            
            <?php
            if(isset($dl_link05) && !empty($dl_link05)) {
            echo'<span class="date">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['dl_btn_s5_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo'
            <p>'.$settings['dl_btn_s5_title'].'</p><strong>'.$dl_link05.'</strong></span>';?>
            <?php } ?>

            <?php
            if(isset($dl_link06) && !empty($dl_link06)) {            
            echo'<span class="date">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['dl_btn_s6_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo'
            <p>'.$settings['dl_btn_s6_title'].'</p><strong>'.$dl_link06.'</strong></span>'; ?>
            <?php } 
            echo'</div>';
            } ?>
            
            <?php echo'</div>'; ?>
            
            <?php
            }
            }    
        }    
        else
        {
            if($settings['active_dl_box'] == 'yes'){
            echo'<div class="post-sidebar dl_box_siderbar dl_box_siderbar_elementor"><img alt="" src="'.$settings['dl_box_img']['url'].'"><span class="title-dlbox">'.$settings['dl_box_title'].'</span>'.$settings['dl_box_roles'].''?>
            <?php if($settings['dl_box_active_meta'] == 'yes'){
            echo'<div class="dl_server1"> <div class="dl_server1"><a href="'.$dl_link01.'" target="_blank" class="dl_server1">'.$settings['dl_btn_s1_title'].'</a></div> </div> <div class="dl_server2"> <div class="dl_server2"><a href="'.$dl_link02.'" target="_blank" class="dl_server2">'.$settings['dl_btn_s2_title'].'</a></div> </div> <div class="siteurl"> <div class="siteurl"><a href="'.$dl_link02.'" target="_blank" class="siteurl">'.$settings['dl_btn_s3_title'].'</a></div> </div> <div class="password_file" style="display:inherit"> <div class="password_file2">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['dl_btn_s4_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo'<span class="cpassword_file">'.$settings['dl_btn_s4_title'].' www.hamkarwp.com</span></div> </div> <div class="info-box-dt"> <span class="date">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['dl_btn_s5_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo'<p>'.$settings['dl_btn_s5_title'].'</p><strong>128 مگابایت </strong></span> <span class="date">'?> <?php \Elementor\Icons_Manager::render_icon( $settings['dl_btn_s6_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo'<p>'.$settings['dl_btn_s6_title'].'</p><strong>zip </strong></span> </div> </div>' ?>
            <?php }
            }
        }
    }
}