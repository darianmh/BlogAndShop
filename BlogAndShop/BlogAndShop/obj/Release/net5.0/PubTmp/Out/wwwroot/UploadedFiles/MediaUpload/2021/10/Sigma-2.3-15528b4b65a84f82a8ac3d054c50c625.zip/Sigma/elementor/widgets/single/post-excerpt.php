<?php
namespace Elementor;

class Post_Excerpt extends Widget_Base {
	
	public function get_name() {
		return 'post-excerpt';
	}
	
	public function get_title() {
		return __( 'Single Excerpt', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-post-excerpt';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Single Excerpt', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
		
		$this->add_control(
			'active_excerpt',
			[
				'label'   => esc_html__( 'Active Excerpt', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

        $this->add_control(
            'post_excerpt_title',
            [
				'label' => __( 'Post Excerpt Title', 'sigma-theme' ),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Post Excerpt Title', 'sigma-theme' ),
                'default' => __( 'Excerpt This Content:', 'sigma-theme' ),
            ]
        );

		$this->add_control(
			'post_excerpt_height',
			[
				'label' => __( 'Post Excerpt Height', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 250,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .entry-excrept ' => 'height:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            if($settings['active_excerpt'] == 'yes'){    
            $content = get_the_excerpt($template->GetRelatedPostId(),10,10);
            echo "<div class='postholder postholder_elementor entry-content entry-excrept'><h3>".$settings['post_excerpt_title']."</h3>".$content."</div>";
            }
        }
        else
        {   
            if($settings['active_excerpt'] == 'yes'){    
            echo "<div class='entry-excrept '><p class='entry-content-sample'>محل قرار گیری چکیده مطالب سایت شما</p>";
            echo "<div class='load-item-content'>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";          
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";
            echo "<span class='load-item-content-index'></span>";                 
            echo "</div></div>";
            }
        }
    }
}