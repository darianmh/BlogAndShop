<?php
namespace Elementor;

class Main_Best_Seller extends Widget_Base {
	
	public function get_name() {
		return 'best-seller';
	}
	
	public function get_title() {
		return  __( 'Best Seller', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-user-preferences';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_best_seller_content',
			[
				'label' => __( 'Best Seller', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'best_seller_fa_title',
			[
				'label' => __( 'Persian Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Best Seller Persian Title Enter', 'sigma-theme' ),
                'default' => __( 'Best Seller In This Week', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'best_seller_en_title',
			[
				'label' => __( 'English Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Best Seller English Title Enter', 'sigma-theme' ),
                'default' => __( 'Best Seller', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'best_sellet_goshop_btn',
			[
				'label' => __( 'Go To Shop Button', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Go To Shop Button Enter', 'sigma-theme' ),
                'default' => __( 'See Shop', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'show_title_seller',
			[
				'label'     => esc_html__( 'Show Avatar Name', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);		
		
		$this->add_control(
			'show_avatar_seller',
			[
				'label'     => esc_html__( 'Show Seller Avatar', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);	
		
		$this->add_control(
			'show_icons_seller',
			[
				'label'     => esc_html__( 'Show Social Icon', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);	
		
		$this->add_control(
			'show_decripsion_seller',
			[
				'label'     => esc_html__( 'Show Decription Seller', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);	

		$this->add_control(
			'show_badge_seller',
			[
				'label'     => esc_html__( 'Show Badge Seller', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);	

		$this->add_control(
			'show_goshop_seller',
			[
				'label'     => esc_html__( 'Show Go To Shop', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
			]
		);	
		
		$this->end_controls_section();
		
				
        $this->start_controls_section(
        	'style_section_best_seller',
        	[
				'label' => __( 'Best Seller Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'best_seller_bg',
				'label' => __( 'Best Seller Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fas_best_seller',
			]
		);

		$this->add_control(
			'best_seller_title_color',
			[
				'label' => __( 'Best Seller Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_meta .fss_specials_products_title h3' => 'color: {{VALUE}}',
				],			
				'default' => '#FFC107'
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'best_seller_title_typography',
				'label' => __( 'Best Seller Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fas_best_seller_meta .fss_specials_products_title h3',
			]
		);
		
		$this->add_control(
			'best_seller_entitle_color',
			[
				'label' => __( 'Best Seller English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fss_specials_products_title small' => 'color: {{VALUE}}',
				],			
				'default' => '#FFFFFF'
			]
		);	
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'best_seller_entitle_typography',
				'label' => __( 'Best Seller English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_specials_products_title small',
			]
		);			
		
		
		$this->add_control(
			'title_icon_size',
			[
				'label' => __( 'Title Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 61,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_meta .fss_specials_products_title:after ' => 'font-size:{{SIZE}}px',
				],
			]
		);
				
		$this->add_control(
			'title_icon_color',
			[
				'label' => __( 'Title Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_meta .fss_specials_products_title:after' => 'color: {{VALUE}}',
				],			
				'default' => '#fdbf07'
			]
		);	
		
        $this->end_controls_section();       		

		
        $this->start_controls_section(
        	'seller_name',
        	[
				'label' => __( 'Seller', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'seller_name_color',
			[
				'label' => __( 'Seller Name Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_name h4' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'seller_name_typography',
				'label' => __( 'Seller Name Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fas_best_seller_name h4',
			]
		);

		$this->add_control(
			'seller_des_color',
			[
				'label' => __( 'Seller Description Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_name small' => 'color: {{VALUE}}',
				],			
				'default' => '#c5c5c5'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'seller_des_typography',
				'label' => __( 'Seller Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fas_best_seller_name small',
			]
		);

		$this->add_control(
			'seller_icon_size',
			[
				'label' => __( 'Seller Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_social ul li a i ' => 'font-size:{{SIZE}}px',
				],
			]
		);

		$this->add_control(
			'seller_icon_color',
			[
				'label' => __( 'Seller Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_social ul li a i' => 'color: {{VALUE}}',
				],			
				'default' => '#a7a7a7'
			]
		);
		
		$this->add_control(
			'seller_note_color',
			[
				'label' => __( 'Seller Note Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_name p' => 'color: {{VALUE}}',
				],			
				'default' => '#d4dfe4'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'seller_note_typography',
				'label' => __( 'Seller Note Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fas_best_seller_name p ',
			]
		);		

		$this->add_control(
			'go_shop_color',
			[
				'label' => __( 'Go Store Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_go_store a' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);		

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'go_shop_bg',
				'label' => __( 'Go Store Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fas_best_seller_go_store a ',
			]
		);

		$this->add_control(
			'go_store_icon_size',
			[
				'label' => __( 'Go Store Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 17,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_go_store a i ' => 'font-size:{{SIZE}}px',
				]
			]
		);

		$this->add_control(
			'go_store_icon_color',
			[
				'label' => __( 'Go Store Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fas_best_seller_go_store a i ' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);
		
        $this->end_controls_section();       
        
		
        $this->start_controls_section(
        	'product_style_section',
        	[
				'label' => __( 'Products', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
		$this->add_control(
			'gp_title_s4_color',
			[
				'label' => __( 'Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seo h2' => 'color: {{VALUE}}',
				],			
				'default' => '#444444'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_title_s4_type',
				'label' => __( 'Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seo h2',
			]
		);	

		$this->add_control(
			'gp_entitle_s4_color',
			[
				'label' => __( 'English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_seo small' => 'color: {{VALUE}}',
				],			
				'default' => '#999999'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'gp_entitle_s4_type',
				'label' => __( 'English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_seo small',
			]
		);	

		$this->add_control(
			'price_color_s4',
			[
				'label' => __( 'Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_price ul li:first-child p' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_type',
				'label' => __( 'Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_price ul li',
			]
		);	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'price_bg_s4',
				'label' => __( 'Price Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fss_card_products_price',
			]
		);

		$this->add_control(
			'cat_s4_color',
			[
				'label' => __( 'Category Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_price ul li:last-child a' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_s4_typography',
				'label' => __( 'Category Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_price ul li:last-child a ',
            ]
		);	

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cat_s4_bg',
				'label' => __( 'Category Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fss_card_products_price ul li:last-child',
			]
		);

		$this->add_control(
			'sales_icons_size_s4',
			[
				'label' => __( 'Sales Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_sale i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		$this->add_control(
			'sales_icons_color_s4',
			[
				'label' => __( 'Sales Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_sale i ' => 'color: {{VALUE}}',
				],			
				'default' => '#999999'
			]
		);

		$this->add_control(
			'sales_count_color_s4',
			[
				'label' => __( 'Sales Counter Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_sale ' => 'color: {{VALUE}}',
				],			
				'default' => '#999999'
			]
		);		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sales_count_type_s4',
				'label' => __( 'Sales Counter Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fss_card_products_sale ',
			]
		);	

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'add_cart_s4_bg',
				'label' => __( 'Add To Cart Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .fss_card_products_buy a',
			]
		);

		$this->add_control(
			'add_cart_s4_color',
			[
				'label' => __( 'Add To Cart Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .fss_card_products_buy a' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);
		
        $this->end_controls_section();       
        
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		echo '<div class="fas_best_seller">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="fas_best_seller_meta">
                        <div class="fss_specials_products_title">
                        <h3>'.$settings['best_seller_fa_title'].'</h3>
                        <small>'.$settings['best_seller_en_title'].'</small>
                        </div>' ?>
                        <?php
                        if($settings['show_avatar_seller'] == 'yes' ){  ?>
                        <div class="fas_best_seller_photo">
                            <img src="http://storefile.eu/sigma/wp-content/themes/Sigma/assets/img/hamkarwp-logo.png">
                        </div>
                        <?php } ?>
                        <div class="fas_best_seller_name">
                        <?php
                        if($settings['show_title_seller'] == 'yes' ){  ?>                            
                            <h4>همکار وردپرس</h4>
                            <small>همکار وردپرسی شما...</small>
                        <?php }   
                        if($settings['show_icons_seller'] == 'yes' ){  ?>
                        <div class="fas_best_seller_social">
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fab fa-telegram"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                            </ul>
                        </div>
                        <?php }   
                        if($settings['show_decripsion_seller'] == 'yes' ){ ?> 
                        <p>تیم همکار وردپرس با 6 سال تجربه و تخصص در زمینه طراحی و کدنویسی سایت و وردپرس تلاش میکند تا بهترین قالب های وردپرس را برای شما عزیزان آماده کند. تخصص در کنار پشتیبانی عالی از ویژگی های این تیم فوق العاده می باشد.</p>
                        <?php }  ?>
                        
                        </div>
                        <?php if($settings['show_badge_seller'] == 'yes' ){ ?>
                        <div class="list_curses_badge">
                            <div class="edc_badges edc_badges_signle">
                                <ul>
                                    <li id="hexagon" class="badge_singel pink_badge"><i class="far fa-user-crown"></i><span class="badge-tooltip">۱۲ سال عضویت</span></li>
                                    <li id="hexagon" class="badge_singel yellow_badge"><i class="far fa-bullseye-pointer"></i><span class="badge-tooltip">۱۰ تا ۲۰ خرید </span></li>
                                    <li id="hexagon" class="badge_singel blue_badge"><i class="far fa-book-reader"></i><span class="badge-tooltip">۲ دوره آموزشی</span></li>
                                    <li id="hexagon" class="badge_singel green_badge"><i class="far fa-browser"></i><span class="badge-tooltip">آموزش ویژه</span></li>
                                                                        <li id="hexagon" class="badge_singel pink_badge"><i class="far fa-user-crown"></i><span class="badge-tooltip">۱۲ سال عضویت</span></li>
                                    <li id="hexagon" class="badge_singel yellow_badge"><i class="far fa-bullseye-pointer"></i><span class="badge-tooltip">۱۰ تا ۲۰ خرید </span></li>
                                    <li id="hexagon" class="badge_singel blue_badge"><i class="far fa-book-reader"></i><span class="badge-tooltip">۲ دوره آموزشی</span></li>
                                    <li id="hexagon" class="badge_singel green_badge"><i class="far fa-browser"></i><span class="badge-tooltip">آموزش ویژه</span></li>
                                </ul>
                            </div>                
                        </div>   
                        <?php }
                        if($settings['show_goshop_seller'] == 'yes' ){ ?>
                        <div class="fas_best_seller_go_store">
                            <a href=""><i class="far fa-store"></i><?php echo $settings['best_sellet_goshop_btn']; ?></a>
                        </div>
                        <?php 
                        } echo'</div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="owl-carousel owl-theme fss_seller_product_gird " id="seller">
                    <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1120px;"><div class="owl-item active" style="width: 260px; margin-left: 20px;"><card class="fss_card_products darkeble">
                            <div class="fss_card_products_photo">
                                <a href="#"><img src="http://storefile.eu/sigma/wp-content/themes/Sigma/assets/img/flatsome.png"></a>
                            </div>
                            <div class="row">
                                <div class="col-9">
                                    <div class="fss_card_products_price">
                                        <ul>
                                            <li><b>79</b>هزار تومان</li>
                                            <li><a href="#">قالب وردپرس</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="npr npl col-3">
                                    <div class="fss_card_products_sale">
                                        <i class="fal fa-shopping-basket"></i>
                                        134
                                    </div>
                                </div>
                            </div>
                            <div class="fss_card_products_seo">
                                <a href=""><h2>قالب وردپرس چندمنظوره و فروشگاهی فلت سام</h2>
                                <small>Flatsome: Best selling theme</small></a>
                                <p style="display:none">پرفروش ترین قالب فروشگاهی تم فارست فارسی سازی اختصاصی تمام بخش&zwnj;ها به همراه ۹ فونت فارسی اختصاصی صفحه ساز بسیار قدرتمند با سرعت بارگذاری بسیار عالی طراحی بهینه برای موبایل</p>
                            </div>
                            <div class="fss_card_products_buy">
                                <a href="#"><i class="fal fa-shopping-bag"></i>خرید این محصول</a>
                            </div>
                        </card></div><div class="owl-item active" style="width: 260px; margin-left: 20px;"><card class="fss_card_products darkeble">
                            <div class="fss_card_products_photo">
                                <a href="#"><img src="http://storefile.eu/sigma/wp-content/themes/Sigma/assets/img/be.jpeg"></a>
                            </div>
                            <div class="row">
                                <div class="col-9">
                                    <div class="fss_card_products_price">
                                        <ul>
                                            <li><b>79</b>هزار تومان</li>
                                            <li><a href="#">قالب وردپرس</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="npr npl col-3">
                                    <div class="fss_card_products_sale">
                                        <i class="fal fa-shopping-basket"></i>
                                        134
                                    </div>
                                </div>
                            </div>
                            <div class="fss_card_products_seo">
                                <a href=""><h2>قالب وردپرس چندمنظوره و فروشگاهی فلت سام</h2>
                                <small>Flatsome: Best selling theme</small></a>
                                <p style="display:none">پرفروش ترین قالب فروشگاهی تم فارست فارسی سازی اختصاصی تمام بخش&zwnj;ها به همراه ۹ فونت فارسی اختصاصی صفحه ساز بسیار قدرتمند با سرعت بارگذاری بسیار عالی طراحی بهینه برای موبایل</p>
                            </div>
                            <div class="fss_card_products_buy">
                                <a href="#"><i class="fal fa-shopping-bag"></i>خرید این محصول</a>
                            </div>
                        </card></div><div class="owl-item" style="width: 260px; margin-left: 20px;"><card class="fss_card_products darkeble">
                            <div class="fss_card_products_photo">
                                <a href="#"><img src="http://storefile.eu/sigma/wp-content/themes/Sigma/assets/img/enfold.png"></a>
                            </div>
                            <div class="row">
                                <div class="col-9">
                                    <div class="fss_card_products_price">
                                        <ul>
                                            <li><b>79</b>هزار تومان</li>
                                            <li><a href="#">قالب وردپرس</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="npr npl col-3">
                                    <div class="fss_card_products_sale">
                                        <i class="fal fa-shopping-basket"></i>
                                        134
                                    </div>
                                </div>
                            </div>
                            <div class="fss_card_products_seo">
                                <a href=""><h2>قالب وردپرس چندمنظوره و فروشگاهی فلت سام</h2>
                                <small>Flatsome: Best selling theme</small></a>
                                <p style="display:none">پرفروش ترین قالب فروشگاهی تم فارست فارسی سازی اختصاصی تمام بخش&zwnj;ها به همراه ۹ فونت فارسی اختصاصی صفحه ساز بسیار قدرتمند با سرعت بارگذاری بسیار عالی طراحی بهینه برای موبایل</p>
                            </div>
                            <div class="fss_card_products_buy">
                                <a href="#"><i class="fal fa-shopping-bag"></i>خرید این محصول</a>
                            </div>
                        </card></div><div class="owl-item" style="width: 260px; margin-left: 20px;"><card class="fss_card_products darkeble">
                            <div class="fss_card_products_photo">
                                <a href="#"><img src="http://storefile.eu/sigma/wp-content/themes/Sigma/assets/img/avada.png"></a>
                            </div>
                            <div class="row">
                                <div class="col-9">
                                    <div class="fss_card_products_price">
                                        <ul>
                                            <li><b>79</b>هزار تومان</li>
                                            <li><a href="#">قالب وردپرس</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="npr npl col-3">
                                    <div class="fss_card_products_sale">
                                        <i class="fal fa-shopping-basket"></i>
                                        134
                                    </div>
                                </div>
                            </div>
                            <div class="fss_card_products_seo">
                                <a href=""><h2>قالب وردپرس چندمنظوره و فروشگاهی فلت سام</h2>
                                <small>Flatsome: Best selling theme</small></a>
                                <p style="display:none">پرفروش ترین قالب فروشگاهی تم فارست فارسی سازی اختصاصی تمام بخش&zwnj;ها به همراه ۹ فونت فارسی اختصاصی صفحه ساز بسیار قدرتمند با سرعت بارگذاری بسیار عالی طراحی بهینه برای موبایل</p>
                            </div>
                            <div class="fss_card_products_buy">
                                <a href="#"><i class="fal fa-shopping-bag"></i>خرید این محصول</a>
                            </div>
                        </card></div></div></div><div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div><div class="owl-dots disabled"></div></div>
                </div>
            </div>
        </div>
    </div>';  
	}
	
}