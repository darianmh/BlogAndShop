<?php
get_header();
get_template_part('template-part/headers/head'); ?>

<?php
/**
 * The Template for displaying all single posts.
 *
 * @package dokan
 * @package dokan - 2014 1.0
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

$store_user = dokan()->vendor->get(get_query_var('author'));
$store_info = $store_user->get_shop_info();
$map_location = $store_user->get_location();

get_header('shop');
?>

    <div class="container">

        <div class="breadcrumb_post">
            <?php
            $args = array(
                'delimiter' => ' <i></i> ',
                'home' => __('home', 'sigma-theme'));
            woocommerce_breadcrumb($args); ?>
        </div>

        <div id="dokan-primary" class="dokan-single-store dokan-w12">
            <div id="dokan-content" class="store-review-wrap woocommerce" role="main">

                <?php dokan_get_template_part('store-header'); ?>

                <div id="vendor-biography">
                    <div id="comments">
                        <?php do_action('dokan_vendor_biography_tab_before', $store_user, $store_info); ?>

                        <h2 class="headline"><?php echo apply_filters('dokan_vendor_biography_title', __('Vendor Biography', 'dokan')); ?></h2>

                        <?php
                        if (!empty($store_info['vendor_biography'])) {
                            echo $store_info['vendor_biography'];
                        }
                        ?>

                        <?php do_action('dokan_vendor_biography_tab_after', $store_user, $store_info); ?>
                    </div>
                </div>

            </div><!-- #content .site-content -->

        </div><!-- .dokan-single-store -->

        <div class="dokan-clearfix"></div>

        <?php do_action('woocommerce_after_main_content'); ?>

    </div>

<?php get_template_part('template-part/footers/footer');
get_footer();