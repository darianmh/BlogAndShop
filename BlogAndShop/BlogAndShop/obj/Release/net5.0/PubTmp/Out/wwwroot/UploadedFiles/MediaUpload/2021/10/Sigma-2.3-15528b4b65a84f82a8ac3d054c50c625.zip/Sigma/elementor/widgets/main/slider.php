<?php
namespace Elementor;

class Main_Sigma_Slides extends Widget_Base {
	
	public function get_name() {
		return 'sigma-slider';
	}
	
	public function get_title() {
		return __( 'Sigma Slider', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-slides';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}


	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_slider',
			[
				'label' => __( 'Sigma Slider', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'slider_reptear',
			[
				'label' => __( 'Slider Items', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'Text Slider', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'List Item Name', 'sigma-theme' ),
						'default' => __( 'Order Tracking', 'sigma-theme' ),
					],
					[
						'name' => 'link',
						'label' => __( 'Link Slider', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => get_site_url(),
        				'default' => [
        					'url' => get_site_url(),
        					'is_external' => true,
        					'nofollow' => true,        					
        				]						
					],
					[
						'name' => 'img',
						'label' => __( 'Image Slider', 'sigma-theme' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'dynamic' => [
                                      'active' => true,
                                     ],
                        'default' => [
                         'url' => get_template_directory_uri() . '/assets/img/slider01-new.png',
                        ],
					],					
				],
				'default' => [
					[
						'text' => __( 'Slider', 'sigma-theme' ),
						'link' => [ 'url' => get_site_url(), 'is_external' => true, 'nofollow' => true, ],
						'icon' => [ 'url' => get_template_directory_uri() . '/assets/img/slider01-new.png', ],
					],
					[
						'text' => __( 'Slider', 'sigma-theme' ),
						'link' => [ 'url' => get_site_url(), 'is_external' => true, 'nofollow' => true, ],
						'icon' => [ 'url' => get_template_directory_uri() . '/assets/img/slider02-new.png', ],
					],
					[
						'text' => __( 'Slider', 'sigma-theme' ),
						'link' => [ 'url' => get_site_url(), 'is_external' => true, 'nofollow' => true, ],
						'icon' => [ 'url' => get_template_directory_uri() . '/assets/img/slider01-new.png', ],
					],					
				],
				'title_field' => '{{{ text }}}',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'slider_setting',
			[
				'label' => __( 'slider Setting', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'slider_coulmns_slider',
			[
				'label'   => esc_html__( 'slider Coulmns desktop', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
				'min' => 1,
				'max' => 6,
			]
		);		

		$this->add_control(
			'slider_coulmns_slider_tablet',
			[
				'label'   => esc_html__( 'slider Coulmns tablet', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
				'min' => 1,
				'max' => 4,
			]
		);	

		$this->add_control(
			'slider_coulmns_slider_mobile',
			[
				'label'   => esc_html__( 'slider Coulmns mobile', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
				'min' => 1,
				'max' => 8,
			]
		);	
		
		$this->add_control(
			'active_nav_slider',
			[
				'label'   => esc_html__( 'Active Nav slider', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'active_dots_slider',
			[
				'label'   => esc_html__( 'Active dots slider', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_control( 
			'active_autoplay_slider',
			[
				'label'   => esc_html__( 'Active autoplay slider', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_control(
			'active_autoplay_speed_slider',
			[
				'label'   => esc_html__( 'autoplay speed slider', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 5000,
				'min' => 1,
				'max' => 20000,
				'condition' => [ 'active_autoplay_slider' => 'yes', ],
			]
		);	
		
		$this->add_control( 
			'active_loop_slider',
			[
				'label'   => esc_html__( 'Active loop slider', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		
		$this->end_controls_section();	
	}


	protected function render() {
		$settings = $this->get_settings();
		$id_element = $this->get_id();
		?>
				<script>
                $(function(){
                $("#sigma-slider-<?php echo $id_element; ?>").owlCarousel( {
                	nav: <?php if($settings['active_nav_slider'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	rtl:!0,
                	loop:<?php if($settings['active_loop_slider'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	dots:<?php if($settings['active_dots_slider'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	autoplay:<?php if($settings['active_autoplay_slider'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	autoplayTimeout:<?php echo $settings['active_autoplay_speed_slider']; ?>,
                	responsive: {
                	0: {
                	items:<?php echo $settings['slider_coulmns_slider_mobile']; ?>
                }
                ,600: {
                	items:<?php echo $settings['slider_coulmns_slider_tablet']; ?>
                }
                ,1000: {
                	items: <?php echo $settings['slider_coulmns_slider']; ?>
                }}})});				
				</script>
        <?php		
        echo'<div class="slider-main-sigma owl-carousel owl-theme owl-rtl owl-loaded owl-drag" id="sigma-slider-'.$id_element.'" >';
        foreach ( $settings['slider_reptear'] as $index => $item ) : 
		$target = $item['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $item['link']['nofollow'] ? ' rel="nofollow"' : '';        
        ?>
            <div class="sgm_slider_main">
                <a href="<?php echo esc_url( $item['link']['url'] ); ?>" <?php echo $target . $nofollow ?>title="<?php echo $item['text']; ?>" ><img alt="<?php echo $item['text']; ?>" title="slider" src="<?php echo esc_url( $item['img']['url'] ); ?>"></a>
            </div>
        <?php endforeach; ?>
        </div>
        <?php    
	}
}
