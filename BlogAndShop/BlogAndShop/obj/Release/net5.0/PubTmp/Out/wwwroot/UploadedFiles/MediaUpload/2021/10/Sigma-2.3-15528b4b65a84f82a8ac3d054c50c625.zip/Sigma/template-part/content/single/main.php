<?php while (have_posts()) :
the_post(); ?>
<div class="content-single">
    <div class="breadcrumb_post">
        <?php
            $args = array(
                'delimiter' => ' <i></i> ',
                'home' => __('home', 'sigma-theme'));
            woocommerce_breadcrumb($args);
        ?>
    </div>

    <div class="postholder">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="meta-posts">
            
        <?php global $sigma; if ($sigma['cat'] == 'inline') { ?>
            <span style="display:<?php global $sigma; echo $sigma['cat']; ?>" class="category">
                <i class="fal fa-list-ul" aria-hidden="true"></i><?php _e('category:', 'sigma-theme'); ?><?php the_category(', ') ?>
            </span>
        <?php } ?>
        
        <?php global $sigma; if ($sigma['date'] == 'inline') { ?>
            <span style="display:<?php echo $sigma['date']; ?>" class="category">
                <i class="fal fa-calendar" aria-hidden="true"></i>
            <?php the_time('j F Y'); ?>
            </span>
        <?php } ?>
        
        <?php global $sigma; if ($sigma['author'] == 'inline') { ?>    
            <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>" target="_blank">
                <span class="category">
                    <i class="fal fa-users" aria-hidden="true"></i><?php the_author() ?>
                </span>
            </a>
        <?php } ?>
        
        <?php global $sigma; if ($sigma['view'] == 'inline') { ?>    
            <span class="category">
                <i class="fal fa-chart-bar" aria-hidden="true"></i>
                <?php echo getPostViews(get_the_ID()); ?>
            </span>
            <?php setPostViews(get_the_ID()); ?>
        </div>
        <?php } ?>
        
        <?php global $sigma; if ($sigma['show_thumnail'] == 'inline') { ?>
        <div class="post_thumb">
            <?php the_post_thumbnail('index'); ?>
        </div>
        <?php } ?>
        
        <?php the_content(); ?>
        
        <?php global $sigma; if ($sigma['tags'] == 'inline') { ?>
        <div class="post_tag">
            <i class="fal fa-tags" aria-hidden="true"></i>
            <?php the_tags(); ?>
        </div>
        <?php } ?>
        
    </div>
    <?php endwhile; ?>
</div>