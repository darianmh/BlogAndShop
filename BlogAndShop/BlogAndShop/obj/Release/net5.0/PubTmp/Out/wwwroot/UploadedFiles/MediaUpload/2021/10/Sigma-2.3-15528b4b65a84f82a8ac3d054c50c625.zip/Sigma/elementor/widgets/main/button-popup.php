<?php
namespace Elementor;

class Main_Botton_Popup extends Widget_Base {
	
	public function get_name() {
		return 'btn-popup-widget';
	}
	
	public function get_title() {
		return __( 'Button Popup', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-button';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Button Popup', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'button_title',
			[
				'label' => __( 'Title Button Popup', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Button Popup Title', 'sigma-theme' ),
                'default' => __( 'Hello Zhaket', 'sigma-theme' ),
			]
		);
		$this->add_control(
			'modal_title',
			[
				'label' => __( 'modal title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'modal title', 'sigma-theme' ),
                'default' => __( 'Hello Zhaket', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'modal_content',
			[
				'label' => __( 'modal content', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'hello dear , sigma is a best wordpress iranian theme', 'sigma-theme' ),
				'placeholder' => __( 'Type modal content here', 'sigma-theme' ),
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Button Popup', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

       $this->add_control(
        	'btn_modal_bg',
        	[
        		'label' => __( 'modal button background', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#007bff',
        		'selectors' => [
        			'{{WRAPPER}} .btn-primary ' => 'background: {{VALUE}}',
        		],		
        	]
        );
        
       $this->add_control(
        	'btn_modal_border',
        	[
        		'label' => __( 'modal button border color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#007bff',
        		'selectors' => [
        			'{{WRAPPER}} .btn-primary ' => 'border-color: {{VALUE}}',
        		],		
        	]
        );        
        
        $this->add_control(
        	'btn_modal_color',
        	[
        		'label' => __( 'modal button color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#fff',
        		'selectors' => [
        			'{{WRAPPER}} .btn-primary ' => 'color: {{VALUE}}',
        		],		
        	]
        );        

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_modal_type',
				'label' => __( 'modal button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .btn-primary ',
			]
		);        
        
        
        
		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_1',
			[
				'label' => __( 'modal Popup', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
        	'modal_header_bg',
        	[
        		'label' => __( 'modal header background', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .sigma-modal .modal-header ' => 'background: {{VALUE}}',
        		],		
        	]
        );

		$this->add_control(
        	'modal_header_color',
        	[
        		'label' => __( 'modal header color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .sigma-modal .modal-title ' => 'color: {{VALUE}}',
        		],		
        	]
        );
        
		$this->add_control(
        	'modal_body_border',
        	[
        		'label' => __( 'modal body border color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .sigma-modal .modal-header ' => 'border-bottom: 1px solid {{VALUE}}',
        		],		
        	]
        );        

		$this->add_control(
        	'modal_body_bg',
        	[
        		'label' => __( 'modal body background', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .sigma-modal .modal-body ' => 'background: {{VALUE}}',
        		],		
        	]
        );        
        
        $this->add_control(
        	'modal_body_color',
        	[
        		'label' => __( 'modal body color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .sigma-modal .modal-body ' => 'color: {{VALUE}}',
        		],		
        	]
        );   

        $this->add_control(
        	'modal_close_color',
        	[
        		'label' => __( 'modal close color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#333',
        		'selectors' => [
        			'{{WRAPPER}} .modal-content button.close span ' => 'color: {{VALUE}}',
        		],		
        	]
        );   

        $this->add_control(
			'modal_color_icon_color',
			[
				'label' => __( 'modal color icon color', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .modal-content button.close span ' => 'font-size:{{SIZE}}px',
				],
			]
		);	

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'modal_title_type',
				'label' => __( 'modal title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-modal .modal-title ',
			]
		);    
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'modal_body_type',
				'label' => __( 'modal body Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sigma-modal .modal-body ',
			]
		);    	
		
		$this->end_controls_section();
		
	}


    protected function render( ) {
        $settings = $this->get_settings();
        $id_element = $this->get_id();
        echo'<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#Modal-'.$id_element.'">
  '.$settings['button_title'].'
</button>

<!-- Modal -->
<div class="sigma-modal modal fade" id="Modal-'.$id_element.'" tabindex="-1" role="dialog" aria-labelledby="ModalLabel-'.$id_element.'" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel-'.$id_element.'">'.$settings['modal_title'].'</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      '.$settings['modal_content'].'
      </div>
    </div>
  </div>
</div>';
    }

}