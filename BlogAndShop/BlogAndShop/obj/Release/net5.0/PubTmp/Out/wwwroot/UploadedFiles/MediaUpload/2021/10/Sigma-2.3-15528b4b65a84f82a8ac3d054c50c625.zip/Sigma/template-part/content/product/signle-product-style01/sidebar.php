<?php while (have_posts()) : the_post(); ?>

    <div class="mobile_cart_fix"><a href="#buy"><i class="fa fa-shopping-basket"></i><?php _e('online buy product', 'sigma-theme'); ?></a></div>
    <div class="product-license" style="display:<?php global $sigma; 
    echo $sigma['license_productv2']; ?>">
        <?php 
        if ($sigma['img_license']['url'] != '') { ?>
            <img src="<?php echo $sigma['img_license']['url']; ?>">
        <?php } else { ?>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/license.svg">
        <?php } ?>

        <h3><?php 
            echo $sigma['title_license']; ?></h3>
        <?php the_excerpt(); ?>
    </div>

    <div class="product-note for-fix-product" id="sidebar">
        <?php 
        if ($sigma['img_detial']['url'] != '') { ?>
            <img src="<?php echo $sigma['img_detial']['url']; ?>">
        <?php } else { ?>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/info.svg">
        <?php } ?>

        <h3><?php 
            echo $sigma['title_detial']; ?></</h3>

        <div class="list-notes" style="display:<?php 
        echo $sigma['license_product']; ?>">
            <?php 
            echo $sigma['license_content']; ?>
        </div>

        <?php echo get_product_countdown_single($id) ; ?>
        <div id="buy" class="summary entry-summary sigma_price_holder sigma_price_holder_v1">
            <?php echo woocommerce_template_single_price(); ?>
            <?php
            global $product;
            if ('' === $product->get_price() || 0 == $product->get_price() && $sigma['free_products_checkout'] == 'disable') {
                $downloads = $product->get_downloads();

                foreach ($downloads as $key => $each_download) {
                    echo '<button class="single_add_to_cart_button button alt freedl_sgm"><a href="' . $each_download["file"] . '">' . $each_download["name"] . '</a></button>';
                }
            } else {
                do_action('woocommerce_single_product_summary');
            }
            ?>
        </div>
    
        <div class="btm_more_sigma" style="display:<?php 
        echo $sigma['show_demo_en']; ?>">
            <div class="help">
                <?php $mid_var = get_post_meta($post->ID, 'help', true);
                if (isset($mid_var) && !empty($mid_var)) : ?>
                
                    <a href="<?php echo get_post_meta($post->ID, 'help', true); ?>" target="_blank" class="help">
                        <?php _e('product help', 'sigma-theme'); ?>
                    </a>
                    
                <?php endif; ?>
            </div>

            <div class="demo-fa" style="display:<?php 
            echo $sigma['show_demo_en']; ?>">
                <?php
                $id = get_the_ID();
                $info = sigma_get_digital_product_info($id);
                ?>
                <a href="<?php echo $info['product_preview'] ?>" target="_blank" class="demo-fa">
                    <?php _e('persian preview', 'sigma-theme'); ?>
                </a>
            </div>

            <div class="demo-en" style="display:<?php 
            echo $sigma['show_demo_en']; ?>">
                <?php $mid_var = get_post_meta($post->ID, 'demo', true);
                if (isset($mid_var) && !empty($mid_var)) : ?>

                    <a href="<?php echo get_post_meta($post->ID, 'demo', true); ?>" target="_blank" class="demo-en">
                        <?php _e('English preview', 'sigma-theme'); ?>                    
                    </a>

                <?php endif; ?>
            </div>

        </div>

        <div class="info-box-dt" style="display:<?php 
        echo $sigma['info_product']; ?>">


        <span class="date"><i class="fa fa-calendar"></i><p><?php _e('Date:', 'sigma-theme'); ?></p><strong> <?php the_time('Y/m/d'); ?></strong></span>


            <?php $mid_var = get_post_meta($post->ID, 'include', true);
            if (isset($mid_var) && !empty($mid_var)) : ?>

                <span class="date">
                    <i class="fa fa-file"></i>
                    <p><?php _e('Include files:', 'sigma-theme'); ?></p>
                    <strong><?php echo get_post_meta($post->ID, 'include', true); ?></strong>
                </span>
                
            <?php endif; ?>

            <span class="date">
                <i class="fa fa-eye-slash"></i>
                <p><?php _e('views:', 'sigma-theme'); ?></p>
                <strong><?php echo getPostViews(get_the_ID()); ?></strong>
            </span>

            <span class="date">
                <i class="fa fa-star"></i>
                <p><?php _e('Product average rating:', 'sigma-theme'); ?></p>
                <strong><?php echo(get_post_meta(get_the_ID(), '_wc_average_rating', true)); ?> <?php _e('From 5', 'sigma-theme'); ?></strong>
        </span>

            <span class="date">
                <i class="fa fa-desktop"></i>
                <p><?php _e('Product version:', 'sigma-theme'); ?></p>
                <strong><?php echo $info['product_version'] ?></strong>
            </span>

            <?php $mid_var = get_post_meta($post->ID, 'rahmnama', true);
            if (isset($mid_var) && !empty($mid_var)) : ?>

            <span class="date">
                <i class="fa fa-info-circle"></i>
                <p><?php _e('Product help:', 'sigma-theme'); ?></p>
                <strong><?php echo get_post_meta($post->ID, 'rahmnama', true); ?></strong>
            </span>
                
            <?php endif; ?>

            <span style="display:<?php echo $sigma['update_show']; ?>" class="date">
                <i class="fa fa-upload"></i>
                <p><?php _e('Product update:', 'sigma-theme'); ?></p>
            <strong><?php global $product; echo '<span class="date_modified">' . $product->get_date_modified()->date_i18n('Y/m/d') . '</span>'; ?></strong>
            </span>

            <?php $mid_var = get_post_meta($post->ID, 'size', true);
            if (isset($mid_var) && !empty($mid_var)) : ?>
            
                <span class="date"><i class="fa fa-file-o"></i>
                <p><?php _e('Product size:', 'sigma-theme'); ?></p>
                <strong><?php echo get_post_meta($post->ID, 'size', true); ?></strong>
                </span>
                
            <?php endif; ?>


            <span class="date" style="display:<?php echo $sigma['sales']; ?>">
                <i class="fa fa-shopping-cart"></i>
                <p><?php _e('Total sale:', 'sigma-theme'); ?></p>
                <strong><?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?></strong>
            </span>


            <span class="date">
                <i class="fa fa-comment"></i>
                <p><?php _e('Comment number:', 'sigma-theme'); ?></p>
            <strong><?php comments_number('0', ' 1 ', ' % '); ?></strong>
            </span>
            
        </div>


        <div class="edc_badges edc_badges_signle">
            <ul>
                <?php
                $id = get_the_ID();
                $medals = sigma_get_product_medals($id);
                if (false != $medals) {
                    foreach ($medals as $medal) {
                        ?>
                        <li id="hexagon" class="badge_singel pink_badge"><img src="<?php echo $medal['medal_pic'] ?>" alt="<?php echo $medal['medal_name'] ?>">
                            <span class="badge-tooltip"><?php echo $medal['medal_name'] ?></span>
                        </li>
                        <?php
                    }
                }
                ?>
            </ul>
        </div>

        <div class="shoppin-card" style="display:<?php echo $sigma['payment_img_active']; ?>;">
            
        <span><?php echo $sigma['payment_img_title']; ?></span>
        
            <?php 
            if ($sigma['payment_img']['url'] != '') { ?>
                <img src="<?php echo $sigma['payment_img']['url']; ?>">
            <?php } else { ?>
                <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/shopping-cart.png">
            <?php } ?>

        </div>
    </div>

<?php endwhile; ?>


<div class="author-product" style="display:<?php echo $sigma['vendor_show']; ?>">
    
    <div class="auther_img">
        <?php echo get_avatar(get_the_author_meta('email'), '60'); ?>
    </div>
    
    <div class="about-vendor">
        <div class="name-vendor"><?php echo(get_the_author_meta('display_name')); ?></a></div>
        <div class="date-vendor">
            <?php
            $user_id = $post->post_author;
            $reg_date = date_i18n('j F Y', strtotime(get_user_by("ID", $user_id)->user_registered));
            ?>
           <?php _e('Register date:', 'sigma-theme'); ?><?php echo $reg_date; ?>     </div>
        <p class="des-vendor"><?php the_author_meta('description'); ?></p>
    </div>
    
    <?php
    if (class_exists('WeDevs_Dokan')) {
        $vendor_id = get_post_field('post_author', get_the_id());
        $vendor = new WP_User($vendor_id);
        $store_url = dokan_get_store_url($vendor_id);
        ?>
        <a href="<?php echo $store_url; ?>" style="display:<?php echo $sigma['vendor_show_btn']; ?>" class="more-product" target="_blank"><i class="fa fa-archive"></i><?php _e('Seller more products', 'sigma-theme'); ?></a>
    <?php } ?>
    
</div>


<div class="box-fav-sup">
    <div style="display:<?php echo $sigma['support_show']; ?>" class="support-btn">
        <a href="<?php echo $sigma['support_link']; ?>" target="_blank" class="support"><i class="fa fa-life-ring"></i><?php _e('Get support center', 'sigma-theme'); ?></a>
    </div>


    <div style="display:<?php echo $sigma['report_show']; ?>;" class="report" id="myBtn">
        <a href="#" id="reportbtn" data-toggle="modal" data-target="#reportmodal" class="report-btn" data-toggle="modal" data-target="#reportbox">
            <i class="fa fa-bug"></i><?php echo $sigma['report_title']; ?>
        </a></div>


    <div id="reportmodal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php _e('Send report for', 'sigma-theme'); ?> <?php the_title(); ?></h4>
                </div>
                <div class="modal-body">
                    <p><?php _e('You are sending a report for the product', 'sigma-theme'); ?><strong><?php the_title(); ?></strong></p>

                    <div class="notice_sigma">
                        <p><strong><?php _e('Please note the following', 'sigma-theme'); ?>:</strong></p>
                        <p></p>
                        <ul>
                            <li><?php _e('Be sure to check the accuracy of your report before submitting a report.', 'sigma-theme'); ?></li>
                            <li><?php _e('Strictly avoid sending successive reports.', 'sigma-theme'); ?></li>
                            <li><?php _e('Your information will be stored in the system.', 'sigma-theme'); ?></li>
                            <li><?php _e('Important Note: Please include the product title in your report.', 'sigma-theme'); ?></li>
                        </ul>
                        <p></p>
                    </div>
                    <div class="report-form">
                        <?php
                        if (wpcf7_install_plugin()) {
                            echo do_shortcode("[contact-form-7 title='500']");
                        } else {
                            echo __('Please Install and active Contact Form 7 Plugin and creat one form name:500', 'sigma-theme');
                        }
                        ?>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div style="display:<?php 
    echo $sigma['urlshort_show']; ?>">
        <span class="short-link"><i class="fa fa-link"></i><?php _e('Short url:', 'sigma-theme'); ?></span>
        <input type="text" class="ulink" value="<?php bloginfo('url'); ?>/?p=<?php the_ID(); ?>" id="myInput">
        <i class="fa fa-file copy" onclick="myFunction()" aria-hidden="true"></i></div>
</div>

<div style="display:<?php 
echo $sigma['side_ads']; ?>" class="ads_sidebar">
    <a href="<?php 
    echo $sigma['ads_side_link']; ?>" target="<?php 
    echo $sigma['ads_side_target']; ?>">

        <?php 
        if ($sigma['ads_side_banner']['url'] != '') { ?>
            <img src="<?php echo $sigma['ads_side_banner']['url']; ?>">
        <?php } else { ?>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/ads300-1.png">
        <?php } ?>

    </a>
</div>

<div id="permissions" class="owl-carousel owl-theme enamad">
    <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('permissions-sidebar')) : else : ?><?php endif; ?>
</div>

<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('single-product-sidebar')) : else : ?><?php endif; ?>	