<?php
namespace Elementor;

class Main_Brands extends Widget_Base {
	
	public function get_name() {
		return 'brands-widget';
	}
	
	public function get_title() {
		return __( 'Brands Logo', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-slider-album';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
    
    function get_brandlist(){
        $terms = get_terms( array(
            'taxonomy' => 'Brand',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }    
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Brands Logo', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'brands_title',
			[
				'label' => __( 'Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Brand Title', 'sigma-theme' ),
                'default' => __( 'Papular Brands', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'brands_en_title',
			[
				'label' => __( 'English Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => 'Popular Brands',
                'default' => 'Popular Brands',
			]
		);
		$this->add_control(
			'brands_title_icon',
            [
                'label' => __( 'Title Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-edit',
					'library' => 'light',
				],            
			]
		);
		
        $this->add_control(
            'col_brands',
            [
                'label'     => esc_html__( 'Select Column', 'sigma-theme' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'columns-6',
                'options'   => [
                      'columns-4'     => esc_html__( '4 Column', 'sigma-theme' ),
                      'columns-5'     => esc_html__( '5 Column', 'sigma-theme' ),
                      'columns-6'     => esc_html__( '6 Column', 'sigma-theme' ),           
                      'columns-7'     => esc_html__( '7 Column', 'sigma-theme' ),
                      'columns-8'     => esc_html__( '8 Column', 'sigma-theme' ),        
                      'columns-9'     => esc_html__( '9 Column', 'sigma-theme' ),
                      'columns-10'    => esc_html__( '10 Column', 'sigma-theme' ),                            
                ]
            ]
        );

		$this->add_control(
			'active_brand_carousel',
			[
				'label'     => esc_html__( 'active brand carousel', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value'	=> 'yes',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'brand_setting',
			[
				'label' => __( 'brand carousel Setting', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        		'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);
		
		$this->add_control(
			'brand_coulmns_brand_desktop',
			[
				'label'   => esc_html__( 'brand carousel Coulmns desktop', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 7,
				'min' => 1,
				'max' => 15,
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);		

		$this->add_control(
			'brand_coulmns_brand_tablet',
			[
				'label'   => esc_html__( 'brand carousel Coulmns tablet', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 2,
				'min' => 1,
				'max' => 10,
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);	

		$this->add_control(
			'brand_coulmns_brand_mobile',
			[
				'label'   => esc_html__( 'brand carousel Coulmns mobile', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 1,
				'min' => 1,
				'max' => 20,
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);	
		
		$this->add_control(
			'active_nav_brand',
			[
				'label'   => esc_html__( 'Active Nav brand carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);

		$this->add_control(
			'active_dots_brand',
			[
				'label'   => esc_html__( 'Active dots brand carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);

		$this->add_control( 
			'active_autoplay_brand',
			[
				'label'   => esc_html__( 'Active autoplay brand carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);

		$this->add_control(
			'active_autoplay_speed_brand',
			[
				'label'   => esc_html__( 'autoplay speed brand carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 5000,
				'min' => 1,
				'max' => 20000,
				'condition' => [
					'active_brand_carousel' => ['yes'],
					'active_autoplay_brand' => ['yes']
				]				
			]
		);	
		
		$this->add_control( 
			'active_loop_brand',
			[
				'label'   => esc_html__( 'Active loop brand carousel', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [ 'active_brand_carousel' => 'yes', ],
			]
		);

		
		$this->end_controls_section();	

        $this->start_controls_section(
        	'style_section_logo',
        	[
				'label' => __( 'Brands Logo', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_brands_index',
        		'label' => _x( 'Brands Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .dgs_brands_index',
        	]
        );
        
        $this->add_control(
        	'dgs_color_title_warp_dgs_i',
        	[
        		'label' => __( 'Title Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#f19077',
        		'selectors' => [
        			'{{WRAPPER}} .title_warp_dgs i' => 'color: {{VALUE}}',
        		],        
        	]
        );
        
		$this->add_control(
			'brands_title_icon_size',
			[
				'label' => __( 'Title Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_dgs i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->add_control(
        	'dgs_color_title_top_text',
        	[
				'label' => __( 'Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#444444',
        		'selectors' => [
        			'{{WRAPPER}} .title_warp_dgs h3' => 'color: {{VALUE}}',
        		],        
        	]
        );
        
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'brand_title_type',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .title_warp_dgs h3',
			]
		);	
		
        $this->add_control(
        	'dgs_color_title_small_text',
        	[
				'label' => __( 'SubTitle Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#999999',
        		'selectors' => [
        			'{{WRAPPER}} .title_warp_dgs small' => 'color: {{VALUE}}',
        		],        
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'brand_subtitle_type',
				'label' => __( 'SubTitle Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .title_warp_dgs small',
			]
		);	
		
		$this->end_controls_section();
	}


    protected function render( ) {
        $settings = $this->get_settings();
        extract($settings);
        $wcatTerms = get_terms('Brand', array('hide_empty' => 0, 'parent' =>0));
        $id_element = $this->get_id(); ?>
				<script>
                $(function(){
                $("#brand-carousel-<?php echo $id_element; ?>").owlCarousel( {
                	nav: <?php if($settings['active_nav_brand'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	rtl:!0,
                	loop:<?php if($settings['active_loop_brand'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	dots:<?php if($settings['active_dots_brand'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	autoplay:<?php if($settings['active_autoplay_brand'] == 'yes') { ?> !0 <?php } else { ?> !1 <?php } ?>,
                	autoplayTimeout:<?php echo $settings['active_autoplay_speed_brand']; ?>,
                	responsive: {
                	0: {
                	items:<?php echo $settings['brand_coulmns_brand_mobile']; ?>
                }
                ,600: {
                	items:<?php echo $settings['brand_coulmns_brand_tablet']; ?>
                }
                ,1000: {
                	items: <?php echo $settings['brand_coulmns_brand_desktop']; ?>
                }}})});				
				    
				</script>				
        <?php
		if($settings['active_brand_carousel'] == 'yes') {
		    echo'<div class="dgs_brands_area"><div class="title_warp_dgs">'?><?php \Elementor\Icons_Manager::render_icon( $settings['brands_title_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'<h3>'.$settings['brands_title'].'</h3> <small>'.$settings['brands_en_title'].'</small></div>';
    		echo'<div id="brand-carousel-'.$id_element.'" class="carousel-products-sgm owl-theme owl-carousel owl-rtl owl-loaded owl-drag">' ?>
            <?php }        
		else {
            echo '<div class="dgs_brands_area"><div class="title_warp_dgs">'?><?php \Elementor\Icons_Manager::render_icon( $settings['brands_title_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'<h3>'.$settings['brands_title'].'</h3> <small>'.$settings['brands_en_title'].'</small></div><div class="dgs_brands_index '.$settings['col_brands'].'">';   
		}
        foreach($wcatTerms as $wcatTerm) : 
        $imges = $wcatTerm->term_image; ;
        $img_atts = wp_get_attachment_image_src($imges, 'full');
        if( $imges = $wcatTerm->term_image ): ?>
        <div class="brands-logo"><a href="<?php echo get_term_link( $wcatTerm->slug, $wcatTerm->taxonomy ); ?>"><img src="<?php echo $img_atts[0]; ?>" title="<?php echo $wcatTerm->name;?>" alt="<?php echo $wcatTerm->name;?>"></a> </div>
        <?php endif; ?>
        <?php 
        endforeach; 
        echo'</div></div>';
    }

}