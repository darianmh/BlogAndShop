<?php

function iconic_remove_password_strength() {
    wp_dequeue_script( 'wc-password-strength-meter' );
}
add_action( 'wp_print_scripts', 'iconic_remove_password_strength', 10 );

function sigma_theme_add_sigma_scripts()
{

    wp_enqueue_style('icons-style', get_template_directory_uri() . '/assets/css/font-awesome.css', array(), '1.1', 'all');
    wp_enqueue_style('bootstrap-style', get_template_directory_uri() . '/assets/css/bootstrap.css', array(), '1.1', 'all');
    wp_enqueue_style('sigma-style', get_template_directory_uri() . '/assets/css/sigma.css', array(), '1', 'all');
    wp_enqueue_style('sigma-style', get_template_directory_uri() . '/assets/css/sigma-mobile.css', array(), '1', 'all');
    wp_enqueue_style('sweetalert-style', get_template_directory_uri() . '/assets/css/sweetalert2.min.css', array(), '1', 'all');

    global $sigma;
    $id = get_the_ID();
    if (sigma_get_load_jquery($id) == "theme") {
    wp_enqueue_script( 'sigma-jquery', get_template_directory_uri() . '/assets/js/jquery.min.js');
    }
    wp_enqueue_script( 'mmenu-script', get_template_directory_uri() . '/assets/js/jquery.mmenu.js', array('jquery'), 1.1, true);
    wp_enqueue_script('carousel-script', get_template_directory_uri() . '/assets/js/owl.carousel.js', array('jquery'), 1.1, true);
    wp_enqueue_script('bootstrap-script', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), 1.1, true);
    wp_enqueue_script('sweetalert', get_template_directory_uri() . '/assets/js/sweetalert2.min.js', array('jquery'), 1.1, true);
    wp_enqueue_script( 'sigma-script', get_template_directory_uri() . '/assets/js/sigma.js', array ( 'jquery' ), 1.1, true);
    wp_localize_script('sigma-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'sigma_theme_add_sigma_scripts');

?>