<link href="<?php bloginfo('template_url') ?>/assets/css/dashboard.css" rel="stylesheet" type="text/css">
<script src="<?php bloginfo('template_url') ?>/assets/js/dashboard.js"></script>
<?php get_template_part('dashboard/panel-menu'); ?>
<section class="vbox">
        <header class="bg-white header header-md navbar navbar-fixed-top-xs box-shadow">
        <div class="navbar-header aside-md dk">
            <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen,open" data-target="#nav,html"> <i class="fal fa-bars"></i> </a>
                        
            <a href="<?php echo get_site_url(); ?>" class="navbar-brand">
                <?php global $sigma;
                if ($sigma['panel_logo']['url'] != '') { ?>
                    <img src="<?php echo $sigma['panel_logo']['url']; ?>">
                <?php } else { ?>
                    <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/favicon.png">
                <?php } ?>
                <span class="hidden-nav-xs"></span>
            </a>
            
            <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user"> <i class="fal fa-cog"></i></a>
            
        </div>
        <ul class="nav navbar-nav hidden-xs">
            <?php if ($sigma['panel_box_top_menu'] == 'inherit') { ?>
            <li class="dropdown">
                <a href="#" class="sgm_quick_links dropdown-toggle" data-toggle="dropdown"> <i class="i i-grid"></i></a>
                <section class="dropdown-menu aside-lg bg-white on animated fadeInLeft">
                    <div class="row m-l-none m-r-none m-t m-b text-center">
                        <div class="col-xs-4">
                            <div class="padder-v">
                                <a href="<?php echo $sigma['menu_panel_03_link']; ?>"> <span class="m-b-xs block"><i class="<?php echo $sigma['menu_panel_03_icon']; ?> text-primary-lt"></i> </span>
                                    <small class="text-muted"> <?php echo $sigma['menu_panel_03_title']; ?></small>
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="padder-v">
                                <a href="<?php echo $sigma['menu_panel_02_link']; ?>"> <span class="m-b-xs block"><i class="<?php echo $sigma['menu_panel_02_icon']; ?> i-2x text-danger-lt"></i> </span>
                                    <small class="text-muted"><?php echo $sigma['menu_panel_02_title']; ?></small>
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="padder-v">
                                <a href="<?php echo $sigma['menu_panel_01_link']; ?>"> <span class="m-b-xs block"><i class="i-2x fa <?php echo $sigma['menu_panel_01_icon']; ?> text-success-lt"></i> </span>
                                    <small class="text-muted"><?php echo $sigma['menu_panel_01_title']; ?></small> 
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="padder-v">
                                <a href="<?php echo $sigma['menu_panel_06_link']; ?>"> <span class="m-b-xs block"><i class="<?php echo $sigma['menu_panel_06_icon']; ?> i-2x text-info-lt"></i> </span>
                                    <small class="text-muted"><?php echo $sigma['menu_panel_06_title']; ?></small>
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="padder-v">
                                <a href="<?php echo $sigma['menu_panel_05_link']; ?>"> <span class="m-b-xs block"><i class="fa <?php echo $sigma['menu_panel_05_icon']; ?> i-2x text-muted"></i> </span>
                                    <small class="text-muted"><?php echo $sigma['menu_panel_05_title']; ?></small>
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="padder-v">
                                <a href="<?php echo $sigma['menu_panel_04_link']; ?>"> <span class="m-b-xs block"><i class="<?php echo $sigma['menu_panel_04_icon']; ?> i-2x text-warning-lter"></i> </span>
                                    <small class="text-muted"><?php echo $sigma['menu_panel_04_title']; ?></small>
                                </a>
                            </div>
                        </div>
                    </div>
                </section>
            </li>
            <?php } ?>
            
        </ul>
        <?php $unique_id = esc_attr(uniqid('search-form-')); ?>
        
        <?php if ($sigma['search_v2_show'] == 'inherit') { ?>
        <form class="hidden-xs" style="float: right; margin: 14px;"
              method="get" action="<?php echo esc_url(home_url('/')); ?>" autocomplate="off">
            <input id="searchInput" onkeyup="fetchResults()" type="text" name="s"
                   placeholder="<?php _e('Search in sigmaplus', 'sigma-theme'); ?>" class="search-panel">
            <button class="btn-search"><i class="fal fa-search" aria-hidden="true"></i>
            </button>
            <div id="datafetch"></div>
        </form>
        <?php } ?>
        
        </div>
        </form>
        <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">
            <?php if ($sigma['cart_v2_show'] == 'inherit') { ?>
            <li class="hidden-xs">
                <a href="#" class="dropdown-toggle shopping_bag_panel" data-toggle="dropdown"><i class="fal fa-shopping-bag"></i> 
                <span class="badge badge-sm up bg-danger count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                </a>
                
                <section class="dropdown-menu aside-xl animated flipInY" style="padding-bottom:0px">
                    <section class="panel bg-white">
                        <div class="panel-heading b-light bg-light"><strong><?php _e('you', 'sigma-theme'); ?><span
                                        class="count"><?php echo WC()->cart->get_cart_contents_count(); ?></span><?php _e('have product in your bag.', 'sigma-theme'); ?></strong></div>
                        <div class="mincart_sigma">
                            <a href="#" class=""> <small class="text-muted">
                                    <ul class="mini-cart">
                                        <ul style="list-style:none;padding: 0 10px 0px 0px;" class="woocommerce-mini-cart cart_list product_list_widget">
                                            <?php do_action('woocommerce_before_mini_cart_contents');

                                            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                                                $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                                                $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);

                                                if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key)) {
                                                    $product_name = apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key);
                                                    $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);
                                                    $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
                                                    $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                                                    ?>
                                                    <li class="woocommerce-mini-cart-item <?php echo esc_attr(apply_filters('woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key)); ?>">
                                                        <?php
                                                        echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                                                            '<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">&times;</a>',
                                                            esc_url(wc_get_cart_remove_url($cart_item_key)),
                                                            __('Remove this item', 'sigma-theme'),
                                                            esc_attr($product_id),
                                                            esc_attr($cart_item_key),
                                                            esc_attr($_product->get_sku())
                                                        ), $cart_item_key);
                                                        ?>
                                                        <?php if (empty($product_permalink)) : ?>
                                                            <?php echo $thumbnail . $product_name; ?>
                                                        <?php else : ?>
                                                            <a href="<?php echo esc_url($product_permalink); ?>">
                                                                <?php echo $thumbnail . $product_name; ?>
                                                            </a>
                                                        <?php endif; ?>
                                                        <?php echo wc_get_formatted_cart_item_data($cart_item); ?><br>
                                                        <?php echo apply_filters('woocommerce_widget_cart_item_quantity', '<span class="quantity">' . sprintf('%s &times; %s', $cart_item['quantity'], $product_price) . '</span>', $cart_item, $cart_item_key); ?>
                                                    </li>
                                                    <?php
                                                }
                                            }

                                            do_action('woocommerce_mini_cart_contents');
                                            ?>
                                        </ul>
                                </small> </a>
                            <a href="#" class="media list-group-item"> <span class="media-body block m-b-none"><?php _e('Total your shopping cart:', 'sigma-theme'); ?><br><span
                                            class="cart-contents" <?php echo sprintf(_n('%d product' , 'sigma-theme' , '%d product' , 'sigma-theme' , WC()->cart->cart_contents_count), WC()->cart->cart_contents_count); ?> - <?php echo WC()->cart->get_cart_total(); ?></span></span>
                            </a>
                        </div>
                        <div class="col-md-6 panel-footer text-sm link_sigma"><a
                                    href="<?php echo wc_get_checkout_url(); ?>" target="_blank" class="pull-right"><i
                                        class="fal fa-money"></i><?php _e('Checkout', 'sigma-theme'); ?></a></div>
                        <div class="col-md-6 panel-footer text-sm link_sigma2"><a
                                    href="<?php echo wc_get_cart_url(); ?>" target="_blank" class="pull-right"><i
                                        class="fal fa-shopping-cart"></i><?php _e('Cart', 'sigma-theme'); ?></a></div>
                    </section>
                </section>
            </li>
            <?php } ?>
            
            
            <?php if ($sigma['panel_menu_v2_show'] == 'inherit') { ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb-sm avatar pull-left">
                    <?php
                    $user = wp_get_current_user();
                    if ($user) : ?>
                        <img src="<?php echo esc_url(get_avatar_url($user->ID)); ?>"/>
                    <?php endif; ?>                    
                    
                    </span>
                    <?php global $current_user;
                    wp_get_current_user();
                    echo $current_user->display_name . "\n"; ?>
                </a>
                <ul class="dropdown-menu animated fadeInRight" style="" padding-bottom:0;>
                    <?php wp_nav_menu(array('theme_location' => 'user-left-menu')); ?>

                </ul>
            </li>
            <?php } ?>
            
        </ul>
    </header>

    <section>
        <section class="hbox stretch">
            <!-- .aside -->
                        <aside class="bg-black aside-md hidden-print hidden-xs" id="nav">
                <section class="vbox">
                    <section class="w-f scrollable">
                        <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0"
                             data-size="10px" data-railOpacity="0.2">
                            <div class="clearfix wrapper dk nav-user hidden-xs">
                                <div class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">
                                        <span class="thumb avatar pull-left m-r">
                                        <?php
                                        $user = wp_get_current_user();
                                        if ($user): ?>
                                            <img src="<?php echo esc_url(get_avatar_url($user->ID)); ?>"/>
                                        <?php endif; ?>
                                            <i class="on md b-black"></i> 
                                        </span> 
                                        <span class="hidden-nav-xs clear">
                                            <span class="block m-t-xs">
                                                <strong class="font-bold text-lt">
                                                <?php global $current_user;
                                                      wp_get_current_user();
                                                      echo $current_user->display_name . "\n"; ?>
                                                </strong>
                                            </span>
                                            <span class="text-muted text-xs block">
                                                <?php global $current_user;
                                                    wp_get_current_user();
                                                    echo $current_user->user_login . "\n"; ?>
                                            </span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <!-- nav -->
                            <nav class="nav-primary hidden-xs">
                                <div class="text-muted text-sm hidden-nav-xs padder m-t-sm m-b-sm">
                                   <?php _e('User Menu', 'sigma-theme'); ?>
                                </div>
                                <?php

                                if ($sigma['active_woo_my_account_nav'] == 'enable') {
                                    do_action('woocommerce_before_account_navigation'); ?>
                                    <ul class="nav nav-main">
                                        <?php foreach (wc_get_account_menu_items() as $endpoint => $label) : ?>
                                            <li class="<?php echo wc_get_account_menu_item_classes($endpoint); ?>">
                                                <a href="<?php echo esc_url(wc_get_account_endpoint_url($endpoint)); ?>"><?php echo esc_html($label); ?></a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                    <?php do_action('woocommerce_after_account_navigation'); ?>
                                <?php } ?>
                                
                                <?php if (has_nav_menu('users-menu')) {
                                    wp_nav_menu(array('theme_location' => 'users-menu', 'container' => '', 'menu_class' => 'nav nav-main'));
                                }
                                ?>

                                <?php if (current_user_can('administrator')) { ?>
                                    <?php if ($sigma['dokan-show'] == 'block') { ?>
                                    <li class="active1 vendor_show">
                                        <a href="<?php echo $sigma['dokan_btn_link']; ?>" target="_blank" class="auto">
                                            <span class="font-bold"></span><?php echo $sigma['dokan_btn_title']; ?><i class="<?php echo $sigma['dokan_btn_icon']; ?>"></i>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    
                                <?php } else if (current_user_can('seller')) { ?>
                                    <?php if ($sigma['dokan-show'] == 'block') { ?>
                                    <li style="display:<?php echo $sigma['dokan-show']; ?>;"
                                        class="active1 vendor_show">
                                        <a href="<?php echo $sigma['dokan_btn_link']; ?>" target="_blank" class="auto">
                                            <span class="font-bold"></span><?php echo $sigma['dokan_btn_title']; ?><i class="<?php echo $sigma['dokan_btn_icon']; ?>"></i>
                                        </a>
                                    </li>
                                    <?php } ?>
                                <?php } ?>

                                <div class="line dk hidden-nav-xs"></div>
                                
                                <?php if (has_nav_menu('btn-panel')) { ?>
                                    <div class="text-muted text-sm hidden-nav-xs padder m-t-sm m-b-sm">
                                       <?php _e('Quick access', 'sigma-theme'); ?>
                                    </div>

                                    <?php
                                    wp_nav_menu(array(
                                        'theme_location' => 'btn-panel',
                                        'container' => '',
                                        'menu_class' => 'nav q-link'
                                    ));
                                }
                                ?>

                                <?php if (has_nav_menu('btn1-panel')) { ?>
                                    <div class="text-muted text-sm hidden-nav-xs padder m-t-sm m-b-sm">
                                        <?php _e('Essential links', 'sigma-theme'); ?>
                                    </div>
                                    <?php
                                    wp_nav_menu(array(
                                        'theme_location' => 'btn1-panel',
                                        'container' => '',
                                        'menu_class' => 'nav q-link'
                                    ));
                                }
                                ?>
                                </ul>
                            </nav>
                            <!-- / nav -->
                        </div>
                    </section>
                    
                    <footer class="footer hidden-xs no-padder text-center-nav-xs">
                        <a href="<?php echo wp_logout_url(home_url()); ?>" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs"><i class="i i-logout"></i> </a>
                        <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs"> <i class="i i-circleleft text"></i> <i class="i i-circleright text-active"></i></a>
                    </footer>
                    
                </section>
            </aside>
            <!-- /.aside -->
            <section id="content">
                <div class="content-panel-v2">
                    <?php while (have_posts()) : the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; ?>

                </div>
                <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen,open" data-target="#nav,html"></a>
            </section>
        </section>
    </section>
</section>
<!-- Bootstrap -->
<!-- App -->