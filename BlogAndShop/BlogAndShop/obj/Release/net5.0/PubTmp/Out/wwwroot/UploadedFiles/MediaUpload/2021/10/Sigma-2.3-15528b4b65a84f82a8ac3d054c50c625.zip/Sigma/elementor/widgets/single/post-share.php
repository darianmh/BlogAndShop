<?php
namespace Elementor;

class Post_Share extends Widget_Base {
	
	public function get_name() {
		return 'post-share';
	}
	
	public function get_title() {
		return __( 'Single Share', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-share';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {

        $this->start_controls_section(
        	'section_content',
        	[
				'label' => __( 'Single Share', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'active_share',
			[
				'label'   => esc_html__( 'Active Share', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
        $this->end_controls_section();       
        
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Single Share', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Share Social Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .share-buttons-elementor li a ' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_ypography',
				'label' => __( 'Share Social Icon Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .share-buttons-elementor li a',
			]
		);			

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Share Social Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .share-buttons-elementor li a i ' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);
		
		$this->add_control(
			'icon_size',
			[
				'label' => __( 'Share Social Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .share-buttons-elementor li a i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {   
            if($settings['active_share'] == 'yes'){
            $permalink = get_permalink($template->GetRelatedPostId());
            $media = get_the_post_thumbnail_url($template->GetRelatedPostId());
            $title = $template->GetRelatedPostField("post_title");
            echo '<ul class="darkeble share-buttons share-buttons-elementor">
                    <li>
                        <a class="share-twitter" href="https://twitter.com/intent/tweet?text='. $permalink . '" target="_blank">
                            <i class="fab fa-twitter"></i>
                            <span>اشتراک در توییتر</span>
                        </a>
                    </li>
                    <li>
                        <a class="share-facebook" href="https://www.facebook.com/sharer/sharer.php?u='. $permalink . '" target="_blank">
                            <i class="fab fa-facebook"></i>
                            <span>اشتراک در فیسبوک</span>
                        </a>
                    </li>
                    <li>
                        <a class="share-googleplus" href="https://telegram.me/share/url?url='. $permalink . '" target="_blank">
                            <i class="fab fa-telegram"></i>
                            <span>اشتراک در تلگرام</span>
                        </a>
                    </li>
                    <li>
                        <a class="share-pinterest" href="http://pinterest.com/pin/create/button/?url='. $permalink . '&amp;media='. $media .'  &amp;description='. $title.'" target="_blank">
                                        <i class="fab fa-pinterest"></i>
                            <span>اشتراک در پینترست</span>
                        </a>
                    </li>
                </ul>';
            }    
        }
        else
        {
            if($settings['active_share'] == 'yes'){
            echo '<ul class="darkeble share-buttons share-buttons-elementor">
                    <li>
                        <a class="share-twitter" href="https://twitter.com/intent/tweet?text=" target="_blank">
                            <i class="fab fa-twitter"></i>
                            <span>اشتراک در توییتر</span>
                        </a>
                    </li>
                    <li>
                        <a class="share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=" target="_blank">
                            <i class="fab fa-facebook"></i>
                            <span>اشتراک در فیسبوک</span>
                        </a>
                    </li>
                    <li>
                        <a class="share-googleplus" href="https://telegram.me/share/url?url=" target="_blank">
                            <i class="fab fa-telegram"></i>
                            <span>اشتراک در تلگرام</span>
                        </a>
                    </li>
                    <li>
                        <a class="share-pinterest" href="http://pinterest.com/pin/create/button" target="_blank">
                                        <i class="fab fa-pinterest"></i>
                            <span>اشتراک در پینترست</span>
                        </a>
                    </li>
                </ul>';
            }    
        }
    }
}