<?php 
/**
 * Template Name: Dokan Panel
 *
 * Login Page Template.
 *
 * @author Hamkarwp Team
 * @since 1.0.0
 */


get_header();


if(is_user_logged_in()) {
    global $sigma;
    get_template_part($sigma['vendor_panel_style'] );
}
else {
    get_template_part('dashboard/my-account');
}


wp_footer();
