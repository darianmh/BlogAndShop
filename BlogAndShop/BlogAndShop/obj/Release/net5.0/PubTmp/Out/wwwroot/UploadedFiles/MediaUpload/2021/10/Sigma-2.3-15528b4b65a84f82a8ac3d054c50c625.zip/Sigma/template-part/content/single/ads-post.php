<?php  global $sigma; if ($sigma['show_ads_product'] == 'inherit') { ?>

<div class="ads_posts">
    <a href="<?php echo $sigma['ads_post_link']; ?>" target="<?php echo $sigma['single_ads_target']; ?>">
        <?php if($sigma['single_ads_image']['url']!='') { ?>
    <img src="<?php echo $sigma['single_ads_image']['url']; ?>">
<?php } else { ?>
    <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/ads728.png">
<?php } ?>
	</a>
</div>

<?php } ?>

