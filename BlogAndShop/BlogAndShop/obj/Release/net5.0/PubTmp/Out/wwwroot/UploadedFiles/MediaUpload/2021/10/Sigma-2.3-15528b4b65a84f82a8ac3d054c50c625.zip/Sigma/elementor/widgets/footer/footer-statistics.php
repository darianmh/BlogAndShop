<?php
namespace Elementor;

class Footer_Store_Statistics extends Widget_Base {

	public function get_name() {
		return 'store-statistics';
	}

	public function get_title() {
		return __( 'Footer Store Statistics', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-slideshow';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}     

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_statictics',
			[
				'label' => __( 'Footer Store Statistics', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
			'statictics_columns',
			[
				'label'          => esc_html__( 'Columns', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '6',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
			]
		);		
		
		$this->add_control(
			'statictics_lists',
			[
				'label' => __( 'Lists Store Statistics', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'title',
						'label' => __( 'Statictics Name', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => __( 'products for sale', 'sigma-theme' ),
					],
					[
						'name' => 'subtitle',
						'label' => __( 'Statictics Count', 'sigma-theme' ),
						'type'  => \Elementor\Controls_Manager::TEXT,
        				'default' => '12',
					],
					[
						'name' => 'image',
						'label' => __( 'Statictics Image', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                         'url' => get_template_directory_uri() . '/assets/img/footer01.png',
                        ],			
                    ],	
				],
				'default' => [
					[
						'title' => 'Products For Sale',
						'subtitle' => '10',
						'image' => [ 'url' => get_template_directory_uri() . '/assets/img/footer01.png', ],
					],
					[
						'title' => 'Purchase Satisfaction',
						'subtitle' => '423',
						'image' => [ 'url' => get_template_directory_uri() . '/assets/img/footer02.png', ],
					],	
					[
						'title' => 'Free Courses',
						'subtitle' => '344',
						'image' => [ 'url' => get_template_directory_uri() . '/assets/img/footer03.png', ],
					],
					[
						'title' => 'Approved Comments',
						'subtitle' => '3221',
						'image' => [ 'url' => get_template_directory_uri() . '/assets/img/footer04.png', ],
					],
					[
						'title' => 'Total Store Earning',
						'subtitle' => '124',
						'image' => [ 'url' => get_template_directory_uri() . '/assets/img/footer05.png', ],
					],
					[
						'title' => 'Support Requests',
						'subtitle' => '956',
						'image' => [ 'url' => get_template_directory_uri() . '/assets/img/footer06.png', ],
					],					
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();
		
        $this->start_controls_section(
        	'statictics_lists_style_section',
        	[
				'label' => __( 'Footer Store Statistics', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_control(
			'footer_counter_title_color',
			[
				'label' => __( 'Statistics Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .footer_v2_counter span' => 'color: {{VALUE}}',
				],		
				'default' => '#555555'
			]
		);
		
		$this->add_control(
			'footer_counter_meta_color',
			[
				'label' => __( 'Statistics Meta Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .footer_v2_counter p' => 'color: {{VALUE}}',
				],	
				'default' => '#555555'
			]
		);	
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'footer_counter_title_typography',
				'label' => __( 'Statistics Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .footer_v2_counter p',
			]
		);	
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'footer_counter_meta_typography',
				'label' => __( 'Statistics Meta Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .footer_v2_counter span',
			]
		);			
		
		$this->end_controls_section();		
		
	}	

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="footers_statictic footers_statictic_columns_<?php echo $settings['statictics_columns'] ; ?>"><ul class="row">
		<?php foreach ( $settings['statictics_lists'] as $index => $item ) : ?>
			<li>
				<?php 
				echo'<div class="footer_v2_counter"> <img src="'.$item['image']['url'].'"> <p>'.$item['subtitle'].'</p> <span>'.$item['title'].'</span> </div>'; 
				?>
			</li>
		<?php endforeach; ?>
		</ul></div>
		<?php
	}	
}