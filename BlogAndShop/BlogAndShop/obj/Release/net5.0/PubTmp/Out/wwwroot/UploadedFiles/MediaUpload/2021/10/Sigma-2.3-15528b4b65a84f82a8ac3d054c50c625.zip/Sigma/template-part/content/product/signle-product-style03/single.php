<?php if (have_posts()):
setPostViews(get_the_ID()); ?>
<div class="full-width-breadcame breadcame_dgs full-width-breadcame-edc">
    <?php global $sigma;
    if ($sigma['single_product_full_width'] == 'enable') { ?>
    <div class="container"> <?php } else{ ?>
        <div class="container-fluid"> <?php } ?>
            <div class="row">
                <div class="col-12">
                    <div class="breadcame">
                        <?php
                        $args = array(
                            'delimiter' => ' <i></i> ',
                            'home' => __('home', 'sigma-theme'));
                        woocommerce_breadcrumb($args);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php while (have_posts()):
    the_post(); ?>


    <?php global $sigma;
    if ($sigma['single_product_full_width'] == 'enable') { ?>
    <div class="container"> <?php } else{ ?>
        <div class="container-fluid"> <?php } ?>
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-sm-12 edc_products_meain">
                    <?php
                    global $sigma;
                    if ($sigma['teacher_active_v3'] == 'block') {
                        ?>

                        <div class="teacher_edc_single_area">

                            <?php
                            $id = get_the_ID();
                            $info = sigma_get_tutorial_info($id);
                            if ($sigma['teacher_active_meta_v3'] == 'block') {
                                ?>
                                <div class="hexagon_teacher_single_bg"></div>
                                <div id="hexagon_teacher" class="hexagon_teacher_single"><img
                                            src="<?php echo $info['teacher_pic'] ?>"></div>
                                <div class="teacher_meta_single">
                                    <h3><?php echo $info['product_teacher'] ?></h3>
                                    <?php if ($sigma['teacher_username_active_v3'] == 'block') { ?>
                                    <span>@<?php $user_author = get_the_author_meta('user_login');
                                        echo $user_author ?></span>
                                    <?php } ?>    
                                    <small><?php echo __('the instructor of this course.', 'sigma-theme') ?></small>
                                </div>
                            <?php } ?>
                            <div class="teacher_number_students">
                                <p><?php echo $info['teacher_about'] ?></p>

                                <?php if ($sigma['teacher_phone_active_v3'] == 'block') { ?>
                                    <div class="teacher_phone_number">
                                        <span><?php echo __('Instructor Phone number:', 'sigma-theme') ?></span>
                                        <?php
                                        global $product;
                                        $logged_in = true;
                                        $user = wp_get_current_user();
                                        $user_id = $user->ID;
                                        $customer_email = $user->user_email;
                                        $product_id = $product->get_id();
                                        $bought = wc_customer_bought_product( $customer_email, $user_id, $product_id ) ;
                                        if ($bought) {
                                            ?>
                                            <div class="teacher_unlocked_phone"><i class="fal fa-phone"></i><small><a
                                                            href="tel:+98<?php echo $info['teacher_number'] ?>"><?php echo $info['teacher_number'] ?></a></small><?php echo __('In fact, it is important to be supportive.', 'sigma-theme') ?>
                                            </div>
                                            <?php
                                        } else { ?>
                                            <div class="teacher_locked_phone"><i class="fal fa-phone"></i><small>●●●●●●●●●<b>09</b></small><?php echo __('(It will be displayed after purchasing the course.)', 'sigma-theme') ?>
                                            </div>
                                        <?php } ?>

                                    </div>
                                <?php } ?>
                                <!--    <div class="edc_badges">
                                        <ul>
                                            <li id="hexagon" class="badge_singel pink_badge"><i class="far fa-user-crown"></i><span class="badge-tooltip">۱۲ سال عضویت</span></li>
                                            <li id="hexagon" class="badge_singel yellow_badge"><i class="far fa-bullseye-pointer"></i><span class="badge-tooltip">۱۰ تا ۲۰ خرید </span></li>
                                            <li id="hexagon" class="badge_singel blue_badge"><i class="far fa-book-reader"></i><span class="badge-tooltip">۲ دوره آموزشی</span></li>
                                            <li id="hexagon" class="badge_singel green_badge"><i class="far fa-browser"></i><span class="badge-tooltip">آموزش ویژه</span></li>
                                            <li id="hexagon" class="badge_singel red_badge"><i class="far fa-briefcase-medical"></i><span class="badge-tooltip">رضایت بیش ۱۰ کاربر</span></li>
                                        </ul>
                                    </div>
                                -->
                            </div>
                        </div>

                    <?php } ?>

                    <div id="<?php if ($sigma['sticky_sidebar_active_v3'] == 'enable') {
                        echo 'edc_course_meta_area_fixed';
                    } ?>" class="edc_sidebar_area edc_course_meta_area">
                        <?php if ($sigma['courese_sales_active_v3'] == 'block') { ?>
                            <span class="edc_n_student_big"><b><?php echo(get_post_meta(get_the_ID(), 'total_sales', true)); ?></b></span>
                            <small><?php echo __('People have bought the course!', 'sigma-theme') ?></small>
                        <?php } ?>

                        <?php if ($sigma['courese_3meta_active_v3'] == 'block') { ?>
                            <div class="meta_qiuck_special_edc edc_single_course_qmeta">
                                <ul>
                                    <li>
                                        <p><?php echo $info['product_time'] ?></p>
                                        <span><?php echo __('Course length', 'sigma-theme') ?></span></li>
                                    <li>
                                        <p><?php echo $info['product_part_number'] ?></p>
                                        <span><?php echo __('Number of sessions', 'sigma-theme') ?></span></li>
                                    <li>
                                        <p><?php echo(get_post_meta(get_the_ID(), '_wc_average_rating', true)); ?></p>
                                        <span><?php echo __('Average points', 'sigma-theme') ?></span></li>
                                </ul>
                            </div>
                        <?php } ?>

                        <?php if ($sigma['courese_qiuck_active_v3'] == 'block') { ?>
                            <ul class="edc_course_qlist">

                                <li><a href="#description"><i
                                                class="far fa-list-ol"></i><?php echo __('Course description', 'sigma-theme') ?>
                                    </a></li>

                                <?php if ($sigma['courese_parts_active_v3'] == 'block') { ?>
                                    <li><a href="#parts"><i
                                                    class="far fa-list-alt"></i><?php echo __('Course sessions', 'sigma-theme') ?>
                                        </a></li>
                                <?php } ?>

                                <?php if ($sigma['courese_comments_active_v3'] == 'block') { ?>
                                    <li><a href="#usercomments"><i
                                                    class="far fa-comment-lines"></i><?php echo __('User Comments', 'sigma-theme') ?>
                                        </a></li>
                                <?php } ?>

                                <?php if ($sigma['courese_related_active_v3'] == 'block') { ?>
                                    <li><a href="#courses"><i
                                                    class="far fa-bars"></i><?php echo __('Other courses teacher', 'sigma-theme') ?>
                                        </a></li>
                                <?php } ?>

                            </ul>
                        <?php } ?>


                        <?php if ($sigma['courese_buy_active_v3'] == 'block') { ?>
                            <div class="edc_special_price edc_single_price dgs_single_price">
                                <?php woocommerce_template_single_price(); ?>
                            </div>
                            <?php
                            global $product;
                            $logged_in = true;
                            $user = wp_get_current_user();
                            $user_id = $user->ID;
                            $customer_email = $user->user_email;
                            $product_id = $product->get_id();
                            $bought = wc_customer_bought_product( $customer_email, $user_id, $product_id ) ;
                            if ($bought) {
                                ?>
                                <a href="<?php echo get_post_permalink(); ?>#parts" class="edc_sidebar_register_btn"><i
                                            class="far fa-book-reader"></i><?php echo __('You are a student of the course!', 'sigma-theme') ?>
                                </a>
                                <?php
                            } else {
                                do_action('woocommerce_single_product_summary');
                            }
                            if ('' === $product->get_price() || 0 == $product->get_price() && $sigma['free_products_checkout'] == 'disable') {
                                $downloads = $product->get_downloads();

                                foreach ($downloads as $key => $each_download) {
                                    echo '<button class="single_add_to_cart_button button alt freedl_sgm"><a href="' . $each_download["file"] . '">' . $each_download["name"] . '</a></button>';
                                }
                            }
                        }
                    echo get_product_countdown_single($id) ;
                        if ($sigma['courese_badge_active_v3'] == 'block') { ?>
                            <?php
                            $id = get_the_ID();
                            $medals = sigma_get_product_medals($id);
                            if (false != $medals) {
                                ?>
                                <?php
                                echo '<div class="edc_badges"> <ul>';
                                foreach ($medals as $medal) {
                                    ?>
                                    <li id="hexagon" class="badge_singel pink_badge"><img
                                                src="<?php echo $medal['medal_pic'] ?>"
                                                alt="<?php echo $medal['medal_name'] ?>"><span
                                                class="badge-tooltip"><?php echo $medal['medal_name'] ?></span></li>
                                    <?php
                                }
                                echo '</ul></div>';
                                ?>
                                <?php
                            }
                        }
                        ?>
                    </div>
                    <div class="edc_sidebar_area crouse_guarantee_area">
                        <div class="edc_icon_sticky_refound"><i class="fal fa-badge-dollar"></i></div>
                        <?php dynamic_sidebar('courses_sidebar'); ?>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-> col-sm-12 edc_products_meain">
                    <?php do_action('woocommerce_before_single_product'); ?>
                    <div class="main_edc_products">
                        <div class="edc_products_photo">
                            <img src="<?php echo get_the_post_thumbnail_url(); ?>">
                            <svg class="decor" width="842px" height="219px" viewBox="0 0 842 219"
                                 preserveAspectRatio="xMaxYMax meet" version="1.1" xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink">
                                <g transform="translate(-381.000000, -362.000000)" fill="#FFFFFF">
                                    <path class="decor-path"
                                          d="M1223,362 L1223,581 L381,581 C868.912802,575.666667 1149.57947,502.666667 1223,362 Z"></path>
                                </g>
                            </svg>
                        </div>
                        <div class="edc_products_description" id="description">
                            <div class="edc_products_meta">
                                <ul>
                                    <?php if ($sigma['courese_date_publish_active_v3'] == 'block') { ?>
                                        <li>
                                            <i class="far fa-calendar-plus"></i><?php echo __('Publish:', 'sigma-theme') ?>
                                            : <?php $post_date = get_the_date('l j F Y');
                                            echo $post_date; ?> </li>
                                    <?php } ?>

                                    <?php if ($sigma['courese_date_update_active_v3'] == 'block') { ?>
                                        <li><i class="far fa-calendar"></i><?php echo __('Update:', 'sigma-theme') ?>
                                            : <?php global $product;
                                            echo '<span class="date_modified">' . $product->get_date_modified()->date_i18n('l j F Y') . '</span>'; ?>
                                        </li>
                                    <?php } ?>

                                    <?php if ($sigma['courese_views_active_v3'] == 'block') { ?>
                                        <li><i class="far fa-eye"></i><?php echo getPostViews(get_the_ID()); ?></li>
                                    <?php } ?>

                                    <?php if ($sigma['courese_cm_active_v3'] == 'block') { ?>
                                        <li>
                                            <i class="far fa-comment"></i><?php comments_popup_link( __('No Comment', 'sigma-theme'), __('1 Comment', 'sigma-theme'), __('% Comments', 'sigma-theme'), __('Comments are Closed', 'sigma-theme') ); ?>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </div>
                            <div class="edc_products_single_title">
                                <h1><?php the_title(); ?></h1>
                                <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>

                                <?php if ($sigma['courese_bookmart_active_v3'] == 'block') { ?>
                                    <?php
                                    if (!sigma_is_in_wishlist($post->ID)) {
                                        ?>
                                        <div class="edc_bookmark_meta_single"><a class="sigma-add-to-wishlist"
                                                                                 data-product-id="<?php echo $post->ID ?>"><i
                                                        class="far fa-bookmark"></i></a></div>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="edc_bookmark_meta_single"><a
                                                    href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank"
                                                    class="sigma-add-to-wishlist-added"
                                                    data-product-id="<?php echo $post->ID ?>"><span
                                                        class="badge-tooltip-all"><?php echo __('See favorites', 'sigma-theme') ?></span><i
                                                        class="far fa-bookmark"></i></a></div>
                                        <?php
                                    }
                                    ?>
                                <?php } ?>

                                <?php if ($sigma['courese_share_active_v3'] == 'block') { ?>
                                    <div class="edc_bookmark_meta_single edc_share_meta_single">
                                        <a href="#"><i class="far fa-share-alt-square"></i></a>
                                        <div class="edd_share_btn_more">
                                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-facebook"></i></a>
                                            <a href="https://telegram.me/share/url?url=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-telegram"></i></a>
                                            <a href="https://twitter.com/intent/tweet?text=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-twitter"></i></a>
                                            <a href="https://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>"><i
                                                        class="fab fa-pinterest"></i></a>
                                        </div>
                                    </div>
                                <?php } ?>

                            </div>
                            <?php if ($sigma['courese_cat_active_v3'] == 'block') { ?>
                                <div class="edc_products_single_cat">
                                    <p><?php echo __('Category:', 'sigma-theme') ?> </p>
                                    <?php
                                    $terms = wp_get_post_terms(get_the_ID(), 'product_cat');
                                    $terms_count = count($terms);
                                    echo '<ul>';
                                    foreach ($terms as $key => $term) {
                                        $sperator = $key !== ($terms_count - 1) ? '' : '';
                                        echo "<li class=''><a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a></li>";
                                    }
                                    echo '</ul>';
                                    ?>
                                </div>
                            <?php } ?>

                            <div class="edc_products_single_content">
                                <p><?php the_content(); ?></p>
                            </div>
                            <?php if ($sigma['courese_tag_active_v3'] == 'block') {
                                $terms = wp_get_post_terms(get_the_ID(), 'product_tag');
                                $terms_count = count($terms);
                                if ($terms_count > 1) {
                                    echo '<div class="edc_course_tags_single"><ul><li>';
                                    foreach ($terms as $key => $term) {
                                        $sperator = $key !== ($terms_count - 1) ? ' ' : ' ';
                                        echo "<a href='" . get_term_link($term->term_id) . "'>" . esc_html($term->name) . $sperator . "</a>";
                                    }
                                    echo '</li></ul></div>';
                                }
                            } ?>

                        </div>
                    </div>

                    <?php if ($sigma['courese_parts_active_v3'] == 'block') { ?>
                        <div class="course_edc_lists_single" id="parts">
                            <h4><?php echo __('Course sessions', 'sigma-theme') ?></h4>
                            </section>
                            <small><?php echo $info['product_part_number'] ?> <?php echo __('session', 'sigma-theme'); ?>
                                <?php echo __('(Total period time:', 'sigma-theme') ?>
                                <?php echo $info['product_time'] ?> )
                            </small>

                            <?php
                            $id = get_the_ID();
                            $tutorials = sigma_get_tutorial_parts($id);
                            if (false != $tutorials) {
                                ?>
                                <ul>
                                    <?php
                                    foreach ($tutorials as $tutorial) {
                                        $free = $tutorial["tutorial_free"];
                                        $bought = false;
                                        $logged_in = false;
                                        if (is_user_logged_in()) {
                                        global $product;
                                            $logged_in = true;
                                            $user = wp_get_current_user();
                                            $user_id = $user->ID;
                                            $customer_email = $user->user_email;
                                            $product_id = $product->get_id();
                                            $bought = wc_customer_bought_product( $customer_email, $user_id, $product_id ) ;
                                        }
                                        ?>
                                        <li>
                                            <span class="edc_parts_name"><?php echo $tutorial['tutorial_part'] ?></span>
                                            <?php
                                            echo '<p>' . $tutorial['tutorial_title'] . '</p>';
                                            if ($free == 1 || $bought) {
                                                ?>
                                                <?php if ($sigma['single_courses_popup_part'] == 'enable') { ?>
                                                    <a data-toggle="modal"
                                                       data-target="#classModal-<?php echo $tutorial['tutorial_part'] ?>"
                                                       href="<?php echo $tutorial['tutorial_link'] ?>"
                                                       target="_blank"><i class="far fa-play"><span
                                                                    class="badge-tooltip-all"><?php echo __('Free show', 'sigma-theme') ?></span></i></a>
                                                    <div class="class-modal modal fade"
                                                         id="classModal-<?php echo $tutorial['tutorial_part'] ?>"
                                                         tabindex="-1" role="dialog"
                                                         aria-labelledby="classModal-<?php echo $tutorial['tutorial_part'] ?>Label"
                                                         aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                    <h5 class="modal-title"
                                                                        id="classModal-<?php echo $tutorial['tutorial_part'] ?>Label"><?php echo $tutorial['tutorial_title']; ?></h5>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <video width="460" height="350" controls>
                                                                        <source src="<?php echo $tutorial['tutorial_link'] ?>"
                                                                                type="video/mp4">
                                                                        <source src="<?php echo $tutorial['tutorial_link'] ?>"
                                                                                type="video/ogg">
                                                                        <?php _e('Your browser does not support this video format!', 'sigma-theme'); ?>
                                                                    </video>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php } else { ?>
                                                    <a href="<?php echo $tutorial['tutorial_link'] ?>"
                                                       target="_blank"><i class="far fa-play"><span
                                                                    class="badge-tooltip-all"><?php echo __('Free show', 'sigma-theme') ?></span></i></a>
                                                <?php }
                                            } else {
                                                ?>
                                                <i class="far fa-lock"><span
                                                            class="badge-tooltip-all"><?php echo __('Premium show', 'sigma-theme') ?></span></i>
                                                <?php
                                            }
                                            ?>
                                            <span class="edc_totaltime_course"><i
                                                        class="far fa-clock"></i><?php echo $tutorial['tutorial_time'] ?></span>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                                <?php
                            }
                            ?>

                        </div>
                    <?php } ?>

                    <?php if ($sigma['courese_comments_active_v3'] == 'block') { ?>
                        <div class="course_edc_warp edc_comments_area edc_comments_area_vet" id="usercomments">
                            <div class="edc_single_comments_lists border_line_left">

                                <div class="edc_single_comments_lists_warp">
                                    <h4><?php echo __('User Comments', 'sigma-theme') ?></h4>
                                    <span class="edc_comments_number_total"><?php comments_popup_link( __('No Comment', 'sigma-theme'), __('1 Comment', 'sigma-theme'), __('% Comments', 'sigma-theme'), __('Comments are Closed', 'sigma-theme') ); ?></span>
                                    <small>User Comments</small>
                                    <?php
                                    echo '<ol class="commentlist">';
                                    //Gather comments for a specific page/post 
                                    $comments = get_comments(array(
                                        'post_id' => $post->ID,
                                        'status' => 'approve'
                                    ));
                                    wp_list_comments(array(
                                        'per_page' => 10, // Allow comment pagination
                                        'reverse_top_level' => false //Show the latest comments at the top of the list
                                    ), $comments);
                                    echo '</ol>';
                                    ?>
                                </div>

                                <h4><?php echo __('Write a comment:', 'sigma-theme') ?></h4>
                                <small>Submit a Comment</small>
                                <div id="reviews" class="woocommerce-Reviews">
                                    <?php if (get_option('woocommerce_review_rating_verification_required') === 'no' || wc_customer_bought_product('', get_current_user_id(), $product->get_id())) : ?>
                                        <div id="review_form_wrapper">
                                            <div id="review_form">
                                                <?php
                                                $commenter = wp_get_current_commenter();
                                                $comment_form = array(
                                                    'title_reply_to' => esc_html__('Leave a Reply to %s', 'woocommerce'),
                                                    'title_reply_before' => '<span id="reply-title" class="comment-reply-title">',
                                                    'title_reply_after' => '</span>',
                                                    'comment_notes_after' => '',
                                                    'label_submit' => esc_html__('Submit', 'woocommerce'),
                                                    'logged_in_as' => '',
                                                    'comment_field' => '',
                                                );

                                                $name_email_required = (bool)get_option('require_name_email', 1);
                                                $fields = array(
                                                    'author' => array(
                                                        'label' => __('Name', 'woocommerce'),
                                                        'type' => 'text',
                                                        'value' => $commenter['comment_author'],
                                                        'required' => $name_email_required,
                                                    ),
                                                    'email' => array(
                                                        'label' => __('Email', 'woocommerce'),
                                                        'type' => 'email',
                                                        'value' => $commenter['comment_author_email'],
                                                        'required' => $name_email_required,
                                                    ),
                                                );

                                                $comment_form['fields'] = array();

                                                foreach ($fields as $key => $field) {
                                                    $field_html = '<p class="comment-form-' . esc_attr($key) . '">';
                                                    $field_html .= '<label for="' . esc_attr($key) . '">' . esc_html($field['label']);

                                                    if ($field['required']) {
                                                        $field_html .= '&nbsp;<span class="required">*</span>';
                                                    }

                                                    $field_html .= '</label><input id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" type="' . esc_attr($field['type']) . '" value="' . esc_attr($field['value']) . '" size="30" ' . ($field['required'] ? 'required' : '') . ' /></p>';

                                                    $comment_form['fields'][$key] = $field_html;
                                                }

                                                $account_page_url = wc_get_page_permalink('myaccount');
                                                if ($account_page_url) {
                                                    /* translators: %s opening and closing link tags respectively */
                                                    $comment_form['must_log_in'] = '<p class="must-log-in">' . sprintf(esc_html__('You must be %1$slogged in%2$s to post a review.', 'woocommerce'), '<a href="' . esc_url($account_page_url) . '">', '</a>') . '</p>';
                                                }

                                                if (wc_review_ratings_enabled()) {
                                                    $comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating">' . esc_html__('Your rating', 'woocommerce') . '</label><select name="rating" id="rating" required>
                                    						<option value="">' . esc_html__('Rate&hellip;', 'woocommerce') . '</option>
                                    						<option value="5">' . esc_html__('Perfect', 'woocommerce') . '</option>
                                    						<option value="4">' . esc_html__('Good', 'woocommerce') . '</option>
                                    						<option value="3">' . esc_html__('Average', 'woocommerce') . '</option>
                                    						<option value="2">' . esc_html__('Not that bad', 'woocommerce') . '</option>
                                    						<option value="1">' . esc_html__('Very poor', 'woocommerce') . '</option>
                                    					</select></div>';
                                                }

                                                $comment_form['comment_field'] .= '<p class="comment-form-comment"><label for="comment">' . esc_html__('Your review', 'woocommerce') . '&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>';

                                                comment_form(apply_filters('woocommerce_product_review_comment_form_args', $comment_form));
                                                ?>
                                            </div>
                                        </div>
                                    <?php else : ?>
                                        <p class="woocommerce-verification-required"><?php esc_html_e('Only logged in customers who have purchased this product may leave a review.', 'woocommerce'); ?></p>
                                    <?php endif; ?>

                                    <div class="clear"></div>
                                </div>
                                <div class="edc_commentes_roles">
                                    <p> <?php global $sigma;
                                        echo $sigma['role_post_content']; ?> </p>
                                </div>
                            </div>
                        </div>
                    <?php } ?>

                    <?php if ($sigma['courese_related_active_v3'] == 'block') { ?>
                        <div class="course_edc_warp edc_lasts_course" id="courses">
                            <h4><?php echo __('Related courses', 'sigma-theme') ?></h4>
                            <small>Related Courses</small>
                            <div class="edc_related_courses">
                                <div id="related_edc" class="owl-carousel">
                                    <?php
                                    $trmids = wp_get_post_terms($post->ID, 'product_cat');
                                    $trmarray = array();
                                    foreach ($trmids as $v) {
                                        $trmarray[] = $v->term_id;
                                    }

                                    $arms = array(
                                        'post_type' => 'product',
                                        'posts_per_page' => '9',
                                        'order' => 'DESC',
                                        'post_status' => 'publish',
                                        'post__not_in' => array($post->ID),
                                        'tax_query' => array(
                                            array(
                                                'taxonomy' => 'product_cat',
                                                'terms' => $trmarray,
                                            ),
                                        )
                                    );
                                    $the_query = new WP_Query($arms);
                                    if ($the_query->have_posts()) : ?>
                                        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>


                                            <?php
                                            echo '<li class="gird_cousrses_sigma gird_cousrses_sigma_archive"> <div class="sigma-wc-courses-inner"><div class="single_curses_warp darkeble">
            <div class="single_curses_img">
                <div class="special_bookmark single_bookmark">' ?>
                                            <?php
                                            if (!sigma_is_in_wishlist($post->ID)) {
                                                ?>
                                                <a class="sigma-add-to-wishlist"
                                                   data-product-id="<?php echo $post->ID ?>"><i
                                                            class="far fa-bookmark"></i></a>
                                                <?php
                                            } else {
                                                ?>
                                                <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank"
                                                   class="sigma-add-to-wishlist-added"
                                                   data-product-id="<?php echo $post->ID ?>"><span
                                                            class="badge-tooltip-all"><?php echo __('See favorites', 'sigma-theme') ?></span><i
                                                            class="far fa-bookmark"></i></a>
                                                <?php
                                            }
                                            ?>
                                            <?php echo '</div>
                <a href="' . get_the_permalink() . '"> ' ?>
                                            <?php
                                            the_post_thumbnail('cousre');
                                            ?>
                                            <?php echo '</a>
            </div>
            <div class="single_curses_meta">
                <div class="hexagon_teacher_single_bg"></div>
                <div id="hexagon_teacher" class="hexagon_teacher_single">' ?>
                                            <?php
                                            $id = get_the_ID();
                                            $info = sigma_get_tutorial_info($id);
                                            echo '<img src="' . $info['teacher_pic'] . '">';
                                            ?>
                                            <?php echo '</div>
                <h2><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></h2>
                <small>' . (get_post_meta(get_the_ID(), 'en_title_sigma', true)) . '</small>' ?>
                                            <?php
                                            echo '<div class="meta_qiuck_special_edc single_quick">
                    <ul>
                        <li> ' ?>
                                            <?php
                                            $id = get_the_ID();
                                            $info = sigma_get_tutorial_info($id);
                                            ?>
                                            <p><?php
                                                if ($info > 1) {
                                                    echo $info['product_time'];
                                                } else {
                                                    echo '-';
                                                }
                                                ?></p><span><?php echo __('Course length', 'sigma-theme') ?></span></li>
                                            <li>
                                            <?php echo '<p>' . get_comments_number() . '</p><span>' . __('Comment Count', 'sigma-theme') . '</span></li>
                        <li>
                            <p>' . (get_post_meta(get_the_ID(), 'total_sales', true)) . '</p><span>' . __('Student Count', 'sigma-theme') . '</span></li>
                    </ul>
                </div>
                <div class="edc_badges edc_badges_signle"><ul>' ?>
                                            <?php
                                            $id = get_the_ID();
                                            $medals = sigma_get_product_medals($id);
                                            if (false != $medals) {
                                                foreach ($medals as $medal) {
                                                    ?>
                                                    <li id="hexagon" class="badge_singel pink_badge"><img
                                                                src="<?php echo $medal['medal_pic'] ?>"
                                                                alt="<?php echo $medal['medal_name'] ?>"><span
                                                                class="badge-tooltip"><?php echo $medal['medal_name'] ?></span>
                                                    </li>
                                                    <?php
                                                }
                                            }
                                            ?>
                                            <?php echo '</div></ul>
            </div>
            <div class="edc_button_single">
                <ul>
                    <li><a href="' . get_post_permalink() . '?add-to-cart=' . get_the_ID() . '"><i class="far fa-shopping-bag"></i></a></li>
                    <li><a href="' . get_the_permalink() . '"><i class="fal fa-ellipsis-h-alt"></i></a></li>
                </ul>
            </div>
        </div></div></li>';

                                            ?>

                                        <?php endwhile; ?>
                                        <?php wp_reset_postdata(); ?>


                                    <?php else : ?>
                                        <p class="nopostdata"><?php _e('There are no products to display.', 'sigma-theme'); ?> </p>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    <?php } ?>

                </div>
            </div>
        </div>

        <script>
            $(window).scroll(() => {
                topOfFooter = $('.footer-sgm-main').position().top;
                scrollDistanceFromTopOfDoc = $(document).scrollTop() + 1350;
                scrollDistanceFromTopOfFooter = scrollDistanceFromTopOfDoc - topOfFooter;

                if (scrollDistanceFromTopOfDoc > topOfFooter) {
                    $('.edc_course_show_fixed').css('opacity', 0);
                } else {
                    $('.edc_course_show_fixed').css('opacity', 1);
                }
            });
        </script>

        <?php endwhile; ?>
        <?php endif; ?>
