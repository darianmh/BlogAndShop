<?php
namespace Elementor;

class Footer_Menu extends Widget_Base {

	public function get_name() {
		return 'footer-menu';
	}

	public function get_title() {
		return __( 'Footer Menu', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}

    public function get_menus(){
        $list = [];
        $menus = wp_get_nav_menus();
        foreach($menus as $menu){
            $list[$menu->slug] = $menu->name;
        }

        return $list;	
    }
    
	protected function _register_controls() {
		$this->start_controls_section(
			'section_main_menu',
			[
				'label' => __( 'Footer Menu', 'sigma-theme' ),
			]
		);

        $this->add_control(
            'sigma_footer_menu',
            [
                'label'     =>esc_html__( 'Select menu', 'sigma-theme' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->get_menus(),
            ]
		);

		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section_footer_menu',
        	[
				'label' => __( 'Footer Menu Item', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography_footer_nav',
				'label' => __( 'Footer Menu Item Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .dgs_simga_footer_nav ul li a',
			]
		);		

		$this->add_control(
			'item_footer_menu_color',
			[
				'label' => __( 'Footer Menu item color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_simga_footer_nav ul li a' => 'color: {{VALUE}}',
				],		
				'default' => '#777777'
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'item_footer_menu_hover_bg',
				'label' => __( 'Footer Menu Background hover color', 'plugin-domain' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .dgs_simga_footer_nav ul li a:hover',
			]
		);
		
		$this->add_control(
			'item_footer_menu_color_hover',
			[
				'label' => __( 'Footer Menu item color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_simga_footer_nav ul li a:hover' => 'color: {{VALUE}}',
				],		
				'default' => '#585858'
			]
		);		
		$this->end_controls_section();	

	}

	protected function render() {

        $settings = $this->get_settings();

        extract( $settings );
        ?>
            <div class="sigma_nav_footer">
                <div class="dgs_simga_footer_nav" role="navigation">
                <?php
                    $args = array(
                        'container_class' => 'collapse navbar-collapse no-padding',
                        'fallback_cb' => '',
                        'menu_id' => 'header-menu',
        				'menu'         	  => $settings['sigma_footer_menu'],
                    );
                    wp_nav_menu($args);
                ?>
                </div>
            </div>
        <?php
    }
    
	protected function _content_template() {

	}
}