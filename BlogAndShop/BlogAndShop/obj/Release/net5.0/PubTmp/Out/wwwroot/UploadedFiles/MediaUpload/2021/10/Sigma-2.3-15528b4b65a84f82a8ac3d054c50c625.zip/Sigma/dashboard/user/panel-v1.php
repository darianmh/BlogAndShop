<?php get_template_part('dashboard/panel-menu'); ?>
<div class="topbar-dashboard-v1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 panel-title col-10">
                <h1><a href="<?php bloginfo('url') ?>"><i class="fal fa-list-ul"></i><?php bloginfo('name'); ?></a></h1>
            </div>

            <div class="col-lg-2 panel-logo col-2">
                <a href="<?php bloginfo('url') ?>" target="_blank">
                    <?php global $sigma;
                    if ($sigma['panel_logo']['url'] != '') { ?>
                        <img src="<?php echo $sigma['panel_logo']['url']; ?>">
                    <?php } else { ?>
                        <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/favicon.png">
                    <?php } ?>
                </a>
            </div>

            <div class="col-lg-5 panel-menu">
                <div class="support-menu">
                    <?php if ($sigma['show_support_phone'] == 'inherit') { ?>
                    <p><i class="fal fa-phone"></i><?php _e('support:', 'sigma-theme'); ?><?php 
                        echo $sigma['supp_phone']; ?> </p>
                    <?php
                    }
                    if (class_exists('WooWallet')) {
                        if ($sigma['show_deposit'] == 'inherit') {
                        echo '<p><i class="fal fa-money"></i>';
                        _e('Wallet balance:', 'sigma-theme');
                        echo woo_wallet()->wallet->get_wallet_balance(get_current_user_id()) . ' </p> ';
                        }
                    }
                    ?>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="container-fluid panel-v1-content">
    <div class="row">
        <div class="col-sm-6 col-lg-3 panel-v1-right nopadding">
            <div class="user_menu_v1">
                <?php
                $user = wp_get_current_user();
                if ($user) { ?>
                    <img src="<?php echo esc_url(get_avatar_url($user->ID)); ?>"/>
                <?php } ?>

                <div class="user-n">
                    <?php $current_user = wp_get_current_user();
                    echo $current_user->display_name . '<br/>'; ?>
                </div>

                <div class="wellcome">
                    <?php
                    $current_user = wp_get_current_user();
                    $reg_date = date_i18n('j F Y', strtotime($current_user->user_registered));
                    ?>
                    <p><?php _e('Your membership date:', 'sigma-theme'); ?><?php echo $reg_date; ?></p>
                </div>
            </div>
            <div class="menu-panel-v1">

                <?php
                if ($sigma['active_woo_my_account_nav'] == 'enable') {
                    do_action('woocommerce_before_account_navigation'); ?>
                    <ul>
                        <?php foreach (wc_get_account_menu_items() as $endpoint => $label) : ?>
                            <li class="<?php echo wc_get_account_menu_item_classes($endpoint); ?>">
                                <a href="<?php echo esc_url(wc_get_account_endpoint_url($endpoint)); ?>"><?php echo esc_html($label); ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php do_action('woocommerce_after_account_navigation');
                } ?>

                <?php if (has_nav_menu('users-menu')) {
                    wp_nav_menu(array('theme_location' => 'users-menu'));
                }
                ?>
            </div>
        </div>
        <div class="col-sm-6 col-lg-9">
            <div class="panel-content">
                
                <div class="breadcrumb_post">
                    <?php
                    $args = array(
                        'delimiter' => ' <i></i> ',
                        'home' => __('home', 'sigma-theme'));
                    woocommerce_breadcrumb($args);
                    ?>
                </div>
                
                <?php while (have_posts()) : the_post(); ?>
                    <div class="postholder pageholder">
                        <?php the_content(); ?>
                    </div>
                <?php endwhile; ?>

            </div>
        </div>
    </div>
</div>    