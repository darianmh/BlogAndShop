<?php
namespace Elementor;

class Main_Sigma_Ads extends Widget_Base {
	
	public function get_name() {
		return 'main-ads';
	}
	
	public function get_title() {
		return __( 'Sigma Ads', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-click';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_ads',
			[
				'label' => __( 'Sigma Ads', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'ads_type_select',
			[
				'label'   => esc_html__( 'Select deal products Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'ads_type_select_01',
				'options' => [
                    'ads_type_select_01' => esc_html__('Default Style', 'sigma-theme'),
                    'ads_type_select_02' => esc_html__('Custom Code', 'sigma-theme'),
                ],
			]
        );

		$this->add_control(
			'custom_code_ads',
			[
				'label' => __( 'Ads Custom Code', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::CODE,
				'language' => 'html',
				'rows' => 20,
				'condition' => [ 'ads_type_select' => 'ads_type_select_02', ],  
			]
		);
		
		$this->add_control(
			'ads_img',
                   [
                    'label' => __( 'Choose Ads Image', 'sigma-theme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'dynamic' => [
                                  'active' => true,
                                 ],
                    'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/ads728.png',
                    ],
                    'condition' => [ 'ads_type_select' => 'ads_type_select_01', ],  
                  ]
		);   

		$this->add_control(
			'ads_url',
			[
				'label' => __( 'Ads Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'Ads Link Enter', 'sigma-theme' ),
                'condition' => [ 'ads_type_select' => 'ads_type_select_01', ],     					
                'default' => [ 'url' => 'https://hamkarwp.com', ]
			]
		);

 		$this->add_control(
			'ads_title',
			[
				'label' => __( 'Ads Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Ads Title', 'sigma-theme' ),
                'condition' => [ 'ads_type_select' => 'ads_type_select_01', ],     					
                'default' => __( 'Advertisement', 'sigma-theme' ),
			]
		);

        $this->add_control(
			'ads_alignment',
			[
				'label' => __( 'Ads Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fal fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fal fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fal fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .sgm_advertisement_area a ' => 'text-align: {{VALUE}};'
                ],	
			]
		);		        		
		$this->end_controls_section();
	}
    
	protected function render() {
		$settings = $this->get_settings();
		$target = $settings['ads_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['ads_url']['nofollow'] ? ' rel="nofollow"' : '';		
		if($settings['ads_type_select'] == 'ads_type_select_01' && !empty($settings['ads_type_select'])){   
		echo '<div class="sgm_advertisement_area"><a href="' . $settings['ads_url']['url'] . '" title"'.$settings['ads_title'].'" ' . $target . $nofollow . '><img alt="ads" title="ads" src="'.$settings['ads_img']['url'].'"></a></div>';
		}
		if($settings['ads_type_select'] == 'ads_type_select_02' ) {
		echo '<div class="sgm_advertisement_area">' . $settings['custom_code_ads'] . '</div>' ;    
		}
	}
}