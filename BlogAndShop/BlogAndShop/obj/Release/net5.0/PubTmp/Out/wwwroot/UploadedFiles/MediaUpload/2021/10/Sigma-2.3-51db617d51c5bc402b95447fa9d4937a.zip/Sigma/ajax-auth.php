<form id="login" class="ajax-auth" action="login" method="post">
    <div class="row">
        <div class="form-bg col-md-6">
        </div>

        <div class="form-conent col-md-6">
            <h3><?php _e("new user?", "sigma-theme") ?><a id="pop_signup" href=""><?php _e("please register", "sigma-theme"); ?></a></h3>
            <hr/>
            <h4><?php __("log in", "sigma-theme"); ?></h4>
            <p class="status"></p>
            <?php wp_nonce_field('ajax-login-nonce', 'security'); ?>
            <input id="username" type="text" class="required" name="username"
                   placeholder=<?php _e("user name", "sigma-theme"); ?>>
            <input id="password" type="password" class="required" name="password"
                   placeholder=<?php _e("your password", "sigma-theme"); ?>>
            <p class="scs"><i class="fa fa-bullhorn"></i><?php _e("use secure and up to date browsers like chrome and firefox" , "sigma-theme");?></p>
            <input class="submit_button" type="submit" value="<?php _e("log in", "sigma-theme"); ?>">
            <hr>
            <a class="text-link" href="<?php echo wc_get_account_endpoint_url('lost-password'); ?>" target="_blanck"
                ><?php _e("lost your password ?", "sigma-theme"); ?></a>
        </div>
        <a class="close" href="">×</a>
    </div>
</form>

<form id="register" class="ajax-auth-register" action="register" method="post">
    <div class="row">
        <div class="form-bg col-md-6">
        </div>
        <div class="form-conent col-md-6">
            <h3><?php _e("you are already a member?", "sigma-theme"); ?><a id="pop_login" href=""><?php _e("log in", "sigma-theme"); ?></a></h3>
            <hr/>
            <h4><?php _e("register", "sigma-theme"); ?></h4>
            <p class="status"></p>
            <?php wp_nonce_field('ajax-register-nonce', 'signonsecurity'); ?>
            <input id="signonname" type="text" name="signonname" class="required"
                   placeholder=<?php _e("your username", "sigma-theme"); ?>>
            <input id="email" type="text" class="required email" name="email"
                   placeholder=<?php _e("your email", "sigma-theme"); ?>>
            <input id="signonpassword" type="password" class="required" name="signonpassword"
                   placeholder=<?php _e("password", "sigma-theme"); ?>>
            <input type="password" id="password2" class="required" name="password2"
                   placeholder=<?php _e("repeat password", "sigma-theme"); ?>>
            <input class="submit_button" type="submit" value="<?php _e("register", "sigma-theme"); ?>">
        </div>
        <a class="close" href="">×</a>
    </div>
</form>