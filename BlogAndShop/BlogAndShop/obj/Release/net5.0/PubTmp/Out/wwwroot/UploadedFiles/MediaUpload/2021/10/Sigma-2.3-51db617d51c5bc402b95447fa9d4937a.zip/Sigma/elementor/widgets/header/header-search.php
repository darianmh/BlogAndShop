<?php

namespace Elementor;

class Header_Search extends Widget_Base
{

    public function get_name()
    {
        return 'header-search';
    }

    public function get_title()
    {
        return __('Header Search', 'sigma-theme');
    }

    public function get_icon()
    {
        return 'eicon-search';
    }

    public function get_categories()
    {
        return ['Sigma-Header'];
    }

    protected function _register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Header Search', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'sigma_select_search',
            [
                'label' => esc_html__('Select Search Style', 'sigma-theme'),
                'type' => Controls_Manager::SELECT,
                'default' => 'style01_search',
                'options' => [
                    'style01_search' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_search' => esc_html__('Style 02', 'sigma-theme'),
                ],
            ]
        );

        $this->add_control(
            'sigma_select_search_style01',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/headers/sigma_select_search_style01.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
            ]
        );

        $this->add_control(
            'sigma_select_search_style02',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/headers/sigma_select_search_style02.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'sigma_select_search' => 'style02_search',
                ],
            ]
        );

        $this->add_control(
            'active_ajax_search',
            [
                'label' => esc_html__('Active ajax search', 'sigma-theme'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'search_post_type',
            [
                'label' => esc_html__('search post type', 'sigma-theme'),
                'type' => Controls_Manager::SELECT,
                'default' => 'products',
                'options' => [
                    'all' => esc_html__('all', 'sigma-theme'),
                    'products' => esc_html__('products', 'sigma-theme'),
                    'posts' => esc_html__('posts', 'sigma-theme'),
                ],
            ]
        );

        $this->add_control(
            'search_placeholder',
            [
                'label' => __('Search Placeholder', 'sigma-theme'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('Enter Search Placeholder', 'sigma-theme'),
                'default' => __('Search In SigmaPlus', 'sigma-theme'),
            ]
        );

        $this->add_control(
            'search_icon',
            [
                'label' => __('Search Icon', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-search',
                    'library' => 'light',
                ],
            ]
        );

        $this->add_control(
            'active_type_search',
            [
                'label' => esc_html__('Active type and category search', 'sigma-theme'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'select_types_search',
            [
                'label' => esc_html__('select search type', 'sigma-theme'),
                'type' => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all' => esc_html__('all', 'sigma-theme'),
                    'products' => esc_html__('products', 'sigma-theme'),
                    'posts' => esc_html__('posts', 'sigma-theme'),
                ],
                'condition' => [
                    'active_type_search' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Header Search', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'color_search_placehoder',
            [
                'label' => __('Search Placeholder Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .search_input::placeholder' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'sigma_select_search' => 'style02_search',
                ],
                'defualt' => '#ccc',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_input-search',
                'label' => _x('Search Input Background', 'sigma-theme'),
                'types' => ['classic', 'gradient', 'video'],
                'selector' => '{{WRAPPER}} .search_input',
                'condition' => [
                    'sigma_select_search' => 'style02_search',
                ],
                'defualt' => '#f3f3f3',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'label' => __('Border', 'sigma-theme'),
                'selector' => '{{WRAPPER}} .search_input',
                'condition' => [
                    'sigma_select_search' => 'style02_search',
                ],
            ]
        );

        $this->add_control(
            'icon_color_search',
            [
                'label' => __('Search Icon Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon_search_top i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'sigma_select_search' => 'style02_search',
                ],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'icon_color_search_s2',
            [
                'label' => __('Search Icon Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn-search-v1' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
                'default' => '#555',
            ]
        );

        $this->add_control(
            'icon_color_search_advenced',
            [
                'label' => __('Advenced Search Icon Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .search_advanced i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
                'default' => '#67676775',
            ]
        );


        $this->add_control(
            'color_search_placehoder_s2',
            [
                'label' => __('Search Placeholder Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ajax-v1::placeholder' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
                'default' => '#67676775',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_input_search_s2',
                'label' => __('Background', 'sigma-theme'),
                'types' => ['classic', 'gradient', 'video'],
                'selector' => '{{WRAPPER}} .ajax-v1',
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
                'default' => '#fafafc',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_submit_s2',
                'label' => __('Background', 'sigma-theme'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .btn-search-v1',
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
                'default' => '#fafafc',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border_input_s2',
                'label' => __('Border', 'sigma-theme'),
                'selector' => '{{WRAPPER}} .ajax-v1',
                'condition' => [
                    'sigma_select_search' => 'style01_search',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        if ($settings['sigma_select_search'] == 'style02_search' && !empty($settings['sigma_select_search'])) {
            echo '<div class="dgs_top_search_area search_edc"><form action="' . home_url('/') . '"> <input type="hidden" name="post_type" value="' ?><?php
            if ($settings['search_post_type'] == 'products') {
                echo 'product';
            }
            if ($settings['search_post_type'] == 'posts') {
                echo 'post';
            }
            if ($settings['search_post_type'] == 'all') {
                echo 'any';
            }
            ?><?php echo '"><input class="search_input" type="text" name="s" placeholder=" ' . $settings['search_placeholder'] . ' ">' ?>
            <?php
            if ($settings['active_ajax_search'] == 'yes') {
                echo '<a class="search_advanced" href="#" data-toggle="modal" data-target="#search_advanced" ><i class="la la-search" title="'.__('Advanced search', 'sigma-theme').'"></i></a><br>';
            }
            ?>
            <?php echo '<button type="submit"><span class="icon_search_top">' ?><?php \Elementor\Icons_Manager::render_icon($settings['search_icon'], ['aria-hidden' => 'true']); ?><?php echo '</span></button> </form></div>'; ?>
            <?php
            if ($settings['active_ajax_search'] == 'yes') { ?>
                <div class="modal fade bd-example-modal-lg" id="search_advanced" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h5 class="modal-title" id="exampleModalLongTitle"><?php _e('Advanced search', 'sigma-theme'); ?></h5>
                            </div>
                            <div class="modal-body">
                                <form class="form__holder_v3" action="<?php echo home_url('/'); ?>"
                                      id="thf_ajax_search">
                                    <div class="input_search row">
                                        <ul class="row">
                                            <?php
                                            if ($settings['active_type_search'] == 'yes') { ?>
                                                <li class="col-lg-5">
                                                    <div class="row h-100">
                                                        <div class="col-sm-6 px-0">
                                                            <select name="post_type" id="thf_type">
                                                                <option value="" disabled hidden ><?php _e('Search type', 'sigma-theme'); ?></option>
                                                                <?php if ($settings['select_types_search'] == 'all') { ?>
                                                                    <option value="all"><?php _e('all', 'sigma-theme'); ?></option>
                                                                    <option value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                                                    <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                                                <?php } ?>
                                                                <?php if ($settings['select_types_search'] == 'posts') { ?>
                                                                    <option selected value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                                                <?php } ?>
                                                                <?php if ($settings['select_types_search'] == 'products') { ?>
                                                                    <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-sm-6 px-0">
                                                            <select name="cat" id="thf_cat">
                                                                <option value="" disabled hidden selected><?php _e('Select category', 'sigma-theme'); ?></option>
                                                                <?php $cats = thf_get_cats(); ?>
                                                                <?php foreach ($cats as $cat): ?>
                                                                    <option value="<?= $cat->cat_ID ?>"><?= $cat->name ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="col-lg-5 px-0">
                                                    <input type="search" value="" name="s" id="thf_input"
                                                           placeholder="<?php echo $settings['search_placeholder']; ?>" autocomplete="off" required>
                                                </li>
                                            <?php } else { ?>
                                                <li class="col-lg-10 px-0">
                                                    <input type="search" value="" name="s" id="thf_input"
                                                           placeholder="<?php echo $settings['search_placeholder']; ?>" autocomplete="off" required>
                                                </li>
                                            <?php } ?>
                                            <li class="col-lg-2">
                                                <input type="button" class="search-submit-home" id="thf_btn"
                                                       value="<?php _e('Search', 'sigma-theme'); ?>">
                                            </li>
                                        </ul>
                                    </div>
                                    <div id="thf_result" class="mt-4">

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
        }
        if ($settings['sigma_select_search'] == 'style01_search') {
            echo '<form method="get" action="' . home_url('/') . '" class="search-form-v1">
        <input type="hidden" name="post_type" value="' ?>
            <?php
            if ($settings['search_post_type'] == 'products') {
                echo 'product';
            }
            if ($settings['search_post_type'] == 'posts') {
                echo 'post';
            }
            if ($settings['search_post_type'] == 'all') {
                echo 'any';
            }
            ?>
            <?php echo '"><input class="ajax-v1 form-control" id="searchInput" onkeyup="fetchResults()" type="text" name="s" placeholder=" ' . $settings['search_placeholder'] . ' "> ' ?>
            <?php
            if ($settings['active_ajax_search'] == 'yes') {
                echo '<a class="search_advanced" href="#" data-toggle="modal" data-target="#search_advanced" ><i class="la la-search" title="'.__('Advanced search', 'sigma-theme').'"></i></a><br>';
            }
            ?>
            <?php echo '<button class="btn-search-v1">' ?><?php \Elementor\Icons_Manager::render_icon($settings['search_icon'], ['aria-hidden' => 'true']); ?><?php echo '</button></form>'; ?>
            <?php
            if ($settings['active_ajax_search'] == 'yes') { ?>
                <div class="modal fade bd-example-modal-lg" id="search_advanced" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h5 class="modal-title" id="exampleModalLongTitle"><?php _e('Advanced search', 'sigma-theme'); ?></h5>
                            </div>
                            <div class="modal-body">
                                <form class="form__holder_v3" action="<?php echo home_url('/'); ?>"
                                      id="thf_ajax_search">
                                    <div class="input_search row">
                                        <ul class="row">
                                            <?php
                                            if ($settings['active_type_search'] == 'yes') { ?>
                                                <li class="col-lg-5">
                                                    <div class="row h-100">
                                                        <div class="col-sm-6 px-0">
                                                            <select name="post_type" id="thf_type">
                                                                <option value="" disabled hidden ><?php _e('Search type', 'sigma-theme'); ?></option>
                                                                <?php if ($settings['select_types_search'] == 'all') { ?>
                                                                    <option value="all"><?php _e('all', 'sigma-theme'); ?></option>
                                                                    <option value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                                                    <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                                                <?php } ?>
                                                                <?php if ($settings['select_types_search'] == 'posts') { ?>
                                                                    <option selected value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                                                <?php } ?>
                                                                <?php if ($settings['select_types_search'] == 'products') { ?>
                                                                    <option selected value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-sm-6 px-0">
                                                            <select name="cat" id="thf_cat">
                                                                <option value="" disabled hidden selected><?php _e('Select category', 'sigma-theme'); ?></option>
                                                                <?php $cats = thf_get_cats(); ?>
                                                                <?php foreach ($cats as $cat): ?>
                                                                    <option value="<?= $cat->cat_ID ?>"><?= $cat->name ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="col-lg-5 px-0">
                                                    <input type="search" value="" name="s" id="thf_input"
                                                           placeholder="<?php echo $settings['search_placeholder']; ?>" autocomplete="off" required>
                                                </li>
                                            <?php } else { ?>
                                                <li class="col-lg-10 px-0">
                                                    <input type="search" value="" name="s" id="thf_input"
                                                           placeholder="<?php echo $settings['search_placeholder']; ?>" autocomplete="off" required>
                                                </li>
                                            <?php } ?>
                                            <li class="col-lg-2">
                                                <input type="button" class="search-submit-home" id="thf_btn"
                                                       value="<?php _e('Search', 'sigma-theme'); ?>">
                                            </li>
                                        </ul>
                                    </div>
                                    <div id="thf_result" class="mt-4">

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }
        }
    }

    protected function _content_template()
    {

    }

} 