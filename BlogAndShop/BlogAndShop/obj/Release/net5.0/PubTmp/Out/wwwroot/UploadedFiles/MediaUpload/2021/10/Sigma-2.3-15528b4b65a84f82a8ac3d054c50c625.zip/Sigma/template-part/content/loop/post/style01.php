<div class="last-posts">
    <?php global $sigma;
    if ($sigma['show_img_loop_v1'] == 'enable') {
        ?>
        <a href="<?php the_permalink() ?>"> <?php the_post_thumbnail('index'); ?> </a>
    <?php } ?>
    <div class="post-meta">
        <?php if ($sigma['show_title_loop_v1'] == 'enable') { ?>
            <div class="title-post">
                <h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
            </div>
        <?php } ?>

        <?php if ($sigma['show_desc_loop_v1'] == 'enable') { ?>
            <p><?php echo wp_trim_words(get_the_content(), 30, '...'); ?></p>
        <?php } ?>

        <div class="row">
            <?php if ($sigma['show_cat_loop_v1'] == 'enable') { ?>
                <div class="cat-post col-lg-7 col-7">
                    <i class="fa fa-folder"></i>
                    <?php the_category(', ') ?>
                </div>
            <?php } ?>

            <?php if ($sigma['show_veiws_loop_v1'] == 'enable') { ?>
                <div class="cat-post col-lg-5 col-5">
                    <i class="fa fa-eye"></i>
                    <?php echo getPostViews(get_the_ID()); ?>
                </div>
            <?php } ?>

        </div>

        <?php if ($sigma['show_btn_loop_v1'] == 'enable') { ?>
            <a class="more-post" href="<?php the_permalink() ?>" target="_blank"><i
                        class="fa fa-list-ul"></i><?php _e('more details', 'sigma-theme'); ?></a>
        <?php } ?>
    </div>
</div>