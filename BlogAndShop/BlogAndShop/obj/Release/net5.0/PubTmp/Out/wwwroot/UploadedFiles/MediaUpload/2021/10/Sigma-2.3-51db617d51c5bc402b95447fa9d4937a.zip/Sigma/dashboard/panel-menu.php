<div id="page" class="mobile-menu" style="display:none">
    <div class="header_mobile">
        <div class="row">
            <div class="col-sm-3 col-3">
                <a class="logo-mobile-main" href="<?php bloginfo('url'); ?>">
                    <?php global $sigma;
                    if ($sigma['logo_mobile']['url'] != '') { ?>
                        <img alt="<?php bloginfo('title'); ?>" src="<?php echo $sigma['logo_mobile']['url']; ?>">
                    <?php } else { ?>
                        <img alt="<?php bloginfo('title'); ?>"
                             src="<?php bloginfo('template_directory'); ?>/assets/img/favicon.png">
                    <?php } ?>

                </a>
            </div>
            <div class="col-sm-2 col-2 cart-mobile">

                <?php

                if ($sigma['cart_icon_mobile'] == 'enable') {
                    ?>
                    <a href="<?php echo wc_get_cart_url(); ?>"><i class="fal fa-shopping-basket"></i>
                        <p class="num-cart-mobile"><?php echo WC()->cart->get_cart_contents_count(); ?></p></a>
                    <?php
                } ?>

            </div>

            <div class="col-sm-2 col-2 cart-mobile">
                <?php
                if ($sigma['wishlist_icon_mobile'] == 'enable') {
                    ?>
                    <a href="<?php bloginfo('url') ?>/wishlist"><i class="fal fa-heart"></i>
                        <p class="num-wishlist-mobile">0</p></a>
                    <?php
                } ?>
            </div>


            <div class="col-sm-2 col-2 cart-mobile search-mobile">
                <?php
                if ($sigma['search_icon_mobile'] == 'enable') {
                    ?>
                    <a href="#" data-toggle="modal" data-target="#searchmodal"><i class="fal fa-search"></i></a>
                <?php } ?>

                <div id="searchmodal" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-dialog-centered">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h5 class="modal-title"
                                    id="exampleModalLongTitle"><?php _e('Advanced search', 'sigma-theme'); ?></h5>
                            </div>
                            <?php if (wp_is_mobile()) { 
                            if ($sigma['advanced_search_icon_mobile'] == 'enable') { ?>
                                <div class="modal-body">
                                    <form class="form__holder_v3" id="thf_ajax_search">
                                        <div class="input_search row">
                                            <ul class="row">
                                                <li class="col-lg-5">
                                                    <div class="row">
                                                        <div class="col-sm-6 px-0">
                                                            <select name="post_type" id="thf_type">
                                                                <option value="" disabled hidden
                                                                        selected><?php _e('Search type', 'sigma-theme'); ?></option>
                                                                <option value="all"><?php _e('all', 'sigma-theme'); ?></option>
                                                                <option value="post"><?php _e('Posts', 'sigma-theme'); ?></option>
                                                                <option value="product"><?php _e('Products', 'sigma-theme'); ?></option>
                                                            </select>
                                                        </div>
                                                        <div class="col-sm-6 px-0">
                                                            <select name="cat" id="thf_cat">
                                                                <option value="" disabled hidden
                                                                        selected><?php _e('Select category', 'sigma-theme'); ?></option>
                                                                <?php $cats = thf_get_cats(); ?>
                                                                <?php foreach ($cats as $cat): ?>
                                                                    <option value="<?= $cat->cat_ID ?>"><?= $cat->name ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="col-lg-5 px-0">
                                                    <input type="search" value="" name="s" id="thf_input"
                                                           placeholder="<?php _e('Search', 'sigma-theme'); ?>" autocomplete="off" required>
                                                </li>
                                                <li class="col-lg-2">
                                                    <input type="button" class="search-submit-home" id="thf_btn"
                                                           value="<?php _e('Search', 'sigma-theme'); ?>">
                                                </li>
                                            </ul>
                                        </div>
                                        <div id="thf_result" class="mt-4">
                                        </div>
                                    </form>
                                </div>

                            <?php } else { ?>
                                <div class="modal-body">
                                    <?php $unique_id = esc_attr(uniqid('search-form-')); ?>

                                    <form method="get" action="<?php echo esc_url(home_url('/')); ?>"
                                          class="search-form-v1">
                                        <input type="hidden" name="post_type" value="<?php
                                        if ($sigma['mobile_search_post_type'] == 'product') {
                                            echo 'product';
                                        }
                                        if ($sigma['mobile_search_post_type'] == 'post') {
                                            echo 'post';
                                        }
                                        if ($sigma['mobile_search_post_type'] == 'any') {
                                            echo 'any';
                                        }
                                        ?>"><input class="ajax-v1 form-control" id="searchInput"
                                                   onkeyup="fetchResults()" type="text" name="s"
                                                   placeholder="<?php _e('Search in products site', 'sigma-theme'); ?>"
                                                   class="search">
                                            <input type="button" class="search-submit-home" id="thf_btn" value="<?php _e('Search', 'sigma-theme'); ?>">       
                                                   
                                    </form>
                                </div>
                            <?php } ?>    
                            <?php } else { ?>
                                <div class="modal-body">
                                    <?php $unique_id = esc_attr(uniqid('search-form-')); ?>

                                    <form method="get" action="<?php echo esc_url(home_url('/')); ?>"
                                          class="search-form-v1">
                                        <input type="hidden" name="post_type" value="<?php
                                        if ($sigma['mobile_search_post_type'] == 'product') {
                                            echo 'product';
                                        }
                                        if ($sigma['mobile_search_post_type'] == 'post') {
                                            echo 'post';
                                        }
                                        if ($sigma['mobile_search_post_type'] == 'any') {
                                            echo 'any';
                                        }
                                        ?>"><input class="ajax-v1 form-control" id="searchInput"
                                                   onkeyup="fetchResults()" type="text" name="s"
                                                   placeholder="<?php _e('Search in products site', 'sigma-theme'); ?>"
                                                   class="search">
                                    </form>
                                </div>

                                <?php
                            }
                            ?>

                        </div>

                    </div>
                </div>


            </div>


            <div class="col-sm-3 col-3 menu-mobile-toggle">
                <a href="#menu01"><span></span></a>
            </div>

        </div>
    </div>
    <nav id="menu01">

        <?php if ($sigma['userarea_mobile'] == 'enable') { ?>
            <?php if (is_user_logged_in()) { ?>

                <span class="row sigma_user_holder_mobile" style="background: <?php
                echo '' . $sigma['mobilemenu_header_bg']['background-color']; ?>; ">
    <p class="col-6 heloo_sigma nopadding" style="color:<?php
    echo $sigma['mobilemenu_header_title']; ?>;">
سلام    <?php $current_user = wp_get_current_user();
        echo '' . $current_user->display_name . ''; ?></p>
    <p class="col-6 login_mobile_btn nopadding" style="border: 2px solid <?php
    echo $sigma['mobilemenu_header_btn']; ?>;">
        <a style="color:<?php
        echo $sigma['mobilemenu_header_btn']; ?> !important;" href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><?php _e('Users panel', 'sigma-theme'); ?></i></a>
    </p>
</span>

            <?php } else { ?>

                <span class="row sigma_user_holder_mobile" style="background: <?php
                echo '' . $sigma['mobilemenu_header_bg']['background-color']; ?>; ">
    <p class="col-6 heloo_sigma nopadding" style="color:<?php
    echo $sigma['mobilemenu_header_title']; ?>;">
    <?php _e('Hello dear', 'sigma-theme'); ?>
    </p>
    <p class="col-6 login_mobile_btn nopadding" style="border: 2px solid <?php
    echo $sigma['mobilemenu_header_btn']; ?>;">
        <a style="color:<?php
        echo $sigma['mobilemenu_header_btn']; ?> !important;" href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><?php _e('Login/Register', 'sigma-theme'); ?></i></a>
    </p>
</span>

            <?php }
        } ?>

        <?php if ($sigma['social_active_mobile'] == 'enable') { ?>
            <span class="social_sigma_mobile">
            <a target="_blank" style="display:<?php
            echo $sigma['facebook_show']; ?>" href="<?php
            echo $sigma['heaader_v1_043']; ?>"><i class="<?php
                echo $sigma['heaader_v1_037']; ?> fb"></i></a>
            <a target="_blank" style="display:<?php
            echo $sigma['instagram_show']; ?>" href="<?php
            echo $sigma['heaader_v1_046']; ?>"><i class="<?php
                echo $sigma['heaader_v1_038']; ?> in"></i></a>
            <a target="_blank" style="display:<?php
            echo $sigma['telegram_show']; ?>" href="<?php
            echo $sigma['heaader_v1_044']; ?>"><i class="<?php
                echo $sigma['heaader_v1_039']; ?> tl"></i></a>
            <a target="_blank" style="display:<?php
            echo $sigma['youtube_show']; ?>" href="<?php
            echo $sigma['heaader_v1_042']; ?>"><i class="<?php
                echo $sigma['heaader_v1_040']; ?> yt"></i></a>
            <a target="_blank" style="display:<?php
            echo $sigma['twitter_show']; ?>" href="<?php
            echo $sigma['heaader_v1_045']; ?>"><i class="<?php
                echo $sigma['heaader_v1_041']; ?> tw"></i></a>
            </span>
            
        <?php } ?>


        <?php
        wp_nav_menu(array(
            'menu' => 'Main Navigation',
            'theme_location' => 'panel-mobile-menu',
        ));
        ?>
    </nav>
</div>
