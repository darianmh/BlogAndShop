<?php

class THF_AJAX {

	private static $_instance;

	public static function init() {
		if ( !self::$_instance ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {

		# Ajax Search
		add_action( 'wp_ajax_thf_search', [ $this, 'search' ] );
		add_action( 'wp_ajax_nopriv_thf_search', [ $this, 'search' ] );

		# Ajax Get Cats
		add_action( 'wp_ajax_thf_getCats', [ $this, 'get_cats' ] );
		add_action( 'wp_ajax_nopriv_thf_getCats', [ $this, 'get_cats' ] );
	}

	public function search() {
		$this->check_ajax_referer();

		$post_type = sanitize_text_field( $_REQUEST['type'] );
		$cat       = sanitize_text_field( $_REQUEST['cat'] );
		$s         = sanitize_text_field( $_REQUEST['s'] );

		$args = [];

		if ( empty( $post_type ) || !in_array( $post_type, [ 'post', 'product' ] ) ) {
			$post_type = [ 'post', 'product' ];
		}

		if ( !empty( $cat ) && $cat !== 'all' ) {
			$po_cat = explode( 'po', $cat );
			$po_cat = array_key_exists( 1, $po_cat ) ? $po_cat[1] : false;

			$pr_cat = explode( 'pr', $cat );
			$pr_cat = array_key_exists( 1, $pr_cat ) ? $pr_cat[1] : false;

			if ( !empty( $po_cat ) && ( $post_type == 'post' || in_array( 'post', $post_type ) ) ) {
				$args['cat'] = $po_cat;
			}

			if ( !empty( $pr_cat ) && ( $post_type == 'product' || in_array( 'product', $post_type ) ) ) {
				$args['tax_query'] = [ [ 'taxonomy' => 'product_cat',
										 'field'    => 'term_id',
										 'terms'    => [ $pr_cat ] ] ];
			}
		}

		# Args
		$args['s']              = $s;
		$args['post_type']      = $post_type;
		$args['posts_per_page'] = 30;

		$posts = get_posts( $args );
		$items = [];
		$error = '<p class="no-data">'. __("Your search returned no results! Check again ..", "sigma-theme") .'</p>';

		if ( !is_wp_error( $posts ) ) {
			foreach ( $posts as $post ) {
				$id    = $post->ID;
				$title = $post->post_title;
				$link  = get_permalink( $id );
				$image = get_the_post_thumbnail_url( $id );

				$items[] = [ 'id'    => $id,
							 'title' => $title,
							 'link'  => $link,
							 'image' => $image, ];
			}

			if ( !empty( $items ) ) wp_send_json_success( [ 'items' => $items ] ); 

		} else {
			$error = $posts->get_error_message();
		}

		wp_send_json_error( [ 'msg' => $error ] );
	}

	public function get_cats() {
		$this->check_ajax_referer();

		$post_type = $_REQUEST['type'];

		if ( !in_array( $post_type, [ 'post', 'product', 'all' ] ) ) {
			$post_type = 'post';
		}

		if ( $post_type == 'all' ) {
			$items[] = [ 'type'  => 'group',
						 'label' => __('Free contents', 'sigma-theme'),
						 'items' => $this->get_cats_array( 'post' ) ];
			$items[] = [ 'type'  => 'group',
						 'label' => __('Products and courses', 'sigma-theme'),
						 'items' => $this->get_cats_array( 'product' ) ];
		} else {
			$items = $this->get_cats_array( $post_type );
		}

		wp_send_json_success( [ 'items' => $items ] );
	}

	public function get_cats_array( $post_type, $prefix = '' ) {
		$cats  = thf_get_cats( $post_type );
		$items = [];

		if ( is_wp_error( $cats ) ) {
			wp_send_json_error( [ 'msg' => $cats->get_error_message() ] );
		}

		if ( empty( $prefix ) ) {
			if ( $post_type == 'post' ) {
				$prefix = 'po';
			} elseif ( $post_type == 'product' ) {
				$prefix = 'pr';
			}
		}

		if ( !empty( $cats ) && is_array( $cats ) ) foreach ( $cats as $cat ) {
			$id      = $cat->cat_ID;
			$title   = $cat->name;
			$items[] = [ 'type'  => 'item',
						 'id'    => $prefix . $id,
						 'title' => $title ];
		}

		return $items;
	}

	/**
	 * Check Ajax Security Nonce
	 */
	public function check_ajax_referer() {
		$check_nonce = check_ajax_referer( 'thf_ajax_security_nonce', 'security', false );

		if ( !$check_nonce || $this->is_bot() ) {
			if ( wp_doing_ajax() ) {
				wp_die( -1, 403 );
			} else {
				die( '-1' );
			}
		}
	}


	/**
	 * Check if the current request made by a known bot?
	 */
	public function is_bot( $ua = null ) {

		if ( empty( $ua ) && !empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
			$ua = $_SERVER['HTTP_USER_AGENT'];
		}

		if ( !empty( $ua ) ) {

			$bot_agents = array( 'alexa',
								 'altavista',
								 'ask jeeves',
								 'attentio',
								 'baiduspider',
								 'bingbot',
								 'chtml generic',
								 'crawler',
								 'fastmobilecrawl',
								 'feedfetcher-google',
								 'firefly',
								 'froogle',
								 'gigabot',
								 'googlebot',
								 'googlebot-mobile',
								 'heritrix',
								 'httrack',
								 'ia_archiver',
								 'irlbot',
								 'iescholar',
								 'infoseek',
								 'jumpbot',
								 'linkcheck',
								 'lycos',
								 'mediapartners',
								 'mediobot',
								 'motionbot',
								 'msnbot',
								 'mshots',
								 'openbot',
								 'pss-webkit-request',
								 'pythumbnail',
								 'scooter',
								 'slurp',
								 'Speed Insights',
								 'snapbot',
								 'spider',
								 'taptubot',
								 'technoratisnoop',
								 'teoma',
								 'twiceler',
								 'yahooseeker',
								 'yahooysmcm',
								 'yammybot',
								 'ahrefsbot',
								 'Pingdom',
								 'GTmetrix',
								 'PageSpeed',
								 'Google Page Speed',
								 'kraken',
								 'yandexbot',
								 'twitterbot',
								 'tweetmemebot',
								 'openhosebot',
								 'queryseekerspider',
								 'linkdexbot',
								 'grokkit-crawler',
								 'livelapbot',
								 'germcrawler',
								 'domaintunocrawler',
								 'grapeshotcrawler',
								 'cloudflare-alwaysonline', );

			foreach ( $bot_agents as $bot_agent ) {
				if ( false !== stripos( $ua, $bot_agent ) ) {
					return true;
				}
			}
		}

		return false;
	}


}