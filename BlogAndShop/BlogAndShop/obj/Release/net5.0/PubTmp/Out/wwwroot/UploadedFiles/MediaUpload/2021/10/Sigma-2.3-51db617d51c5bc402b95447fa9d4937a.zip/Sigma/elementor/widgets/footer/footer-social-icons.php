<?php
namespace Elementor;

class Footer_Social_Icons extends Widget_Base {

	public function get_name() {
		return 'footer-social-icons';
	}

	public function get_title() {
		return __( 'Footer social icons', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-facebook';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}     

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_socials',
			[
				'label' => __( 'Footer Social Icons', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'social_icons_alignment',
			[
				'label' => __( 'Social Icons Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_social ul ' => 'text-align: {{VALUE}};'
                ],				
			]
		);	
		
		$this->add_control(
			'list_socials_icon',
			[
				'label' => __( 'Socail Icons List', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'Text Social Name', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Social Name', 'sigma-theme' ),
						'default' => __( 'Facebook', 'sigma-theme' ),
					],
					[
						'name' => 'link',
						'label' => __( 'Link Social', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => 'https://telegram.me/hamkarwp',
        				'default' => [
        					'url' => 'https://telegram.me/hamkarwp',
        				]						
					],
					[
						'name' => 'icon',
						'label' => __( 'Icon Social', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
						'default' => [ 'value' => 'fab fa-telegram', 'library' => 'brand', ],
					],					
				],
				'default' => [
					[
						'text' => __( 'Facebook', 'sigma-theme' ),
						'link' => 'https://facebook.com/hamkarwp',
						'icon' => [ 'value' => 'fab fa-facebook', 'library' => 'brand', ],
					],
					[
						'text' => __( 'Telegram', 'sigma-theme' ),
						'link' => 'https://telegram.me/hamkarwp',
						'icon' => [ 'value' => 'fab fa-telegram', 'library' => 'brand', ],
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);

		$this->end_controls_section();
		
        $this->start_controls_section(
        	'style_section_social_icons',
        	[
				'label' => __( 'Footer social icons', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_control(
			'social_icon_size',
			[
				'label' => __( 'Social Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_social ul li a i ' => 'font-size:{{SIZE}}px',
				],
			]
		);

		$this->add_control(
			'social_icon_space',
			[
				'label' => __( 'Space Social Icon', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 5,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_social ul li a ' => 'margin: 0 {{SIZE}}px',
				],
			]
		);		
				
		$this->add_control(
			'social_icons_color',
			[
				'label' => __( 'Social Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_social ul li a' => 'color: {{VALUE}}',
				],		
				'default' => '#888888'
			]
		);

		$this->add_control(
			'social_icons_color_hover',
			[
				'label' => __( 'Social Icon Color Hover', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .dgs_footer_social ul li a:hover ' => 'color: {{VALUE}}',
				],		
				'default' => '#ffffff'
			]
		);
		
		$this->end_controls_section();		
		
	}	

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="dgs_footer_social"><ul>
		<?php foreach ( $settings['list_socials_icon'] as $index => $item ) : ?>
			<li>
				<?php
					echo '<a href="'.$item['link']['url'].'" title="'.$item['text'].'">'?> <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</a>';
				?>
			</li>
		<?php endforeach; ?>
		</ul></div>
		<?php
	}
	
}
