<li class="gird_cousrses_sigma gird_cousrses_sigma_archive">
    <div class="sigma-wc-courses-inner">
        <div class="single_curses_warp darkeble">
            <div class="single_curses_img">
                <?php global $sigma;
                if ($sigma['show_wishlist_product_loop_v5'] == 'enable') {
                    ?>
                    <div class="special_bookmark single_bookmark">
                        <?php
                        if (!sigma_is_in_wishlist($post->ID)) {
                            ?>
                            <a class="sigma-add-to-wishlist" data-product-id="<?php the_ID(); ?>"><i
                                        class="far fa-bookmark"></i></a>
                            <?php
                        } else {
                            ?>
                            <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank"
                               class="sigma-add-to-wishlist-added" data-product-id="<?php the_ID(); ?>"><span
                                        class="badge-tooltip-all"><?php _e('view wishlist', 'sigma-theme'); ?></span><i
                                        class="far fa-bookmark"></i></a>
                            <?php
                        }
                        ?>
                    </div>
                <?php } ?>

                <?php if ($sigma['show_img_product_loop_v5'] == 'enable') { ?>
                    <a href="<?php echo get_the_permalink(); ?>">
                        <?php
                        the_post_thumbnail('cousre');
                        ?>
                    </a>
                <?php } ?>

            </div>
            <div class="single_curses_meta">

                <?php if ($sigma['show_avatar_product_loop_v5'] == 'enable') { ?>
                    <div class="hexagon_teacher_single_bg"></div>
                    <div id="hexagon_teacher" class="hexagon_teacher_single">
                        <?php
                        $id = get_the_ID();
                        $info = sigma_get_tutorial_info($id);
                        echo '<img alt="avatar" src="' . $info['teacher_pic'] . '">';
                        ?>
                    </div>
                <?php } ?>

                <?php if ($sigma['show_title_product_loop_v5'] == 'enable') { ?>
                    <h2><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
                <?php } ?>

                <?php if ($sigma['show_en_title_product_loop_v5'] == 'enable') { ?>
                    <small><?php echo(get_post_meta(get_the_ID(), 'en_title_sigma', true)); ?></small>
                <?php } ?>

                <div class="single_lists_quick single_quick_v2"><p><span>
                <?php echo woocommerce_template_single_price(); ?>
                    </p>
                </div>

                <?php if ($sigma['show_desc_product_loop_v5'] == 'enable') { ?>
                    <div class="meta_qiuck_special_edc single_quick">
                        <ul>
                            <li>
                                <?php
                                $id = get_the_ID();
                                $info = sigma_get_tutorial_info($id);
                                ?>
                                <p><?php
                                    if ($info > 1) {
                                        echo $info['product_time'];
                                    } else {
                                        echo '-';
                                    }
                                    ?></p><span><?php _e('Course length', 'sigma-theme'); ?></span></li>
                            <li>
                                <p><?php echo get_comments_number(); ?></p><span><?php _e('Comments number', 'sigma-theme'); ?></span></li>
                            <li>
                                <p><?php echo get_post_meta(get_the_ID(), 'total_sales', true); ?></p>
                                <span><?php _e('Students number', 'sigma-theme'); ?></span></li>
                        </ul>
                    </div>
                <?php } ?>

                <?php if ($sigma['show_badge_product_loop_v5'] == 'enable') { ?>
                    <div class="edc_badges edc_badges_signle">
                        <ul>
                            <?php
                            $id = get_the_ID();
                            $medals = sigma_get_product_medals($id);
                            if (false != $medals) {
                                foreach ($medals as $medal) {
                                    ?>
                                    <li id="hexagon" class="badge_singel pink_badge"><img src="<?php echo $medal['medal_pic'] ?>" alt="<?php echo $medal['medal_name'] ?>"><span class="badge-tooltip"><?php echo $medal['medal_name'] ?></span>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>    
                    </div>
                <?php } ?>

                <div class="edc_button_single">
                    <ul>
                        <?php if ($sigma['show_qviews_product_loop_v5'] == 'enable') { ?>
                            <li><a href="<?php echo get_post_permalink(); ?>?add-to-cart=<?php echo get_the_ID(); ?>"><i
                                            class="far fa-shopping-bag"></i></a></li>
                        <?php } ?>

                        <?php if ($sigma['show_cart_product_loop_v5'] == 'enable') { ?>
                            <li><a href="<?php echo get_the_permalink(); ?>"><i class="fal fa-ellipsis-h-alt"></i></a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
</li>