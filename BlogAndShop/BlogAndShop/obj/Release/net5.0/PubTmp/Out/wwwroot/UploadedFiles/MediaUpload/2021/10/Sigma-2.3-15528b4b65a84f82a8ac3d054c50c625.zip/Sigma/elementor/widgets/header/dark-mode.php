<?php
namespace Elementor;

class Header_Dark_Mode extends Widget_Base {
	
	public function get_name() {
		return 'dark-mode';
	}
	
	public function get_title() {
		return __( 'Dark Mode', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-toggle';
	}
	
	public function get_categories() {
		return [ 'Sigma-Header' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Dark Mode', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'light_icon',
			[
				'label' => __( 'Light Mode Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-sun',
					'library' => 'light',
				],
			]
		);

		$this->add_control(
			'dark_icon',
			[
				'label' => __( 'Dark Mode Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'far fa-moon',
					'library' => 'light',
				],
			]
		);

		$this->add_control(
			'swithcer_align',
			[
				'label' => __( 'Switcher Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .sgm-dark-mode' => 'text-align: {{VALUE}};'
                ],				
			]
		);
		
		$this->end_controls_section();


        $this->start_controls_section(
        	'style_section_swithcher',
        	[
				'label' => __( 'Dark Mode Switcher Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 


		$this->add_control(
			'dark_mode_icon_color',
			[
				'label' => __( 'Dark Mode Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sgm-dark-mode i:first-child' => 'color: {{VALUE}}',
				],			
				'default' => '#b7b7b7'
			]
		);

		$this->add_control(
			'light_mode_icon_color',
			[
				'label' => __( 'Light Mode Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .sgm-dark-mode i:last-child' => 'color: {{VALUE}}',
				],			
				'default' => '#b7b7b7'
			]
		);	
		
		$this->add_control(
			'light_mode_switcher_bg',
			[
				'label' => __( 'Light Mode Switcher Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch + label:after' => 'background: {{VALUE}}',
				],			
				'default' => '#e9eef5'
			]
		);

		$this->add_control(
			'dark_mode_switcher_bg',
			[
				'label' => __( 'Dark Mode Switcher Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch:checked + label:after' => 'background: {{VALUE}}',
				],			
				'default' => '#3d4e9b'
			]
		);

		$this->add_control(
			'light_mode_switcher_border',
			[
				'label' => __( 'Light Mode Switcher Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch + label:after' => 'border-color: {{VALUE}}',
				],			
				'default' => '#e9eef5'
			]
		);

		$this->add_control(
			'dark_mode_switcher_border',
			[
				'label' => __( 'Dark Mode Switcher Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch:checked + label:after' => 'border-color: {{VALUE}}',
				],			
				'default' => '#3d4e9b'
			]
		);

		$this->add_control(
			'light_mode_circle_bg',
			[
				'label' => __( 'Light Mode Circle Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch + label:before' => 'background: {{VALUE}}',
				],			
				'default' => '#ffe25d'
			]
		);

		$this->add_control(
			'dark_mode_circle_bg',
			[
				'label' => __( 'Dark Mode Circle Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch:checked + label:before' => 'background: {{VALUE}}',
				],			
				'default' => '#3c4e9b'
			]
		);

		$this->add_control(
			'light_mode_circle_border',
			[
				'label' => __( 'Light Mode Circle Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch + label:before' => 'border-color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_control(
			'dark_mode_circle_border',
			[
				'label' => __( 'Dark Mode Circle Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .switch:checked + label:before' => 'border-color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		echo '<div class="sgm-dark-mode">' ?><?php \Elementor\Icons_Manager::render_icon( $settings['dark_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'<input class="switch" id="darkmode" type="checkbox"><label  class="dark-mode" for="darkmode">&nbsp;</label>' ?><?php \Elementor\Icons_Manager::render_icon( $settings['light_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'</div>';  
	}
}