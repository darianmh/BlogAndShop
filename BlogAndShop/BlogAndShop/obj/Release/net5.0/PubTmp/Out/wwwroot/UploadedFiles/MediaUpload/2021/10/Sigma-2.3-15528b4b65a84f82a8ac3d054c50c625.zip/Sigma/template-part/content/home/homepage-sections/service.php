<div class="services">
    <div class="row">
        <div class="col-lg-3 col-service col-6 col-sm-6">
            <img src="<?php bloginfo('template_directory'); ?>/assets/img/s1.png">
            <p><?php _e('Standard design', 'sigma-theme'); ?></p>
            <span><?php _e('Designs provided', 'sigma-theme'); ?></span>
        </div>

        <div class="col-lg-3 col-service col-6 col-sm-6">
            <img src="<?php bloginfo('template_directory'); ?>/assets/img/s2.png">
            <p><?php _e('Refund', 'sigma-theme'); ?></p>
            <span><?php _e('a week of purchase', 'sigma-theme'); ?></span>
        </div>

        <div class="col-lg-3 col-service col-6 col-sm-6">
            <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/s3.png">
            <p><?php _e('Easy to install', 'sigma-theme'); ?></p>
            <span><?php _e('In all host', 'sigma-theme'); ?></span>
        </div>
        <div class="col-lg-3 col-service col-6 col-sm-6" style="border:none;">
            <img alt="" src="<?php bloginfo('template_directory'); ?>/assets/img/s4.png">
            <p><?php _e('Secure payment', 'sigma-theme'); ?></p>
            <span><?php _e('With all bank cards', 'sigma-theme'); ?></span>
        </div>
    </div>
</div>