<?php

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

# Vars
define( 'THF_VER', '1.0' );
define( 'THF_FOLDER', basename( dirname( __FILE__ ) ) );
define( 'THF_DIR', get_template_directory_uri() . '/includes/' . THF_FOLDER );
define( 'THF_URL', get_template_directory_uri() . '/includes/' . THF_FOLDER );
define( 'THEME_URL', get_template_directory_uri() );
define( 'THF_ASSETS', THEME_URL . '/assets' );
define( 'THF_CSS', THF_ASSETS . '/css' );
define( 'THF_JS', THF_ASSETS . '/js' );



# Includes
require_once( 'search-functions.php' );
require_once( 'search-class-ajax.php' );

# Magic happens here !
$thf         = [];
$thf['ajax'] = THF_AJAX::init();