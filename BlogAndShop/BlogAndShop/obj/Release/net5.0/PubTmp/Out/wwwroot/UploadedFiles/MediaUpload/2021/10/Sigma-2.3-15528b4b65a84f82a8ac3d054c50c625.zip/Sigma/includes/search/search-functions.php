<?php

# Register CSS & JS
add_action( 'wp_enqueue_scripts', 'thf_enqueue_scripts', 9 );
function thf_enqueue_scripts() {

	# CSS & JS
	wp_enqueue_script( 'thf-scripts', THF_JS . '/popper.min.js', [ 'jquery' ], THF_VER, true );

	# Localize vars
	$js_vars = [ 'ajaxURL'  => admin_url( 'admin-ajax.php' ),
				 'security' => wp_create_nonce( 'thf_ajax_security_nonce' ), ];

	wp_localize_script( 'thf-scripts', 'THF', $js_vars );
}


# Get custom post type cats
function thf_get_cats( $post_type = 'post' ) {
	$args = array( 'hierarchical' => 1,
				   'hide_empty'   => 1, );

	# Product
	if ( $post_type == 'product' ) {
		$args['taxonomy'] = 'product_cat';
	}

	return get_categories( $args );
}

# WP Search Page Query
//add_action( 'pre_get_posts', 'thf_search_query', 10 , 1 );
function thf_search_query( $query ) {
	/* @var $query WP_Query */
	if ( $query->is_main_query() && is_search() ) {

		$post_type = isset( $_GET['post_type'] ) ? sanitize_text_field( $_GET['post_type'] ) : false;
		$cat       = isset( $_GET['cat'] ) ? sanitize_text_field( $_GET['cat'] ) : false;
		$s         = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : false;

		if ( empty( $post_type ) || !in_array( $post_type, [ 'post', 'product' ] ) ) {
			$post_type = [ 'post', 'product' ];
		}

		if ( !empty( $post_type ) ) {
			$query->set( 'post_type', $post_type );
		}

		$query->set( 'cat', [] );
		$query->set( 'tax_query', [] );

		if ( !empty( $cat ) && $cat !== 'all' ) {
			$po_cat = explode( 'po', $cat );
			$po_cat = array_key_exists( 1, $po_cat ) ? $po_cat[1] : false;

			$pr_cat = explode( 'pr', $cat );
			$pr_cat = array_key_exists( 1, $pr_cat ) ? $pr_cat[1] : false;

			if ( !empty( $po_cat ) && ( $post_type == 'post' || in_array( 'post', $post_type ) ) ) {
				$query->set( 'cat', $po_cat );
			}

			if ( !empty( $pr_cat ) && ( $post_type == 'product' || in_array( 'product', $post_type ) ) ) {
				$query->set( 'tax_query', [ [ 'taxonomy' => 'product_cat',
											  'field'    => 'term_id',
											  'terms'    => [ $pr_cat ] ] ] );
			}
		}

		if ( !empty( $s ) ) {
			$query->set( 's', trim( $s ) );
		}
	}

	return $query;
}

# Show Top Alert By Cookie
function thf_show_top_alert(){
	if( isset( $_COOKIE['thfShowTopAlert'] ) && $_COOKIE['thfShowTopAlert'] == 'false' ){
		return false;
	}

	return true;
}


# Show PopUp By Cookie
function sgm_show_popup_newsletter(){
	if( isset( $_COOKIE['sgmPopupNewsletter'] ) && $_COOKIE['sgmPopupNewsletter'] == 'false' ){
		return false;
	}

	return true;
}
