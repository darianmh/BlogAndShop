<?php global $sigma; if ($sigma['ralated_post'] == 'inherit') { ?>

<div class="ralated-post">

    <h4><?php echo $sigma['relate_post_title']; ?></h4>
    <div id="related" class="owl-carousel owl-theme">

        <?php $related = get_posts(array('category__in' => wp_get_post_categories($post->ID),
            'orderby' => 'rand', 'numberposts' => 12, 'post__not_in' => array($post->ID)));
        if ($related) foreach ($related as $post) {
            setup_postdata($post); ?>

            <div class="last-posts">
                <?php get_template_part($sigma['post_style_loop']); ?>
            </div>

        <?php }
        wp_reset_postdata(); ?>
    </div>
</div>

<?php } ?>