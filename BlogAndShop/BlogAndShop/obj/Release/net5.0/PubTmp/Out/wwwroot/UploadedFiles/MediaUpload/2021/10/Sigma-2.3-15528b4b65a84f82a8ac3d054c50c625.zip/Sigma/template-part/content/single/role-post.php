<?php
global $sigma;
if ($sigma['role_comment_pro'] == 'inherit') {
    ?>
    <div class="role-comment">
        <p><?php echo $sigma['role_post_content']; ?></p>
    </div>
<?php } ?>