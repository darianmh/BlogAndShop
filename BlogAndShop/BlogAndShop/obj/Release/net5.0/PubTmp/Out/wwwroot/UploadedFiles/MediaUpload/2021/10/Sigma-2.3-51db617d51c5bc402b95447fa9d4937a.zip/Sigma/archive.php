<?php
get_header();
get_template_part('template-part/headers/head');
get_template_part('template-part/content/archive/archive');
get_template_part('template-part/footers/footer');
get_footer();

