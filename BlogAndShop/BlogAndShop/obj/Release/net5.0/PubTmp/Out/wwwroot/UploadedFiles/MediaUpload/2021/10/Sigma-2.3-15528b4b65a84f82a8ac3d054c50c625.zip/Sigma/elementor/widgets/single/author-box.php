<?php
namespace Elementor;

class Author_Box extends Widget_Base {
	
	public function get_name() {
		return 'author-box';
	}
	
	public function get_title() {
		return  __( 'Author Box', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-person';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {

        $this->start_controls_section(
        	'section_content',
        	[
				'label' => __( 'Author Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 

		$this->add_control(
			'author_author_box',
			[
				'label'   => esc_html__( 'Active Author Box', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'author_avatar',
			[
				'label'   => esc_html__( 'Author Avatar', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_control(
			'author_name',
			[
				'label'   => esc_html__( 'Author Name', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_control(
			'author_reg',
			[
				'label'   => esc_html__( 'Author Register Date', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_control(
			'author_des',
			[
				'label'   => esc_html__( 'Author Description', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);
		
        $this->end_controls_section();       
        
        
        
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Author Box', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'author_box_bg',
			[
				'label' => __( 'Author Box Background', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .autherarea' => 'background: {{VALUE}}',
				],			
				'default' => '#ffffff',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);
		
		$this->add_control(
			'author_name_color',
			[
				'label' => __( 'Author Name Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .author-name' => 'color: {{VALUE}}',
				],			
				'default' => '#555555',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_name_type',
				'label' => __( 'Author Name Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .author-name ',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_control(
			'reg_date_color',
			[
				'label' => __( 'Register Date Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .author-date' => 'color: {{VALUE}}',
				],			
				'default' => '#555555',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'reg_date_type',
				'label' => __( 'Register Date Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .author-date ',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_control(
			'des_color',
			[
				'label' => __( 'Author Description Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .author_about p' => 'color: {{VALUE}}',
				],			
				'default' => '#555555',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'des_type',
				'label' => __( 'Author Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .author_about p ',
				'condition' => [ 'author_author_box' => 'yes', ],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .autherarea',
                'condition' => [ 'author_author_box' => 'yes', ],				
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .autherarea',
                'condition' => [ 'author_author_box' => 'yes', ],				
			]
		);
		
        $this->end_controls_section();       
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            $user_id = $template->GetRelatedRawPost()->post_author;
            $reg_date = date_i18n('j F Y', strtotime(get_user_by("ID", $user_id)->user_registered));
            $post_author = $template->GetRelatedPostField("post_author");
            $avatar_author= esc_url( get_avatar_url( $user_id ) );
            $decription_author= wpautop( get_the_author_meta( 'description' ) );
            if($settings['author_author_box'] == 'yes'){
            echo'<div class="autherarea darkeble"> ' ?>
            <?php if($settings['author_avatar'] == 'yes'){
            echo'<div class="auther_img">
                <img src="'.$avatar_author.'" class="gravatar avatar avatar-75 um-avatar um-avatar-default" width="75" height="75" alt="'.$post_author.'"></div>' ?>
            <?php } ?>   
            <?php echo'<div class="author_about">' ?>
            <?php if($settings['author_name'] == 'yes'){
               echo'<div class="author-name">'.$post_author.'</div>' ?>
            <?php  } ?>
            <?php if($settings['author_reg'] == 'yes'){
            echo'<div class="author-date"> تاریخ عضویت  :  '.$reg_date.'</div>' ?>
        	<?php } ?>   
            <?php if($settings['author_des'] == 'yes'){
            echo'<p>'.$decription_author.'</p>'?>
            <?php } ?>   
            <?php echo'</div></div>';
            }
        }        
        else
        {
            if($settings['author_author_box'] == 'yes'){
            echo'<div class="autherarea darkeble"> ' ?>
            <?php if($settings['author_avatar'] == 'yes'){
            echo'<div class="auther_img">
            <img src="'. get_template_directory_uri() .'/assets/img/default-avatar.png" class="gravatar avatar avatar-75 um-avatar um-avatar-default" width="75" height="75" alt="همکار وردپرس وردپرس" </div>' ?>
            <?php } ?>   
            <?php echo'<div class="author_about">' ?>
            <?php if($settings['author_name'] == 'yes'){
               echo'<div class="author-name"> همکار وردپرس</div>' ?>
            <?php  } ?>
            <?php if($settings['author_reg'] == 'yes'){
            echo'<div class="author-date"> تاریخ عضویت  :25 آبان ماه  </div>' ?>
        	<?php } ?>   
            <?php if($settings['author_des'] == 'yes'){
            echo'<p>همکار وردپرس یک تیم برنامه نویسی و توسعه وب سایت ها در ایران است که همواره با به کار گیری جدید ترین تکنولوژی های روز دنیا بهترین و کارآمد ترین محصولات تحت وردپرس را برای شما مهیا میکند!</p>' ?>
            <?php } ?>
            <?php echo'</div></div>';
            }
        }
    }
}