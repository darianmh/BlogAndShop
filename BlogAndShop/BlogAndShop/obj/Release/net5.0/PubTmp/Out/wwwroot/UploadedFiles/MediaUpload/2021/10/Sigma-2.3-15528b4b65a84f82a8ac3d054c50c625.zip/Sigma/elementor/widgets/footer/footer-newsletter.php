<?php

namespace Elementor;

class Footer_Newsletter extends Widget_Base
{

    public function get_name()
    {
        return 'footer-newsletter';
    }

    public function get_title()
    {
        return __('Footer Newsletter', 'sigma-theme');
    }

    public function get_icon()
    {
        return 'eicon-envelope';
    }

    public function get_categories()
    {
        return ['Sigma-Footer'];
    }

    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_newsletter_content',
            [
                'label' => __('Footer Newsletter', 'sigma-theme'),
            ]
        );


        $this->add_control(
            'newslatter_style_select',
            [
                'label' => esc_html__('Select Search Style', 'sigma-theme'),
                'type' => Controls_Manager::SELECT,
                'default' => 'style01_newsletter',
                'options' => [
                    'style01_newsletter' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_newsletter' => esc_html__('Style 02', 'sigma-theme'),
                    'style03_newsletter' => esc_html__('Style 03', 'sigma-theme'),
                    'style04_newsletter' => esc_html__('Style 04', 'sigma-theme'),
                    'style05_newsletter' => esc_html__('Style 05', 'sigma-theme'),
                    'style06_newsletter' => esc_html__('Style 06', 'sigma-theme'),
                ],
            ]
        );

        $this->add_control(
            'newslatter_select_style01',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/footers/newslatter_select_style01.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'newslatter_style_select' => 'style01_newsletter',
                ],
            ]
        );

        $this->add_control(
            'newslatter_select_style02',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/footers/newslatter_select_style02.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'newslatter_style_select' => 'style02_newsletter',
                ],
            ]
        );

        $this->add_control(
            'newslatter_select_style03',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/footers/newslatter_select_style03.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'newslatter_style_select' => 'style03_newsletter',
                ],
            ]
        );

        $this->add_control(
            'newslatter_select_style04',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/footers/newslatter_select_style04.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'newslatter_style_select' => 'style04_newsletter',
                ],
            ]
        );

        $this->add_control(
            'newslatter_select_style05',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/footers/newslatter_select_style05.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'newslatter_style_select' => 'style05_newsletter',
                ],
            ]
        );

        $this->add_control(
            'newslatter_select_style06',
            [
                'raw' => '<img class="admin_select_img_style" src="' . get_template_directory_uri() . '/assets/img/styles/footers/newslatter_select_style06.jpg">',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'newslatter_style_select' => 'style06_newsletter',
                ],
            ]
        );

        $this->add_control(
            'footer_newsletter_title',
            [
                'label' => __('Footer Newsletter Title', 'sigma-theme'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('Sigma Plus Newsletter', 'sigma-theme'),
                'default' => 'Sigma Plus Newsletter',
            ]
        );

        $this->add_control(
            'footer_newsletter_subtitle',
            [
                'label' => __('Footer Newsletter SubTitle', 'sigma-theme'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('Subscribe to Sigma Plus newsletter to get the latest discounts ...', 'sigma-theme'),
                'default' => 'Subscribe to Sigma Plus newsletter to get the latest discounts...',
                'condition' => ['newslatter_style_select' => ['style04_newsletter', 'style06_newsletter']],
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy',
            [
                'label' => __('Footer Newsletter Privacy', 'sigma-theme'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('We will only email you campaigns and discounts.', 'sigma-theme'),
                'default' => 'We will only email you campaigns and discounts.',
            ]
        );

        $this->add_control(
            'footer_newsletter_icon',
            [
                'label' => __('Footer Newsletter Icon', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fal fa-lock',
                    'library' => 'light',
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'style_section_footer_newsletter',
            [
                'label' => __('Footer Newsletter', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_style_01_newsletter_background',
                'label' => __('Form Placeholder Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .newslleter ',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
                'default' => '#ffffff',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'footer_style_01_newsletter_border',
                'label' => __('Form Border', 'sigma-theme'),
                'selector' => '{{WRAPPER}} .newslleter',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_title_color',
            [
                'label' => __('Newsletter Title Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_cols h3' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
                'default' => '#333333',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_title_typography_s4',
                'label' => __('Newsletter Title Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .dgs_footer_cols h3',
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_title_typography_s2',
                'label' => __('Newsletter Title Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .sigma-newslatter h3',
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_title_typography_s3',
                'label' => __('Newsletter Title Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .sigma-newslatter-v3 h3',
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_title_typography_s1',
                'label' => __('Newsletter SubTitle Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .newslleter span',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
            ]
        );
        $this->add_control(
            'footer_newsletter_title_color_style3',
            [
                'label' => __('Newsletter Title Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter-v3 h3' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'footer_newsletter_title_color_style2',
            [
                'label' => __('Newsletter Title Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter h3' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
                'default' => '#ca87c1',
            ]
        );

        $this->add_control(
            'footer_newsletter_title_color_style1',
            [
                'label' => __('Newsletter Title Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .newslleter span' => 'color: {{VALUE}}',
                ],
                'default' => '#333333',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
            ]
        );

        $this->add_control(
            'footer_newsletter_subtitle_color',
            [
                'label' => __('Newsletter SubTitle Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_newslatter p' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_subtitle_typography',
                'label' => __('Newsletter SubTitle Color', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .dgs_footer_newslatter p',
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_privacy_typography_s4',
                'label' => __('Newsletter Privacy Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .dgs_footer_newslatter p',
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_privacy_typography_s3',
                'label' => __('Newsletter Privacy Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .sigma-newslatter-v3 small',
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_privacy_typography_s2',
                'label' => __('Newsletter Privacy Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .sigma-newslatter small',
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_newsletter_privacy_typography_s1',
                'label' => __('Newsletter Privacy Typography', 'sigma-theme'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .newslleter p',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_color',
            [
                'label' => __('Newsletter Privacy Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_newslatter small' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_color_style3',
            [
                'label' => __('Newsletter Privacy Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter-v3 small' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_color_style2',
            [
                'label' => __('Newsletter Privacy Color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter small' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'privacy_icon_size_s2',
            [
                'label' => __('Newsletter Privacy Icon Size', 'sigma-theme'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 15,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter small i ' => 'font-size:{{SIZE}}px',
                ],
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
            ]
        );

        $this->add_control(
            'privacy_icon_size_s3',
            [
                'label' => __('Newsletter Privacy Icon Size', 'sigma-theme'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 15,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter-v3 small i ' => 'font-size:{{SIZE}}px',
                ],
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
            ]
        );

        $this->add_control(
            'privacy_icon_size_s4',
            [
                'label' => __('Newsletter Privacy Icon Size', 'sigma-theme'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 15,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_newslatter small i ' => 'font-size:{{SIZE}}px',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_color_style1',
            [
                'label' => __('footer newsletter privacy color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .newslleter p' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_icon_color',
            [
                'label' => __('footer newsletter privacy icon color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_newslatter small i' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_icon_color_style2',
            [
                'label' => __('footer newsletter privacy icon color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter small i' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
                'default' => '#f27d27',
            ]
        );

        $this->add_control(
            'footer_newsletter_privacy_icon_color_style3',
            [
                'label' => __('footer newsletter privacy icon color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter-v3 small i' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
                'default' => '#f27d27',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_style1_img',
                'label' => __('newsletter lock image', 'sigma-theme'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .lock',
                'condition' => [
                    'newslatter_style_select' => 'style01_newsletter',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_style1_document_img',
                'label' => __('newsletter document image', 'sigma-theme'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .document',
                'condition' => [
                    'newslatter_style_select' => 'style01_newsletter',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section_footer_newsletter_input',
            [
                'label' => __('Footer Newsletter form', 'sigma-theme'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'bordernewsletter',
                'label' => __('Border Input', 'sigma-theme'),
                'selector' => '{{WRAPPER}} .sgm_newsletter_area input',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_placeholder_color',
            [
                'label' => __('footer newsletter form placeholder color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dgs_footer_newslatter input::placeholder ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_placeholder_color_style3',
            [
                'label' => __('footer newsletter form placeholder color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter-v3 input::placeholder ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_placeholder_color_style2',
            [
                'label' => __('footer newsletter form placeholder color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sigma-newslatter input::placeholder ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_placeholder_color_style1',
            [
                'label' => __('footer newsletter form placeholder color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .newslleter-newslleter input::placeholder ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
                'default' => '#999999',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_placeholder_background',
                'label' => __('footer newsletter form placeholder Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .dgs_footer_newslatter input[type=text]',
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
            ]
        );


        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_placeholder_background_style3',
                'label' => __('footer newsletter form placeholder Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .sigma-newslatter-v3 input',
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_placeholder_background_style2',
                'label' => __('footer newsletter form placeholder Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .sigma-newslatter input',
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_placeholder_background_style1',
                'label' => __('footer newsletter form placeholder Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .newslleter-newslleter input',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
            ]
        );


        $this->add_control(
            'footer_newsletter_form_submit_color',
            [
                'label' => __('footer newsletter form submit color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgm_newsletter_submit ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_submit_color_style3',
            [
                'label' => __('footer newsletter form submit color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn-subscribe ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_submit_color_style2',
            [
                'label' => __('footer newsletter form submit color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .submit-sg ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'footer_newsletter_form_submit_color_style1',
            [
                'label' => __('footer newsletter form submit color', 'sigma-theme'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .newslleter-btn ' => 'color: {{VALUE}}',
                ],
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
                'default' => '#ffffff',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_submit_background-4',
                'label' => __('footer newsletter submit Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .sgm_newsletter_submit',
                'condition' => ['newslatter_style_select' => 'style04_newsletter',],
            ]
        );


        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_submit_background_style3',
                'label' => __('footer newsletter submit Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}}  .btn-subscribe',
                'condition' => ['newslatter_style_select' => 'style03_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_submit_background_style2',
                'label' => __('footer newsletter submit Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .submit-sg',
                'condition' => ['newslatter_style_select' => 'style02_newsletter',],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_newsletter_form_submit_background_style1',
                'label' => __('footer newsletter submit Background', 'plugin-domain'),
                'types' => ['classic'],
                'selector' => '{{WRAPPER}} .newslleter-btn',
                'condition' => ['newslatter_style_select' => 'style01_newsletter',],
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        echo '<div class="sgm_newsletter_area">';
        $settings = $this->get_settings_for_display();
        if ($settings['newslatter_style_select'] == 'style04_newsletter' && !empty($settings['newslatter_style_select'])) {
            echo '<div class="dgs_footer_cols dgs_footer_newslatter"> <h3>' . $settings['footer_newsletter_title'] . '</h3> <p>' . $settings['footer_newsletter_subtitle'] . '</p> <input class="sgm_newsletter_name" type="text" placeholder="' . __('Your Name', 'sigma-theme') . '" name="name" required=""> <input class="sgm_newsletter_email" type="text" placeholder="' . __('Your Email...', 'sigma-theme') . '" name="mail" required=""> <input class="sgm_newsletter_submit" type="submit" value="' . __('Submit', 'sigma-theme') . '"><small>' ?><?php \Elementor\Icons_Manager::render_icon($settings['footer_newsletter_icon'], ['aria-hidden' => 'true']); ?><?php echo ' ' . $settings['footer_newsletter_privacy'] . '</small> </div>';
        }
        if ($settings['newslatter_style_select'] == 'style03_newsletter') {
            echo '<div class="sigma-newslatter-v3"><h3>' . $settings['footer_newsletter_title'] . '</h3><div class="input-group"><input type="text" class="form-control" placeholder="' . __('Your Email...', 'sigma-theme') . '" required=""><input type="text" class="form-control" placeholder="' . __('Your Name', 'sigma-theme') . '" required=""><button class="btn btn-subscribe">' . __('Submit', 'sigma-theme') . '</button><small>' ?><?php \Elementor\Icons_Manager::render_icon($settings['footer_newsletter_icon'], ['aria-hidden' => 'true']); ?><?php echo '' . $settings['footer_newsletter_privacy'] . '</small></div>';
        }
        if ($settings['newslatter_style_select'] == 'style02_newsletter') {
            echo '<form class="sigma-newslatter"><h3>' . $settings['footer_newsletter_title'] . '</h3><input class="name-sg" type="text" placeholder="' . __('Your Name', 'sigma-theme') . '"> <input class="email-sg" type="text" placeholder="' . __('Your Email...', 'sigma-theme') . '"><button class="submit-sg" type="submit" name="button">' . __('Submit', 'sigma-theme') . '</button><small>' ?><?php \Elementor\Icons_Manager::render_icon($settings['footer_newsletter_icon'], ['aria-hidden' => 'true']); ?><?php echo '' . $settings['footer_newsletter_privacy'] . '</small></form>';
        }
        if ($settings['newslatter_style_select'] == 'style01_newsletter') {
            echo '<div class="newslleter"> <img class="document"> <span>' . $settings['footer_newsletter_title'] . '</span> <img class="lock"> <p>' . $settings['footer_newsletter_privacy'] . '</p> <div class="newslleter-newslleter" style=""> <input type="text" placeholder="' . __('Your Name', 'sigma-theme') . '" name="NAME" required=""> <input type="text" placeholder="' . __('Your Email...', 'sigma-theme') . '" name="mail" required=""></div> <div class="newslleter-newslleter"><button class="newslleter-btn" type="submit" name="button">' . __('Submit', 'sigma-theme') . '</button></div></div>';
        }
        if ($settings['newslatter_style_select'] == 'style05_newsletter') {
            echo '<div class="fss_newsletter">
        <div class="container">
            <div class="row">
                <div class="col-6">
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="fss_newsletter_area">
                        <div class="fss_newsletter_title">
                            <p>' . $settings['footer_newsletter_title'] . '</p>
                            <small>' ?><?php \Elementor\Icons_Manager::render_icon($settings['footer_newsletter_icon'], ['aria-hidden' => 'true']); ?><?php echo ' ' . $settings['footer_newsletter_privacy'] . '</small
                        </div>
                        <div class="fss_newsletter_form">
                            <form>
                                <input type="email" placeholder="' . __('Your email', 'sigma-theme') . '">
                                <input type="text" placeholder="' . __('Your Name', 'sigma-theme') . '">
                                <button type="submit"><i class="fal fa-envelope"></i></button>                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
        }
        if ($settings['newslatter_style_select'] == 'style06_newsletter') {
            echo '<div class="edc_newsletter_footer">
                <h3 class="title_widget_edc">' . $settings['footer_newsletter_title'] . '</h3>
                <p>' . $settings['footer_newsletter_subtitle'] . '</p>
                <form class="edc_newslatter_form">
                   <input class="edc_footer_first_name" type="text" placeholder="' . __('Your Name', 'sigma-theme') . '" aria-label="Search">  
                   <input class="edc_footer_email" type="text" placeholder="' . __('Your email', 'sigma-theme') . '" aria-label="Search">  
                   <button class="edc_footer_nl_submit" type="submit"><i class="fal fa-paper-plane"></i></button>
                </form>
                <small>' ?><?php \Elementor\Icons_Manager::render_icon($settings['footer_newsletter_icon'], ['aria-hidden' => 'true']); ?><?php echo '' . $settings['footer_newsletter_privacy'] . '</small>
        </div>';
        }
        echo '</div>';

    }


    protected function _content_template()
    {

    }
}