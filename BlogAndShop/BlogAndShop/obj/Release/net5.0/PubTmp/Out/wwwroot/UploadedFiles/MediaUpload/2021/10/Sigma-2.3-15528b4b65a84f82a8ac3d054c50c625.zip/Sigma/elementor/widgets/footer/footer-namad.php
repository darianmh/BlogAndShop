<?php
namespace Elementor;

class Footer_Namad extends Widget_Base {

	public function get_name() {
		return 'footer-namad';
	}

	public function get_title() {
		return __( 'Footer Namad', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}  
	
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Footer Namad', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'namad_alignment',
			[
				'label' => __( 'Namad Alignment', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'sigma-theme' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'sigma-theme' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'sigma-theme' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} div#permissions ' => 'text-align: {{VALUE}};'
                ],				
			]
		);	
		
		$this->add_control(
			'list_footer_namad',
			[
				'label' => __( 'List Footer Namad', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'text',
						'label' => __( 'Html Code', 'sigma-theme' ),
        				'label' => __( 'Custom HTML', 'plugin-domain' ),
        				'type' => \Elementor\Controls_Manager::CODE,
        				'language' => 'html',
        				'placeholder' => __( 'List Item', 'sigma-theme' ),
						'default' => '<img src="' .get_template_directory_uri(). '/assets/img/enamad-sigma.png" alt="" style="cursor:pointer">'
					],
				],
				'default' => [
					[
						'text' => '<img src="' .get_template_directory_uri(). '/assets/img/enamad-sigma.png" alt="" style="cursor:pointer">'
					],
					[
						'text' => '<img src="' .get_template_directory_uri(). '/assets/img/samandehi-sigma.png" alt="" style="cursor:pointer">'
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div id="permissions_footer" class="owl-carousel owl-theme edc_permissions">
		<?php foreach ( $settings['list_footer_namad'] as $index => $item ) : ?>
			<div>
			    <?php echo $item['text']; ?>
			</div>
		<?php endforeach; ?>
		</div>
		<?php
	}

	protected function _content_template() {

	}
	
}