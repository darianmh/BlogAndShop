<?php
namespace Elementor;

class Main_Contact_From_7 extends Widget_Base {
	
	public function get_name() {
		return 'contact-form-7-main';
	}
	
	public function get_title() {
		return __( 'Sigma Contact From 7', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-accordion';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}

    function sigma_cf7form() {
        $wpcf7_form_list = get_posts( array(
            'post_type'	 => 'wpcf7_contact_form',
            'showposts'	 => 999,
        ) );
        $posts			 = array();
        if ( !empty( $wpcf7_form_list ) && !is_wp_error( $wpcf7_form_list ) ) {
            foreach ( $wpcf7_form_list as $post ) {
                $options[ $post->ID ] = $post->post_title;
            }
            return $options;
        }
    }
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_7',
			[
				'label' => __( 'Sigma Contact From 7', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'select_7_form',
            [
                'label' =>esc_html__( 'Select Contact Form', 'sigma-theme' ),
                'type' => Controls_Manager::SELECT,
                'options' => $this->sigma_cf7form()
            ]
        );

		$this->add_control(
			'important_note',
			[
				'label' => __( 'Important Note:', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' => __( 'If you have not installed the Contact Form 7 plugin, please install it through <a href="https://fa.wordpress.org/plugins/contact-form-7/" target="_blank" >this link</a> to load the forms.', 'sigma-theme' ),
				'content_classes' => 'your-class',
			]
		);
		
		$this->end_controls_section();

		
        $this->start_controls_section(
        	'style_section_c7',
        	[
				'label' => __( 'Contact Form 7 Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 
        
		$this->add_control(
			'title_c7_color',
			[
				'label' => __( 'Form Label Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sgm-contact-7-form label' => 'color: {{VALUE}}',
				],			
				'default' => '#999999'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_c7_typography',
				'label' => __( 'Form Label Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sgm-contact-7-form label',
			]
		);

		$this->add_control(
			'input_c7_bg',
			[
				'label' => __( 'Input Form Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sgm-contact-7-form input ' => 'background: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_control(
			'textarea_c7_bg',
			[
				'label' => __( 'Textarea Form Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sgm-contact-7-form textarea ' => 'background: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_control(
			'submit_c7_color',
			[
				'label' => __( 'Submit Button Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sgm-contact-7-form input[type="submit"]' => 'color: {{VALUE}}',
				],			
				'default' => '#FFFFFF'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'submit_c7_typography',
				'label' => __( 'Submit Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .sgm-contact-7-form input[type="submit"] ',
			]
		);

		$this->add_control(
			'submit_c7_bg',
			[
				'label' => __( 'Submit Button Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .sgm-contact-7-form input[type="submit"] ' => 'background: {{VALUE}}',
				],			
				'default' => '#CDDC39'
			]
		);
		
				
        $this->end_controls_section();       
        
	}
    
	protected function render() {
		$settings = $this->get_settings();
        echo '<div class="sgm-contact-7-form">';
        echo do_shortcode('[contact-form-7 id="'.$settings['select_7_form'].'"]' );
        echo '</div>';		
	}
}