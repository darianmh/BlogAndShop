<?php
namespace Elementor;

class Footer_Copyright extends Widget_Base {
    
	public function get_name() {
		return 'footer-copyright';
	}

	public function get_title() {
		return __( 'Footer Copyright', 'sigma-theme' );
	}

	public function get_icon() {
		return 'eicon-footer';
	}

	public function get_categories() {
		return [ 'Sigma-Footer' ];
	}      
	
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content_copyright',
			[
				'label' => __( 'Footer copyright', 'sigma-theme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'select_copyright_style',
			[
				'label'   => esc_html__( 'Select Copyright Style', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style01_copyright',
				'options' => [
                    'style01_copyright' => esc_html__('Style 01', 'sigma-theme'),
                    'style02_copyright' => esc_html__('Style 02', 'sigma-theme'),
                ],
			]
        );
        
		$this->add_control(
			'sigma_select_copyright_style01',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/footers/sigma_select_copyright_style01.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_copyright_style' => 'style01_copyright',
                ],      				
			]
		);        

		$this->add_control(
			'sigma_select_copyright_style02',
			[
				'raw' => '<img class="admin_select_img_style" src="'.get_template_directory_uri().'/assets/img/styles/footers/sigma_select_copyright_style02.jpg">',
				'type' => Controls_Manager::RAW_HTML,
                'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ],      				
			]
		);      
		
		$this->add_control(
			'copyright_text',
			[
				'label' => __( 'Footer Copyright Text', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Footer copyright Text', 'sigma-theme' ),
                'default' => __( 'Designer and coder: Hamkarwp Team', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'copyright_link',
			[
				'label' => __( 'Footer Copyright Link', 'sigma-theme' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'http://hamkarwp.com', 'sigma-theme' ),
				'default' => [
					'url' => __( 'http://hamkarwp.com', 'sigma-theme' ),
				]
			]
		);
		
		$this->add_control(
			'copyright_icon',
            [
                'label' => __( 'Footer Copyright Icon', 'sigma-theme' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
					'value' => 'far fa-code',
					'library' => 'regular',
				],
                'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 
            ]
		);		
		
		$this->end_controls_section();

        $this->start_controls_section(
        	'style_section_copyright',
        	[
				'label' => __( 'Footer Copyright', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	  

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cp_style2_bg',
				'label' => __( 'Copyright Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .designer_footer_edc',
				'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 				
			]
		);
		
		$this->add_control(
			'copyright_text_color_s1',
			[
				'label' => __( 'Copyright Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .copyright_style_01' => 'color: {{VALUE}}',
				],		
				'condition' => [
                    'select_copyright_style' => 'style01_copyright',
                ], 
                'default' => '#b7b7b7'
			]
		);
		
		$this->add_control(
			'copyright_text_color',
			[
				'label' => __( 'Copyright Text Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .designer_footer_edc a' => 'color: {{VALUE}}',
				],		
				'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 
                'default' => '#666666'
			]
		);

		$this->add_control(
			'copyright_icon_color',
			[
				'label' => __( 'Copyright Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .designer_footer_edc a i' => 'color: {{VALUE}}',
				],			
				'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 
                'default' => '#ffffff'
			]
		);

		$this->add_control(
			'copyright_style01_background',
			[
				'label' => __( 'Copyright Background', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .copyright_style_01' => 'background: {{VALUE}}',
				],			
				'default' => '#bdbdbd'
			]
		);

		$this->add_control(
			'copyright_style01_background_hover',
			[
				'label' => __( 'Copyright Background', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'condition' => [
                    'select_copyright_style' => 'style01_copyright',
                ],		
				'selectors' => [
					'{{WRAPPER}} .copyright_style_01:hover' => 'background: {{VALUE}}',
				],		
				'default' => '#8781bd'
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'copyright_style01_background_author',
				'label' => __( 'Copyright Background Developer', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'condition' => [
                    'select_copyright_style' => 'style01_copyright',
                ],
				'selector' => '{{WRAPPER}} .copyright_style_01:after ',
			]
		);		
				
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'copyright_icon_bg',
				'label' => __( 'Copyright Icon Background', 'plugin-domain' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .designer_footer_edc a i',
				'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 
			]
		);

		$this->add_control(
			'width_cp',
			[
				'label' => __( 'Footer copyright Width', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 60,
				],
				'selectors' => [
					'{{WRAPPER}} .designer_footer_edc' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 
			]
		);

		$this->add_control(
			'width_cp_hover',
			[
				'label' => __( 'Footer Copyright Hover Width', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 210,
				],
				'selectors' => [
					'{{WRAPPER}} .designer_footer_edc:hover' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
                    'select_copyright_style' => 'style02_copyright',
                ], 
			]
		);
 
		$this->end_controls_section();
		
	}

	protected function render() {
        $settings = $this->get_settings_for_display();
        $url = $settings['copyright_link']['url'];
        if($settings['select_copyright_style'] == 'style01_copyright' && !empty($settings['select_copyright_style'])){    
        echo '<a class="copyright_style_01" href="'.$url.'">'.$settings['copyright_text'].'</a>';  
        }
        if($settings['select_copyright_style'] == 'style02_copyright'){    
        echo '<div class="designer_footer_edc designer_footer_dgs"><a href="'.$url.'">'?><?php \Elementor\Icons_Manager::render_icon( $settings['copyright_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo'<span>'.$settings['copyright_text'].'</span></a></div>';  
        }        
	}	
}