<?php
namespace Elementor;

class Main_Flip_Box extends Widget_Base {
	
	public function get_name() {
		return 'flipbox-widget';
	}
	
	public function get_title() {
		return __( 'Flip Box', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-flip-box';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Flip Box', 'sigma-theme' ),
			]
		);
		
		$this->add_responsive_control(
			'flipbox_cols',
			[
				'label'          => esc_html__( 'Columns Flip Box', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
                'default' => '4',
			]
		);			

		$this->add_control(
			'list_flipbox',
			[
				'label' => __( 'List Table Price', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'title_intro',
						'label' => __( 'Title Intro', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Title Intro enter', 'sigma-theme' ),
						'default' => __( 'Refund Money', 'sigma-theme' ),
					],
					[
						'name' => 'description_intro',
						'label' => __( 'Description Intro', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Description Intro enter', 'sigma-theme' ),
						'default' => __( 'A one-month money back guarantee is available for all products unconditionally.', 'sigma-theme' ),
					],	
					[
						'name' => 'icon_intro',
						'label' => __( 'Icon Intro', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::ICONS,
        				'default' => [
        					'value' => 'far fa-user',
        					'library' => 'regular',
        				],						
					],						
					[
						'name' => 'title_back',
						'label' => __( 'Title Back', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Title Back Enter', 'sigma-theme' ),
						'default' => __( 'Refund Money', 'sigma-theme' ),
					],
					[
						'name' => 'description_back',
						'label' => __( 'Description Back', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'title Description Intro', 'sigma-theme' ),
						'default' => __( 'A one-month money back guarantee is available for all products unconditionally.', 'sigma-theme' ),
					],	
					[
						'name' => 'btn_title_back',
						'label' => __( 'Button Title Back', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'placeholder' => __( 'Button Title Back Intro', 'sigma-theme' ),
						'default' => __( 'Apply for registration', 'sigma-theme' ),
					],	
					[
						'name' => 'btn_url_back',
						'label' => __( 'Button Url Back', 'sigma-theme' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => get_site_url() . '/shop',
        				'default' => [
        					'url' => get_site_url() . '/shop',
        				]						
					],				
				],
				'default' => [
					[
						'title_intro' => __( 'Refund Money', 'sigma-theme' ),
						'description_intro' => __( 'A one-month money back guarantee is available for all products unconditionally.', 'sigma-theme' ),
						'icon_intro' => [ 'value' => 'far fa-user', 'library' => 'regular', ],
						'title_back' => __( 'Refund Money', 'sigma-theme' ),
						'description_back' => __( 'A one-month money back guarantee is available for all products unconditionally.', 'sigma-theme' ),
						'btn_title_back' => __( 'Apply for registration', 'sigma-theme' ),
						'btn_url_back' => get_site_url() . '/shop',
					],
					[
						'title_intro' => __( 'Refund Money', 'sigma-theme' ),
						'description_intro' => __( 'A one-month money back guarantee is available for all products unconditionally.', 'sigma-theme' ),
						'icon_intro' => [ 'value' => 'far fa-user', 'library' => 'regular', ],
						'title_back' => __( 'Refund Money', 'sigma-theme' ),
						'description_back' => __( 'A one-month money back guarantee is available for all products unconditionally.', 'sigma-theme' ),
						'btn_title_back' => __( 'Apply for registration', 'sigma-theme' ),
						'btn_url_back' => get_site_url() . '/shop',
					],
				],
				'title_field' => '{{{ title_intro }}}',
			]
		);
		
		$this->end_controls_section();

        $this->start_controls_section(
              'section_style_intro',
              [
                'label' => __( 'Flip Box Intro', 'sigma-theme' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
              ]
            );    

        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_flip_box_front',
        		'label' => _x( 'Color Background Flip Box Front', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .flip-box-front',
        	]
        );     
        
        $this->add_control(
        	'dgs_color_flip_box_Text_front_a',
        	[
        		'label' => __( 'Flip Box Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#333333',
        		'selectors' => [
        			'{{WRAPPER}} .flip-box-front h5' => 'color: {{VALUE}}',
        		],		
        	]
        );    

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'flipbox_text_type',
        		'label' => __( 'Flip Box Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .flip-box-front h5',
			]
		);	
		
        $this->add_control(
        	'dgs_color_flip_box_description_front_a',
        	[
        		'label' => __( 'Flip Box Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#929292',
        		'selectors' => [
        			'{{WRAPPER}} .flip-box-front p' => 'color: {{VALUE}}',
        		],		
        	]
        );  

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'flipbox_description_type',
        		'label' => __( 'Flip Box Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .flip-box-front p',
			]
		);	
		
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_flip_icob_bg',
        		'label' => _x( 'Icon Background Color', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .flip-box-front i',
        	]
        );

        $this->add_control(
        	'dgs_flip_box_icon_color',
        	[
        		'label' => __( 'Flip Box Icon Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .flip-box-front i ' => 'color: {{VALUE}}',
        		],		
        	]
        );  

		$this->add_control(
			'dgs_flip_box_icon_size',
			[
        		'label' => __( 'Flip Box Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 45,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .flip-box-front i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Icon Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .flip-box-front i ',
			]
		);
		
		$this->end_controls_section();
		
        //back style
		
        $this->start_controls_section(
              'section_style_back',
              [
                'label' => __( 'Flip Box Back', 'sigma-theme' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
              ]
            );
            
        $this->add_group_control(
        	Group_Control_Background::get_type(),
        	[
        		'name' => 'dgs_color_background_flip_box_back',
        		'label' => _x( 'Color Background Flip Box Back', 'sigma-theme' ),
        		'types' => [ 'classic', 'gradient'],
        		'selector' => '{{WRAPPER}} .flip-box-back',
        	]
        );    
        
        $this->add_control(
        	'dgs_color_flip_box_back',
        	[
        		'label' => __( 'Flip Box Title Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .flip-box-back h5' => 'color: {{VALUE}}',
        		],		
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'flipbox_back_title_type',
        		'label' => __( 'Flip Box Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .flip-box-back h5',
			]
		);	
		
        $this->add_control(
        	'dgs_color_flip_box_back_descripion',
        	[
        		'label' => __( 'Flip Box Description Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .flip-box-back p' => 'color: {{VALUE}}',
        		],		
        	]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'flipbox_back_descripion_type',
        		'label' => __( 'Flip Box Description Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .flip-box-back p',
			]
		);	
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'flipbox_btn_bg',
				'label' => __( 'Flipbox Button Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .flip-box-back a',
			]
		);

        $this->add_control(
        	'dgs_color_flip_box_back_a',
        	[
				'label' => __( 'Flipbox Button Color', 'sigma-theme' ),
        		'type' => \Elementor\Controls_Manager::COLOR,
        		'scheme' => [
        			'type' => \Elementor\Scheme_Color::get_type(),
        			'value' => \Elementor\Scheme_Color::COLOR_1,
        		],
        		'default' => '#ffffff',
        		'selectors' => [
        			'{{WRAPPER}} .flip-box-back a' => 'color: {{VALUE}}',
        		],		
        	]
        );		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'flipbox_back_btn_type',
				'label' => __( 'Flipbox Button Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .flip-box-back a',
			]
		);	
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'dgs_color_flip_box_back_border',
				'label' => __( 'Flipbox Button Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .flip-box-back a ',
			]
		);
		
        $this->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings_for_display(); ?>
		<div class="flip_box_sgm columns-<?php echo $settings['flipbox_cols']; ?>">
        <?php foreach ( $settings['list_flipbox'] as $index => $item ) :
		echo '<div class="flip-box">
          <div class="flip-box-inner">
            <div class="flip-box-front">'?>
                <?php \Elementor\Icons_Manager::render_icon( $item['icon_intro'], [ 'aria-hidden' => 'true' ] );
                echo'<h5>'.$item['title_intro'].'</h5>
                <p>'.$item['description_intro'].'</p>
                    </div>
            <div class="flip-box-back">
              <h5>'.$item['title_back'].'</h5>
                <p>'.$item['description_back'].'</p>
              <a href="'.$item['btn_url_back']['url'].'">'.$item['btn_title_back'].'</a>
            </div>
          </div>
        </div>';  
		endforeach; ?>
		</div> <?php
    }
}