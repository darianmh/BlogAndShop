<div class="content-post">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 main-content-post">
                <?php get_template_part('template-part/content/single/main'); ?>
                <?php get_template_part('template-part/share-template'); ?>
                <?php get_template_part('template-part/content/single/auther'); ?>
                <?php get_template_part('template-part/content/single/raleted'); ?>
                <?php get_template_part('template-part/content/single/ads-post'); ?>
                <?php get_template_part('template-part/content/single/role-post'); ?>
                <?php get_template_part('template-part/content/single/comment-post'); ?>
            </div>
            <div class="col-lg-3 sidebar-post nopadding-right">
                <?php get_template_part('template-part/content/single/sidebar'); ?>
            </div>
        </div>
    </div>
</div>