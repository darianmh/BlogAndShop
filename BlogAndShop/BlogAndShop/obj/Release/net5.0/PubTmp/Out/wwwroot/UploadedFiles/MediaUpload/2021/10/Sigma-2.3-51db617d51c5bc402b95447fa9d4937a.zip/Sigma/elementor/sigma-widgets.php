<?php


class Sigma_Elementor_Widgets
{

    protected static $instance = null;

    public static function get_instance()
    {
        if (!isset(static::$instance)) {
            static::$instance = new static;
        }

        return static::$instance;
    }

    protected function __construct()
    {

// header elemenet include	

        require_once('widgets/header/logo-header.php');
        require_once('widgets/header/contact-information.php');
        require_once('widgets/header/nav-qiuck-link.php');
        require_once('widgets/header/header-search.php');
        require_once('widgets/header/header-userarea.php');
        require_once('widgets/header/header-cart.php');
        require_once('widgets/header/header-wishlist.php');
        require_once('widgets/header/main-menu.php');
        require_once('widgets/header/dark-mode.php');
        require_once('widgets/header/alert-sigma.php');

// footer elemenet include	

        require_once('widgets/footer/footer-nav-information.php');
        require_once('widgets/footer/footer-menu.php');
        require_once('widgets/footer/footer-newsletter.php');
        require_once('widgets/footer/footer-namad.php');
        require_once('widgets/footer/footer-copyright.php');
        require_once('widgets/footer/footer-social-icons.php');
        require_once('widgets/footer/vertical-menu.php');
        require_once('widgets/footer/footer-apps.php');
        require_once('widgets/footer/footer-statistics.php');
        require_once('widgets/footer/tags.php');
        require_once('widgets/footer/back-to-top.php');


// body elemenet include	

        require_once('widgets/main/deal-products.php');
        require_once('widgets/main/products-grid.php');
        require_once('widgets/main/category-box.php');
        require_once('widgets/main/advanced-search.php');
        //require_once('widgets/main/best-seller.php');
        require_once('widgets/main/posts-grid.php');
        require_once('widgets/main/price-table.php');
        require_once('widgets/main/flip-box.php');
        require_once('widgets/main/service-box.php');
        require_once('widgets/main/brands.php');
        require_once('widgets/main/courses.php');
        require_once('widgets/main/categories.php');
        require_once('widgets/main/courses-deal.php');
        require_once('widgets/main/ads.php');
        require_once('widgets/main/contact-form-7.php');
        require_once('widgets/main/slider.php');
        require_once('widgets/main/products-carousel.php');
        require_once('widgets/main/post-carousel.php');
        require_once('widgets/main/button-popup.php');

// single elemenet include	

        require_once('widgets/single/post-title.php');
        require_once('widgets/single/post-content.php');
        require_once('widgets/single/post-thumbnail.php');
        require_once('widgets/single/post-meta.php');
        require_once('widgets/single/post-excerpt.php');
        require_once('widgets/single/post-share.php');
        require_once('widgets/single/author-box.php');
        require_once('widgets/single/telegram-box.php');
        require_once('widgets/single/comments-roles.php');
        require_once('widgets/single/post-comments.php');
        require_once('widgets/single/related-post.php');
        require_once('widgets/single/short-url.php');
        require_once('widgets/single/download-box.php');
        require_once('widgets/single/breadcrumb.php');
        require_once('widgets/single/post-tag.php');

        add_action('elementor/widgets/widgets_registered', [$this, 'register_widgets']);
    }

    public function register_widgets()
    {
        // Header Elements Start
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Logo_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Contact_Information());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Nav_Qiuck_Link());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Search());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Login_Area());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Cart());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Wishlist());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Menu());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Header_Dark_Mode());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Alert_Sigma_Header());

        // Footer Elements Start
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Nav_Information());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Menu());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Newsletter());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Namad());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Copyright());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Social_Icons());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_App_Lists());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Store_Statistics());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Vertical_Menu());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Sigma_Tag());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Footer_Sigma_BackToTop());

        // Body Elements Start
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Grid_Poroducts_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Deal_Poroducts_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Advanced_Search());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Category_Box());
        //\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Main_Best_Seller() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Grid_Posts());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Price_Table());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Flip_Box());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Service_Box());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Brands());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Courses());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Products_Categories());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Courses_Deal());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Sigma_Ads());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Contact_From_7());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Sigma_Slides());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Carousel_Poroducts_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Carousel_Posts());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Main_Botton_Popup());

        // Single Elements Start
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Title());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Content());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Thumbnail());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Meta());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Excerpt());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Share());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Author_Box());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Telegram_Box());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Comments_Roles());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Comments());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Related_Posts());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Short_Url());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Download_Box());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Elementor\Post_Breadcrumbs());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Post_Tag() );

    }
}

function create_custom_categories($elements_manager)
{

    $elements_manager->add_category(
        'Sigma-Header',
        [
            'title' => __('Sigma header builder elements', 'sigma-theme'),
            'icon' => 'fa fa-plug',
        ]
    );
    $elements_manager->add_category(
        'Sigma-Main',
        [
            'title' => __('Sigma main elements', 'sigma-theme'),
            'icon' => 'fa fa-plug',
        ]
    );
    $elements_manager->add_category(
        'Sigma-Footer',
        [
            'title' => __('Sigma footer builder elements', 'sigma-theme'),
            'icon' => 'fa fa-plug',
        ]
    );
    $elements_manager->add_category(
        'Sigma-Single',
        [
            'title' => __('Sigma singles elements', 'sigma-theme'),
            'icon' => 'fa fa-plug',
        ]
    );
}

add_action('elementor/elements/categories_registered', 'create_custom_categories');

add_action('init', 'Sigma_Elementor_Widgets_init');
function Sigma_Elementor_Widgets_init()
{
    Sigma_Elementor_Widgets::get_instance();
}