<?php
namespace Elementor;

class Related_Posts extends Widget_Base {
	
	public function get_name() {
		return 'related-post';
	}
	
	public function get_title() {
		return  __( 'Related Posts', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-gallery-grid';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {
		
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Related Posts', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 
		
		$this->add_control(
			'active_related',
			[
				'label'   => esc_html__( 'Active Related Post', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

 		$this->add_control(
			'related_title',
			[
				'label' => __( 'Related Posts Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Related Posts Title', 'sigma-theme' ),
                'condition' => [
                    'active_related' => 'yes',
                ],      	                
                'default' => __( 'Be sure to read the following:', 'sigma-theme' ),
                'condition' => [ 'active_related' => 'yes', ],
			]
		);
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Related Posts', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'related_post_title_bg_color',
			[
				'label' => __( 'Related Post Title Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .ralated-post h4' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'active_related' => 'yes', ],
				'default' => '#fff'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'related_post_title_type',
				'label' => __( 'Related Post Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .ralated-post h4',
				'condition' => [ 'active_related' => 'yes', ],
			]
		);
		
		$this->add_control(
			'related_post_title_color',
			[
				'label' => __( 'Related Post Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .ralated-post h4' => 'color: {{VALUE}}',
				],			
				'default' => '#333333',
				'condition' => [ 'active_related' => 'yes', ],
			]
		);

		$this->add_control(
			'related_post_title_border_color',
			[
				'label' => __( 'Related Post Title Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .ralated-post h4' => 'border-right: 3px solid {{VALUE}}',
				],			
				'default' => '#ff5721',
				'condition' => [ 'active_related' => 'yes', ],
			]
		);

		$this->add_control(
			'related_post_bg',
			[
				'label' => __( 'Related Post Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} div#related ' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'active_related' => 'yes', ],
				'default' => '#fff'
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'relate_post_bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .ralated-post-elementor',
				'condition' => [ 'active_related' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .ralated-post-elementor',
                'condition' => [ 'active_related' => 'yes', ],					
			]
		);
		
        $this->end_controls_section();       
        
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            echo'<div class="darkeble ralated-post ralated-post-elementor">
            <h4>'.$settings['related_title'].'</h4>
             <div id="related" class="owl-carousel owl-theme"> '?>
            <?php example_cats_related_post() ?>
            <?php echo'</div>
            </div>';
        }
        else
        {
            echo'<div class="darkeble ralated-post ralated-post-elementor">
            <h4>'.$settings['related_title'].'</h4>
            <div id="related" class="owl-carousel owl-theme"> '?>
            <?php 
            global $sigma;
            get_template_part($sigma['post_style_loop'] );
            get_template_part($sigma['post_style_loop'] );
            get_template_part($sigma['post_style_loop'] );
            get_template_part($sigma['post_style_loop'] );
            get_template_part($sigma['post_style_loop'] );
            get_template_part($sigma['post_style_loop'] );
            echo'</div>
            </div>';            
        }
    }
}