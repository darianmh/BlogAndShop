<?php get_header(); ?>
<style>a.added_to_cart.wc-forward { display: none; }</style>


  <!-- left+right -->
<div class="container center">
<div class="row center">
    


  <!-- left -->
<div class="left col-8 shoppage">
  <!-- grid-shop -->





    
<div class="breadcrumb_product">
<?php 
$args = array(
'delimiter' => ' » ',
'home' => _x( 'خانه', 'breadcrumb', 'woocommerce' ));
woocommerce_breadcrumb($args); ?>
</div>



<div class="card-group cat-product col-sx-8">

 
    <?php 	do_action( 'woocommerce_before_shop_loop' );

	woocommerce_product_loop_start();

	if ( wc_get_loop_prop( 'total' ) ) {
		while ( have_posts() ) {
			the_post();

			/**
			 * Hook: woocommerce_shop_loop.
			 *
			 * @hooked WC_Structured_Data::generate_product_data() - 10
			 */
			do_action( 'woocommerce_shop_loop' );

			wc_get_template_part( 'content', 'product' );
		}
	}

	woocommerce_product_loop_end();


	// end of the loop. ?>

 



</div>
 
<?php woocommerce_product_loop_end(); ?>
  <!-- grid-shop -->

<?php sigma_numeric_posts_nav(); ?>


</div>

<div class="shop_side col-sx-4">

<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('سایدبار راست - فروشگاه')) : else : ?><?php endif; ?>


</div>
  <!-- left -->
</div>
</div>
</div>
  <!-- left+right -->


<?php get_footer(); ?>
