<?php // Do not delete these lines
if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) die ('Please do not load this page directly. Thanks!');
if (!empty($post->post_password)) { // if there's a password
	if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
?>

<h2><?php _e('Password Protected'); ?></h2>
<p><?php _e('Enter the password to view comments.'); ?></p>

<?php return;
	}
}

	/* This variable is for alternating comment background */

$oddcomment = 'alt';

?>

<!-- You can start editing here. -->

<?php if ($comments) : ?>




<ol class="commentlist">
<?php wp_list_comments("type=comment&callback=mytheme_comment"); ?>
</ol>


<?php /* Changes every other comment to a different class */
	if ('alt' == $oddcomment) $oddcomment = '';
	else $oddcomment = 'alt';
?>


<?php else : // this is displayed if there are no comments so far ?>

<?php if ('open' == $post->comment_status) : ?>
	<!-- If comments are open, but there are no comments. -->
	<?php else : // comments are closed ?>

	<!-- If comments are closed. -->
<p class="nocomments">امکان ارسال نظر وجود ندارد</p>

	<?php endif; ?>
			<?php endif; ?>
<?php if ('open' == $post->comment_status) : ?>

    
    <div class="user_ID"><?php cancel_comment_reply_link(); ?></div>
	<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
برای ارسال نظر لطفا ابتدا  <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>">وارد شوید</a> <?php else : ?>
<div class="comment-form">
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
<?php if ( $user_ID ) : ?>
<div class="user_ID">
شما با نام کاربری  <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a> وارد شده اید. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="خارج شدن">خارج می شوید ؟  &raquo;</a></div>
<?php else : ?>	
    	<input class="name-sigma" name="author" type="text" class="cm_input" placeholder="نام شما">
    	<input class="email-sigma" type="email" name="email" class="cm_input" placeholder="پست الکترونیک">
    	<input class="url-sigma" type="url" name="url" class="cm_input" placeholder="وبسایت">
	<?php endif; ?>
   <textarea class="text-sigma" name="comment" rows="5" id="textarea" class="input-xlarge mytextarea"></textarea> 
    <input type="submit" class="btn btn-primary submit-sigma" value="ارسال دیدگاه">
	<input class="submit-sigma" type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
<?php comment_id_fields(); ?>
<?php do_action('comment_form', $post->ID); ?>

</form>
 </div> 
<?php endif; // If registration required and not logged in ?>

<?php endif; // if you delete this the sky will fall on your head ?>
   
    
