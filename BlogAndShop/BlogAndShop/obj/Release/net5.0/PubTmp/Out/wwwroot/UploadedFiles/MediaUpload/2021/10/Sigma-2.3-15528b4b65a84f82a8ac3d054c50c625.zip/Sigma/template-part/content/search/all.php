<div class="breadcrumb_post">
    <?php
    $args = array(
        'delimiter' => ' <i></i> ',
        'home' => __('home', 'sigma-theme'));
    woocommerce_breadcrumb($args);
    ?>
</div>

<div class="archive-sigma">
    <div class="row">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

            <div class="col-lg-4 last-posts col-sm-6">
                
                <?php
                global $sigma;
                get_template_part($sigma['post_style_loop']);
                ?>
                
            </div>
            
        <?php endwhile; else: ?><?php endif; ?>

        <div class="pagenavi">
            <?php sigma_numeric_posts_nav(); ?>
        </div>
    </div>
</div>