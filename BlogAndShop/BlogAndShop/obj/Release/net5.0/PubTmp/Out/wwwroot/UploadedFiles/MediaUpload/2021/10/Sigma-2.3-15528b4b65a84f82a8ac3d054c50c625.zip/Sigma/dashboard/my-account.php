<?php

if ( is_user_logged_in() ) { 
    
    get_template_part('dashboard/dashboard');
    } 
    else {
    get_header();
    get_template_part('woocommerce/myaccount/form-login');
    get_footer();
    }
?>