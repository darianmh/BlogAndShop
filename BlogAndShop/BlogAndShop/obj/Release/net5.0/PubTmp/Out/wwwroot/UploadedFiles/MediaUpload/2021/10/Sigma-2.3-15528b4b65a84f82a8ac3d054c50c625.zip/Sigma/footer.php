<div class="top-footer" style="background:<?php echo ot_get_option("bg_top_footer"); ?>">
<div class="container">


<div class="counters" style="display:<?php echo ot_get_option("counter_shop"); ?>" >

<div class="counter">

<img src="<?php echo ot_get_option("shop_counter_products_icon"); ?>" alt="footer05">
<h6><?php echo do_shortcode("[product_count]"); ?></h6>

<p><?php echo ot_get_option("shop_counter_products_title"); ?></p>

</div>

<div class="counter">

<img src="<?php echo ot_get_option("shop_counter_sales_icon"); ?>" alt="footer01">
<h6><?php echo do_shortcode("[user_count]"); ?></h6>

<p><?php echo ot_get_option("shop_counter_sales_title"); ?></p>

</div>

<div class="counter">

<img src="<?php echo ot_get_option("shop_counter_posts_icon"); ?>" alt="footer02">
<h6><?php echo do_shortcode("[total_posts]"); ?></h6>

<p><?php echo ot_get_option("shop_counter_posts_title"); ?></p>

</div>

<div class="counter">

<img src="<?php echo ot_get_option("shop_counter_earning_icon"); ?>" alt="footer04">
<h6><?php echo ot_get_option("show_sales"); ?></h6>

<p><?php echo ot_get_option("shop_counter_earning_title"); ?></p>

</div>

<div class="counter">

<img src="<?php echo ot_get_option("shop_counter_support_icon"); ?>" alt="footer03">
<h6><?php echo ot_get_option("support_counter"); ?></h6>

<p><?php echo ot_get_option("shop_counter_support_title"); ?></p>

</div>
</div>

</div>

</div>
<div class="footer" style="background:<?php echo ot_get_option("bg_bottom_footer"); ?>">
<div class="container">

		<div class="footer-cl-menu1 col-xl-3 col-lg-6 col-sx-6">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('فوتر ستون یک')) : else : ?><?php endif; ?>
	</div>

	
		<div class="footer-cl-menu col-xl-2 col-lg-2" style="font-size:<?php echo ot_get_option("footer_item_size"); ?>;font-family:<?php echo ot_get_option("font_itmem_footer"); ?>" >
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('فوتر ستون دو')) : else : ?><?php endif; ?>

	</div>
	
			<div class="footer-cl-menu col-xl-2 col-lg-2 col-sx-6" style="font-size:<?php echo ot_get_option("footer_item_size"); ?>;font-family:<?php echo ot_get_option("font_itmem_footer"); ?>">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('فوتر ستون سه')) : else : ?><?php endif; ?>


	</div>
	
		<div class="footer-cl-menu col-xl-2 col-lg-2" style="font-size:<?php echo ot_get_option("footer_item_size"); ?>;font-family:<?php echo ot_get_option("font_itmem_footer"); ?>" >
<div class="footer-app">
	
<div class="app-apk"><a href="<?php echo ot_get_option("apk_dl"); ?>" class="apk"><?php echo ot_get_option("apk_title"); ?><i class="fa fa-android"></i></a></div>
<div class="app-sibapp"><a href="<?php echo ot_get_option("ios_dl"); ?>" class="sibapp"><?php echo ot_get_option("ios_title"); ?><i class="fa fa-apple"></i></a></div>
<div class="app-playstore"><a href="<?php echo ot_get_option("win_dl"); ?>" class="playstore"><?php echo ot_get_option("win_title"); ?><i class="fa fa-play"></i></a></div>
	</div>

	</div>

	
	<div class="footer-menu" style="font-size:<?php echo ot_get_option("footer_item_size"); ?>;font-family:<?php echo ot_get_option("font_itmem_footer"); ?>" >
<?php wp_nav_menu( array( 'theme_location' => 'footer-menu' ) ); ?>

	</div>
	
	<div class="copyright" style="font-size:<?php echo ot_get_option("support_size"); ?>;font-family:<?php echo ot_get_option("footer_address_font"); ?>" >
<?php echo ot_get_option("address"); ?>
<br>
<?php echo ot_get_option("support"); ?>

	</div>

<div style="color:<?php echo ot_get_option("title_color_cpright"); ?> ;background:<?php echo ot_get_option("bg_cpright"); ?>" class="auther col-xl-3 col-lg-4"><a style="color:<?php echo ot_get_option("title_color_cpright"); ?>" href="<?php echo ot_get_option("author_link"); ?>"><?php echo ot_get_option("author_name"); ?></a></div>	

<div class="cpright" style="font-size:<?php echo ot_get_option("cp_size_font"); ?>;font-family:<?php echo ot_get_option("cp_font"); ?>" >
<?php echo ot_get_option("cpright"); ?>

</div>

<?php wp_footer(); ?>
<div><a  style="background:<?php echo ot_get_option("bg_backtop"); ?> ;display:<?php echo ot_get_option("backto_up"); ?>" href="#" class="topbutton" ><i class="fa fa-angle-up"></i></a></div>

</div>
</div>

</div><!--main-->
<script>
 $(document).ready(function(){
 <!--menus-->
 $(".sub ul li").click(function(){
 $(this).children("ul").slideToggle("fast");
 });
 $("#xsmenu").click(function(){
 $("#main").animate({left:'-200px'});
 $("#black").css("display","block");
 $(".top-menu-xs").css("display","block");
 $(".top-menu-xs").animate({right:'0%'});
 });
 $("#black,.removeicon").click(function(){
 $("#main").animate({left:'0px'});
 $("#black").css("display","none");
 $(".top-menu-xs").animate({right:'-200px'});
 $(".search-box").animate({width:'0px',height:'0px',margin:'20% 50%'},[,'fast']);
 });
 <!--menus-->
 });
 </script>

<style>
.footer-app {display:<?php echo ot_get_option("appli_dl"); ?>}
</style>
