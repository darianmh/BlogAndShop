<?php
namespace Elementor;

class Short_Url extends Widget_Base {
	
	public function get_name() {
		return 'short-url';
	}
	
	public function get_title() {
		return  __( 'Short Url Post', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-url';
	}
	
	public function get_categories() {
		return [ 'Sigma-Single' ];
	}
    
	protected function _register_controls() {

		
        $this->start_controls_section(
        	'style_section_content',
        	[
				'label' => __( 'Short Url Post', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        	]
        );	 


		$this->add_control(
			'avtive_short_url',
			[
				'label'   => esc_html__( 'Active Short Url', 'sigma-theme' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
 		$this->add_control(
			'short_url_title',
			[
				'label' => __( 'Short Url Post Title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter Short Url Post Title', 'sigma-theme' ),
                'condition' => [
                    'avtive_short_url' => 'yes',
                ],      	                
                'default' => __( 'Short Url Post', 'sigma-theme' ),
			]
		);

		$this->add_control(
			'short_url_icon',
			[
				'label' => __( 'Short Url Post Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-link',
					'library' => 'light',
				],
                'condition' => [
                    'avtive_short_url' => 'yes',
                ],				
			]
		);

        $this->end_controls_section();       
        
        $this->start_controls_section(
        	'section_content_style',
        	[
				'label' => __( 'Short Url Post', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_control(
			'short_url_background',
			[
				'label' => __( 'Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .short_url_post' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'avtive_short_url' => 'yes', ],
				'default' => '#fff'
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} span.short-link' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'avtive_short_url' => 'yes', ],
				'default' => '#444444',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_type',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} span.short-link',
				'condition' => [ 'avtive_short_url' => 'yes', ],
			]
		);


		$this->add_control(
			'title_icon_size',
			[
				'label' => __( 'Title Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} span.short-link i ' => 'font-size:{{SIZE}}px',
				],
				'condition' => [ 'avtive_short_url' => 'yes', ],
			]
		);

		$this->add_control(
			'title_icon_color',
			[
				'label' => __( 'Title Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} span.short-link i ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'avtive_short_url' => 'yes', ],
				'default' => '#444444',
			]
		);

		$this->add_control(
			'copy_icon_color',
			[
				'label' => __( 'Copy Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .copy ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'avtive_short_url' => 'yes', ],
				'default' => '#fff',
			]
		);

		$this->add_control(
			'copy_icon_bg',
			[
				'label' => __( 'Copy Icon Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} .copy' => 'background: {{VALUE}}',
				],			
				'condition' => [ 'avtive_short_url' => 'yes', ],
				'default' => '#949494'
			]
		);
		
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bx_shdw',
				'label' => __( 'Box Shadow', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .short_url_post',
				'condition' => [ 'avtive_short_url' => 'yes', ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .short_url_post',
                'condition' => [ 'avtive_short_url' => 'yes', ],					
			]
		);

        $this->end_controls_section();       
        
		
        $this->start_controls_section(
        	'style_section_input',
        	[
				'label' => __( 'Short Url Post Input Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        		'condition' => [ 'avtive_short_url' => 'yes', ],	
        	]
        );
        
		$this->add_control(
			'input_bg_color',
			[
				'label' => __( 'Input Background Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
					],
				'selectors' => [
					'{{WRAPPER}} input.ulink' => 'background: {{VALUE}}',
				],			
				'default' => '#ffffff',
				'condition' => [ 'avtive_short_url' => 'yes', ],	
			]
		);

		$this->add_control(
			'input_color',
			[
				'label' => __( 'Input Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} input.ulink ' => 'color: {{VALUE}}',
				],			
				'condition' => [ 'avtive_short_url' => 'yes', ],
				'default' => '#999999',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'input_typography',
				'label' => __( 'Input Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} input.ulink ',
				'condition' => [ 'avtive_short_url' => 'yes', ],
			]
		);

		
        $this->end_controls_section();       
        
	}

    protected function render() {
        $settings = $this->get_settings_for_display();
        $template = \SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
        if($template->IsRealRender())
        {
            if($settings['avtive_short_url'] == 'yes'){
            echo'<div class="short_url_post short_url_post_elementor">
                <span class="short-link">'?><?php \Elementor\Icons_Manager::render_icon( $settings['short_url_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $settings['short_url_title'] ?> <?php echo'</span> 
    			    <input type="text" class="ulink" value="'. get_bloginfo('url').'/?p='.get_the_ID().' " id="myInput">	
				<i class="fal fa-copy copy" onclick="myFunction()" aria-hidden="true"></i></div>';
            }
        }
        else
        {
            if($settings['avtive_short_url'] == 'yes'){
            echo'<div class="short_url_post short_url_post_elementor">
                <span class="short-link">'?><?php \Elementor\Icons_Manager::render_icon( $settings['short_url_icon'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $settings['short_url_title'] ?> <?php echo'</span> 
    			    <input type="text" class="ulink" value="'. get_bloginfo('url').'/?p='.get_the_ID().' " id="myInput">	
				<i class="fal fa-copy copy" onclick="myFunction()" aria-hidden="true"></i></div>';
            }	
        }
    }
}