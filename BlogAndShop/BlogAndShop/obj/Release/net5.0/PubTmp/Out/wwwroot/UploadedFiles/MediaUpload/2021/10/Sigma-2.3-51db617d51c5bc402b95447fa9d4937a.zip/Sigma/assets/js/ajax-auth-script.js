jQuery(document).ready(function (e) {
    e("#pop_login, #pop_signup").on("click", function (o) {
        return (
            (formToFadeOut = e("form#register")),
            (formtoFadeIn = e("form#login")),
            "pop_signup" == e(this).attr("id") && ((formToFadeOut = e("form#login")), (formtoFadeIn = e("form#register"))),
            formToFadeOut.fadeOut(500, function () {
                formtoFadeIn.fadeIn();
            }),
            !1
        );
    }),
        e(document).on("click", ".login_overlay, .close", function () {
            return (
                e("form#login, form#register").fadeOut(500, function () {
                    e(".login_overlay").remove();
                }),
                !1
            );
        }),
        e("#show_login, #show_signup").on("click", function (o) {
            e("body").prepend('<div class="login_overlay"></div>'), "show_login" == e(this).attr("id") ? e("form#login").fadeIn(500) : e("form#register").fadeIn(500), o.preventDefault();
        }),
        e("form#login, form#register").on("submit", function (o) {
            if (!e(this).valid()) return !1;
            e("p.status", this).show().text(ajax_auth_object.loadingmessage),
                (action = "ajaxlogin"),
                (username = e("form#login #username").val()),
                (password = e("form#login #password").val()),
                (email = ""),
                (security = e("form#login #security").val()),
                "register" == e(this).attr("id") && ((action = "ajaxregister"), (username = e("#signonname").val()), (password = e("#signonpassword").val()), (email = e("#email").val()), (security = e("#signonsecurity").val())),
                (ctrl = e(this)),
                e.ajax({
                    type: "POST",
                    dataType: "json",
                    url: ajax_auth_object.ajaxurl,
                    data: { action: action, username: username, password: password, email: email, security: security },
                    success: function (o) {
                        e("p.status", ctrl).text(o.message), 1 == o.loggedin && (document.location.href = ajax_auth_object.redirecturl);
                    },
                }),
                o.preventDefault();
        }),
        jQuery("#register").length ? jQuery("#register").validate({ rules: { password2: { equalTo: "#signonpassword" } } }) : jQuery("#login").length && jQuery("#login").validate();
});
