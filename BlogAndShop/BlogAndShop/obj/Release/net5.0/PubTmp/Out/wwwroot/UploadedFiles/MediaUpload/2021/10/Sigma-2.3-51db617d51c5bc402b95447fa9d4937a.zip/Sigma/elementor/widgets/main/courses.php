<?php
namespace Elementor;

class Main_Courses extends Widget_Base {
	
	public function get_name() {
		return 'course-widget';
	}
	
	public function get_title() {
		return __( 'Sigma Courses', 'sigma-theme' );
	}
	
	public function get_icon() {
		return 'eicon-post-list';
	}
	
	public function get_categories() {
		return [ 'Sigma-Main' ];
	}


    function get_product_cat(){
        $terms = get_terms( array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }
 
    function get_product_tag(){
        $terms = get_terms( array(
            'taxonomy' => 'product_tag',
            'hide_empty' => false,
        ));
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        foreach ( $terms as $term ) {
            $options[ $term->term_id ] = $term->name;
        }
        return $options;
        }
    }    
    
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Sigma Courses', 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'course_style',
			[
				'label' => __( 'Courses Style', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'list' => [
						'title' => __( 'List', 'sigma-theme' ),
						'icon' => 'fa fa-list',
					],
					'gird' => [
						'title' => __( 'Gird', 'sigma-theme' ),
						'icon' => 'fa fa-th',
					],
				],
				'default' => 'list',
				'toggle' => true,
			]
		);

		$this->add_control(
			'show_sigma_course_title',
			[
				'label'     => __( 'Show Course title', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => __( 'yes' , 'sigma-theme' ),
			]
		);
		
		$this->add_control(
			'grid_products_title',
			[
				'label' => __( 'title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'title products title', 'sigma-theme' ),
                'default' => __( 'Digital and Electric Goods', 'sigma-theme' ),
                'condition' => [ 'show_sigma_course_title' => 'yes', ],                
			]
		);

		$this->add_control(
			'grid_products_en_title',
			[
				'label' => __( 'english title', 'sigma-theme' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'english title products title', 'sigma-theme' ),
                'default' => __( 'Digital and Electric Goods', 'sigma-theme' ),
                'condition' => [ 'show_sigma_course_title' => 'yes', ],                
			]
		);	
		
		$this->add_control(
			'icon_title',
			[
				'label' => __( 'Icon title', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'far fa-ellipsis-h-alt',
					'library' => 'light',
				],
                'condition' => [ 'show_sigma_course_title' => 'yes', ],                
			]
		);
		
		$this->add_control(
			'show_sigma_course_filter',
			[
				'label'     => __( 'Show Sigmal Course filter', 'sigma-theme' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => __( 'yes' , 'sigma-theme' ),
			]
		);
		
		
		$this->add_responsive_control(
			'sigma_columns',
			[
				'label'          => esc_html__( 'Columns', 'sigma-theme' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
                ],
                'default' => '4',
                'condition' => [ 'course_style' => 'gird', ],                
			]
			
		);		
		
		$this->add_control(
			'sigma_posts_per_page',
			[
				'label'   => esc_html__( 'Product Limit', 'sigma-theme' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);
		
		$this->add_control(
			'sigma_orderby',
			[
				'label'   => esc_html__( 'Order by', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'     => esc_html__( 'Date', 'sigma-theme' ),
					'title'    => esc_html__( 'Title', 'sigma-theme' ),
					'category' => esc_html__( 'Category', 'sigma-theme' ),
					'rand'     => esc_html__( 'Random', 'sigma-theme' ),
					'total_sales'     => esc_html__( 'Sale', 'sigma-theme' ),
					'modified' => esc_html__( 'Updated', 'sigma-theme' ),
				],
			]
		);

		$this->add_control(
			'sigma_order',
			[
				'label'   => esc_html__( 'Order', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__( 'Descending', 'sigma-theme' ),
					'ASC'  => esc_html__( 'Ascending', 'sigma-theme' ),
				],
			]
		);		

		$this->add_control(
			'sigma_woo_product_select',
			[
				'label'   => esc_html__( 'Show product by ', 'sigma-theme' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'category',
				'options' => [
                    'category' => esc_html__('Category', 'sigma-theme'),
                    'product' => esc_html__('Product', 'sigma-theme'),
                    'tag' => esc_html__('Tag', 'sigma-theme'),
                ],
			]
        );
        
		$this->add_control(
			'sigma_woo_cat',
			[
				'label'   => esc_html__( 'Category', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_cat(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'category',
                ],
			]
        );

		$this->add_control(
			'sigma_woo_tag',
			[
				'label'   => esc_html__( 'tag', 'sigma-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => $this->get_product_tag(),
                'multiple'  => true,
                'condition' => [
                    'sigma_woo_product_select' => 'tag',
                ],
			]
        );     
        
		$this->end_controls_section();


        $this->start_controls_section(
        	'section_style',
        	[
				'label' => __( 'Sigma Courses Title Section', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );

		$this->add_control(
			'courses_area_icon_color',
			[
				'label' => __( 'Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc i ' => 'color: {{VALUE}}',
				],			
				'default' => '#41d3e6'
			]
		);

		$this->add_control(
			'courses_area_title_color',
			[
				'label' => __( 'Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc h3 ' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_area_title_typography',
				'label' => __( 'Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title_warp_edc h3 ',
			]
		);

		$this->add_control(
			'courses_area_en_title_color',
			[
				'label' => __( 'Sub Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc small ' => 'color: {{VALUE}}',
				],			
				'default' => '#bbbbbb'
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_area_subtitle_typography',
				'label' => __( 'Sub Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .title_warp_edc small ',
			]
		);		

		$this->add_control(
			'courses_area_icon_size',
			[
				'label' => __( 'Title Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 35,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .title_warp_edc i ' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
		$this->end_controls_section();
		
		
        $this->start_controls_section(
        	'style_section',
        	[
				'label' => __( 'Filter Courses Area', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'filter_bg',
				'label' => __( 'Filter Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .search_ajax_edc_index ',
			]
		);        

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border_search_filter',
				'label' => __( 'Filter Search Border', 'sigma-theme' ),
				'selector' => '{{WRAPPER}} .search_ajax_edc_index',
			]
		);

		$this->add_control(
			'color_logged_in',
			[
				'label' => __( 'Filter Search Placeholder Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .search_ajax_edc_index input::placeholder' => 'color: {{VALUE}}',
				],			
				'default' => '#888888'
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Filter Search Placeholder Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .search_ajax_edc_index input::placeholder',
			]
		);        

		$this->add_control(
			'filter_search_icon_size',
			[
				'label' => __( 'Filter Search Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .search_ajax_edc_index_warp form button i ' => 'font-size:{{SIZE}}px',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'filter_search_icon_bg',
				'label' => __( 'Filter Search Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .search_ajax_edc_index_warp form button i ',
			]
		);
		
		$this->add_control(
			'filter_search_icon_color',
			[
				'label' => __( 'Filter Search Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .search_ajax_edc_index_warp form button i ' => 'color: {{VALUE}}',
				],			
				'default' => '#ffffff'
			]
		);

		$this->add_control(
			'filter_nav_color',
			[
				'label' => __( 'Filter Nav Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .search_index_filter_edc ul li a ' => 'color: {{VALUE}}',
				],			
				'default' => '#999999'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'filter_nav_typography',
				'label' => __( 'Filter Nav Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .search_index_filter_edc ul li a ',
			]
		);
		
		$this->add_control(
			'filter_nav_border',
			[
				'label' => __( 'Filter Nav Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .search_index_filter_edc ul li a ' => 'border-left: 1px solid {{VALUE}}',
				],			
				'default' => '#e7edee'
			]
		);
		
		$this->add_control(
			'filter_nav_border_active',
			[
				'label' => __( 'Filter Avtive Nav Border Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .search_index_filter_edc ul li a.active ' => 'border-right: 3px solid {{VALUE}}',
				],			
				'default' => '#41d3e6'
			]
		);

		$this->add_control(
			'filter_nav_icon_color',
			[
				'label' => __( 'Filter Layout Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .search_index_layout_edc ul li a ' => 'color: {{VALUE}}',
				],			
				'default' => '#333'
			]
		);

		$this->add_control(
			'zoom_icon_size',
			[
				'label' => __( 'Filter Layout Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 25,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .search_index_layout_edc ul li a  i' => 'font-size:{{SIZE}}px',
				],
			]
		);
		
        $this->end_controls_section();       

		
        $this->start_controls_section(
        	'course_single_style',
        	[
				'label' => __( 'Courses Single Style', 'sigma-theme' ),
        		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        	]
        );	 

//list style
        
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'course_single_bg_list',
				'label' => __( 'Course Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'course_style' => 'list', ],
				'selector' => '{{WRAPPER}} .single_cusrse_list ',
			]
		);

		$this->add_control(
			'course_single_title_color_list',
			[
				'label' => __( 'Course Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .list_curses_name h2' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'list' ],
				'default' => '#333333'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'course_single_title_type_list',
				'label' => __( 'Course Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .list_curses_name h2',
                'condition' => [ 'course_style' => 'list', ],
			]
		);

		$this->add_control(
			'course_single_entitle_color_list',
			[
				'label' => __( 'Course English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .list_curses_name small' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'list', ],
				'default' => '#aba6a6'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'course_single_entitle_type_list',
				'label' => __( 'Course English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .list_curses_name small',
                'condition' => [ 'course_style' => 'list', ],
			]
		);

		$this->add_control(
			'courses_meta_count_color',
			[
				'label' => __( 'Courses Meta Counter Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta_qiuck_special_edc ul li p' => 'color: {{VALUE}}',
				],			
				'default' => '#656565',
                'condition' => [ 'course_style' => 'list', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_meta_count_tyoe',
				'label' => __( 'Courses Meta Counter Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .meta_qiuck_special_edc ul li p',
                'condition' => [ 'course_style' => 'list', ],				
			]
		);

		$this->add_control(
			'courses_label_count_color',
			[
				'label' => __( 'Courses Meta Label Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta_qiuck_special_edc ul li span' => 'color: {{VALUE}}',
				],			
				'default' => '#656565',
                'condition' => [ 'course_style' => 'list', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_meta_label_tyoe',
				'label' => __( 'Courses Meta Label Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .meta_qiuck_special_edc ul li span',
                'condition' => [ 'course_style' => 'list', ],				
			]
		);

		$this->add_control(
			'courses_price_color_s1',
			[
				'label' => __( 'Coureses Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .single_lists_quick p span' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'list', ],				
				'default' => '#41d3e6'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_price_type_s1',
				'label' => __( 'Coureses Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single_lists_quick p span',
                'condition' => [ 'course_style' => 'list', ],				
			]
		);

		$this->add_control(
			'courses_currency_color_s1',
			[
				'label' => __( 'Coureses Currency Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .single_lists_quick p' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'list', ],				
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_currency_type_s1',
				'label' => __( 'Coureses Currency Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single_lists_quick p',
                'condition' => [ 'course_style' => 'list', ],				
			]
		);

		$this->add_control(
			'courese_icon_size',
			[
				'label' => __( 'Coureses Qiuck Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .icon_box_curses_list i ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [ 'course_style' => 'list', ],
			]
		);
		

		$this->add_control(
			'courese_qicon_size',
			[
				'label' => __( 'Coureses Qiuck Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .icon_box_curses_list i ' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'list', ],
				'default' => '#888888'
			]
		);		
		
//grid style
        
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'course_single_bg_gird',
				'label' => __( 'Course Background', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'course_style' => 'gird', ],
				'selector' => '{{WRAPPER}} .single_curses_warp ',
			]
		);

		$this->add_control(
			'course_single_title_color_gird',
			[
				'label' => __( 'Course Persian Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .single_curses_warp h2 a' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'gird' ],
				'default' => '#333333'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'course_single_title_type_gird',
				'label' => __( 'Course Persian Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single_curses_warp h2 a',
                'condition' => [ 'course_style' => 'gird', ],
			]
		);

		$this->add_control(
			'course_single_entitle_color_gird',
			[
				'label' => __( 'Course English Title Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .single_curses_meta small ' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'gird', ],
				'default' => '#aba6a6'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'course_single_entitle_type_gird',
				'label' => __( 'Course English Title Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single_curses_meta small',
                'condition' => [ 'course_style' => 'gird', ],
			]
		);

		$this->add_control(
			'courses_meta_count_color_gird',
			[
				'label' => __( 'Courses Meta Counter Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta_qiuck_special_edc ul li p' => 'color: {{VALUE}}',
				],			
				'default' => '#656565',
                'condition' => [ 'course_style' => 'gird', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_meta_count_tyoe_gird',
				'label' => __( 'Courses Meta Counter Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .meta_qiuck_special_edc ul li p',
                'condition' => [ 'course_style' => 'gird', ],				
			]
		);

		$this->add_control(
			'courses_label_count_color_gird',
			[
				'label' => __( 'Courses Meta Label Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .meta_qiuck_special_edc ul li span' => 'color: {{VALUE}}',
				],			
				'default' => '#656565',
                'condition' => [ 'course_style' => 'gird', ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_meta_label_type_gird',
				'label' => __( 'Courses Meta Label Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}}  .meta_qiuck_special_edc ul li span',
                'condition' => [ 'course_style' => 'list', ],				
			]
		);

		$this->add_control(
			'courses_price_color_gird',
			[
				'label' => __( 'Coureses Price Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .single_lists_quick p span' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'gird', ],				
				'default' => '#41d3e6'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_price_type_gird',
				'label' => __( 'Coureses Price Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single_lists_quick p span',
                'condition' => [ 'course_style' => 'gird', ],				
			]
		);

		$this->add_control(
			'courses_currency_color_gird',
			[
				'label' => __( 'Coureses Currency Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .single_lists_quick p' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'gird', ],				
				'default' => '#777777'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_currency_type_gird',
				'label' => __( 'Coureses Currency Typography', 'sigma-theme' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .single_lists_quick p',
                'condition' => [ 'course_style' => 'gird', ],				
			]
		);

		$this->add_control(
			'courese_icon_size_gird',
			[
				'label' => __( 'Coureses Qiuck Icon Size', 'sigma-theme' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 25,
				],
				'range' => [	
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .edc_button_single ul li a ' => 'font-size:{{SIZE}}px',
				],
                'condition' => [ 'course_style' => 'gird', ],
			]
		);
		

		$this->add_control(
			'courese_qicon_size_gird',
			[
				'label' => __( 'Coureses Qiuck Icon Color', 'sigma-theme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .edc_button_single ul li a ' => 'color: {{VALUE}}',
				],			
                'condition' => [ 'course_style' => 'gird', ],
				'default' => '#888484'
			]
		);		


		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'courese_qicon_bg_gird',
				'label' => __( 'Coureses Qiuck Icon Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'course_style' => 'gird', ],
				'selector' => '{{WRAPPER}} .edc_button_single ul li',
			]
		);


		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'courese_qicon_bg_gird_hover_first',
				'label' => __( 'Coureses First Qiuck Icon Hover Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'course_style' => 'gird', ],
				'selector' => '{{WRAPPER}} .edc_button_single ul li:first-child a:hover',
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'courese_qicon_bg_gird_hover_last',
				'label' => __( 'Coureses Last Qiuck Icon Hover Background Color', 'sigma-theme' ),
				'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [ 'course_style' => 'gird', ],
				'selector' => '{{WRAPPER}} .edc_button_single ul li:last-child a:hover',
			]
		);		
        $this->end_controls_section();       
        
        
	}

    protected function render(){
		$settings = $this->get_settings();
        if($settings['course_style'] == 'list' && !empty($settings['course_style'])){   
            if($settings['show_sigma_course_title'] == 'yes') {
            echo'<div class="title_warp_edc title_edc_single">' ?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['icon_title'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php echo'<h3>'.$settings['grid_products_title'].'</h3> <small>'.$settings['grid_products_en_title'].'</small> </div>';
            }
            echo'<div class="single_cusrse_list_area">';
			//$this->render_filter();
    		$this->render_loop_item();
            echo'</div>';            
        }
        if($settings['course_style'] == 'gird') {
            if($settings['show_sigma_course_title'] == 'yes') {            
            echo'<div class="title_warp_edc title_edc_single">' ?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['icon_title'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php echo'<h3>'.$settings['grid_products_title'].'</h3> <small>'.$settings['grid_products_en_title'].'</small> </div>';
            }
            echo'<div class="single_cusrse_list_area">';
			//$this->render_filter();
    		$this->render_loop_item();
            echo'</div>';              
        }
    }

    /**
    public function render_filter() {
		$settings = $this->get_settings();
        if($settings['show_sigma_course_filter'] == 'yes' && !empty($settings['show_sigma_course_filter'])){    
		echo '<div class="row search_ajax_edc_index darkeble">
        <div class="col-md-4 col-sm-12 serch_box_edc_index">
            <div class="search_ajax_edc_index_warp">
                <form action="/action_page.php">
                    <input type="text" name="search_edc" placeholder="نام آموزش ، دوره یا کلمه مورد نظر...">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form> 
            </div>
        </div>    
        <div class="col-md-6 col-sm-12 search_index_filter_edc">
            <ul>
                <li><a href="#" class="active">جدید ترین ها</a></li>
                <li><a href="#"> پرفروش ترین ها</a></li>
                <li><a href="#"> ازران ترین ها</a></li>
            </ul>
        </div>
        <div class="col-md-2 col-sm-12 search_index_layout_edc">
            <ul>
                <li><a href="#"><i class="fa fa-th"></i></a></li>
                <li><a href="#"><i class="fa fa-list"></i></a></li>
            </ul>    
        </div>
        </div>';   ?>
        
        <?php
            }
        }
    */

	public function render_description() {
		$settings = $this->get_settings();
		global $product;
		
        if($settings['course_style'] == 'list' && !empty($settings['course_style'])){    
        echo '<div class="single_cusrse_list darkeble">
        <div class="row">
            <div class="col-md-3 col-sm-12 list_curses_name">
                <h2><a href="'.get_the_permalink().'">'.get_the_title().'</a></h2>
                <small>'.( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ).'</small></a>
            </div>
            <div class="col-md-3 col-sm-12 list_curses_badge">
                <div class="edc_badges edc_badges_signle">
                    <ul>' ?>
                <?php
                $id = get_the_ID();
                $medals = sigma_get_product_medals($id);
                if(false != $medals)
                {
                    foreach ($medals as $medal)
                        {
                            ?>
                            <li id="hexagon" class="badge_singel pink_badge"><img src="<?php echo $medal['medal_pic'] ?>" alt="<?php echo $medal['medal_name'] ?>" title="<?php echo $medal['medal_name'] ?>"><span class="badge-tooltip"><?php echo $medal['medal_name'] ?></span></li>
                            <?php
                        }    
                }        
                ?>
                <?php echo'</ul>
                </div>                
            </div>
            <div class="col-md-3 col-sm-12 list_cruses_meta">
                <div class="meta_qiuck_special_edc single_quick single_lists_quick">
                    <ul>
                        <li> '?>
                <?php
                $id = get_the_ID();
                $info = sigma_get_tutorial_info($id);        
                ?>                            
                            <p><?php 
                            if($info > 1 ) {
                            echo $info['product_time'];
                            }
                            else {
                                echo'-';
                            }
                            ?></p><span>طول دوره</span></li>
                        <li>
                            <?php echo'<p>'.get_comments_number().'</p><span>تعداد دیدگاه</span></li>
                        <li>
                            <p>'.( get_post_meta( get_the_ID(), 'total_sales', true ) ).'</p><span>تعداد دانشجو</span></li>
                    </ul>
                    <div class="row">
                        <div class="col-8"><p><span>' ?>
                        <?php echo woocommerce_template_single_price(); ?>
                        <?php echo'</div>
                        <div class="col-4 icon_box_curses_list">
                        <span>'?>
                        <?php
                            if(!sigma_is_in_wishlist(''))
                            {
                                ?>
                                <a class="sigma-add-to-wishlist" data-product-id="<?php the_ID(); ?>"><i class="far fa-bookmark"></i></a>
                                <?php
                            }
                            else
                            {
                                ?>
                                <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank" class="sigma-add-to-wishlist-added" data-product-id="<?php the_ID(); ?>"><span class="badge-tooltip-all">مشاهده علاقه مندی ها</span><i class="far fa-bookmark"></i></a>
                                <?php
                            }
                        ?>    
                        <?php echo'<a href="'.get_post_permalink().'?add-to-cart='.get_the_ID().'"><i class="far fa-shopping-bag"></i></a>
                        </span></div>
                    </div>
                </div>
            </div>
            <div class="col-md-1 col-sm-6">
            <div class="hexagon_teacher_single_bg list_hexagon_teacher_single_bg"></div>
            <div id="hexagon_teacher" class="hexagon_teacher_single hexagon_teacher_single_list">' ?>
                <?php
                    $id = get_the_ID();
                    $info = sigma_get_tutorial_info($id);    
                    echo'<img alt="avatar" title="avatar" src="'.$info['teacher_pic'].'">';
                ?>
                <?php echo'</div>                
            </div>
            <div class="col-md-2 col-sm-6 list_cruses_photo">
                <a href="'.get_the_permalink().'">'?>
                <?php 
                the_post_thumbnail( 'cousre-list' );
                ?>
                <?php echo'</a>
            </div>
        </div>
        </div>';
        }    
        if($settings['course_style'] == 'gird') {
            echo'<div class="single_curses_warp darkeble">
            <div class="single_curses_img"><div class="special_bookmark single_bookmark">'?>
                        <?php
                            if(!sigma_is_in_wishlist(''))
                            {
                                ?>
                                <a class="sigma-add-to-wishlist" data-product-id="<?php the_ID(); ?>"><i class="far fa-bookmark"></i></a>
                                <?php
                            }
                            else
                            {
                                ?>
                                <a href="<?php echo bloginfo('url'); ?>/wishlist" target="_blank" class="sigma-add-to-wishlist-added" data-product-id="<?php the_ID(); ?>"><span class="badge-tooltip-all">مشاهده علاقه مندی ها</span><i class="far fa-bookmark"></i></a>
                                <?php
                            }
                        ?>    
                <?php echo'</div><a href="'.get_the_permalink().'">'?>
                
                <?php 
                the_post_thumbnail( 'cousre' );    
                ?>
                
                <?php echo'</a>
            </div>
            <div class="single_curses_meta">
                <div class="hexagon_teacher_single_bg"></div>
                <div id="hexagon_teacher" class="hexagon_teacher_single">' ?>
                <?php
                    $id = get_the_ID();
                    $info = sigma_get_tutorial_info($id);    
                    echo'<img alt="avatar" title="avatar" src="'.$info['teacher_pic'].'">';
                ?>
                <?php echo'</div><h2><a href="'.get_the_permalink().'">'.get_the_title().'</a></h2>
                <small>'.( get_post_meta( get_the_ID(), 'en_title_sigma', true ) ).'</small>' ?>
                <?php
                echo'<div class="single_lists_quick single_quick_v2"><p><span>'?>
                <?php echo woocommerce_template_single_price(); ?>
                </p>
                </div>
            
                <div class="meta_qiuck_special_edc single_quick">
                    <ul>
                        <li>
                <?php
                $id = get_the_ID();
                $info = sigma_get_tutorial_info($id);        
                ?>                            
                            <p><?php 
                            if($info > 1 ) {
                            echo $info['product_time'];
                            }
                            else {
                                echo'-';
                            }
                            ?></p><span>طول دوره</span></li>
                        <li>
                            <?php echo'<p>'.get_comments_number().'</p><span>تعداد دیدگاه</span></li>
                        <li>
                            <p>'.( get_post_meta( get_the_ID(), 'total_sales', true ) ).'</p><span>تعداد دانشجو</span></li>
                    </ul>
                </div>
                <div class="edc_badges edc_badges_signle">
                    <ul>' ?>
                <?php
                $id = get_the_ID();
                $medals = sigma_get_product_medals($id);
                if(false != $medals)
                {
                    foreach ($medals as $medal)
                        {
                            ?>
                            <li id="hexagon" class="badge_singel pink_badge"><img src="<?php echo $medal['medal_pic'] ?>" alt="<?php echo $medal['medal_name'] ?>" title="<?php echo $medal['medal_name'] ?>"><span class="badge-tooltip"><?php echo $medal['medal_name'] ?></span></li>
                            <?php
                        }    
                }        
                ?>
                <?php echo'</ul>
                </div>
            </div>
            <div class="edc_button_single">
                <ul>
                    <li><a href="'.get_post_permalink().'?add-to-cart='.get_the_ID().'"><i class="far fa-shopping-bag"></i></a></li>
                    <li><a href="'.get_the_permalink().'"><i class="fal fa-ellipsis-h-alt"></i></a></li>
                </ul>
            </div>
        </div>';
        }        
	}
	
	public function render_query() {
		$settings = $this->get_settings();

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } 
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } 
		else { $paged = 1; }

        if($settings['sigma_orderby'] == 'total_sales'){
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'order'               => $settings['sigma_order'],
            'meta_key'            => 'total_sales',
            'orderby'             => 'meta_value_num',			
			'paged'               => $paged,
        );
        }
        elseif($settings['sigma_orderby'] == 'modified'){
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'order'               => $settings['sigma_order'],
			'paged'               => $paged,
			'orderby'  => 'modified',
        );            
        }    
        else {
		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $settings['sigma_posts_per_page'],
			'orderby'             => $settings['sigma_orderby'],
			'order'               => $settings['sigma_order'],
			'paged'               => $paged,
        );
        }
    
        
        if($settings['sigma_woo_product_select'] == 'category'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_cat',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_cat'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}

        if($settings['sigma_woo_product_select'] == 'tag'){
            $arg_tax =[
                'tax_query'      => [
                    [
                    'taxonomy'   => 'product_tag',
                    'field'        => 'term_id',
                    'terms'         => $settings['sigma_woo_tag'],
                    ],
                ]
            ];

            $args = array_merge($args, $arg_tax);
		}
		
        if($settings['sigma_woo_product_select'] == 'product' && !empty($settings['sigma_woo_product'])){
            $arg_product = [
				'post__in' => $settings['sigma_woo_product'],
			];
			$args = array_merge($args, $arg_product);
		}

		$wp_query = new \WP_Query($args);

		return $wp_query;
	}
	
	public function render_loop_item() {
		$settings = $this->get_settings();
		global $post;

        $wp_query = $this->render_query();

		if($wp_query->have_posts()) {

			$this->add_render_attribute('sigma-wc-products-wrapper', 'sigma-grid', '');
            if($settings['course_style'] == 'gird') {
			$this->add_render_attribute(
				[
					'sigma-wc-products-wrapper' => [
						'class' => [
							'sigma-wc-products-wrapper',
							'sigma-grid',
							'sigma-grid-medium',
							'woocommerce',
							'columns-' . $settings['sigma_columns'],
							'sigma-tablet-columns-'. $settings['sigma_columns_tablet'],
							'sigma-mobile-columns-'. $settings['sigma_columns_mobile'],
						],
					],
				]
			);
            }
			?>
			<div <?php echo $this->get_render_attribute_string( 'sigma-wc-products-wrapper' ); ?>>
			<?php			

			$this->add_render_attribute('sigma-wc-product', 'class', [
				'sigma-wc-product',
				]); 
				?>
				<ul class="courses_sigma_area">
					<?php $count = 1; while ( $wp_query->have_posts() ) : $wp_query->the_post(); 
                    
					if($settings['course_style'] == 'list' && !empty($settings['course_style'])){
					?>
						<li class="lists_cousrses_sigma">
							<div class="sigma-wc-courses-inner">

							<?php 
								$this->render_description();
							?>
							</div>
						
						</li>
					<?php
                    }
                    if($settings['course_style'] == 'gird') { ?>

						<li class="gird_cousrses_sigma">
							<div class="sigma-wc-courses-inner">
							<?php 
								$this->render_description();
							?>
							</div>
						</li>
						
                    <?php }
                    if($count % $settings['sigma_columns'] === 0) : ?>
							<div style="clear:both"></div>
						<?php endif; ?>
					<?php $count++; endwhile;	?>
				</ul>
			</div>
			<?php

			wp_reset_postdata();
			
		} else {
			echo '<div class="attr-alert-warning attr-alert no-products">' . esc_html__( 'Oops! No products were found.', 'sigma-theme' ) .'<div>';
		}
	}	
	
}
