<?php


namespace SigmaCore\SigmaTemplateBuilder;

class SigmaTemplateBuilder
{
    private static $instance = null;
    private $relatedPostId = null;
    private $relatedPost = null;
    private $hasCustomTemplate = false;
    private $isBuiltIn = true;
    private $customTemplateId = null;
    private $isElementorStyleNeeded = false;
    private $isElementorStyleLoaded = false;

    private function __construct()
    {
        $post_types = sigma_admin_page_get_included_post_types();
        foreach ($post_types as $post_type) {
            $filter_string = 'theme_' . $post_type . '_templates';
            add_filter($filter_string, function ($templates, $theme, $post, $post_type) {
                $search_value = serialize(array('template_type' => $post_type));
                $args = array(
                    'post_type' => 'sigma-template',
                    'meta_key' => 'sigma_template_type',
                    'meta_value' => $search_value,
                    'meta_compare' => '='
                );
                $template_query = new \WP_Query($args);
                $sigma_templates = $template_query->get_posts();
                if (is_array($sigma_templates)) {
                    foreach ($sigma_templates as $template) {
                        $templates['sigma-template-number-' . $template->ID] = $template->post_title;
                    }
                }
                return $templates;
            }, 100, 4);
        }
    }

    public static function GetInstance()
    {
        if (self::$instance == null) {
            self::$instance = new SigmaTemplateBuilder();
        }
        return self::$instance;
    }

    private function GetHeader()
    {

        ob_start();
        get_header();
        if ($this->isBuiltIn == false && !is_singular('ticket') && !\Elementor\Plugin::$instance->preview->is_preview_mode()) {
            if (metadata_exists('post', $this->relatedPostId, 'sigma_header_section')) {
                $header = get_post_meta($this->relatedPostId, 'sigma_header_section', true)['default_header'];
                switch ($header) {
                    case 'sigma_default_layout':
                        get_template_part('template-part/headers/head');
                        break;
                    case 'no_header':
                        break;
                    default:
                        $headerPost = get_post($header);
                        if ($headerPost != null && !wp_is_mobile()) {
                            ?>
                            <div class="sgm_header_element">
                                <?php
                                echo self::GetRawContentById($headerPost->ID);
                                ?>
                            </div>
                            <?php
                        }
                        break;
                }
            } else {
                get_template_part('template-part/headers/head');
            }
        }
        $content = ob_get_contents();
        ob_end_clean();
        echo $content;
    }

    private function GetFooter()
    {
        ob_start();
        if ($this->isBuiltIn == false && !is_singular('ticket') && !\Elementor\Plugin::$instance->preview->is_preview_mode()) {
            if (metadata_exists('post', $this->relatedPostId, 'sigma_footer_section')) {
                $footer = get_post_meta($this->relatedPostId, 'sigma_footer_section', true)['default_footer'];
                switch ($footer) {
                    case 'sigma_default_layout':
                        get_template_part('template-part/footers/footer');
                        break;
                    case 'no_footer':
                        break;
                    default:
                        $footerPost = get_post($footer);
                        if ($footerPost != null) {
                            ?>
                            <div class="footer-sgm-main">
                                <?php
                                echo self::GetRawContentById($footerPost->ID);
                                ?>
                            </div>
                            <?php
                        }
                }
            } else {
                get_template_part('template-part/footers/footer');
            }
        }
        get_footer();
        $content = ob_get_contents();
        ob_end_clean();
        echo $content;
    }

    public function RenderSingular()
    {
        if (have_posts()) {
            while (have_posts()) {
                the_post();
                $this->ProcessTemplate();
                $this->GetHeader();
            }
        }
        $this->GetContent();
        if (have_posts()) {
            while (have_posts()) {
                the_post();
                $this->GetFooter();
            }
        }
    }

    private function GetRawContentById($id)
    {
        $args = array(
            'p' => $id,
            'post_type' => 'any'
        );
        $post = new \WP_Query($args);
        ob_start();
        if ($post->have_posts()) {
            while ($post->have_posts()) {
                $post->the_post();
                the_content();
            }
        }
        $content = ob_get_contents();
        ob_end_clean();
        wp_reset_postdata();
        return $content;
    }

    private function GetContent()
    {
        ob_start();
        if ($this->isBuiltIn) {
            if (have_posts()) {
                ?>
                <div class="sigma-content">
                    <?php
                    while (have_posts()) {
                        the_post();
                        the_content();
                    }
                    ?>
                </div>
                <?php
            }
        } else {
            if ($this->hasCustomTemplate) {
                if (\Elementor\Plugin::$instance->db->is_built_with_elementor($this->customTemplateId)) {
                    ?>
                    <div class="sigma-content">
                        <?php
                        echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display($this->customTemplateId, true);
                        ?>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="sigma-content">
                        <?php
                        echo self::GetRawContentById($this->customTemplateId);
                        ?>

                    </div>
                    <?php
                }
            } else {
                if (is_shop()) {
                    wc_get_template( 'archive-product.php' );
                } else if (is_product_category()) {
                    wc_get_template( 'archive-product.php' );
                } else if (is_singular('product')) {
                    global $sigma;

                    $id = get_the_ID();

                    if (sigma_get_product_type($id) == "c") {
                        get_template_part('template-part/content/product/signle-product-style03/single');
                    }
                    if (sigma_get_product_type($id) == "a") {
                        get_template_part('template-part/content/product/signle-product-style02/single');
                    }
                    if (sigma_get_product_type($id) == "b") {
                        get_template_part('template-part/content/product/signle-product-style01/single');
                    }
                    if (sigma_get_product_type($id) == "e") {
                        get_template_part('template-part/content/product/signle-product-style04/single');
                    }
                    if (sigma_get_product_type($id) == "d") {
                        global $sigma;
                        get_template_part($sigma['products_style_page']);
                    } else {
                    }
                } else if (is_singular('ticket')) {
                    global $sigma;
                    get_template_part($sigma['user_panel_style_index']);
                } else if (is_singular('page') && !is_checkout() && !is_cart()) {
                    get_template_part('template-part/page-elementor');
                } else if (is_page( 'cart' ) || is_page( 'checkout' ) ) {
                     get_template_part('template-part/page-template');
                } 
                else {
                    get_template_part('template-part/content/single/post');
                }
            }
        }
        $content = ob_get_contents();
        ob_end_clean();
        echo $content;
    }

    private function ProcessTemplate()
    {
        $post_type = get_post_type();
        $this->relatedPostId = get_the_ID();
        $this->relatedPost = get_post();
        if (\Elementor\Plugin::$instance->db->is_built_with_elementor($this->relatedPostId)) {
            $this->isElementorStyleLoaded = true;
            $this->isElementorStyleNeeded = true;
        }
        switch ($post_type) {
            case 'sigma-header':
            case 'sigma-footer':
            case 'sigma-megamenu':
            case 'sigma-template':
                $this->isBuiltIn = true;
                break;
            default:
                $this->isBuiltIn = false;
                break;
        }
        if ($this->isBuiltIn == false) {
            $slug = get_page_template_slug($this->relatedPostId);
            if (strpos($slug, 'sigma-template-number') !== false) {
                $this->hasCustomTemplate = true;
                $this->isElementorStyleNeeded = true;
                $exploded = explode('-', $slug);
                $id = end($exploded);
                $this->customTemplateId = $id;
            } else {
                $this->hasCustomTemplate = false;
            }
        }
    }

    public function GetRelatedPostId()
    {
        if ($this->relatedPostId == null) {
            return false;
        } else {
            return $this->relatedPostId;
        }
    }

    public function GetRelatedRawPost()
    {
        if ($this->relatedPostId == null) {
            return false;
        } else {
            return $this->relatedPost;
        }
    }

    public function HasCustomTemplate()
    {
        return $this->hasCustomTemplate;
    }

    public function GetRelatedPostField($field)
    {
        $result = null;
        if ($this->IsRealRender()) {
            if (isset($this->relatedPost->$field)) {
                switch ($field) {
                    case 'post_content':
                        $result = $this->GetRawContentById($this->relatedPostId);
                        break;
                    case 'post_author':
                        $result = apply_filters('the_author', get_the_author_meta('display_name', $this->relatedPost->$field));
                        break;
                    default:
                        $result = $this->relatedPost->$field;
                        break;
                }
                return apply_filters('sigma_post_field', $result, $field, $this->relatedPostId);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function IsRealRender()
    {
        if ($this->hasCustomTemplate && \Elementor\Plugin::$instance->editor->is_edit_mode() == false) {
            return true;
        } else {
            return false;
        }
    }

    public function WpFooter()
    {
        if ($this->isElementorStyleNeeded && !$this->isElementorStyleLoaded) {
            \Elementor\Plugin::$instance->frontend->enqueue_styles();
            \Elementor\Plugin::$instance->frontend->enqueue_scripts();
            \Elementor\Plugin::$instance->frontend->print_fonts_links();
        }
    }
}

\SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance();
add_action('wp_footer', array(\SigmaCore\SigmaTemplateBuilder\SigmaTemplateBuilder::GetInstance(), 'WpFooter'));